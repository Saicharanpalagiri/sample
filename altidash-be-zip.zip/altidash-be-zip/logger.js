/* (c) 2022 Autoven Private Limited. All rights reserved. */

const Loggly =require('winston-loggly-bulk').Loggly;
const winston=require('winston')

const { createLogger, format, transports } = require('winston');
const { combine, timestamp,json} = format;

const myFormat = format.printf(({ level, message, label, url,timestamp }) => {
    return `${timestamp} ${level}: ${message}`;
  });


const level=process.env.NODE_LOGGING_LEVEL||'info';


const logger = winston.createLogger({
   format: combine( timestamp(),format.errors(),json()),
    // defaultMeta:{service:'user-service'},
    level,
    transports: [
        new Loggly(
            {
            "token":process.env.LOGGER_TOKEN || "6e6fddeb-4026-40b6-9373-2c71f8737311",
            "subdomain":process.env.LOGGER_SUBDOMAIN || "altigreenlogs",
            "tags":["NodeJS"]
        }
        ),
        //new winston.transports.Console({}),
        new winston.transports.File({filename:'./generated/logs/error.log',level:"error"}),
        new winston.transports.File({filename:'./generated/logs/warn.log',level:"warn"}),
        //new winston.transports.File({filename:'./generated/logs/com.log'})

    ]
})

logger.stream = {
    write: (info,error)=>{
        logger.info(info)
    }
}

module.exports=logger