

const hexToVdmFault = 
{
    "1": {
     "Fault": "VDM_SIM_DETECTION_FAULT",
     "Description": "Sim not Present"
    },
   "2": {
     "Fault": "VDM_GPRS_ATTACH_FAULT",
     "Description": "GPRS not activated"
   },
   "4": {
     "Fault": "VDM_GPRS_NETWORK_FAULT",
     "Description": ""
   },
   "8": {
     "Fault": "VDM_SERVER_ACTIVE_FAULT",
     "Description": "Server not active"
   },
   "10": {
     "Fault": "VDM_GSM_RX_FAULT",
     "Description": "GSM module not responding"
   },
   "20": {
     "Fault": "VDM_GPS_RX_FAULT",
     "Description": "GPS module Not responding"
   },
   "40": {
     "Fault": "VDM_CAN_RX_FAULT",
     "Description": "VCU - VDM CAN communication problem"
   },
   "80": {
     "Fault": "VDM_SERVER_DETACTH_FAULT",
     "Description": ""
   },
   "100": {
     "Fault": "VDM_GSM_SIGNAL_FAULT",
     "Description": "GSM module week signal strength"
   },
   "200": {
     "Fault": "VDM_RTC_FAULT",
     "Description": "RTC Init error"
   },
   "400": {
     "Fault": "VDM_GSM_RSP_FAULT",
     "Description": "GPS module Not responding"
   },
   "800": {
     "Fault": "VDM_CALIB_FAULT",
     "Description": "No calibration programmed"
   },
   "1000": {
     "Fault": "VDM_FLASH_INIT_FAULT",
     "Description": "S-flash Init error"
   },
   "2000": {
     "Fault": "VDM_FLASH_READ_FAULT",
     "Description": "Problem in reading the s-flash"
   },
   "4000": {
     "Fault": "VDM_48V_TOPUP_STATUS",
     "Description": "TopUp status"
   },
   "8000": {
     "Fault": "VDM_WAKE_OR_ALIVE_STATUS",
     "Description": "Alive/Wake status"
   }
}

const hexToFaultCodeTwo = 
{
    "1": {
        "Fault": "OVER_SPEED_FAULT",
        "Description": "OVER SPEED FAULT"
    },
    "2": {
        "Fault": "THROTTLE_FAULT",
        "Description": "THROTTLE FAULT"
    },
    "4": {
        "Fault": "DC_BUS_FAULT",
        "Description": "DC BUS FAULT"
    },
    "8": {
        "Fault": "INPUT_VOLTAGE_FAULT",
        "Description": "INPUT VOLTAGE FAULT"
    },
    "10": {
        "Fault": "OVER_LOAD_FAULT",
        "Description": "OVER LOAD FAULT"
    },
    "20": {
        "Fault": "BATTERY_PACK_WARNING",
        "Description": "BATTERY PACK WARNING"
    },
    "40": {
        "Fault": "RNFB_FAULT",
        "Description": "RNFB FAULT"
    },
    "80": {
        "Fault": "CALIBRATION_FAULT",
        "Description": "CALIBRATION FAULT"
    },
    "100": {
        "Fault": "VEHICLE_DISABLE",
        "Description": "VEHICLE DISABLE"
    },
    "200": {
        "Fault": "SPEED_PHASE_FAULT",
        "Description": "SPEED PHASE FAULT"
    }
}


const DtcStatusOne = {
  1: {
    Fault: "Discharge_Limit_Enforcement_Fault",
    Description: "Discharge Limit Enforcement Fault",
  },
  2: {
    Fault: "Charger_Safety_Relay_Fault",
    Description: "Charger Safety Relay Fault",
  },
  4: {
    Fault: "Internal_Hardware_Fault",
    Description: "Internal_Hardware_Fault",
  },
  8: {
    Fault: "Internal_Heatsink_Thermistor_Fault",
    Description: "Internal Heatsink Thermistor Fault",
  },
  10: {
    Fault: "Internal_Software_Fault",
    Description: "Internal Software Fault",
  },
  20: {
    Fault: "Highest_Cell_Voltage_Too_High_Fault",
    Description: "Highest Cell Voltage Too High Fault",
  },
  40: {
    Fault: "Lowest_Cell_Voltage_Too_Low_Fault",
    Description: "Lowest Cell Voltage Too Low Fault",
  },
  80: {
    Fault: "Pack_Too_Hot_Fault",
    Description: "Pack Too Hot Fault",
  },
};

const DtcStatusTwo = {
  1: {
    Fault: "Internal_Communication_Fault",
    Description: "Internal Communication Fault",
  },
  2: {
    Fault: "Cell_Balancing_Stuck_Off_Fault",
    Description: "Cell Balancing Stuck Off Fault",
  },
  4: {
    Fault: "Weak_Cell_Fault",
    Description: "Weak Cell Fault",
  },
  8: {
    Fault: "Low_Cell_Voltage_Fault",
    Description: "Low Cell Voltage Fault",
  },
  10: {
    Fault: "Open_Wiring_Fault",
    Description: "Open Wiring Fault",
  },
  20: {
    Fault: "Current_Sensor_Fault",
    Description: "Current Sensor Fault",
  },
  40: {
    Fault: "Highest_Cell_Voltage_Over_5V_Fault",
    Description: "Highest Cell Voltage Over 5V Fault",
  },
  80: {
    Fault: "Cell_ASIC_Fault",
    Description: "Cell ASIC Fault",
  },
  100: {
    Fault: "Weak_Pack_Fault",
    Description: "Weak Pack Fault",
  },
  200: {
    Fault: "Fan_Monitor_Fault",
    Description: "Fan Monitor Fault",
  },
  400: {
    Fault: "Thermistor_Fault",
    Description: "Thermistor Fault",
  },
  800: {
    Fault: "External_Communication_Fault",
    Description: "External Communication Fault",
  },
  1000: {
    Fault: "Redundant_Power_Supply_Fault",
    Description: "Redundant Power Supply Fault",
  },
  2000: {
    Fault: "High_Voltage_Isolation_Fault",
    Description: "High Voltage Isolation Fault",
  },
  4000: {
    Fault: "Input_Power_Supply_Fault",
    Description: "Input Power Supply Fault",
  },
  8000: {
    Fault: "Charge_Limit_Enforcement_Fault",
    Description: "Charge Limit Enforcement Fault",
  },
};

 
/**
 * 
 * @param {*} faultValue 
 * @returns Convers faultValue into array of fault
 */
  const hexToVdmFaultArray = (faultValue) => {
    //console.log("c46",faultValue)
    const sortedFaultCodes = Object.keys(hexToVdmFault).sort((a, b) => b - a);
    const faults = [];
  
    const findFaults = (value) => {
      if (value === 0) {
        return;
      }
  
      for (let i = 0; i < sortedFaultCodes.length; i++) {
        const faultCode = parseInt(sortedFaultCodes[i]);
  
        if (value >= faultCode) {
          faults.push(faultCode);
          findFaults(value - faultCode);
          break;
        }
      }
    };
  
    findFaults((Number(faultValue)).toString(16));
    // return faults
    return faults.map((faultCode) => hexToVdmFault[faultCode].Fault);
  };

  const hexToFaultCodeTwoArray = (faultValue) => {
    // console.log("c31",faultValue)
    const sortedFaultCodes = Object.keys(hexToFaultCodeTwo).sort((a, b) => b - a);
    const faults = [];
  
    const findFaults = (value) => {
      if (value === 0) {
        return;
      }
  
      for (let i = 0; i < sortedFaultCodes.length; i++) {
        const faultCode = parseInt(sortedFaultCodes[i]);
  
        if (value >= faultCode) {
          faults.push(faultCode);
          findFaults(value - faultCode);
          break;
        }
      }
    };
  
    findFaults((Number(faultValue)).toString(16));
    // return faults
    return faults.map((faultCode) => hexToFaultCodeTwo[faultCode].Fault);
  };
  

  const DtcStatusOneArray = (faultValue) => {
    const sortedFaultCodes = Object.keys(DtcStatusOne).sort((a, b) => b - a);
    const faults = [];
  
    const findFaults = (value) => {
      if (value === 0) {
        return;
      }
  
      for (let i = 0; i < sortedFaultCodes.length; i++) {
        const faultCode = parseInt(sortedFaultCodes[i]);
  
        if (value >= faultCode) {
          if(faults.indexOf(faultCode)==-1){
            faults.push(faultCode);
          }
          findFaults(value - faultCode);
          break;
        }
      }
    };
  
    findFaults((Number(faultValue)).toString(16));
    
    //console.log(faults,'faults')
    // return faults
    return faults.map((faultCode) => DtcStatusOne[faultCode].Fault);
  };



  const DtcStatusTwoArray = (faultValue) => {
    const sortedFaultCodes = Object.keys(DtcStatusTwo).sort((a, b) => b - a);
    const faults = [];
    const findFaults = (value) => {
      if (value === 0) {
        return;
      }
  
      for (let i = 0; i < sortedFaultCodes.length; i++) {
        const faultCode = parseInt(sortedFaultCodes[i]);
        if (parseInt(value) >= faultCode) {
         if(faults.indexOf(faultCode)==-1){
            faults.push(faultCode);
          }
          findFaults(parseInt(value) - faultCode);
          break;
        }
      }
    };
  
    findFaults((Number(faultValue)));
    return faults.map((faultCode) => DtcStatusTwo[faultCode.toString()].Fault);
  };
  

  const vehicleDataToHexObject = (totalVehicleData) => {

    console.log(totalVehicleData[0].topic)
    let faultArray = []
    const allFaultCountObject = {}
    // VehicleData contains mqtt objects from desired range
    for(const vehicleData of totalVehicleData){
        const faultValue = vehicleData["C46"] || 0
        if(!faultValue) continue;
        faultArray = [...faultArray,...hexToFaultArray(faultValue)]
    }
    // Once the array containing all the instances of fault are created we can create a final Object containing all the faults and theor count
    for( const key of Object.keys(hexToVdmFault).sort((a, b) => a - b)){
        // Nowe find the value for each key and push ito object
        allFaultCountObject[`${hexToVdmFault[key]["Fault"]}`] = faultArray.filter((v) => Number(v) === Number(key)).length 
    }
    console.log(allFaultCountObject)
   return allFaultCountObject

  }

  // console.log(hexToVdmFaultArray(4983))

  // console.log(hexToFaultCodeTwoArray(4983))
                                         
  
module.exports = {
  vehicleDataToHexObject,
  hexToVdmFaultArray,
  hexToFaultCodeTwoArray,
  DtcStatusOne,
  DtcStatusTwo,
  DtcStatusOneArray,
  DtcStatusTwoArray
}
