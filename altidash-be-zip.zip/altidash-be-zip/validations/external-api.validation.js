const Joi = require('joi');
// const { password } = require('./custom.validation');

const getExponent = {
  body: Joi.object().keys({
    username: Joi.string().required(),
    
    authkey: Joi.string().required(),
    
    vehicle_ids: Joi.string().allow(''),
  }),
};
const getcccVehicleStatus = {
  body: Joi.object().keys({
    username: Joi.string().required(),
    
    authkey: Joi.string().required(),
    
    vehicle_id: Joi.string().allow(''),
  }),
};

const remoteLock = {
  body: Joi.object().keys({
    username: Joi.string().required(),
    
    authkey: Joi.string().required(),
    
    vehicle_id: Joi.string().allow(''),
    request_for : Joi.string().allow('')
  }),
};

const getVehicleInfoWithDate = {
  body: Joi.object().keys({
    username: Joi.string().required(), 
    authkey: Joi.string().required(),    
    vehicle_ids: Joi.string().allow(''),
    date: Joi.string().required()
  }),
};

const getVehicleInfoWithTime = {
  body: Joi.object().keys({
    username: Joi.string().required(), 
    authkey: Joi.string().required(),    
    vehicle_ids: Joi.string().allow(''),
    start_time: Joi.string().required(),
    end_time: Joi.string().required()
  }),
};

const getVehicleStatus = {
  body: Joi.object().keys({
    username: Joi.string().required(),
    
    authkey: Joi.string().required(),
    
    vehicle_ids: Joi.string().required(),
  }),
};

const getDayCumulativeVehicleInfo = {
  body: Joi.object().keys({
    username: Joi.string().required(),
    authkey: Joi.string().required(),
    vehicle_ids: Joi.string().allow(''),
    date: Joi.string().required()
  }),
};

const getDayCumulativeVehicleOdoInfo = {
  body: Joi.object().keys({
    username: Joi.string().required(),
    authkey: Joi.string().required(),
    vehicle_ids: Joi.string().allow(''),
    start_date: Joi.string().required(),
    end_date: Joi.string().required()
  }),
};

const addVehicle = {
  body:  Joi.object().keys({
    username: Joi.string().required(),
    authkey: Joi.string().required(),
"VehicleRegNo":Joi.string().required(),
"vDisplayName":Joi.string().required().allow(""),
"Kit_ID":Joi.string().required(),
"VIN":Joi.string().required(),
"chassisSrNo":Joi.string().alphanum().required().allow(""),
"motorSrNo":Joi.string().alphanum().required().allow(""),
"gearBoxSrNo":Joi.string().alphanum().required().allow(""),
"batterySrNo":Joi.string().required().allow(""),
"distributionSrNo":Joi.string().alphanum().required().allow(""),
"dc_dcSrNo":Joi.string().alphanum().required().allow(""),
"displayConsoleSrNo":Joi.string().alphanum().required().allow(""),
"displaySoftwareVr":Joi.string().alphanum().required().allow(""),
"controllerSoftwareVr":Joi.string().alphanum().required().allow(""),
"model":Joi.string().required().allow(""),
"bModel":Joi.string().alphanum().required().allow(""),
"bCapacity":Joi.string().alphanum().required().allow(""),
"SIMservicePrName":Joi.string().alphanum().required().allow(""),
"SIMsrNo":Joi.string().alphanum().required().allow(""),
"mobNo":Joi.string().alphanum().required().allow(""),
"contactName":Joi.string().alphanum().required().allow(""),
"contactNo":Joi.string().alphanum().required().allow(""),
"drivingLicenseNo":Joi.string().alphanum().required().allow(""),
"drivingLicenseVal":Joi.string().required().allow(""),
vehicleColor: Joi.string().required().allow(""),
chargerSrNo: Joi.string().alphanum().required().allow(""),
"fleets": Joi.array().min(1).required()
})    
}

const updateVehicle = {
  body:  Joi.object().keys({
    username: Joi.string().required(),
    authkey: Joi.string().required(),
    "VehicleRegNo": Joi.string().required(),
    "vDisplayName": Joi.string().required(),
    "Kit_ID": Joi.string().required(),
    "VIN": Joi.string().required(),
    "chassisSrNo":Joi.string().alphanum().required().allow(""),
"motorSrNo":Joi.string().alphanum().required().allow(""),
"gearBoxSrNo":Joi.string().alphanum().required().allow(""),
"batterySrNo":Joi.string().required().allow(""),
"distributionSrNo":Joi.string().alphanum().required().allow(""),
"dc_dcSrNo":Joi.string().alphanum().required().allow(""),
"displayConsoleSrNo":Joi.string().alphanum().required().allow(""),
"displaySoftwareVr":Joi.string().alphanum().required().allow(""),
"controllerSoftwareVr":Joi.string().alphanum().required().allow(""),
"model":Joi.string().required().allow(""),
"bModel":Joi.string().alphanum().required().allow(""),
"bCapacity":Joi.string().alphanum().required().allow(""),
"SIMservicePrName":Joi.string().alphanum().required().allow(""),
"SIMsrNo":Joi.string().alphanum().required().allow(""),
"mobNo":Joi.string().alphanum().required().allow(""),
"contactName":Joi.string().alphanum().required().allow(""),
"contactNo":Joi.string().alphanum().required().allow(""),
"drivingLicenseNo":Joi.string().alphanum().required().allow(""),
"drivingLicenseVal":Joi.string().required().allow(""),
vehicleColor: Joi.string().required().allow(""),
chargerSrNo: Joi.string().alphanum().required().allow(""),
    "fleets": Joi.array().min(1).required(),
    "prevFleets": Joi.array().required()
  })
}

const addFleet = {
    body: Joi.object().keys({
      username: Joi.string().required(),
      authkey: Joi.string().required(),
        "clientCode": Joi.string().required(),
        "ClientFullName": Joi.string().required(),//nn
        "address": Joi.string().required(), //nn
        "city":Joi.string().required(), //nn
        "pincode": Joi.number().required().min(1), //nn
        "state": Joi.string().required(), //nn
        "country":Joi.string().required(), //nn
        "addressContact": Joi.string().required().allow(""),
        "emailContact": Joi.string().required().allow(""),
        "telephoneContact": Joi.string().required().allow(""),
        "enteredApis": Joi.array().required(),
        "enablePushApis": Joi.number().valid(0).required(),
        "enteredPushApis": Joi.string().allow(""),
        "duration": Joi.string().allow(""),
        "apiKey": Joi.string().allow(""),
        "endPoint": Joi.string().allow(""),
        "paramOne": Joi.string().allow(""),
        "paramTwo": Joi.string().allow(""),
        "paramThree": Joi.string().allow("")
      })
}

const updateFleet = {
  body: Joi.object().keys({
    username: Joi.string().required(),
    authkey: Joi.string().required(),
      "clientCode": Joi.string().required(),
      "ClientFullName": Joi.string().required(),//nn
      "address": Joi.string().required(), //nn
      "city":Joi.string().required(), //nn
      "pincode": Joi.number().required().min(1), //nn
      "state": Joi.string().required(), //nn
      "country":Joi.string().required(), //nn
      "addressContact": Joi.string().required().allow(""),
      "emailContact": Joi.string().required().allow(""),
      "telephoneContact": Joi.string().required().allow(""),
      "enteredApis": Joi.array().required(),
      "enablePushApis": Joi.number().valid(0).required(),
      "enteredPushApis": Joi.string().allow(""),
      "duration": Joi.string().allow(""),
      "apiKey": Joi.string().allow(""),
      "endPoint": Joi.string().allow(""),
      "paramOne": Joi.string().allow(""),
      "paramTwo": Joi.string().allow(""),
      "paramThree": Joi.string().allow(""),
      "prevCustApis": Joi.array(),
      "prevPushApis": Joi.array(),

    })
    
}
const downloadLogs = {
  body: Joi.object().keys({
    username: Joi.string().required(),
    authkey: Joi.string().required(),
    vehicle_ids: Joi.string(),
    date : Joi.string().allow(''),
    logType : Joi.number().required().valid(1,2),
    dataType : Joi.number().required().valid(1,2),
    logCount : Joi.number()
  }),
};

const serviceData = {
  body: Joi.object().keys({
    vehicle_ids: Joi.string().required(),
  }),
};


const VehicleInfo30Days={
  body: Joi.object().keys({
    username:Joi.string().required(),
    authkey:Joi.string().required(),
    vin: Joi.string().required(), 
    startDate: Joi.string().allow('').regex(/^[0-9+]{4}-[0-9+]{2}-[0-9+]{2}$/).required(), 
    endDate: Joi.string().allow('').regex(/^[0-9+]{4}-[0-9+]{2}-[0-9+]{2}$/).required(),
  }),
}

const changeRegBody={
  body: Joi.object().keys({
    username:Joi.string().required(),
    authkey:Joi.string().required(),
    vin: Joi.string().regex(/^[a-zA-Z0-9/]+$/).required(), 
    oldReg:Joi.string().alphanum().required(),
    newReg:Joi.string().alphanum().required(),
    user:Joi.string().required()
     }),
}


const chartData={
  body: Joi.object().keys({
    username:Joi.string().required(),
    authkey:Joi.string().required(),
    vin: Joi.string().regex(/^[a-zA-Z0-9/]+$/).required(), 
    from:Joi.string().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}$/).required(),
    to:Joi.string().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}$/).required()
     }),
}

const authbody={
  body: Joi.object().keys({
    username:Joi.string().required(),
    authkey:Joi.string().required(),

     }),
}

// const getVehicleBMSInfo={
//   body: Joi.object().keys({
//     username:Joi.string().required(),
//     authkey:Joi.string().required(),
//     date:Joi.string().regex(/^[0-9+]{4}-[0-9+]{2}-[0-9+]{2}$/).required(),
//     startTime:Joi.string().pattern(/^$|^(?:[01]\d|2[0-3]):[0-5]\d$/).required(),
//     endTime:Joi.string().pattern(/^$|^(?:[01]\d|2[0-3]):[0-5]\d$/).required(),
//     vehicle_ids:Joi.string().required()
//      }),
// }

const getVehicleBMSInfo = {
  body: Joi.object().keys({
    username: Joi.string().required().messages({
      'string.base': 'Username should be a string',
      'string.empty': 'Username is required',
    }),
    authkey: Joi.string().required().messages({
      'string.base': 'Authkey should be a string',
      'string.empty': 'Authkey is required',
    }),
    date: Joi.string()
      .regex(/^[0-9+]{4}-[0-9+]{2}-[0-9+]{2}$/)
      .required()
      .messages({
        'string.pattern.base': 'Date should be in the format YYYY-MM-DD',
        'string.empty': 'Date is required',
      }),
    startTime: Joi.string()
      .pattern(/^$|^(?:[01]\d|2[0-3]):[0-5]\d$/)
      .required()
      .messages({
        'string.pattern.base': 'Start time should be in HH:mm format',
        'string.empty': 'Start time is required',
      }),
    endTime: Joi.string()
      .pattern(/^$|^(?:[01]\d|2[0-3]):[0-5]\d$/)
      .required()
      .messages({
        'string.pattern.base': 'End time should be in HH:mm format',
        'string.empty': 'End time is required',
      }),
    vehicle_ids: Joi.string().required().messages({
      'string.base': 'Vehicle IDs should be a string',
      'string.empty': 'Vehicle IDs are required',
    }),
  }),
};


const vehicleDetailSchema = Joi.object({
  vehicleNo: Joi.string().required(),
  isOnline: Joi.string().valid('0', '1').required(),
  lastUpdated: Joi.string().required(),
  latitude: Joi.number().required(),
  longitude: Joi.number().required(),
  ignition: Joi.string().valid('0', '1').required(),
  speed: Joi.number().required(),
  odometer: Joi.number().required(),
  direction: Joi.string().allow(''),
  temperature: Joi.string().allow(''),
  driverName: Joi.string().allow(''),
});

const vendorDetailSchema = {
  body: Joi.object().keys({
    username:Joi.string().required(),
    authkey:Joi.string().required(),
    gpsProviderToken:Joi.string().allow(''),
    vendorVehicleDetails:Joi.array().items({
      vendorCode: Joi.string().required(),
      vendorName: Joi.string().required(),
      vehicleDetails: Joi.array().items(vehicleDetailSchema).required(),
    }),
    customParams:Joi.string().allow('')
     }),

  // vendorCode: Joi.string().required(),
  // vendorName: Joi.string().required(),
  // vehicleDetails: Joi.array().items(vehicleDetailSchema).required(),
};

module.exports = {
  getExponent,
  addVehicle,
  addFleet,
  updateFleet,
  updateVehicle,
  getDayCumulativeVehicleInfo,
  getVehicleStatus,
  getVehicleInfoWithDate,
  getVehicleInfoWithTime,
  getcccVehicleStatus,
  remoteLock,
  downloadLogs,
  serviceData,
  VehicleInfo30Days,
  changeRegBody,
  chartData,
  authbody,
  vendorDetailSchema,
  getVehicleBMSInfo,
  getDayCumulativeVehicleOdoInfo
};
