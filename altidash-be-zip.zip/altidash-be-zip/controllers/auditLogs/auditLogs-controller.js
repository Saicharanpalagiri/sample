const { getCurrentTime } = require("../../utils/constants");
const AltidashLogs = require("../../models/altidashLogs");
const mongoose = require("mongoose");

const url =
  "mongodb+srv://alti-admin-prod:APL2023ADMIN@mqtt-production.iqeii.mongodb.net/mqttDatabase_aplmq";

connection = (url) => {
  mongoose.connect(url, { useNewUrlParser: true });
};

const addLogs = async (req, res) => {
  await connection(url);

  try {
    const { email, action, description } = req.body;

    await AltidashLogs.create({
      email,
      action,
      description,
      timeStamp: getCurrentTime(),
      ip: req.ip,
    });

    return res.json({
      status: true,
    });
  } catch (error) {
    console.log(error, "err");
    return res.json({
      status: false,
      code: 500,
      values: "Internal Server Error",
    });
  }
};

const getLogs = async (req, res) => {
  await connection(url);

  try {
    let result = await AltidashLogs.aggregate([
      {
        $project: {
          _id: 0,
         email: 1,
         action: 1,
         description: 1,
         timeStamp: 1,
         ip: 1 
        }
      },
      {
        $sort: {
          timeStamp: -1
        }
      }
    ]);

    return res.json({
      status: true,
      data: result,
    });
  } catch (error) {
    console.log(error, "err");
    return res.json({
      status: false,
      code: 500,
      values: "Internal Server Error",
    });
  }
};

module.exports = { addLogs, getLogs };
