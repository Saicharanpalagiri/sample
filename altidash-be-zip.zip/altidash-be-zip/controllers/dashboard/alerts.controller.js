const dealerDetails = require("../../models/dealerDetails");
const dealerMonthly = require("../../models/dealerMonthly");
const VehicleDailyData = require("../../models/vehicleDailyData");
// const ApiError = require('../utils/ApiError');
const moment = require("moment");
const mongoose = require("mongoose");
const { aplToVDD } = require("../../utils/vehicleDailyDataMapping");
const sequelize = require("../../utils/sqldb");
const Vehicle = require("../../models/vehicle");
const { Sequelize, Op } = require("sequelize");
const Client = require("../../models/client");
const ClientVehicle = require("../../models/client-vehicle");
const VehicleSaleStatment = require("../../models/VehicleSaleStatement");
const { errorMonitor } = require("form-data");

connection = (url) => {
  mongoose.connect(url, { useNewUrlParser: true });
};

const url =
  "mongodb+srv://alti-admin-prod:APL2023ADMIN@mqtt-production.iqeii.mongodb.net/mqttDatabase_aplmq";

const alertController = async (req, res) => {
  Client.belongsToMany(Vehicle, { through: ClientVehicle, foreignKey: "cid" });
  Vehicle.belongsToMany(Client, { through: ClientVehicle, foreignKey: "vid" });

  try {
    let { date } = req.body;
    await connection(url);

    await sequelize.sync();

    date = moment(date).format("YYYY-MM-DD");

    let vehiclesList = await Vehicle.findAll({
      attributes: ["VIN", "VehicleRegNo"],
      where: {
        deleteVehicleStatus: 0,
        [Op.or]: [
          { VIN: { [Op.like]: "mq/MD9%" } },
          { VIN: { [Op.like]: "mq/P6R%" } },
        ],
      },
      nest: true,
      include: [
        {
          model: Client,
          attributes: ["clientCode"],
          through: { attributes: [] },
        },
      ],
    });

    let data = await VehicleDailyData.aggregate([
      {
        $match: {
          date: date,
          x12: { $gt: 1 },
          topic: {
            $in: vehiclesList.map((item) => item.dataValues.VIN),
          },
        },
      },
    ]);

    let alertObject = {};
    let bmsFaultObject = { "BMS Balance fault": [], "BMS VTG Fault": [] };
    let set = new Set();
    for (const item of data) {
      // console.log(item)
      if (item.hasOwnProperty("x57") && item["x57"].length > 0) {
        item["x57"].map((alert) => {
          if (
            alertObject.hasOwnProperty(alert["Alert"]) &&
            alert["Frequency"] > 10
          ) {
            let alertObj = {};
            alertObj["vin"] = alert["topic"].slice(3);
            alertObj = { ...alertObj, ...alert };
            delete alertObj["topic"];
            alertObject[alert["Alert"]].push(alertObj);
            set.add(item.topic);
          } else if (alert["Frequency"] > 10) {
            let alertObj = {};
            alertObj["vin"] = alert["topic"].slice(3);
            alertObj = { ...alertObj, ...alert };
            delete alertObj["topic"];
            alertObject[alert["Alert"]] = [alertObj];
            set.add(item.topic);
          }
        });

        if (item["x116"] > 10)
          bmsFaultObject["BMS Balance fault"].push({
            vin: item.topic.slice(3),
            "Reg No": item.x1,
            Frequency: item["x116"],
          });

        if (item["x117"] > 10)
          bmsFaultObject["BMS VTG Fault"].push({
            vin: item.topic.slice(3),
            "Reg No": item.x1,
            Frequency: item["x117"],
          });

        // set.add(item.topic)
        // console.log(set)
      }
    }
    const vins = [];
    set.forEach((i) => vins.push(i));

    alertObject = { ...alertObject, ...bmsFaultObject };
    // console.log(vins,'end')
    return res.json({
      status: true,
      code: 200,
      message: "success",
      // vins:vins,
      data: alertObject,
      length: vins.length,
    });
    // return res.json({
  } catch (error) {
    console.log(error);
    return res.json({
      status: false,
      code: 500,
      message: error.message,
    });
  }
};

const alertControllerByVin = async (req, res) => {
  try {
    await connection(url);
    let { startDate, endDate, vin } = req.body;
    startDate = moment(startDate).format("YYYY-MM-DD");
    endDate = moment(endDate).format("YYYY-MM-DD");
    //        vin=vin.startsWith('mq/')?vin:'mq/'+vin
    vin = "mq/" + vin;
    let queryData = await VehicleDailyData.aggregate([
      {
        $match: {
          date: {
            $gte: startDate,
            $lte: endDate,
          },
          topic: vin,
          x12: { $gt: 0 },
        },
      },
      {
        $sort: {
          date: -1,
        },
      },
    ]);
    let resultData = [];
    for (const data of queryData) {
      if (data.hasOwnProperty("x57") && data["x57"].length > 0) {
        data["x57"].map((alert) => {
          if (alert["Frequency"] > 20) {
            resultData.push({
              date: data["date"],
              topic: alert.topic.slice(3),
              Severity: alert["Severity"],
              Alert: alert["Alert"],
              Frequency: alert["Frequency"],
              // ...alert,
            });
          }
        });
      }
    }
    return res.json({
      status: true,
      code: 200,
      data: resultData,
    });
  } catch (error) {
    console.log(error);
    return res.json({
      status: false,
      code: 500,
      message: error,
    });
  }
};

const alertControllerByVinCard = async (req, res) => {
  try {
    await connection(url);
    let { startDate, endDate, vin } = req.body;
    startDate = moment(startDate).format("YYYY-MM-DD");
    endDate = moment(endDate).format("YYYY-MM-DD");
    vin = vin.startsWith("mq/") ? vin : "mq/" + vin;
    let queryData = await VehicleDailyData.aggregate([
      {
        $match: {
          date: {
            $gte: startDate,
            $lte: endDate,
          },
          topic: vin,
          x12: { $gt: 0 },
        },
      },
      {
        $sort: {
          date: -1,
        },
      },
    ]);
    let resultData = {};
    resultData["Total critical Events"] = [];
    for (const data of queryData) {
      if (data.hasOwnProperty("x57") && data["x57"].length > 0) {
        data["x57"].map((alert) => {
          //if(alert['Frequency']>20){
          if (resultData.hasOwnProperty(alert["Alert"])) {
            resultData[alert["Alert"]].push({
              date: data["date"],
              topic: alert.topic.slice(3),
              Severity: alert["Severity"],
              Alert: alert["Alert"],
              Frequency: alert["Frequency"],
            });
          } else {
            resultData[alert["Alert"]] = [
              {
                date: data["date"],
                topic: alert.topic.slice(3),
                Severity: alert["Severity"],
                Alert: alert["Alert"],
                Frequency: alert["Frequency"],
              },
            ];
          }
          resultData["Total critical Events"].push({
            date: data["date"],
            topic: alert.topic.slice(3),
            Severity: alert["Severity"],
            Alert: alert["Alert"],
            Frequency: alert["Frequency"],
          });
          // }
        });
      }
    }
    return res.json({
      status: true,
      code: 200,
      data: resultData,
    });
  } catch (error) {
    console.log(error);
    return res.json({
      status: false,
      code: 500,
      message: error,
    });
  }
};

const anamoliesByVin = async (req, res) => {
  try {
    await connection(url);
    let { startDate, endDate, vin } = req.body;
    startDate = moment(startDate).format("YYYY-MM-DD");
    endDate = moment(endDate).format("YYYY-MM-DD");
    vin = vin.startsWith("mq/") ? vin : "mq/" + vin;
    const conditions = [
      {
        $match: {
          date: {
            $gte: startDate,
            $lte: endDate,
          },
          topic: vin,
          x78: "Running",
          $or: [
            {
              $expr: {
                $and: [{ $gt: ["$x87", 30000] }, { $ne: ["$x87", "NA"] }],
              },
            }, //energy_used
            { $expr: { $lte: ["$x53", 0] } }, // avg_soh
            { $expr: { $gt: ["$x12", 500] } }, // distance
            { $expr: { $or: [{ $eq: ["$x51", "NA"] }, { $eq: ["$x51", 0] }] } }, //start_ah
            { $expr: { $eq: ["$x52", 0] } }, // end_ah
            { $expr: { $gt: ["$x24", 75] } }, // max_inv_temp
            { $expr: { $gt: ["$x21", 160] } }, //max_im_temp
            {
              $expr: {
                $and: [{ $gt: ["$x35", 200] }, { $ne: ["$x35", "NA"] }],
              },
            }, // efficiency
            {
              $expr: {
                $and: [{ $lt: ["$x35", 60] }, { $gt: ["$x12", 5] }],
              },
            },
            { $expr: { $gt: ["$x100", "$x101"] } }, //start_charge_cycle_count end_charge_cycle_count
            { $expr: { $gt: ["$x10", "$x11"] } }, //start_odo end_odo
            // { $expr: { $gt: ["$x10", "$x11"] } },
            { $expr: { $gt: ["$x29", 0.3] } }, // max_delta_cell_voltage
            { $expr: { $and: [{ $eq: ["$x59", "NA"] }] } },
            { $expr: { $and: [{ $lt: ["$x114", 10] }] } },
          ],
        },
      },
      {
        $project: {
          _id: 0,
          topic: 1,
          date: 1,
          x78: 1,
          x1: 1,
          x96: 1,
          x87: 1,
          x53: 1,
          x12: 1,
          x51: 1,
          x52: 1,
          x24: 1,
          x21: 1,
          x35: 1,
          x100: 1,
          x101: 1,
          x10: 1,
          x11: 1,
          x29: 1,
          x58: 1,
          x59: 1,
          x114: 1,
        },
      },
    ];
    const vehicleDailyData = await VehicleDailyData.aggregate(conditions);
    const energyConsumptionAnamoly = [],
      chargeCycleAnamoly = [],
      distanceAnamoly = [],
      inverterTemperatureAnamoly = [],
      motorTempAnamoly = [],
      sohAnamoly = [],
      startAh = [],
      endAh = [],
      odoMeterAnamoly = [],
      energyUsedAnamoly = [],
      maxDeltaCellVoltage = [],
      geoCodeAnomaly = [],
      brakePedalAnomaly = [],
      totalAnamoly = [];
    for (let element of vehicleDailyData) {
      let item = {
        date: element.date,
        vin: element.topic.startsWith("mq/")
          ? element.topic.slice(3)
          : element.topic,
        vehicle_reg_number: element.x1,
        efficiency: element.x35,
        distance: element.x12,
        battery_type: element.x96,
        start_ah: element.x51 ? element.x51 : "NA",
        // geo_code: element.x59,
        max_brake_pedal: element.x114,
        end_ah: element.x52 ? element.x52 : "NA",
        max_inv_temp: element.x24,
        start_charge_cycle_count: element.x100,
        end_charge_cycle_count: element.x101,
        start_odo: element.x10,
        end_odo: element.x11,
        soh: element.x53,
        energy_used: element.x87,
        max_delta_cell_voltage: element.x29,
      };
      if ((element.x35 < 60 && element.x12 > 5) || element.x35 > 200) {
        energyConsumptionAnamoly.push({
          date: element.date,
          vin: element.topic.startsWith("mq/")
            ? element.topic.slice(3)
            : element.topic,
          vehicle_reg_number: element.x1,
          efficiency: element.x35,
          distance: element.x12,
          battery_type: element.x96,
          // start_ah: element.x51 ? element.x51 : "NA",
        });
        totalAnamoly.push(item);
      }
      if (element.x51 == 0 || element.x51 === "NA") {
        // console.log(element.topic)
        startAh.push({
          date: element.date,
          vin: element.topic.startsWith("mq/")
            ? element.topic.slice(3)
            : element.topic,
          vehicle_reg_number: element.x1,
          start_ah: element.x51 ? element.x51 : "NA",
          battery_type: element.x96,
        });
        totalAnamoly.push(item);
      }

      if (element.x59 === "NA" && element.x12 > 0 && element.x12 <= 500) {
        // console.log(element.topic)
        geoCodeAnomaly.push({
          date: element.date,
          vin: element.topic.startsWith("mq/")
            ? element.topic.slice(3)
            : element.topic,
          vehicle_reg_number: element.x1,
          distance: element.x12,

          geo_code: element.x59,

          battery_type: element.x96,
        });
        totalAnamoly.push(item);
      }

      if (element.x114 < 10 && element.x12 > 0 && element.x12 <= 500) {
        // console.log(element.topic)
        brakePedalAnomaly.push({
          date: element.date,
          vin: element.topic.startsWith("mq/")
            ? element.topic.slice(3)
            : element.topic,
          vehicle_reg_number: element.x1,
          distance: element.x12,
          max_brake_pedal: element.x114,
        });
        totalAnamoly.push(item);
      }
      if (element.x52 == 0 || element.x52 === "NA") {
        endAh.push({
          date: element.date,
          vin: element.topic.startsWith("mq/")
            ? element.topic.slice(3)
            : element.topic,
          vehicle_reg_number: element.x1,
          end_ah: element.x52 ? element.x52 : "NA",
          battery_type: element.x96,
        });
        totalAnamoly.push(item);
      }
      if (element.x24 > 75) {
        inverterTemperatureAnamoly.push({
          date: element.date,
          vin: element.topic.startsWith("mq/")
            ? element.topic.slice(3)
            : element.topic,
          vehicle_reg_number: element.x1,
          max_inv_temp: element.x24,
          battery_type: element.x96,
        });
        totalAnamoly.push(item);
      }
      if (element.x21 > 160) {
        motorTempAnamoly.push({
          date: element.date,
          vin: element.topic.startsWith("mq/")
            ? element.topic.slice(3)
            : element.topic,
          vehicle_reg_number: element.x1,
          max_im_temp: element.x21,
          battery_type: element.x96,
        });
        totalAnamoly.push(item);
      }
      if (element.x100 > element.x101) {
        chargeCycleAnamoly.push({
          date: element.date,
          vin: element.topic.startsWith("mq/")
            ? element.topic.slice(3)
            : element.topic,
          vehicle_reg_number: element.x1,
          start_charge_cycle_count: element.x100,
          end_charge_cycle_count: element.x101,
          battery_type: element.x96,
        });
        totalAnamoly.push(item);
      }
      if (element.x12 > 300) {
        distanceAnamoly.push({
          date: element.date,
          vin: element.topic.startsWith("mq/")
            ? element.topic.slice(3)
            : element.topic,
          vehicle_reg_number: element.x1,
          distance: element.x12,
          battery_type: element.x96,
          start_odo: element.x10,
          end_odo: element.x11,
        });
        totalAnamoly.push(item);
      }
      if (element.x12 < 0 || element.x10 > element.x11) {
        odoMeterAnamoly.push({
          date: element.date,
          vin: element.topic.startsWith("mq/")
            ? element.topic.slice(3)
            : element.topic,
          vehicle_reg_number: element.x1,
          distance: element.x12,
          start_odo: element.x10,
          end_odo: element.x11,
          battery_type: element.x96,
        });
        totalAnamoly.push(item);
      }
      if (element.x53 == 0) {
        sohAnamoly.push({
          date: element.date,
          vin: element.topic.startsWith("mq/")
            ? element.topic.slice(3)
            : element.topic,
          vehicle_reg_number: element.x1,
          soh: element.x53,
          battery_type: element.x96,
        });
        totalAnamoly.push(item);
      }
      if (element.x87 > 30000) {
        // console.log(element.topic)
        energyUsedAnamoly.push({
          date: element.date,
          vin: element.topic.startsWith("mq/")
            ? element.topic.slice(3)
            : element.topic,
          vehicle_reg_number: element.x1,
          energy_used: element.x87,
          battery_type: element.x96,
        });
        totalAnamoly.push(item);
      }
      if (element.x29 > 0.3) {
        maxDeltaCellVoltage.push({
          date: element.date,
          vin: element.topic.startsWith("mq/")
            ? element.topic.slice(3)
            : element.topic,
          vehicle_reg_number: element.x1,
          max_delta_cell_voltage: element.x29,
          battery_type: element.x96,
        });
        totalAnamoly.push(item);
      }
    }

    let data = {
      "Total Anamolies": totalAnamoly,
      "soh Anamoly": sohAnamoly,
      "OdoMeter Anamoly": odoMeterAnamoly,
      "Distance Anamoly": distanceAnamoly,
      "MotorTemperature Anamoly": motorTempAnamoly,
      "InverterTemperature Anamoly": inverterTemperatureAnamoly,
      "EnergyConsumption Anamoly": energyConsumptionAnamoly,
      "EnergyUsed Anamoly": energyUsedAnamoly,
      "StartAh Anamoly": startAh,
      "EndAh Anamoly": endAh,
      "ChargeCycle Anamoly": chargeCycleAnamoly,
      //totalAnamolies:result[0],
      "MaxDeltaCellVoltage Anamoly": maxDeltaCellVoltage,
      "GeoCode Anamoly": geoCodeAnomaly,
      "BrakePedal Anamoly": brakePedalAnomaly,
      // totalAnamoliesLength: vehicleDailyData.length,
    };

    // let resultData=[]
    return res.json({
      status: true,
      code: 200,
      data: data,
    });
  } catch (error) {
    console.log(error);
    return res.json({
      status: false,
      code: 500,
      message: error.message,
    });
  }
};


const getFaultCodesData = async (req, res) => {
  try {
    await connection(url);

    await sequelize.sync();

    const { type, date, vin,startDate,endDate } = req.body;
    // console.log(req.body,'body')
    let result;
    const faultTypes = {
      "Fault code 1": [
        "OVERRUN_FAULT",
        "HARDWARE_FAULT",
        "OVER_CURRENT_FAULT",
        "OVER_CURRENT_NEG_FAULT",
        "OVER_VOLTAGE_FAULT",
        "PHASE_CURR_FAULT",
        "FAULT_CODE_2",
        "UNDER_VOLTAGE_FAULT",
        "PRECHARGE_FAULT",
        "BGND_OR_FAULT",
        "OVER_VOLTAGE_FAULT1",
        "DCDC_FAULT",
        "CHARGER_CONNECTED",
        "IM_OVER_TEMP_FAULT",
        "BMS_FAULT",
        "CONTACTOR_STATE_INV",
      ],
      "Fault code 2": [
        "OVER_SPEED_FAULT",
        "THROTTLE_FAULT",
        "GATE_DRIVER_FAULT",
        "INPUT_VOLTAGE_FAULT",
        "OVER_LOAD_FAULT",
        "BATTERY_PACK_WARNING",
        "RNFB_FAULT",
        "CALIBRATION_FAULT",
        "VEHICLE_DISABLE",
        "SPEED_PHASE_FAULT",
        "PPR_CONF_FAULT",
      ],
      "VDM Module Fault": [
        "VDM_SIM_DETECTION_FAULT",
        "VDM_GPRS_ATTACH_FAULT",
        "VDM_GPRS_NETWORK_FAULT",
        "VDM_SERVER_ACTIVE_FAULT",
        "VDM_GSM_RX_FAULT",
        "VDM_GPS_RX_FAULT",
        "VDM_CAN_RX_FAULT",
        "VDM_SERVER_DETACTH_FAULT",
        "VDM_GSM_SIGNAL_FAULT",
        "VDM_RTC_FAULT",
        "VDM_GSM_RSP_FAULT",
        "VDM_CALIB_FAULT",
        "VDM_FLASH_INIT_FAULT",
        "VDM_FLASH_READ_FAULT",
        "VDM_48V_TOPUP_STATUS",
        "VDM_WAKE_OR_ALIVE_STATUS",
      ],
      "VDM Module Status": [
        "VDM_CHARGE_DETECT_STATUS",
        "VDM_BMS_CAN_RX_FAULT",
        "NETWORK_CONFIG_MISMATCH",
        "BATTERY_12V_CHECK_HEALTH",
        "VEHICLE_DISABLE_CMD",
        "VDM_SHUTDOWN_12V_LOW",
        "VDM_SHUTDOWN_GSM_RX",
        "RTC_PREFETCH_FAILED",
        "GSM_MODULE_LOWER_THRESHOLD",
        "VDM_BRAKE_OIL_LOW",
        "DISP_IMG_MISMATCH",
        "No_GPS_FIX",
      ],
    };

    const getFaultType = (fault) => {
      let foundFault = Object.entries(faultTypes).find(
        ([_, faultCodes]) => faultCodes.includes(fault)
      );

      return foundFault ? foundFault[0] : null;
    };

    const getFaults = {
      fault: async function () {
        const data = await VehicleDailyData.aggregate([
          {
            $match: {
              date: date,
              // x78: "Running",
              x125: {
                $nin: ["NA", null],
              },
            },
          },
          {
            $project: {
              _id: 0,
              topic: 1,
              x125: 1,
            },
          },
        ]);

        if (data.length) {
          let formattedData = data.reduce(
            (acc, cur) => {
              if (cur.x125.length) {
                let vin = cur.topic.slice(3);
                let faults = cur.x125;

                faults.forEach((faultObj) => {
                  const foundFault = getFaultType(faultObj.Fault);
                  if (foundFault) {
                    acc[foundFault].push({
                      vin: vin,
                      frequency: faultObj.Frequency,
                    });
                  }
                });

                return acc;
              } else {
                return acc;
              }
            },
            {
              "Fault code 1": [],
              "Fault code 2": [],
              "VDM Module Fault": [],
              "VDM Module Status": [],
            }
          );

          return formattedData;
        } else {
          return null;
        }
      },
      vin: async function () {
        const data = await VehicleDailyData.aggregate([
          {
            $match: {
              date: {
                $gte:startDate,
                $lte:endDate
              },
              topic: `mq/${vin}`,
              x125: {
                $nin: ["NA", null],
              },
            },
          },
          {
            $project: {
              _id: 0,
              date:1,
              topic: 1,
              x125: 1,
            },
          },
        ]);
        // console.log(data,'data');

        if (data.length) {
          let formattedData = data.reduce(
            (acc, cur) => {
              // console.log(cur,'cur')
              if (cur.x125.length) {
                let faults = cur.x125;

                faults.forEach((faultObj) => {
                  const faultItem={
                    fault: faultObj.Fault,
                    date:cur.date,
                    frequency: faultObj.Frequency,
                  }
                  // const foundFault = getFaultType(faultObj.Fault);
                  if (acc.hasOwnProperty(faultObj.Fault)) {
                    acc[faultObj.Fault].push(faultItem);
                  }else{
                    acc[faultObj.Fault]=[faultItem]
                  }

                  acc['Total Faults'].push(faultItem)
                });

                return acc;
              } else {
                return acc;
              }
            },{
              'Total Faults':[]
            }
            // {
            //   "Fault code 1": [],
            //   "Fault code 2": [],
            //   "VDM Module Fault": [],
            //   "VDM Module Status": [],
            // }
          );

          return formattedData;
        } else {
          return [];
        }
      },
    };

    result = await getFaults[type]();

    if (result) {
      return res.json({ status: true,code:200, data: result });
    } else {
      return res.json({ status: false, error: "No data" });
    }
  } catch (error) {
    console.log(error);
    return res.json({ status: false, error: "Internal Server Error!" });
  }
};

module.exports = {
  alertController,
  alertControllerByVin,
  alertControllerByVinCard,
  anamoliesByVin,
  getFaultCodesData
};
