const dealerDetails = require("../../models/dealerDetails");
const dealerMonthly = require("../../models/dealerMonthly");
const VehicleDailyData = require("../../models/vehicleDailyData");
// const ApiError = require('../utils/ApiError');
const moment = require("moment");
const mongoose = require("mongoose");
const { aplToVDD } = require("../../utils/vehicleDailyDataMapping");
const sequelize = require("../../utils/sqldb");
const Vehicle = require("../../models/vehicle");
const { Sequelize, Op } = require("sequelize");
const Client = require("../../models/client");
const ClientVehicle = require("../../models/client-vehicle");
const VehicleSaleStatment = require("../../models/VehicleSaleStatement");
const calculatorUser = require("../../models/CalculatorModel");
const momentz=require("moment-timezone");
const AltidashUser = require("../../models/AltidashUser");


connection = (url) => {
    mongoose.connect(url, { useNewUrlParser: true });
  };
  
  const url =
    "mongodb+srv://alti-admin-prod:APL2023ADMIN@mqtt-production.iqeii.mongodb.net/mqttDatabase_aplmq";

    const createUser=async(req,res)=>{
      try {
        await connection(url);
        let existingUser=await calculatorUser.findOne({mobile:req.body.mobile})
        // console.log(existingUser,'existingUser')
        if(existingUser==null){
          let user=await calculatorUser.create({name:req.body.username,mobile:req.body.mobile,time:momentz.tz('Asia/Kolkata').format('YYYY-MM-DD HH:mm:ss'),data:req.body.data?req.body.data:null})
        return res.json({status:true,
        code:200,
        data:user});
        }
        else{
          // console.log("user there",existingUser.name,existingUser.time)
          existingUser.name = req.body.username;
          existingUser.time = momentz.tz('Asia/Kolkata').format('YYYY-MM-DD HH:mm:ss');
          existingUser.data = req.body.data===null?existingUser.data:req.body.data;
          await existingUser.save();
          return res.json({status:true,
            code:200,
            data:existingUser});
        }  
      } catch (error) {
        return res.json({status:false,
        code:500,
      message:error})
      }
    }

    const dashboardApi = async (req, res) => {
      let finalResult = {
        trendData: {
          previousData: null,
          currentData: null,
        },
        topDistanceVehicles: null,
        distance_comparison: null,
        topOdoVehicles: null,
        unique_pincodes: null,
        odo_meter_range: null,
        vehicle_info: null,
        charging_status: null,
      };
      try {
        await connection(url);
        await sequelize.sync();
        Vehicle.belongsToMany(Client, {
          through: ClientVehicle,
          foreignKey: "vid",
        });
        Client.belongsToMany(Vehicle, {
          through: ClientVehicle,
          foreignKey: "cid",
        });
    
        const data =
          await sequelize.query(`select distinct veh.VIN as vin,veh.VehicleRegNo,veh.model,veh.SIMservicePrName,veh.network_type,
        GROUP_CONCAT(DISTINCT cl.ClientFullName SEPARATOR ',') as name,vs.vinserialnum from Client cl 
        join ClientVehicle cv on cl.cid = cv.cid 
        join Vehicle veh on cv.vid = veh.vid 
        left join VinSerialNum vs on vs.vehicleId=veh.vid 
        where deleteVehicleStatus=0 and 
        (veh.vin like 'mq/MD9%' or veh.vin like 'mq/P6R%' ) group by veh.vin`);

        console.log(data[0],'data')
    
        const dealerVinsList = [],
          vehicleSaleVins = [],
          VehicleTableData = {};
        data[0].map((item) => {
          dealerVinsList.push(item.vin);
          vehicleSaleVins.push(item.vin.slice(3));
          VehicleTableData[item.vin] = item;
        });
        let { date } = req.params;
        date = moment(date).format("YYYY-MM-DD");
        let previousDay = moment(date).subtract(1, "days").format("YYYY-MM-DD");
        let VehicleSaleStatmentQuery = await VehicleSaleStatment.aggregate([
          { $match: { chassis_no: { $in: vehicleSaleVins } } },
          {
            $project: {
              _id: 0,
              vin: "$chassis_no",
              customer: "$customer",
              city: "$city",
              model: "$model_name",
            },
          },
        ]);
        const VehicleSaleObject = {};
        VehicleSaleStatmentQuery.map((item) => {
          VehicleSaleObject["mq/" + item["vin"]] = item;
        });
    
        let query = await VehicleDailyData.aggregate([
          {
            $match: {
              date: { $in: [previousDay, date] },
              topic: { $in: dealerVinsList },
              x12: { $gt: 0, $lte: 500, $ne: "NA" },
            },
          },
          {
            $facet: {
              overviewData: [
                {
                  $group: {
                    _id: "$date",
                    total_vehicles: { $sum: 1 },
                    total_distance: { $sum: "$x12" },
                    total_co2_saved_ed: {
                      $sum: {
                        $multiply: [{ $divide: ["$x12", 25] }, 2.64],
                      },
                    },
                    avg_distance_covered: { $avg: "$x12" },
                    avg_energy_consumption: {
                      $avg: {
                        $cond: [
                          {
                            $and: [
                              { $gt: ["$x12", 5] },
                              { $gte: ["$x35", 30] },
                              { $lte: ["$x35", 200] },
                            ],
                          },
                          "$x87",
                          null,
                        ],
                      },
                    },
                    avg_efficiency: {
                      $avg: {
                        $cond: [
                          {
                            $and: [
                              { $gt: ["$x12", 5] },
                              { $gte: ["$x35", 30] },
                              { $lte: ["$x35", 200] },
                            ],
                          },
                          "$x35",
                          null,
                        ],
                      },
                    },
                    ">100kms": {
                      $sum: {
                        $cond: [{ $gt: ["$x12", 100] }, 1, 0],
                      },
                    },
                  },
                },
              ],
              vehicleData: [
                { $match: { date: date } },
                {
                  $project: {
                    _id: 0,
                    vin: "$topic",
                    distance: "$x12",
                    odo: "$x11",
                    soc: "$x55",
                    charging_status: "$x99",
                  },
                },
              ],
              topDistance: [
                {
                  $match: {
                    date: date,
                  },
                },
                {
                  $group: {
                    _id: "$topic",
                    distance: { $last: "$x12" },
                    vehicle_reg_number: { $last: "$x1" },
                  },
                },
                {
                  $sort: { distance: -1 },
                },
                {
                  $limit: 10,
                },
              ],
              topOdo: [
                {
                  $match: {
                    date: date,
                  },
                },
                {
                  $group: {
                    _id: "$topic",
                    odo: { $last: "$x11" },
                    vehicle_reg_number: { $last: "$x1" },
                  },
                },
                {
                  $sort: { odo: -1 },
                },
                {
                  $limit: 10,
                },
              ],
              distanceComparison: [
                {
                  $match: { date: date },
                },
                {
                  $group: {
                    _id: {
                      $switch: {
                        branches: [
                          {
                            case: {
                              $and: [{ $gte: ["$x12", 0] }, { $lte: ["$x12", 5] }],
                            },
                            then: "0 to 5 kms",
                          },
                          {
                            case: {
                              $and: [{ $gt: ["$x12", 5] }, { $lte: ["$x12", 60] }],
                            },
                            then: "5 to 60 kms",
                          },
                          {
                            case: {
                              $and: [
                                { $gt: ["$x12", 60] },
                                { $lte: ["$x12", 100] },
                              ],
                            },
                            then: "60 to 100 kms",
                          },
                          {
                            case: {
                              $and: [
                                { $gt: ["$x12", 100] },
                                { $lte: ["$x12", 200] },
                              ],
                            },
                            then: "100 to 200 kms",
                          },
                          { case: { $gt: ["$x12", 200] }, then: ">200 kms" },
                        ],
                        default: "Unknown",
                      },
                    },
                    data: {
                      $push: {
                        vin: "$topic",
                        vehicle_reg_number: "$x1",
                        distance: "$x12",
                        soc: "$x55",
                        end_odo: "$x11",
                      },
                    },
                  },
                },
              ],
              odoComparison: [
                {
                  $match: { date: date },
                },
                {
                  $group: {
                    _id: {
                      $switch: {
                        branches: [
                          {
                            case: {
                              $and: [
                                { $gte: ["$x11", 500] },
                                { $lte: ["$x11", 1000] },
                              ],
                            },
                            then: "500 to 1000 kms",
                          },
                          {
                            case: {
                              $and: [
                                { $gte: ["$x11", 1001] },
                                { $lte: ["$x11", 2000] },
                              ],
                            },
                            then: "1001 to 2000 kms",
                          },
                          {
                            case: {
                              $and: [
                                { $gte: ["$x11", 2001] },
                                { $lte: ["$x11", 5000] },
                              ],
                            },
                            then: "2001 to 5000 kms",
                          },
                          {
                            case: {
                              $and: [
                                { $gte: ["$x11", 5001] },
                                { $lte: ["$x11", 10000] },
                              ],
                            },
                            then: "5001 to 10000 kms",
                          },
                          {
                            case: {
                              $and: [
                                { $gte: ["$x11", 10001] },
                                { $lte: ["$x11", 20000] },
                              ],
                            },
                            then: "10001 to 20000 kms",
                          },
                          {
                            case: {
                              $and: [
                                { $gte: ["$x11", 20001] },
                                { $lte: ["$x11", 40000] },
                              ],
                            },
                            then: "20001 to 40000 kms",
                          },
                          { case: { $gt: ["$x11", 40000] }, then: ">40000 kms" },
                        ],
                        default: "Unknown",
                      },
                    },
                    data: {
                      $push: {
                        vin: "$topic",
                        vehicle_reg_number: "$x1",
                        distance: "$x12",
                        soc: "$x55",
                        end_odo: "$x11",
                      },
                    },
                  },
                },
              ],
            },
          },
        ]);
    
        //formatting start

        // console.log(query[0].overviewData);
    
        if (query.length) {
          //trend data formatting
          if (query[0].overviewData.length) {
            let overviewLength = query[0].overviewData.length;
            if (overviewLength === 1) {
              let singleData = query[0].overviewData[0];
              if (date === singleData["_id"]) {
                finalResult.trendData.currentData = {
                  ...singleData,
                  date: singleData["_id"],
                };
                finalResult.trendData.previousData = null;
              } else {
                finalResult.trendData.previousData = {
                  ...singleData,
                  date: singleData["_id"],
                };
                finalResult.trendData.currentData = null;
              }
            } else if (overviewLength === 2) {
              let index = query[0].overviewData.findIndex(item=>item._id === date);
              finalResult.trendData.currentData = {
                ...query[0].overviewData[index],
                date: query[0].overviewData[index]["_id"],
              };
              let prevIndex = index === 0 ? 1 : 0;
              finalResult.trendData["previousData"] = {
                ...query[0].overviewData[prevIndex],
                date: query[0].overviewData[prevIndex]["_id"],
              }          
            }
          }
    
          //top 10 distance vehicles
    
          if (query[0].topDistance.length) {
            finalResult.topDistanceVehicles = query[0].topDistance.map((item) => {
              return {
                vin: item._id.slice(3),
                distance: item.distance,
                vehicle_reg_number: VehicleTableData[item._id]["VehicleRegNo"],
                name:VehicleTableData[item._id]["name"],
                customer: VehicleSaleObject[item._id]
                  ? VehicleSaleObject[item._id]["customer"].trim()
                  : null,
                city: VehicleSaleObject[item._id]
                  ? VehicleSaleObject[item._id]["city"].trim()
                  : null,
                model: VehicleSaleObject[item._id]
                  ? VehicleSaleObject[item._id]["model"]
                  : VehicleTableData[item._id]["model"],
              };
            });
          }
    
          //top 10 odo vehicles
    
          if (query[0].topOdo.length) {
            finalResult.topOdoVehicles = query[0].topOdo.map((item) => {
              return {
                vin: item._id.slice(3),
                odo: item.odo,
                vehicle_reg_number: VehicleTableData[item._id]["VehicleRegNo"],
                name:VehicleTableData[item._id]["name"],
                customer: VehicleSaleObject[item._id]
                  ? VehicleSaleObject[item._id]["customer"].trim()
                  : null,
                city: VehicleSaleObject[item._id]
                  ? VehicleSaleObject[item._id]["city"].trim()
                  : null,
                model: VehicleSaleObject[item._id]
                  ? VehicleSaleObject[item._id]["model"]
                  : VehicleTableData[item._id]["model"],
              };
            });
          }
    
          //vehicle info
          if (query[0].vehicleData.length) {
            finalResult.vehicle_info = query[0].vehicleData.map((item) => {
              return {
                vin: item["vin"].slice(3),
                vehicle_reg_number: VehicleTableData[item["vin"]]["VehicleRegNo"],
                fleet_name: VehicleTableData[item["vin"]]["name"],
                distance: Number(Number(item["distance"]).toFixed(2)),
                soc: item["soc"],
                end_odo: item["odo"],
                network_type: VehicleTableData[item["vin"]]["network_type"],
              };
            });
          }
    
          //distance comparison
          if (query[0].distanceComparison.length) {
            DistanceComparison = {
              "0 to 5 kms":[],
              "5 to 60 kms":[],
              "60 to 100 kms":[],
              "100 to 200 kms":[],
              ">200 kms":[]
            };
            query[0].distanceComparison.map((item) => {
              DistanceComparison[item["_id"]] = item["data"].map((it) => {
                return {
                  vin: it["vin"].slice(3),
                  vehicle_reg_number: VehicleTableData[it["vin"]]["VehicleRegNo"],
                  fleet_name: VehicleTableData[it["vin"]]["name"],
                  distance: it["distance"],
                  soc: it["soc"],
                  end_odo: it["end_odo"],
                  network_type: VehicleTableData[it["vin"]]["network_type"],
                };
              });
            });
            finalResult.distance_comparison = { ...DistanceComparison };
          }
    
          //odo comparison
          if (query[0].odoComparison.length) {
            OdoComparison = {
              "500 to 1000 kms":[],
              "1001 to 2000 kms": [],
              "2001 to 5000 kms": [],
              "5001 to 10000 kms":[],
              "10001 to 20000 kms":[],
              "20001 to 40000 kms":[],
              ">40000 kms":[],
            };
            query[0].odoComparison.map((item) => {
              if(OdoComparison.hasOwnProperty(item["_id"])){
                OdoComparison[item["_id"]] = item["data"].map((it) => {
                  return {
                    vin: it["vin"].slice(3),
                    vehicle_reg_number: VehicleTableData[it["vin"]]["VehicleRegNo"],
                    fleet_name: VehicleTableData[it["vin"]]["name"],
                    distance: it["distance"],
                    soc: it["soc"],
                    end_odo: it["end_odo"],
                    network_type: VehicleTableData[it["vin"]]["network_type"],
                  };
                });
              }
            });
    
            finalResult.odo_meter_range = { ...OdoComparison };
          }
    
          //charging status
          if (query[0].vehicleData.length) {
          chargingObj = { Charged: [], "Not Charged": [] };
    
            query[0].vehicleData.map((item) => {
              item["charging_status"] == true
                ? chargingObj["Charged"].push({
                    vin: item["vin"].slice(3),
                    vehicle_reg_number:
                      VehicleTableData[item["vin"]]["VehicleRegNo"],
                    fleet_name: VehicleTableData[item["vin"]]["name"],
                    distance: item["distance"],
                    soc: item["soc"],
                    end_odo: item["odo"],
                    network_type: VehicleTableData[item["vin"]]["network_type"],
                  })
                : chargingObj["Not Charged"].push({
                    vin: item["vin"].slice(3),
                    vehicle_reg_number:
                      VehicleTableData[item["vin"]]["VehicleRegNo"],
                    fleet_name: VehicleTableData[item["vin"]]["name"],
                    distance: item["distance"],
                    soc: item["soc"],
                    end_odo: item["odo"],
                    network_type: VehicleTableData[item["vin"]]["network_type"],
                  });
              return {};
            });
            finalResult.charging_status = {...chargingObj}
          }
        }
        console.log(VehicleTableData,'vehicleTableData')
        //formatting end
    
        return res.json({
          status: true,
          ...finalResult,
        });
      } catch (error) {
        return res.json(error);
      }
    };



const batteryApi = async(req, res) => {
  try {
    let result = null;
    let vehiclesList;

    const {date} = req.body;
  
    Client.belongsToMany(Vehicle, { through: ClientVehicle, foreignKey: "cid" });
    Vehicle.belongsToMany(Client, { through: ClientVehicle, foreignKey: "vid" });
  
    await connection(url);

    await sequelize.sync();


    const vehicleDailyData = await VehicleDailyData.find({
      date: date,
      $and: [{x12: {$gt: 0} }, { x78: "Running" }],
    }).select({
      _id: 0,
      topic: 1,
      date: 1,
      x78: 1, //status
      x1: 1, //reg number
      x96: 1, //battery type
      x11: 1,
      x12: 1, //distance
      x54: 1, //start soc
      x55: 1, // end soc
      x108: 1, //min day soc
      x109: 1, //max day soc
      x53: 1, //avg soh
      x24: 1, //max_inv_temp
      x21: 1, //Max Im Temp
      x30: 1, //max_battery_temp
      x110: 1, //max_12V_battery
    });



    vehiclesList = await Vehicle.findAll({
      attributes: ["VIN", "VehicleRegNo", "SIMservicePrName", "network_type", "model"],
      where: {
        deleteVehicleStatus: 0,
        [Op.or]: [
          { VIN: { [Op.like]: "mq/MD9%" } },
          { VIN: { [Op.like]: "mq/P6R%" } },
        ],
        VIN: {
          [Op.in]: vehicleDailyData.map((item) => item.topic),
        },
      },
      nest: true,
      include: [
        {
          model: Client,
          attributes: ["clientCode"],
          through: { attributes: [] },
        },
      ],
    });

    let start_soc = {"0-20": [], "21-40": [], "41-60": [], "61-80": [], "81-100": []}
    let end_soc = {"0-20": [], "21-40": [], "41-60": [], "61-80": [], "81-100": []}
    let min_day_soc = {"0-20": [], "21-40": [], "41-60": [], "61-80": [], "81-100": []}
    let max_day_soc = {"0-20": [], "21-40": [], "41-60": [], "61-80": [], "81-100": []}
    let soh = {"0-70": [], "71-75": [], "76-80": [], "81-85": [], "86-90": [], "91-95": [], "96-100": []}
    let min_12v_battery = {"<10": [], "<11": [], "<12": [], "<13": [], "<14": [], "<15": []}
    let max_inv_temp = {
      "0-20": [],
      "21-30": [],
      "31-40": [],
      "41-50": [],
      "51-60": [],
      "61-70": [],
      "71-80": [],
      "81-90": [],
      "91-100": [],
      "> 100": []
    } 

    let max_im_temp = {
      "0-20": [],
      "21-30": [],
      "31-40": [],
      "41-50": [],
      "51-60": [],
      "61-70": [],
      "71-80": [],
      "81-90": [],
      "91-100": [],
      "100-120": [],
      "120-150": [],
      "> 150": []
    }

    let max_battery_temp = {
      "0-10": [],
      "11-20": [],
      "21-30": [],
      "31-40": [],
      "41-50": [],
      "51-60": [],
      "61-70": [],
      "71-80": [],
      "81-90": [],
      "91-100": []
    }
  
    for (const i of vehiclesList) {

      const foundVehicle = vehicleDailyData.find((score) => score.topic === i.VIN);
      if (foundVehicle) {
        // Start Soc
        if (foundVehicle.x54 <= 20) {
          start_soc["0-20"].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            start_soc: foundVehicle.x54,
          });
        } else if (foundVehicle.x54 > 20 && foundVehicle.x54 <= 40) {
          start_soc["21-40"].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            start_soc: foundVehicle.x54,
          });
        } else if (foundVehicle.x54 > 40 && foundVehicle.x54 <= 60) {
          start_soc["41-60"].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            start_soc: foundVehicle.x54,
          });
        } else if (foundVehicle.x54 > 60 && foundVehicle.x54 <= 80) {
          start_soc["61-80"].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            start_soc: foundVehicle.x54,
          });
        } else if (foundVehicle.x54 > 80 && foundVehicle.x54 <= 100) {
          start_soc["81-100"].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            start_soc: foundVehicle.x54,
          });
        }

        // End Soc
        if (foundVehicle.x55 <= 20) {
          end_soc["0-20"].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            end_soc: foundVehicle.x55,
          });
        } else if (foundVehicle.x55 > 20 && foundVehicle.x55 <= 40) {
          end_soc["21-40"].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            end_soc: foundVehicle.x55,
          });
        } else if (foundVehicle.x55 > 40 && foundVehicle.x55 <= 60) {
          end_soc["41-60"].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            end_soc: foundVehicle.x55,
          });
        } else if (foundVehicle.x55 > 60 && foundVehicle.x55 <= 80) {
          end_soc["61-80"].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            end_soc: foundVehicle.x55,
          });
        } else if (foundVehicle.x55 > 80 && foundVehicle.x55 <= 100) {
          end_soc["81-100"].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            end_soc: foundVehicle.x55,
          });
        }

         // Min Day Soc
         if (foundVehicle.x108 <= 20) {
          min_day_soc["0-20"].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            min_day_soc: foundVehicle.x108,
          });
        } else if (foundVehicle.x108 > 20 && foundVehicle.x108 <= 40) {
          min_day_soc["21-40"].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            min_day_soc: foundVehicle.x108,
          });
        } else if (foundVehicle.x108 > 40 && foundVehicle.x108 <= 60) {
          min_day_soc["41-60"].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            min_day_soc: foundVehicle.x108,
          });
        } else if (foundVehicle.x108 > 60 && foundVehicle.x108 <= 80) {
          min_day_soc["61-80"].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            min_day_soc: foundVehicle.x108,
          });
        } else if (foundVehicle.x108 > 80 && foundVehicle.x108 <= 100) {
          min_day_soc["81-100"].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            min_day_soc: foundVehicle.x108,
          });
        }

        // Max Day Soc
        if (foundVehicle.x109 <= 20) {
          max_day_soc["0-20"].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            max_day_soc: foundVehicle.x109,
          });
        } else if (foundVehicle.x109 > 20 && foundVehicle.x109 <= 40) {
          max_day_soc["21-40"].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            max_day_soc: foundVehicle.x109,
          });
        } else if (foundVehicle.x109 > 40 && foundVehicle.x109 <= 60) {
          max_day_soc["41-60"].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            max_day_soc: foundVehicle.x109,
          });
        } else if (foundVehicle.x109 > 60 && foundVehicle.x109 <= 80) {
          max_day_soc["61-80"].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            max_day_soc: foundVehicle.x109,
          });
        } else if (foundVehicle.x109 > 80 && foundVehicle.x109 <= 100) {
          max_day_soc["81-100"].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            max_day_soc: foundVehicle.x109,
          });
        }

        // SOH
        if (foundVehicle.x53 <= 70) {
          soh['0-70'].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            soh: foundVehicle.x53,
          })
        } else if (foundVehicle.x53 > 70 && foundVehicle.x53 <= 75) {
          soh['71-75'].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            soh: foundVehicle.x53,
          })
        } else if (foundVehicle.x53 > 75 && foundVehicle.x53 <= 80) {
          soh['76-80'].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            soh: foundVehicle.x53,
          })
        } else if (foundVehicle.x53 > 80 && foundVehicle.x53 <= 85) {
          soh['81-85'].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            soh: foundVehicle.x53,
          })
        } else if (foundVehicle.x53 > 85 && foundVehicle.x53 <= 90) {
          soh['86-90'].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            soh: foundVehicle.x53,
          })
        } else if (foundVehicle.x53 > 90 && foundVehicle.x53 <= 95) {
          soh['91-95'].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            soh: foundVehicle.x53,
          })
        } else if (foundVehicle.x53 > 95 && foundVehicle.x53 <= 100) {
          soh['96-100'].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            soh: foundVehicle.x53,
          })
        }


        // Max Inv Temp
        if (foundVehicle.x24 >= 0 && foundVehicle.x24 <= 20) {
          max_inv_temp['0-20'].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            max_inv_temp: foundVehicle.x24,
          })
        }
        else if (foundVehicle.x24 > 20 && foundVehicle.x24 <= 30) {
          max_inv_temp['21-30'].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            max_inv_temp: foundVehicle.x24,
          })
        } else if (foundVehicle.x24 > 30 && foundVehicle.x24 <= 40) {
          max_inv_temp['31-40'].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            max_inv_temp: foundVehicle.x24,
          })
        } else if (foundVehicle.x24 > 40 && foundVehicle.x24 <= 50) {
          max_inv_temp['41-50'].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            max_inv_temp: foundVehicle.x24,
          })
        } else if (foundVehicle.x24 > 50 && foundVehicle.x24 <= 60) {
          max_inv_temp['51-60'].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            max_inv_temp: foundVehicle.x24,
          })
        } else if (foundVehicle.x24 > 60 && foundVehicle.x24 <= 70) {
          max_inv_temp['61-70'].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            max_inv_temp: foundVehicle.x24,
          })
        } else if (foundVehicle.x24 > 70 && foundVehicle.x24 <= 80) {
          max_inv_temp['71-80'].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            max_inv_temp: foundVehicle.x24,
          })
        } else if (foundVehicle.x24 > 80 && foundVehicle.x24 <= 90) {
          max_inv_temp['81-90'].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            max_inv_temp: foundVehicle.x24,
          })
        } else if (foundVehicle.x24 > 90 && foundVehicle.x24 <= 100) {
          max_inv_temp['91-100'].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            max_inv_temp: foundVehicle.x24,
          })
        } else if (foundVehicle.x24 > 100) {
          max_inv_temp['> 100'].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            max_inv_temp: foundVehicle.x24,
          })
        }


        // Max Im Temp
        if (foundVehicle.x21 >= 0 && foundVehicle.x21 <= 20) {
          max_im_temp['0-20'].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            max_im_temp: foundVehicle.x21,
          })
        }
        else if (foundVehicle.x21 > 20 && foundVehicle.x21 <= 30) {
          max_im_temp['21-30'].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            max_im_temp: foundVehicle.x21,
          })
        } else if (foundVehicle.x21 > 30 && foundVehicle.x21 <= 40) {
          max_im_temp['31-40'].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            max_im_temp: foundVehicle.x21,
          })
        } else if (foundVehicle.x21 > 40 && foundVehicle.x21 <= 50) {
          max_im_temp['41-50'].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            max_im_temp: foundVehicle.x21,
          })
        } else if (foundVehicle.x21 > 50 && foundVehicle.x21 <= 60) {
          max_im_temp['51-60'].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            max_im_temp: foundVehicle.x21,
          })
        } else if (foundVehicle.x21 > 60 && foundVehicle.x21 <= 70) {
          max_im_temp['61-70'].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            max_im_temp: foundVehicle.x21,
          })
        } else if (foundVehicle.x21 > 70 && foundVehicle.x21 <= 80) {
          max_im_temp['71-80'].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            max_im_temp: foundVehicle.x21,
          })
        } else if (foundVehicle.x21 > 80 && foundVehicle.x21 <= 90) {
          max_im_temp['81-90'].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            max_im_temp: foundVehicle.x21,
          })
        } else if (foundVehicle.x21 > 90 && foundVehicle.x21 <= 100) {
          max_im_temp['91-100'].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            max_im_temp: foundVehicle.x21,
          })
        }else if (foundVehicle.x21 > 100 && foundVehicle.x21 <= 120) {
          max_im_temp['100-120'].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            max_im_temp: foundVehicle.x21,
          })
        }else if (foundVehicle.x21 > 120 && foundVehicle.x21 <= 150) {
          max_im_temp['120-150'].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            max_im_temp: foundVehicle.x21,
          })
        } else if (foundVehicle.x21 > 150) {
          max_im_temp['> 150'].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            max_im_temp: foundVehicle.x21,
          })
        }  

        // Max Battery Temp
        if (foundVehicle.x30 >= 0 && foundVehicle.x30 <= 10) {
          max_battery_temp['0-10'].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            max_battery_temp: foundVehicle.x30,
          })
        }
        else if (foundVehicle.x30 > 10 && foundVehicle.x30 <= 20) {
          max_battery_temp['11-20'].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            max_battery_temp: foundVehicle.x30,
          })
        } else if (foundVehicle.x30 > 20 && foundVehicle.x30 <= 30) {
          max_battery_temp['21-30'].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            max_battery_temp: foundVehicle.x30,
          })
        } else if (foundVehicle.x30 > 30 && foundVehicle.x30 <= 40) {
          max_battery_temp['31-40'].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            max_battery_temp: foundVehicle.x30,
          })
        } else if (foundVehicle.x30 > 40 && foundVehicle.x30 <= 50) {
          max_battery_temp['41-50'].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            max_battery_temp: foundVehicle.x30,
          })
        } else if (foundVehicle.x30 > 50 && foundVehicle.x30 <= 60) {
          max_battery_temp['51-60'].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            max_battery_temp: foundVehicle.x30,
          })
        } else if (foundVehicle.x30 > 60 && foundVehicle.x30 <= 70) {
          max_battery_temp['61-70'].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            max_battery_temp: foundVehicle.x30,
          })
        } else if (foundVehicle.x30 > 70 && foundVehicle.x30 <= 80) {
          max_battery_temp['71-80'].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            max_battery_temp: foundVehicle.x30,
          })
        } else if (foundVehicle.x30 > 80 && foundVehicle.x30 <= 90) {
          max_battery_temp['81-90'].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            max_battery_temp: foundVehicle.x30,
          })
        } else if (foundVehicle.x30 > 90 && foundVehicle.x30 <= 100) {
          max_battery_temp['91-100'].push({
            vin: i.VIN.slice(3),
            vehicle_reg_number: i.VehicleRegNo,
            model: i.dataValues.model,
            fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
            network_type: i.dataValues.network_type,
            max_battery_temp: foundVehicle.x30,
          })
        } 
        // console.log(i)

          if (foundVehicle.x110 < 10) {
            min_12v_battery['<10'].push({
              vin: i.VIN.slice(3),
              vehicle_reg_number: i.VehicleRegNo,
              model: i.dataValues.model,
              fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
              network_type: i.dataValues.network_type,
              min_12v_battery: foundVehicle.x110,
            })
          } else if (foundVehicle.x110 >= 10 && foundVehicle.x110 < 11) {
            min_12v_battery['<11'].push({
              vin: i.VIN.slice(3),
              vehicle_reg_number: i.VehicleRegNo,
              model: i.dataValues.model,
              fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
              network_type: i.dataValues.network_type,
              min_12v_battery: foundVehicle.x110,
            })
          } else if (foundVehicle.x110 >= 11 && foundVehicle.x110 < 12) {
            min_12v_battery['<12'].push({
              vin: i.VIN.slice(3),
              vehicle_reg_number: i.VehicleRegNo,
              model: i.dataValues.model,
              fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
              network_type: i.dataValues.network_type,
              min_12v_battery: foundVehicle.x110,
            })
          } else if (foundVehicle.x110 >= 12 && foundVehicle.x110 < 13) {
            min_12v_battery['<13'].push({
              vin: i.VIN.slice(3),
              vehicle_reg_number: i.VehicleRegNo,
              model: i.dataValues.model,
              fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
              network_type: i.dataValues.network_type,
              min_12v_battery: foundVehicle.x110,
            })
          } else if (foundVehicle.x110 >= 13 && foundVehicle.x110 < 14) {
            min_12v_battery['<14'].push({
              vin: i.VIN.slice(3),
              vehicle_reg_number: i.VehicleRegNo,
              model: i.dataValues.model,
              fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
              network_type: i.dataValues.network_type,
              min_12v_battery: foundVehicle.x110,
            })
          } else if (foundVehicle.x110 >= 14 && foundVehicle.x110 < 15) {
            min_12v_battery['<15'].push({
              vin: i.VIN.slice(3),
              vehicle_reg_number: i.VehicleRegNo,
              model: i.dataValues.model,
              fleet_name: i["Clients"].map((client) => client.dataValues.clientCode).join(","),
              network_type: i.dataValues.network_type,
              min_12v_battery: foundVehicle.x110,
            })
          }

      }
    }
    // return res.json({start_soc, end_soc, min_day_soc, max_day_soc, soh, min_12v_battery})
    return res.json({
      status: true,
      code: 200,
      values: {start_soc, end_soc, min_day_soc, max_day_soc, soh, min_12v_battery, max_inv_temp, max_im_temp, max_battery_temp},
    });

  } catch (error) {
    console.log(error, "err");
    return res.json({
      status: false,
      code: 500,
      values: "Internal Server Error",
    });
  }
}
const rolesapi=async(req,res)=>{
  try {
    await sequelize.sync();
    const data=await AltidashUser.findOne({where:{email:req.body.email},raw: true},)
    data.role_id = data.role_id.split(',').map(id=>parseInt(id));
    if(data.status) {
      return res.json({status: true, code: 200, data:data});
    }
    else{
      return res.json({
        status: false, 
        error: "Unauthorized user"
      })
    }
  } catch (error) {
    return res.json({status: false, code: 500, values: "Internal Server Error"})
  }
}

const distanceFormatter=(object,item)=>{
if(item.distance>=1 && item.distance<=5){
  object['1 to 5 kms'].push(item)
}else if(item.distance>5 && item.distance<=20){
  object['5 to 20 kms'].push(item)
}
else if(item.distance>20 && item.distance<=40){
  object['20 to 40 kms'].push(item)
}
else if(item.distance>40 && item.distance<=60){
  object['40 to 60 kms'].push(item)
}
else if(item.distance>60 && item.distance<=100){
  object['60 to 100 kms'].push(item)
}
else if(item.distance>100 && item.distance<=200){
  object['100 to 200 kms'].push(item)
}
else if(item.distance>200){
  object['>200 kms'].push(item)
}
}

const CustomerDayWiseDistance=async(req,res)=>{
  try {
    let {date}=req.body;
    console.log(date)
    date=moment(date).format('YYYY-MM-DD');
    await sequelize.sync();
    await connection(url);
    Vehicle.belongsToMany(Client, {
      through: ClientVehicle,
      foreignKey: "vid",
    });
    Client.belongsToMany(Vehicle, {
      through: ClientVehicle,
      foreignKey: "cid",
    });

    const vinsQuery =
      await sequelize.query(`select distinct veh.VIN as vin,veh.VehicleRegNo,veh.model,veh.SIMservicePrName,veh.network_type,
    GROUP_CONCAT(DISTINCT cl.ClientFullName SEPARATOR ',') as name,vs.vinserialnum,vs.customer_category from Client cl 
    join ClientVehicle cv on cl.cid = cv.cid 
    join Vehicle veh on cv.vid = veh.vid 
    left join VinSerialNum vs on vs.vehicleId=veh.vid 
    where deleteVehicleStatus=0 and vs.customer_category IN ('Captive' , 'DCO/MLO', 'B2B') and 
    (veh.vin like 'mq/MD9%' or veh.vin like 'mq/P6R%' ) group by veh.vin`);
    dealerVinsList=[]
      VehicleTableData = {};
      vinsQuery[0].map((item) => {
      dealerVinsList.push(item.vin);
      VehicleTableData[item.vin] = item;
    });
    let mongoDataQuery=await VehicleDailyData.aggregate([
      {
        $match:{
          'topic':{
            $in:vinsQuery[0].map(item=>item.vin)
          },
          'date':date,
          x78: "Running",
          x12: {
            $gt: 1,
            $lte: 500
          }
        }
      },{
        $project:{
          '_id':0,
          vin:'$topic',
          distance:'$x12',
          vehicle_reg_number:'$x1',
          end_odo:'$x10',
          soc:'$x55'
        }
      }
    ])
    const captiveDcoDistanceComparison={
      '1 to 5 kms':[],
      '5 to 20 kms':[],
      '20 to 40 kms':[],

      '40 to 60 kms':[],

      '60 to 100 kms':[],
      '100 to 200 kms':[],
      '>200 kms':[]
    }
    const b2bDistanceComparison={
      '1 to 5 kms':[],
      '5 to 20 kms':[],
      '20 to 40 kms':[],

      '40 to 60 kms':[],      '60 to 100 kms':[],
      '100 to 200 kms':[],
      '>200 kms':[]
    }

    let b2bcount = 0;
    let dcocount = 0;

    for(let item of mongoDataQuery){
      if(VehicleTableData.hasOwnProperty(item.vin) && VehicleTableData[item.vin]['customer_category']){
        let category=VehicleTableData[item.vin]['customer_category'] 
        let newItem={
          vin:item.vin.slice(3),
          vehicle_reg_number:
                      VehicleTableData[item["vin"]]["VehicleRegNo"],
          fleet_name: VehicleTableData[item["vin"]]["name"],
          distance: item["distance"],
          soc: item["soc"],
          end_odo: item["odo"],
          network_type: VehicleTableData[item["vin"]]["network_type"],
          customer_category:VehicleTableData[item["vin"]]["customer_category"]
        }

       
       if(category === 'Captive' || category ==='CAPTIVE' || category==='DCO/MLO' ){
        // print(dcocount)
        dcocount++;
        distanceFormatter(captiveDcoDistanceComparison,newItem)
       }else if(category==='B2B'){
        // print(dcocount)
        b2bcount++;
        distanceFormatter(b2bDistanceComparison,newItem)
       }
       else{
        console.log(category)
       }
      }
    }

    console.log(b2bcount)
    console.log(dcocount)



    return res.json({
      status:true,
      code:200,
      b2bDistanceComparison:b2bDistanceComparison,
      captiveDcoDistanceComparison:captiveDcoDistanceComparison
    })
  } catch (error) {
    console.log(error);
    return res.json({status: false, code: 500, values: "Internal Server Error"})
  }
}

module.exports = {
    dashboardApi,
    batteryApi,
    createUser,
    rolesapi,
    CustomerDayWiseDistance
  };