const dealerDetails = require("../../models/dealerDetails");
const dealerMonthly = require("../../models/dealerMonthly");
const VehicleDailyData = require("../../models/vehicleDailyData");
// const ApiError = require('../utils/ApiError');
const moment = require("moment");
const mongoose = require("mongoose");
const { aplToVDD } = require("../../utils/vehicleDailyDataMapping");
const sequelize = require("../../utils/sqldb");
const Vehicle = require("../../models/vehicle");
const { Sequelize, Op } = require("sequelize");
const Client = require("../../models/client");
const ClientVehicle = require("../../models/client-vehicle");
const VehicleSaleStatment = require("../../models/VehicleSaleStatement");

connection = (url) => {
  mongoose.connect(url, { useNewUrlParser: true });
};

const url =
  "mongodb+srv://alti-admin-prod:APL2023ADMIN@mqtt-production.iqeii.mongodb.net/mqttDatabase_aplmq";

const batteryObj = {
  0: "None",
  1: "Lead Acid pack",
  2: "ACME 57 Ah in parallel",
  3: "ACME 78 Ah in parallel",
  4: "EXICOM 75 Ah in parallel V-1.0",
  5: "EXICOM 75 Ah in parallel V-1.1",
  6: "Prana 11.a 216 Ah single pack",
  7: "EXICOM 10 kWh single pack",
  8: "GreenEvolve 200Ah single pack",
  9: "NextCharge 200Ah single pack",
  10: "Exponent pack - 8kWh",
  11: "Prana 11.a 216 Ah - APL BMS",
};

const grossMonthComparableOne = async (date1, date2, dealerVinsList) => {
  try {
    const query = await VehicleDailyData.aggregate([
      {
        $match: {
          date: { $gte: date1, $lte: date2 },
          x12: { $gt: 0, $lte: 500 },
          // x13: { $lt: 70 } ,
          // x14: { $lt: 70 } ,
          // $or: [{ x58: { $ne: ',' } }, { x59: { $ne: ',' } }] ,
          topic: { $in: dealerVinsList },
          // $expr: { $lte: ["$x100", "$x101"] },
          // $or: [{ x58: { $ne: "NA" } }, { x59: { $ne: "NA" } }],
          // x10: { $ne: 'NA' },
          x11: { $ne: "NA" },
          // x101: { $ne: 'NA' },
        },
      },
      {
        $group: {
          _id: null,
          uniqueVinsCount: { $addToSet: "$topic" },
          totalDistanceCovered: { $sum: "$x12" },
          total_co2_saved_ed: {
            $sum: {
              $multiply: [{ $divide: ["$x12", 25] }, 2.64],
            },
          },
        },
      },
      {
        $project: {
          _id: 0,
          uniqueVinsCount: { $size: "$uniqueVinsCount" },
          totalDistanceCovered: "$totalDistanceCovered",
          total_co2_saved_ed: {
            $round: ["$total_co2_saved_ed", 2],
          },
        },
      },
    ]);

    data = {};
    // console.log(query[0]);
    if (query.length) {
      data = {
        dates: date1 + " - " + date2,
        total_vehicles: query[0].uniqueVinsCount,
        total_co2_saved_ed: query[0].total_co2_saved_ed,
        total_distance: query[0].totalDistanceCovered,
      };
    }
    // console.log(data);

    return data;
  } catch (error) {
    return error;
  }
};

const grossMonthComparable = async (req, res) => {
  try {
    const { date1, date2 } = req.params;
    let dateOne = new Date(date1);
    let lastDate = new Date(date2);
    const lastMonthLastDay = moment(lastDate)
      .subtract(1, "months")
      .endOf("month")
      .format("YYYY-MM-DD");
    const lastMonthFirstDay = moment(
      new Date(dateOne.getFullYear(), dateOne.getMonth() - 1, dateOne.getDate())
    ).format("YYYY-MM-DD");
    dateOne = moment(dateOne).format("YYYY-MM-DD");
    lastDate = moment(lastDate).format("YYYY-MM-DD");
    console.log(dateOne, lastDate, lastMonthLastDay, lastMonthFirstDay);
    await connection(url);
    await sequelize.sync();
    Vehicle.belongsToMany(Client, {
      through: ClientVehicle,
      foreignKey: "vid",
    });
    Client.belongsToMany(Vehicle, {
      through: ClientVehicle,
      foreignKey: "cid",
    });

    let data =
      await sequelize.query(`select distinct veh.VIN as vin,veh.VehicleRegNo,veh.model,veh.SIMservicePrName,veh.network_type,
    GROUP_CONCAT(DISTINCT cl.ClientFullName SEPARATOR ',') as name from Client cl 
    join ClientVehicle cv on cl.cid = cv.cid 
    join Vehicle veh on cv.vid = veh.vid where deleteVehicleStatus=0 and 
    (vin like 'mq/MD9%' or vin like 'mq/P6R%' ) group by vin`);
    const dealerVinsList = [],
      vehicleSaleVins = [];
    VehicleTableData = {};
    data[0].map((item) => {
      dealerVinsList.push(item.vin);
      vehicleSaleVins.push(item.vin.slice(3));
      VehicleTableData[item.vin] = item;
    });

    let VehicleSaleStatmentQuery = await VehicleSaleStatment.aggregate([
      { $match: { chassis_no: { $in: vehicleSaleVins } } },
      {
        $project: {
          _id: 0,
          vin: "$chassis_no",
          customer: "$customer",
          city: "$city",
          model: "$model_name",
        },
      },
    ]);
    const VehicleSaleObject = {};
    VehicleSaleStatmentQuery.map((item) => {
      VehicleSaleObject["mq/" + item["vin"]] = item;
    });

    let query = await grossMonthComparableOne(
      dateOne,
      lastDate,
      dealerVinsList
    );

    let query2 = await grossMonthComparableOne(
      lastMonthFirstDay,
      lastMonthLastDay,
      dealerVinsList
    );

    let DistanceAndOdotop = await VehicleDailyData.aggregate([
      {
        $match: {
          date: {
            $gte: dateOne,
            $lte: lastDate,
          },
          topic: { $in: dealerVinsList },
          x12: { $gt: 0, $lte: 500 },
          // x13: { $lt: 70 },
          // x14: { $lt: 70 },
          // $expr: { $lte: ["$x100", "$x101"] },
          // $or: [{ x58: { $ne: "NA" } }, { x59: { $ne: "NA" } }],
        },
      },
      {
        $facet: {
          top10distance: [
            {
              $group: {
                _id: "$topic",
                distance: { $sum: "$x12" },
                vehicle_reg_number: { $last: "$x1" },
              },
            },
            { $sort: { distance: -1 } },
            { $limit: 10 },
          ],

          top10Odo: [
            {
              $group: {
                _id: "$topic",
                odo: { $last: "$x11" },
                vehicle_reg_number: { $last: "$x1" },
              },
            },
            { $sort: { odo: -1 } },
            { $limit: 10 },
          ],

          totalVehicles: [
            {
              $group: {
                _id: "$topic",
                odo: { $last: "$x11" },
                distance: { $sum: "$x12" },
                controller_software_version: { $last: "$x85" },
                display_software_version: { $last: "$x86" },
                battery_type: { $last: "$x96" },
              },
            },
          ],
        },
      },
    ]);
    // maxDistanceTravelledVehicle=DistanceAndOdotop[0].top10distance.map(item=>{
    //   return {
    //     vin:item._id.slice(3),
    //     vehicle_reg_number:VehicleTableData[item._id]['VehicleRegNo'],
    //     dist:item.distance,
    //     name:VehicleTableData[item._id]['name'],
    //     model:VehicleTableData[item._id]['model'],
    //     customer:VehicleSaleObject[item._id]?VehicleSaleObject[item._id]['customer'].trim():null,
    //     city:VehicleSaleObject[item._id]?VehicleSaleObject[item._id]['city'].trim():null
    //   }
    // })
    // end_odo=DistanceAndOdotop[0].top10Odo.map(item=>{
    //   return {
    //     vin:item._id.slice(3),
    //     vehicle_reg_number:VehicleTableData[item._id]['VehicleRegNo'],
    //     odo:item.odo,
    //     name:VehicleTableData[item._id]['name'],
    //     model:VehicleTableData[item._id]['model'],
    //     customer:VehicleSaleObject[item._id]['customer'],
    //     city:VehicleSaleObject[item._id]['city']
    //   }
    // })

    maxDistanceTravelledVehicle = DistanceAndOdotop[0].top10distance.map(
      (item) => {
        const vin = item._id.slice(3);
        const vehicleRegNo = VehicleTableData[item._id]["VehicleRegNo"];
        const dist = Number(item.distance).toFixed(2);
        const name = VehicleTableData[item._id]["name"];
        const model = VehicleTableData[item._id]["model"];

        const customer = VehicleSaleObject[item._id]
          ? VehicleSaleObject[item._id]["customer"].trim()
          : null;
        const city = VehicleSaleObject[item._id]
          ? VehicleSaleObject[item._id]["city"].trim()
          : null;
        const hasVehicleSaleData = VehicleSaleObject[item._id];
        const resultObject = {
          vin,
          vehicle_reg_number: vehicleRegNo,
          dist,
          name,
          model,
          ...(hasVehicleSaleData && { customer }),
          ...(hasVehicleSaleData && { city }),
        };
        return resultObject;
      }
    );

    end_odo = DistanceAndOdotop[0].top10Odo.map((item) => {
      const vin = item._id.slice(3);
      const vehicleRegNo = VehicleTableData[item._id]["VehicleRegNo"];
      const odo = item.odo;
      const name = VehicleTableData[item._id]["name"];
      const model = VehicleTableData[item._id]["model"];
      const customer = VehicleSaleObject[item._id]
        ? VehicleSaleObject[item._id]["customer"].trim()
        : null;
      const city = VehicleSaleObject[item._id]
        ? VehicleSaleObject[item._id]["city"].trim()
        : null;
      const hasVehicleSaleData = VehicleSaleObject[item._id];
      const resultObject = {
        vin,
        vehicle_reg_number: vehicleRegNo,
        odo,
        name,
        model,
        ...(hasVehicleSaleData && { customer }),
        ...(hasVehicleSaleData && { city }),
      };

      return resultObject;
    });

    // console.log(end_odo);

    let splitDate = date1.split("-");
    let created_vehicles = [];
    console.log(Number(splitDate[1]));
    for (const i of data[0]) {
      if (
        Number(splitDate[0]) === Number(i.mfgyear) &&
        Number(splitDate[1]) === Number(i.mfgmonth)
      ) {
        created_vehicles.push({
          vin: i.vin.slice(3),
          veh_re_number: i.VehicleRegNo,
          fleet_name: i.name,
        });
      }
    }

    //  console.log(DistanceAndOdotop+"DistanceAndOdotop")
    let vehiclegreaterThanThousand = DistanceAndOdotop[0].totalVehicles.reduce(
      (acc, val) => {
        return acc + (val.distance >= 1000 ? 1 : 0);
      },
      0
    );
    const vehicles = DistanceAndOdotop[0].totalVehicles.map((item) => {
      const vin = item._id.slice(3);
      const vehicleRegNo = VehicleTableData[item._id]["VehicleRegNo"];
      const odo = item.odo;
      const distance = Number(Number(item.distance).toFixed(2));
      const name = VehicleTableData[item._id]["name"];
      const model = VehicleTableData[item._id]["model"];
      const customer = VehicleSaleObject[item._id]
        ? VehicleSaleObject[item._id]["customer"].trim()
        : null;
      const city = VehicleSaleObject[item._id]
        ? VehicleSaleObject[item._id]["city"].trim()
        : null;
      const hasVehicleSaleData = VehicleSaleObject[item._id];
      const network_type = VehicleTableData[item._id]["network_type"];
      const hw_ver = VehicleTableData[item._id]["hw_ver"];
      const controller_software_version = item.controller_software_version;
      const display_software_version = item.display_software_version;
      const battery_type =
        typeof item.battery_type == "string"
          ? item.battery_type
          : batteryObj[item.battery_type + ""];
      const resultObject = {
        vin,
        vehicle_reg_number: vehicleRegNo,
        distance,
        odo,
        name,
        model,
        network_type,
        hw_ver,
        controller_software_version,
        display_software_version,
        battery_type,
        ...(hasVehicleSaleData && { customer }),
        ...(hasVehicleSaleData && { city }),
      };

      return resultObject;
    });

    console.log(vehicles.length);

    return res.json({
      status: true,
      data: {
        trendsData: { presentMonth: query, lastMonth: query2 },
        maxDistanceTravelledVehicle,
        end_odo,
        vehiclegreaterThanThousand,
        vehicles,
        created_vehicles,
      },
    });
  } catch (error) {
    console.log(error);
    return res.json({ status: false, data: error });
  }
};

const customWeekWiseController = async (req, res) => {
  try {
    const { date1, date2 } = req.params;
    let dateOne = new Date(date1);
    let lastDate = new Date(date2);
    dateOne = moment(dateOne).format("YYYY-MM-DD");
    lastDate = moment(lastDate).format("YYYY-MM-DD");
    console.log(dateOne, lastDate);
    await connection(url);
    await sequelize.sync();
    Vehicle.belongsToMany(Client, {
      through: ClientVehicle,
      foreignKey: "vid",
    });
    Client.belongsToMany(Vehicle, {
      through: ClientVehicle,
      foreignKey: "cid",
    });

    let data =
      await sequelize.query(`select distinct veh.VIN as vin,veh.VehicleRegNo,veh.model,veh.SIMservicePrName,veh.network_type,
    GROUP_CONCAT(DISTINCT cl.ClientFullName SEPARATOR ',') as name from Client cl 
    join ClientVehicle cv on cl.cid = cv.cid 
    join Vehicle veh on cv.vid = veh.vid where deleteVehicleStatus=0 and 
    (vin like 'mq/MD9%' or vin like 'mq/P6R%' ) group by vin`);
    const dealerVinsList = [],
      vehicleSaleVins = [];
    VehicleTableData = {};
    data[0].map((item) => {
      dealerVinsList.push(item.vin);
      vehicleSaleVins.push(item.vin.slice(3));
      VehicleTableData[item.vin] = item;
    });

    const query = await VehicleDailyData.aggregate([
      {
        $match: {
          date: { $gte: dateOne, $lte: lastDate },
          x12: { $gt: 0, $lte: 700 },
          // x13: { $lt: 70 } ,
          // x14: { $lt: 70 } ,
          // $or: [{ x58: { $ne: ',' } }, { x59: { $ne: ',' } }] ,
          topic: { $in: dealerVinsList },
          // $expr: { $lte: ["$x100", "$x101"] },
          // $or: [{ x58: { $ne: "NA" } }, { x59: { $ne: "NA" } }],
          // x10: { $ne: 'NA' },
          x11: { $ne: "NA" },
          // x101: { $ne: 'NA' },
        },
      },

      {
        $facet: {
          DistanceComparison: [
            {
              $group: {
                _id: "$date",
                distance: {
                  $sum: "$x12",
                },
                //  maxDistance:{$max:'$x12'},
                maxDistance: {
                  $push: {
                    x12: "$x12",
                    topic: "$topic",
                  },
                },
              },
            },

            { $sort: { _id: 1 } },
            {
              $group: {
                _id: null,
                date: { $push: "$_id" },
                distance: { $push: "$distance" },
                // maxDistance:{$push:'$maxDistance'},
                // efficiency:{$push:'$efficiency'},
                maxDistance: {
                  $push: {
                    $reduce: {
                      input: "$maxDistance",
                      initialValue: { x12: Number.MIN_VALUE },
                      in: {
                        $cond: {
                          if: { $gt: ["$$this.x12", "$$value.x12"] },
                          then: {
                            x12: "$$this.x12",
                            topic: "$$this.topic",
                            date: "$_id",
                          },
                          else: "$$value",
                        },
                      },
                    },
                  },
                },
              },
            },
          ],
          vehicleCount: [
            {
              $group: {
                _id: "$date",
                vehicleNum: { $addToSet: "$topic" },
              },
            },
            { $sort: { _id: 1 } },
            {
              $project: {
                _id: 0,
                date: "$_id",
                count: { $size: "$vehicleNum" },
              },
            },
            {
              $group: {
                _id: null,
                date: { $push: "$date" },
                vehicleCount: { $push: "$count" },
              },
            },
          ],
          efficiencyQuery: [
            { $match: { x35: { $gte: 30, $lte: 200 } } },
            {
              $group: {
                _id: "$date",
                efficiency: { $avg: "$x35" },
              },
            },

            { $sort: { _id: 1 } },
            {
              $group: {
                _id: null,
                date: { $push: "$_id" },
                efficiency: { $push: "$efficiency" },
              },
            },
          ],
        },
      },
    ]);

    if (!query[0].DistanceComparison.length) {
      return res.json({ status: false, code: 401, data: "Invalid Parameter" });
    }

    const dates = query[0] ? query[0].DistanceComparison[0].date : [],
      distance = query[0] ? query[0].DistanceComparison[0].distance : [],
      co2_saved_daywise = query[0]
        ? query[0].DistanceComparison[0].distance.map((item) =>
            ((item * 2.64) / 25).toFixed(2)
          )
        : [],
      maxDistance = query[0]
        ? query[0].DistanceComparison[0].maxDistance.map((item) => {
            return {
              distance: item.x12,
              vin: item.topic.slice(3),
              date: item.date,
              vehicle_reg_number: VehicleTableData[item.topic]["VehicleRegNo"],
              name: VehicleTableData[item.topic]["name"],
            };
          })
        : [],
      efficiency = query[0]
        ? query[0].efficiencyQuery[0].efficiency.map((item) => item.toFixed(2))
        : [],
      vehiclecount = query[0] ? query[0].vehicleCount[0].vehicleCount : [];

    return res.json({
      status: true,
      code: 200,
      data: {
        distance_comparison: [dates, distance],
        day_wise_vehicle_comparison: [dates, vehiclecount],
        efficiency: [dates, efficiency],
        co2_saved_daywise: [dates, co2_saved_daywise],
        maxDistance: maxDistance,
      },
    });
  } catch (error) {
    console.log(error);
    return res.json({ status: false, code: 500, data: error });
  }
};

function getLastDayOfMonth(dateString) {
  const date = new Date(dateString);
  const year = date.getFullYear();
  const month = date.getMonth() + 1; 
  const lastDay = new Date(year, month, 0).getDate();
  return lastDay;
}

const grossMonthControllerUnComparable = async (req, res) => {
  try {
    const { date1, date2 } = req.params;
    let dateOne = new Date(date1);
    let lastDate = new Date(date2);
    dateOne = moment(dateOne).format("YYYY-MM-DD");
    lastDate = moment(lastDate).format("YYYY-MM-DD");
    await connection(url);
    await sequelize.sync();
    Vehicle.belongsToMany(Client, {
      through: ClientVehicle,
      foreignKey: "vid",
    });
    Client.belongsToMany(Vehicle, {
      through: ClientVehicle,
      foreignKey: "cid",
    });

    let data =
      await sequelize.query(`select distinct veh.VIN as vin,veh.VehicleRegNo,veh.model,veh.SIMservicePrName,veh.network_type,vs.type,
  GROUP_CONCAT(DISTINCT cl.ClientFullName SEPARATOR ',') as name from Client cl 
  join ClientVehicle cv on cl.cid = cv.cid 
  join Vehicle veh on cv.vid = veh.vid 
  left join VinSerialNum vs on vs.vehicleId=veh.vid 
  where deleteVehicleStatus=0 and 
  (veh.vin like 'mq/MD9%' or veh.vin like 'mq/P6R%' ) group by veh.vin`);
    const dealerVinsList = [],
      vehicleSaleVins = [];
    VehicleTableData = {};
    data[0].map((item) => {
      dealerVinsList.push(item.vin);
      vehicleSaleVins.push(item.vin.slice(3));
      VehicleTableData[item.vin] = item;
    });
    let numberOfDaysInMonth=getLastDayOfMonth(lastDate);
    console.log(lastDate,numberOfDaysInMonth);
    let query = await VehicleDailyData.aggregate([
      {
        $match: {
          date: { $gte: dateOne, $lte: lastDate },
          x12: { $gt: 0, $lte: 500 },
          // x13: { $lt: 70 } ,
          // x14: { $lt: 70 } ,
          // $or: [{ x58: { $ne: ',' } }, { x59: { $ne: ',' } }] ,
          topic: { $in: dealerVinsList },
          // $expr: { $lte: ["$x100", "$x101"] },
          // $or: [{ x58: { $ne: "NA" } }, { x59: { $ne: "NA" } }],
          // x10: { $ne: 'NA' },
          x11: { $ne: "NA" },
          // x101: { $ne: 'NA' },
        },
      },

      {
        $facet: {
          DistanceData: [
            {
              $group: {
                _id: "$topic",
                distance: { $sum: "$x12" },
                vehicle_reg_number: { $last: "$x1" },
                vin: { $last: "$topic" },
                end_odo: { $last: "$x11" },
                // soc:{$last:'$x55'}
              },
            },
            {
              $group: {
                _id: {
                  $switch: {
                    branches: [
                      {
                        case: {
                          $and: [
                            { $gte: ["$distance", 0] },
                            { $lte: ["$distance", 1000] },
                          ],
                        },
                        then: "0 to 1000 kms",
                      },
                      {
                        case: {
                          $and: [
                            { $gt: ["$distance", 1000] },
                            { $lte: ["$distance", 2000] },
                          ],
                        },
                        then: "1000 to 2000 kms",
                      },
                      {
                        case: {
                          $and: [
                            { $gt: ["$distance", 2000] },
                            { $lte: ["$distance", 3000] },
                          ],
                        },
                        then: "2000 to 3000 kms",
                      },
                      {
                        case: {
                          $and: [
                            { $gt: ["$distance", 3000] },
                            { $lte: ["$distance", 4000] },
                          ],
                        },
                        then: "3000 to 4000 kms",
                      },
                      {
                        case: {
                          $and: [
                            { $gt: ["$distance", 4000] },
                            { $lte: ["$distance", 5000] },
                          ],
                        },
                        then: "4000 to 5000 kms",
                      },
                      { case: { $gt: ["$distance", 5000] }, then: ">5000 kms" },
                    ],
                    default: "Unknown",
                  },
                },
                data: {
                  $push: {
                    vin: "$vin",
                    vehicle_reg_number: "$vehicle_reg_number",
                    distance: "$distance",
                    end_odo: "$end_odo",
                  },
                },
                // data: { $push: { vin: '$vin', vehicle_reg_number: '$vehicle_reg_number', distance: '$distance'} },
              },
            },
          ],
          VehicleCount: [
            {
              $group: {
                _id: "$topic",
                vin: { $first: "$topic" },
                // vehicle_reg_number: { $first: "$x1" },
                // fleet_name: { $first: "$c.name" },
                count: { $sum: 1 },
              },
            },
            {
              $match: { count: { $gte: 21, $lte: numberOfDaysInMonth } },
            },
            {
              $group: {
                _id: "$count",
                vehicles: { $push: "$vin" },
              },
            },
            { $project: { count: "$_id", vehicles: 1, _id: 0 } },
            { $sort: { count: 1 } },
          ],
        },
      },
    ]);
    // return res.json({query})
    // return res.json(query)
    // if(!query[0].VehicleCount.length){
    //   return res.json({status:false,
    //   code:401,
    // data:"InValid Parameter"})
    // }
    // return res.json({query:query})

    const DistanceData = {
      "0 to 1000 kms": [],
      "1000 to 2000 kms": [],
      "2000 to 3000 kms": [],
      "3000 to 4000 kms": [],
      "4000 to 5000 kms": [],
      ">5000 kms": [],
    };
    const TezDistanceData={
      "0 to 1000 kms": [],
      "1000 to 2000 kms": [],
      "2000 to 3000 kms": [],
      "3000 to 4000 kms": [],
      "4000 to 5000 kms": [],
      ">5000 kms": [],
    }
    const BhaiDistanceData={
      "0 to 1000 kms": [],
      "1000 to 2000 kms": [],
      "2000 to 3000 kms": [],
      "3000 to 4000 kms": [],
      "4000 to 5000 kms": [],
      ">5000 kms": [],
    }
    const RahiDistanceData={
      "0 to 1000 kms": [],
      "1000 to 2000 kms": [],
      "2000 to 3000 kms": [],
      "3000 to 4000 kms": [],
      "4000 to 5000 kms": [],
      ">5000 kms": [],
    }
    const NeEvDistanceData={
      "0 to 1000 kms": [],
      "1000 to 2000 kms": [],
      "2000 to 3000 kms": [],
      "3000 to 4000 kms": [],
      "4000 to 5000 kms": [],
      ">5000 kms": [],
    }
    vehiclecount = {};
    query[0].DistanceData.map((item) => {
      DistanceData[item._id] = item.data.map((item1) => {
        if(VehicleTableData[item1.vin]['type']=='TEZ'){
          TezDistanceData[item._id].push({...item1,
            vin: item1.vin.slice(3),
            distance: Number(Number(item1.distance).toFixed(2)),
            fleet_name: VehicleTableData[item1.vin]["name"],
            network_type: VehicleTableData[item1.vin]["network_type"],
            model:VehicleTableData[item1.vin]['type']
          })
        }else if(VehicleTableData[item1.vin]['type']=='BHAI'){
          BhaiDistanceData[item._id].push({...item1,
            vin: item1.vin.slice(3),
            distance: Number(Number(item1.distance).toFixed(2)),
            fleet_name: VehicleTableData[item1.vin]["name"],
            network_type: VehicleTableData[item1.vin]["network_type"],
            model:VehicleTableData[item1.vin]['type']
          })
        }else if(VehicleTableData[item1.vin]['type']=='RAHI'){
          RahiDistanceData[item._id].push({...item1,
            vin: item1.vin.slice(3),
            distance: Number(Number(item1.distance).toFixed(2)),
            fleet_name: VehicleTableData[item1.vin]["name"],
            network_type: VehicleTableData[item1.vin]["network_type"],
            model:VehicleTableData[item1.vin]['type']
          })
        }
        else if(VehicleTableData[item1.vin]['type']=='neEv'){
          NeEvDistanceData[item._id].push({...item1,
            vin: item1.vin.slice(3),
            distance: Number(Number(item1.distance).toFixed(2)),
            fleet_name: VehicleTableData[item1.vin]["name"],
            network_type: VehicleTableData[item1.vin]["network_type"],
            model:VehicleTableData[item1.vin]['type']
          })
        }
        // console.log(VehicleTableData[item1.vin],'item')
        return {
          ...item1,
          vin: item1.vin.slice(3),
          distance: Number(Number(item1.distance).toFixed(2)),
          fleet_name: VehicleTableData[item1.vin]["name"],
          network_type: VehicleTableData[item1.vin]["network_type"],
          model:VehicleTableData[item1.vin]['type']
        };
      });
      //  console.log(item._id,item.data.length);
    });
    RangeObject = {};
    query[0].VehicleCount.map((item) => {
      vehiclecount[item.count + " days"] = item.vehicles.map((item1) =>
        item1.slice(3)
      );
      if (!RangeObject.hasOwnProperty(item.count + " days")) {
        RangeObject[item.count + " days"] = [];
      }
      RangeObject[item.count + " days"] = item.vehicles.map((item1) => {
        return {
          vin: item1.slice(3),
          vehicle_reg_number: VehicleTableData[item1]["VehicleRegNo"],
          fleet_name: VehicleTableData[item1]["name"],
          network_type: VehicleTableData[item1]["network_type"],
        };
      });
    });

    rangeObj = [
      Object.keys(vehiclecount),
      Object.values(vehiclecount).map((item) => item.length),
    ];
    return res.json({
      status: true,
      code: 200,
      data: { DistanceData,TezDistanceData,BhaiDistanceData,RahiDistanceData,NeEvDistanceData,vehiclecount,RangeObject, rangeObj},
    });
  } catch (error) {
    console.log(error);
    return res.json({ status: false, code: 500, data: error });
  }
};

const grossCustomWeekWiseController = async (req, res) => {
  try {
    const { date1, date2 } = req.params;
    let dateOne = new Date(date1);
    let lastDate = new Date(date2);
    const date = new Date(date1);
    const day = date.getDay();
    const lastWeekLastDay = moment(
      new Date(date.getFullYear(), date.getMonth(), date.getDate() - 1)
    ).format("YYYY-MM-DD");
    const lastWeekFirstDay = moment(
      new Date(date.getFullYear(), date.getMonth(), date.getDate() - 7)
    ).format("YYYY-MM-DD");
    dateOne = moment(dateOne).format("YYYY-MM-DD");
    lastDate = moment(lastDate).format("YYYY-MM-DD");
    // console.log(dateOne,lastDate,lastMonthLastDay,lastMonthFirstDay)
    await connection(url);
    await sequelize.sync();
    Vehicle.belongsToMany(Client, {
      through: ClientVehicle,
      foreignKey: "vid",
    });
    Client.belongsToMany(Vehicle, {
      through: ClientVehicle,
      foreignKey: "cid",
    });

    let data =
      await sequelize.query(`select distinct veh.VIN as vin,veh.VehicleRegNo,veh.model,veh.SIMservicePrName,veh.network_type,
GROUP_CONCAT(DISTINCT cl.ClientFullName SEPARATOR ',') as name from Client cl 
join ClientVehicle cv on cl.cid = cv.cid 
join Vehicle veh on cv.vid = veh.vid where deleteVehicleStatus=0 and 
(vin like 'mq/MD9%' or vin like 'mq/P6R%' ) group by vin`);
    const dealerVinsList = [],
      vehicleSaleVins = [];
    VehicleTableData = {};
    data[0].map((item) => {
      dealerVinsList.push(item.vin);
      vehicleSaleVins.push(item.vin.slice(3));
      VehicleTableData[item.vin] = item;
    });
    let VehicleSaleStatmentQuery = await VehicleSaleStatment.aggregate([
      { $match: { chassis_no: { $in: vehicleSaleVins } } },
      {
        $project: {
          _id: 0,
          vin: "$chassis_no",
          customer: "$customer",
          city: "$city",
          model: "$model_name",
        },
      },
    ]);
    const VehicleSaleObject = {};
    VehicleSaleStatmentQuery.map((item) => {
      VehicleSaleObject["mq/" + item["vin"]] = item;
    });
    let presentquery = await grossMonthComparableOne(
      dateOne,
      lastDate,
      dealerVinsList
    );
    let yesterdayquery = await grossMonthComparableOne(
      lastWeekFirstDay,
      lastWeekLastDay,
      dealerVinsList
    );

    if (
      !Object.keys(presentquery).length ||
      !Object.keys(yesterdayquery).length
    ) {
      //|| moment(date2).diff(moment(date1),'days') !==6
      // console.log(moment(date1).diff(moment(date2),'days'))
      return res.json({
        status: false,
        code: 401,
        data: "Invalid input parameter",
      });
    }

    presentDayQuery = { dates: dateOne + " - " + lastDate, ...presentquery };
    yesterDayQuery = {
      dates: lastWeekFirstDay + " - " + lastWeekLastDay,
      ...yesterdayquery,
    };

    let DistanceAndOdotop = await VehicleDailyData.aggregate([
      {
        $match: {
          date: {
            $gte: dateOne,
            $lte: lastDate,
          },
          topic: { $in: dealerVinsList },
          x12: { $gt: 0, $lte: 500 },
        },
      },
      {
        $facet: {
          top10distance: [
            {
              $group: {
                _id: "$topic",
                distance: { $sum: "$x12" },
                vehicle_reg_number: { $last: "$x1" },
              },
            },
            { $sort: { distance: -1 } },
            { $limit: 10 },
          ],
          top10Odo: [
            {
              $group: {
                _id: "$topic",
                odo: { $last: "$x11" },
                vehicle_reg_number: { $last: "$x1" },
              },
            },
            { $sort: { odo: -1 } },
            { $limit: 10 },
          ],
          distance_comparison: [
            {
              $group: {
                _id: "$topic",
                distance: { $sum: "$x12" },
                vehicle_reg_number: { $last: "$x1" },
                end_odo: { $last: "$x11" },
                vin: { $last: "$topic" },
              },
            },
            {
              $group: {
                _id: {
                  $switch: {
                    branches: [
                      {
                        case: {
                          $and: [
                            { $gte: ["$distance", 0] },
                            { $lte: ["$distance", 50] },
                          ],
                        },
                        then: "0 to 50 kms",
                      },
                      {
                        case: {
                          $and: [
                            { $gt: ["$distance", 50] },
                            { $lte: ["$distance", 100] },
                          ],
                        },
                        then: "50 to 100 kms",
                      },
                      {
                        case: {
                          $and: [
                            { $gt: ["$distance", 100] },
                            { $lte: ["$distance", 300] },
                          ],
                        },
                        then: "100 to 300 kms",
                      },
                      {
                        case: {
                          $and: [
                            { $gt: ["$distance", 300] },
                            { $lte: ["$distance", 500] },
                          ],
                        },
                        then: "300 to 500 kms",
                      },
                      {
                        case: {
                          $and: [
                            { $gt: ["$distance", 500] },
                            { $lte: ["$distance", 1000] },
                          ],
                        },
                        then: "500 to 1000 kms",
                      },
                      { case: { $gt: ["$distance", 1000] }, then: ">1000 kms" },
                    ],
                    default: "Unknown",
                  },
                },
                data: {
                  $push: {
                    vin: "$vin",
                    vehicle_reg_number: "$vehicle_reg_number",
                    distance: "$distance",
                    end_odo: "$end_odo",
                  },
                },
              },
            },
          ],
          total_vehicles: [
            {
              $group: {
                _id: "$topic",
                distance: { $sum: "$x12" },
                end_odo: { $last: "$x11" },
                soc: { $last: "$x55" },
                display_sotware_version: { $last: "$x86" },
                controller_software_version: { $last: "$x85" },
                battery_type: { $last: "$x96"}
              },
            },
          ],
        },
      },
    ]);

    // return res.json(DistanceAndOdotop);

    greaterThan100 = 0;

    maxDistanceTravelledVehicle = DistanceAndOdotop[0].top10distance.map(
      (item) => {
        return {
          vin: item._id.slice(3),
          vehicle_reg_number: VehicleTableData[item._id]["VehicleRegNo"],
          dist: Number(item.distance).toFixed(2),
          name: VehicleTableData[item._id]["name"],
          model: VehicleTableData[item._id]["model"],
          customer: VehicleSaleObject[item._id]
            ? VehicleSaleObject[item._id]["customer"].trim()
            : null,
          city: VehicleSaleObject[item._id]
            ? VehicleSaleObject[item._id]["city"].trim()
            : null,
        };
      }
    );

    end_odo = DistanceAndOdotop[0].top10Odo.map((item) => {
      return {
        vin: item._id.slice(3),
        vehicle_reg_number: VehicleTableData[item._id]["VehicleRegNo"],
        odo: item.odo,
        name: VehicleTableData[item._id]["name"],
        model: VehicleTableData[item._id]["model"],
        customer: VehicleSaleObject[item._id]
          ? VehicleSaleObject[item._id]["customer"].trim()
          : null,
        city: VehicleSaleObject[item._id]
          ? VehicleSaleObject[item._id]["city"].trim()
          : null,
      };
    });

    distance_comparison_chart = {
      "0 to 50 kms": [],
      "50 to 100 kms": [],
      "100 to 300 kms": [],
      "300 to 500 kms": [],
      "500 to 1000 kms": [],
      ">1000 kms": [],
    };

    DistanceAndOdotop[0].distance_comparison.map((item) => {
      distance_comparison_chart[item._id] = item.data.map((item1) => {
        return {
          vin: item1.vin.slice(3),
          vehicle_reg_number: VehicleTableData[item1.vin]["VehicleRegNo"],
          distance: Number(Number(item1.distance).toFixed(2)),
          end_odo: item1.end_odo,
          network_type: VehicleTableData[item1.vin]["network_type"],
          name: VehicleTableData[item1.vin]["name"],
          model: VehicleTableData[item1.vin]["model"],
          customer: VehicleSaleObject[item1.vin]
            ? VehicleSaleObject[item1.vin]["customer"].trim()
            : null,
          city: VehicleSaleObject[item1.vin]
            ? VehicleSaleObject[item1.vin]["city"].trim()
            : null,
        };
      });
    });

    vehicles = DistanceAndOdotop[0].total_vehicles.map((item) => {
      if (item.distance >= 250) {
        greaterThan100++;
      }
      return {
        vin: item._id.slice(3),
        vehicle_reg_number: VehicleTableData[item._id]["VehicleRegNo"],
        total_distance: Number(Number(item.distance).toFixed(2)),
        odo: item.end_odo,
        soc: item.soc,
        name: VehicleTableData[item._id]["name"],
        battery_type: item.battery_type,
        network_type: VehicleTableData[item._id]["network_type"],
        model: VehicleTableData[item._id]["model"],
        display_sotware_version: item.display_sotware_version,
        controller_software_version: item.controller_software_version,
      };
    });
    console.log(vehicles.length);
    trendsData = {
      previousweek: { ...yesterDayQuery },
      currentweek: { ...presentDayQuery },
    };
    uncomparableObj = {
      total_displays: 0,
      maxDistanceTravelledVehicle,
      end_odo,
      distance_comparison_chart,
      vehicles,
      greaterThan100,
      topfiveDriveScores: [],
      protocol_type: {},
    };

    return res.json({
      status: true,
      code: 200,
      data: { trendsData, ...uncomparableObj },
    });

    //  return res.json({DistanceAndOdotop,query});
  } catch (error) {
    console.log(error);
    return res.json({ status: false, data: error });
  }
};

module.exports = {
  grossMonthComparable,
  customWeekWiseController,
  grossMonthControllerUnComparable,
  grossCustomWeekWiseController,
};
