const Client = require("../../models/client");
const ClientVehicle = require("../../models/client-vehicle");
const Vehicle = require("../../models/vehicle");
const VehicleDailyData = require("../../models/vehicleDailyData");
const sequelize = require("../../utils/sqldb");
const { Op } = require("sequelize");
const moment = require("moment");
const { stateCodes } = require("../../utils/constants");

const url =
  "mongodb+srv://alti-admin-prod:APL2023ADMIN@mqtt-production.iqeii.mongodb.net/mqttDatabase_aplmq";

connection = (url) => {
  mongoose.connect(url, { useNewUrlParser: true });
};

const getAllVehiclesDetails = async (req, res) => {
  Client.belongsToMany(Vehicle, { through: ClientVehicle, foreignKey: "cid" });
  Vehicle.belongsToMany(Client, { through: ClientVehicle, foreignKey: "vid" });

  await connection(url);

  try {
    await sequelize.sync();

    let segmentResult = await VehicleDailyData.aggregate([
      {
        $match: {
          x78: "Running",
          x11: { $lte: 200000 },
        },
      },
      {
        $sort: {
          date: -1, // Sort by date in descending order to get the latest dates first
        },
      },
      {
        $group: {
          _id: "$topic",
          end_odo: { $first: "$x11" },
          last_driven: { $first: "$date" },
        },
      },
    ]).allowDiskUse(true);;

    if (!segmentResult.length) {
      return res.status(200).json({
        status: false,
        data: [],
      });
    }

    vehiclesList = await Vehicle.findAll({
      attributes: ["VIN", "VehicleRegNo"],
      where: {
        deleteVehicleStatus: 0,
        [Op.or]: [
          { VIN: { [Op.like]: "mq/MD9%" } },
          { VIN: { [Op.like]: "mq/P6R%" } },
        ],
        VIN: {
          [Op.in]: segmentResult.map((item) => item._id),
        },
      },
      nest: true,
      include: [
        {
          model: Client,
          attributes: ["clientCode"],
          through: { attributes: [] },
        },
      ],
    });

    let result = [];
    let odoSum = 0;
    const uniqueReg = new Set();
    const regNumbers = [];
    let registeredVehicles = [];
    let registered = /^(?!MD9|P6R)[A-Za-z]{2}\d.*$/;

    for (const i of vehiclesList) {
      const foundVehicle = segmentResult.find((score) => score._id === i.VIN);
      // console.log(foundVehicle);
      if (foundVehicle) {
        result.push({
          vin: i.VIN.slice(3),
          vehicle_reg_number: i.VehicleRegNo,
          odometer: foundVehicle.end_odo,
          last_pinged: foundVehicle.last_driven,
          fleet: i["Clients"]
            .map((client) => client.dataValues.clientCode)
            .join(","),
        });
        odoSum += foundVehicle.end_odo ? foundVehicle.end_odo : 0;
        let regex = /^[a-zA-Z]{2}\d{2}/;

        const firstFourCharacters = i.VehicleRegNo.slice(0, 4);
        if (
          !uniqueReg.has(firstFourCharacters) &&
          !firstFourCharacters.startsWith("P6") &&
          !firstFourCharacters.startsWith("MD9") &&
          !firstFourCharacters.startsWith("APL") &&
          regex.test(firstFourCharacters)
        ) {
          uniqueReg.add(firstFourCharacters);
          regNumbers.push(firstFourCharacters);
        }
      }

      if (registered.test(i.VehicleRegNo)) {
        registeredVehicles.push({
          vin: i.VIN.slice(3),
          vehicle_reg_number: i.VehicleRegNo,
          fleet: i["Clients"]
            .map((client) => client.dataValues.clientCode)
            .join(","),
        });
      }
    }

    console.log(result.length);

    let x = odoSum / 25;
    let co2reduced = Number(((x * 2.64) / 1000).toFixed(2));

    let treeYearPlanted = (Number(co2reduced) / 22) * 1000;

    let cubbonParksNo = treeYearPlanted / 6000;

    let states = vehiclesList.reduce((acc, cum) => {
      let code = cum.VehicleRegNo.slice(0, 2);
      let state = stateCodes.find((veh) => veh.code === code);
      return acc.findIndex((vehicle) => vehicle.code === code) > -1 ||
        state === undefined
        ? acc
        : [...acc, { state: state.state, code }];
    }, []);

    return res.json({
      status: true,
      code: 200,
      values: {
        vehicle: result,
        sumEndOdo: odoSum.toFixed(2),
        co2reduced,
        treeYearPlanted: Math.round(treeYearPlanted),
        cubbonParksNo: Number(cubbonParksNo).toFixed(2),
        regNumbers,
        states,
        registeredVehicles,
      },
    });
  } catch (error) {
    console.log(error, "err");
    return res.json({
      status: false,
      code: 500,
      values: "Internal Server Error",
    });
  }
};

const rtoLocations = async (req, res) => {
  await connection(url);

  try {
    let result;

    let segmentResult = await VehicleDailyData.aggregate([
      {
        $match: {
          x1: {
            $regex:
              /^(KA53|MH12|MH14|KA04|MH43|KL41|TN99|AP39|TN66|TN37|TS08|RJ14|KL07|JH05|KL40|KA09|JH01|TN09|DL51|KA03|HR55|DL1L|DL 5|DL 1|TN12|MH03|TN07|TN38|TN13|KA20|WB25|TS07|MH47|TS09|TN05|MH02|GJ01|UP16|OD02|TS10|PB10|UP32|TN22|MH40|MH04|MH29|KL32|KL08|KL46|KL11|KL17|UP78|TN14|GJ27|MH46|TN01|TN02|MP04|TN21|TN36|TN60|GJ19|GJ05|MH48|MH01|TS17|MH42|CH01|TN11|TN10|KA01|GJ38|MH11|MH10|PB65|BR01|BR21|TN40|UP85|MH09|TN39|KL04|TS15|KA32|KA56|AS01|KA39|MH05|GA07|AS23|AS12|TN29|WB19|WB29|WB23|GJ06|GJ16|TN69|HR38|TN25|TS24|TN18|TS04|TN70|TN57|TN04|TN83|TN19|WB15|TN42|TN59|TN58|WB11|TN84|KL64|GJ13|GA03|KL43|TN20|MH49|MP48|MH36|MH31|RJ36|UP41|UP43|TN45|TN86|TN63|TN64|UP33|TN23|MP50|GJ39|MP28|OD05|TN87|TN94|TN15|RJ20|KA25|KA11|TN78|TS02|TN67|KL84)/,
          },
          x78: "Running",
          x59: { $ne: "NA" },
        },
      },
      {
        $group: {
          _id: "$x1",
          regNo: { $last: "$x1" },
          startGeoCode: { $last: "$x58" },
          endGeoCode: { $last: "$x59" },
          timeStamp: { $last: "$x82" },
        },
      },
    ]);

    if (!segmentResult.length) {
      return res.status(200).json({
        status: false,
        data: [],
      });
    }
    segmentResult.sort((a, b) => moment(b.timeStamp) - moment(a.timeStamp));
    // let clusteredFilters = [];
    result = segmentResult.reduce((acc, cum) => {
      if (
        acc.findIndex(
          (item) => item.regNo.slice(0, 4) === cum.regNo.slice(0, 4)
        ) === -1
      ) {
        return [...acc, cum];
      } else return acc;
    }, []);

    // console.log(result.length);

    return res.json({
      status: true,
      code: 200,
      data: result,
    });
  } catch (error) {
    console.log(error, "err");
    return res.json({
      status: false,
      code: 500,
      values: "Internal Server Error",
    });
  }
};

const getDistance = async (req, res) => {
  Client.belongsToMany(Vehicle, { through: ClientVehicle, foreignKey: "cid" });
  Vehicle.belongsToMany(Client, { through: ClientVehicle, foreignKey: "vid" });

  await connection(url);

  try {
    await sequelize.sync();
    console.log('log1')

    let vehiclesList = await Vehicle.findAll({
      attributes: ["VIN", "VehicleRegNo"],
      where: {
        deleteVehicleStatus: 0,
        [Op.or]: [
          { VIN: { [Op.like]: "mq/MD9%" } },
          { VIN: { [Op.like]: "mq/P6R%" } },
        ],
        
      },
      nest: true,
      include: [
        {
          model: Client,
          attributes: ["clientCode"],
          through: { attributes: [] },
        },
      ],
    });

    console.log('log2')


    if (!vehiclesList.length) {
      return res.status(200).json({
        status: false,
        data: [],
      });
    }

    let vehicles = vehiclesList.map(item=>item.dataValues.VIN);

    console.log('log3')


    let segmentResult = await VehicleDailyData.aggregate([
      {
        $match: {
          x78: "Running",
          x11: { $lte: 200000 },
        },
      },
      {
        $sort: {
          date: -1
        }
      },
      {
        $group: {
          _id: "$topic",
          x11: {$first: "$x11"},
          date: {$first: "$date"}
        }
      },
     
    ]);

    console.log('log4')


    if (!segmentResult.length) {
      return res.status(200).json({ 
        status: false,
        data: [],
      });
    }
    let count = 0;

    // return segmentResult;

    // return res.json({segmentResult})
    let result = segmentResult.reduce((acc, cur)=>{
      if(vehicles.includes(cur._id) && cur.x11){
        count++;
        return acc+cur.x11;
      }
      else{
        return acc;
      }
    },0);

    console.log("count"+count)

    return res.json({
      status: true,
      code: 200,
      data: {
        distance: parseInt(result)
      }
    });
  } catch (error) {
    console.log(error, "err");
    return res.json({
      status: false,
      code: 500,
      values: "Internal Server Error",
    });
  }
};

module.exports = { getAllVehiclesDetails, rtoLocations, getDistance };
