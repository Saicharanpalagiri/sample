const dealerDetails = require("../../models/dealerDetails");
const dealerMonthly = require("../../models/dealerMonthly");
const VehicleDailyData = require("../../models/vehicleDailyData");
// const ApiError = require('../utils/ApiError');
const moment = require("moment");
const mongoose = require("mongoose");
const { aplToVDD } = require("../../utils/vehicleDailyDataMapping");
const sequelize = require("../../utils/sqldb");
const Vehicle = require("../../models/vehicle");
const { Sequelize, Op } = require("sequelize");
const Client = require("../../models/client");
const ClientVehicle = require("../../models/client-vehicle");
const VehicleSaleStatment = require("../../models/VehicleSaleStatement");
const { errorMonitor } = require("form-data");

connection = (url) => {
  mongoose.connect(url, { useNewUrlParser: true });
};

const url =
  "mongodb+srv://alti-admin-prod:APL2023ADMIN@mqtt-production.iqeii.mongodb.net/mqttDatabase_aplmq";

const batteryObj = {
  0: "None",
  1: "Lead Acid pack",
  2: "ACME 57 Ah in parallel",
  3: "ACME 78 Ah in parallel",
  4: "EXICOM 75 Ah in parallel V-1.0",
  5: "EXICOM 75 Ah in parallel V-1.1",
  6: "Prana 11.a 216 Ah single pack",
  7: "EXICOM 10 kWh single pack",
  8: "GreenEvolve 200Ah single pack",
  9: "NextCharge 200Ah single pack",
  10: "Exponent pack - 8kWh",
  11: "Prana 11.a 216 Ah - APL BMS",
};

const maxAvg = async (req, res) => {
  try {
    await connection(url);
    await sequelize.sync();
    Vehicle.belongsToMany(Client, {
      through: ClientVehicle,
      foreignKey: "vid",
    });
    Client.belongsToMany(Vehicle, {
      through: ClientVehicle,
      foreignKey: "cid",
    });

    const data =
      await sequelize.query(`select distinct veh.VIN as vin,veh.VehicleRegNo,veh.model,veh.SIMservicePrName,veh.network_type,
    GROUP_CONCAT(DISTINCT cl.ClientFullName SEPARATOR ',') as name from Client cl 
    join ClientVehicle cv on cl.cid = cv.cid 
    join Vehicle veh on cv.vid = veh.vid where deleteVehicleStatus=0 and 
    (vin like 'mq/MD9%' or vin like 'mq/P6R%' ) group by vin`);

    // console.log(data);

    // console.log(data.length)
    const dealerVinsList = [];
    let VehicleTableData = {};
    data[0].map((item) => {
      dealerVinsList.push(item.vin);
      //   vehicleSaleVins.push(item.vin.slice(3))
      VehicleTableData[item.vin] = item;
    });
    let { date } = req.params;
    date = moment(date).format("YYYY-MM-DD");
    // let previousDay = moment(date).subtract(1, 'days').format('YYYY-MM-DD');

    console.log("log 1");

    let queryResult = await VehicleDailyData.aggregate([
      {
        $match: {
          date: date,
          topic: { $in: dealerVinsList },
          x12: { $gt: 0, $lte: 500, $ne: "NA" },
        },
      },

      {
        $facet: {
          speedResult: [
            {
              $group: {
                _id: "$topic",
                vehicle_reg_number: { $last: "$x1" },
                max_speed: { $last: "$x14" },
                avg_speed: { $first: "$x13" },
                distance: { $first: "$x12" },
              },
            },
          ],
          speedPieChart: [
            {
              $match: {
                x12: { $gt: 10 },
              },
            },
            {
              $group: {
                _id: null,
                "Speed < 10KM/hr": { $sum: "$x41" },
                "Speed 10-20 Km/hr": { $sum: "$x42" },
                "Speed 20-30 Km/hr": { $sum: "$x43" },
                "Speed 30-40 Km/hr": { $sum: "$x44" },
                "Speed >40Km/hr": { $sum: "$x45" },
              },
            },
          ],
        },
      },
    ]);

    // console.log("log 2");

    queryResult = queryResult[0];

    let query = queryResult.speedResult;

    // console.log(queryResult.speedPieChart);

    let speedPieChart = queryResult.speedPieChart[0];
    delete speedPieChart._id;

    // let total_distance = query.reduce((acc, cum)=>acc+cum.distance, 0);

    // // console.log(total_distance)

    // let pieSum = Object.values(speedPieChart).reduce((acc, cum) => acc + cum);

    // if (pieSum !== total_distance) {
    //   // console.log('not equal')
    //   let diff = total_distance - pieSum;
    //   // console.log(diff)
    //   speedPieChart["Speed >40Km/hr"] += Number(Number(diff).toFixed(2));
    //   speedPieChart["Speed >40Km/hr"] = Number(Number(speedPieChart["Speed >40Km/hr"]).toFixed(2))
    // }

    // console.log(speedPieChart["Speed >40Km/hr"])

    // console.log("log 3");

    let obj = {
      max_speed: {
        "0-10": [],
        "11-20": [],
        "21-30": [],
        "31-40": [],
        "41-50": [],
        "51-60": [],
        "61-70": [],
      },
      avg_speed: {
        "0-10": [],
        "11-20": [],
        "21-30": [],
        "31-40": [],
        "41-50": [],
        "51-60": [],
        "61-70": [],
      },
    };

    for (let i of query) {
      if (i.max_speed >= 0 && i.max_speed <= 10)
        obj.max_speed["0-10"].push({
          vin: i._id,
          vehicle_reg_number: VehicleTableData[i._id]["VehicleRegNo"],
          name: VehicleTableData[i._id]["name"],
          max_speed: i.max_speed,
          model: VehicleTableData[i._id]["model"],
          network_type: VehicleTableData[i._id]["network_type"],
        });
      else if (i.max_speed > 10 && i.max_speed <= 20)
        obj.max_speed["11-20"].push({
          vin: i._id,
          vehicle_reg_number: VehicleTableData[i._id]["VehicleRegNo"],
          name: VehicleTableData[i._id]["name"],
          max_speed: i.max_speed,
          model: VehicleTableData[i._id]["model"],
          network_type: VehicleTableData[i._id]["network_type"],
        });
      else if (i.max_speed > 20 && i.max_speed <= 30)
        obj.max_speed["21-30"].push({
          vin: i._id,
          vehicle_reg_number: VehicleTableData[i._id]["VehicleRegNo"],
          name: VehicleTableData[i._id]["name"],
          max_speed: i.max_speed,
          model: VehicleTableData[i._id]["model"],
          network_type: VehicleTableData[i._id]["network_type"],
        });
      else if (i.max_speed > 30 && i.max_speed <= 40)
        obj.max_speed["31-40"].push({
          vin: i._id,
          vehicle_reg_number: VehicleTableData[i._id]["VehicleRegNo"],
          name: VehicleTableData[i._id]["name"],
          max_speed: i.max_speed,
          model: VehicleTableData[i._id]["model"],
          network_type: VehicleTableData[i._id]["network_type"],
        });
      else if (i.max_speed > 40 && i.max_speed <= 50)
        obj.max_speed["41-50"].push({
          vin: i._id,
          vehicle_reg_number: VehicleTableData[i._id]["VehicleRegNo"],
          name: VehicleTableData[i._id]["name"],
          max_speed: i.max_speed,
          model: VehicleTableData[i._id]["model"],
          network_type: VehicleTableData[i._id]["network_type"],
        });
      else if (i.max_speed > 50 && i.max_speed <= 60)
        obj.max_speed["51-60"].push({
          vin: i._id,
          vehicle_reg_number: VehicleTableData[i._id]["VehicleRegNo"],
          name: VehicleTableData[i._id]["name"],
          max_speed: i.max_speed,
          model: VehicleTableData[i._id]["model"],
          network_type: VehicleTableData[i._id]["network_type"],
        });
      else if (i.max_speed > 60 && i.max_speed <= 70)
        obj.max_speed["61-70"].push({
          vin: i._id,
          vehicle_reg_number: VehicleTableData[i._id]["VehicleRegNo"],
          name: VehicleTableData[i._id]["name"],
          max_speed: i.max_speed,
          model: VehicleTableData[i._id]["model"],
          network_type: VehicleTableData[i._id]["network_type"],
        });
    }

    for (let i of query) {
      if (i.avg_speed >= 0 && i.avg_speed <= 10)
        obj.avg_speed["0-10"].push({
          vin: i._id,
          vehicle_reg_number: VehicleTableData[i._id]["VehicleRegNo"],
          name: VehicleTableData[i._id]["name"],
          avg_speed: i.avg_speed,
          model: VehicleTableData[i._id]["model"],
          network_type: VehicleTableData[i._id]["network_type"],
        });
      else if (i.avg_speed > 10 && i.avg_speed <= 20)
        obj.avg_speed["11-20"].push({
          vin: i._id,
          vehicle_reg_number: VehicleTableData[i._id]["VehicleRegNo"],
          name: VehicleTableData[i._id]["name"],
          avg_speed: i.avg_speed,
          model: VehicleTableData[i._id]["model"],
          network_type: VehicleTableData[i._id]["network_type"],
        });
      else if (i.avg_speed > 20 && i.avg_speed <= 30)
        obj.avg_speed["21-30"].push({
          vin: i._id,
          vehicle_reg_number: VehicleTableData[i._id]["VehicleRegNo"],
          name: VehicleTableData[i._id]["name"],
          avg_speed: i.avg_speed,
          model: VehicleTableData[i._id]["model"],
          network_type: VehicleTableData[i._id]["network_type"],
        });
      else if (i.avg_speed > 30 && i.avg_speed <= 40)
        obj.avg_speed["31-40"].push({
          vin: i._id,
          vehicle_reg_number: VehicleTableData[i._id]["VehicleRegNo"],
          name: VehicleTableData[i._id]["name"],
          avg_speed: i.avg_speed,
          model: VehicleTableData[i._id]["model"],
          network_type: VehicleTableData[i._id]["network_type"],
        });
      else if (i.avg_speed > 40 && i.avg_speed <= 50)
        obj.avg_speed["41-50"].push({
          vin: i._id,
          vehicle_reg_number: VehicleTableData[i._id]["VehicleRegNo"],
          name: VehicleTableData[i._id]["name"],
          avg_speed: i.avg_speed,
          model: VehicleTableData[i._id]["model"],
          network_type: VehicleTableData[i._id]["network_type"],
        });
      else if (i.avg_speed > 50 && i.avg_speed <= 60)
        obj.avg_speed["51-60"].push({
          vin: i._id,
          vehicle_reg_number: VehicleTableData[i._id]["VehicleRegNo"],
          name: VehicleTableData[i._id]["name"],
          avg_speed: i.avg_speed,
          model: VehicleTableData[i._id]["model"],
          network_type: VehicleTableData[i._id]["network_type"],
        });
      else if (i.avg_speed > 60 && i.avg_speed <= 70)
        obj.avg_speed["61-70"].push({
          vin: i._id,
          vehicle_reg_number: VehicleTableData[i._id]["VehicleRegNo"],
          name: VehicleTableData[i._id]["name"],
          avg_speed: i.avg_speed,
          model: VehicleTableData[i._id]["model"],
          network_type: VehicleTableData[i._id]["network_type"],
        });
    }

    console.log("log 4");

    return res.json({ ...obj, speedPieChart });
  } catch (error) {
    return res.json(error);
  }
};

const configApis = async (req, res) => {
  try {
    await connection(url);
    await sequelize.sync();
    Vehicle.belongsToMany(Client, {
      through: ClientVehicle,
      foreignKey: "vid",
    });
    Client.belongsToMany(Vehicle, {
      through: ClientVehicle,
      foreignKey: "cid",
    });

    const data =
      await sequelize.query(`select distinct veh.VIN as vin,veh.VehicleRegNo,veh.model,veh.SIMservicePrName,veh.network_type,veh.vehicleColor,
      GROUP_CONCAT(DISTINCT cl.ClientFullName SEPARATOR ',') as name from Client cl 
      join ClientVehicle cv on cl.cid = cv.cid 
      join Vehicle veh on cv.vid = veh.vid where deleteVehicleStatus=0 and 
      (vin like 'mq/MD9%' or vin like 'mq/P6R%' ) group by vin`);
    const dealerVinsList = [];
    VehicleTableData = {};
    data[0].map((item) => {
      dealerVinsList.push(item.vin);
      VehicleTableData[item.vin] = item;
    });
    let { date } = req.params;
    date = moment(date).format("YYYY-MM-DD");
    let query = await VehicleDailyData.aggregate([
      {
        $match: {
          date: date,
          topic: { $in: dealerVinsList },
          x12: { $gt: 0, $lte: 500, $ne: "NA" },
        },
      },
      {
        $project: {
          _id: "$topic",
          vehicle_reg_number: "$x1",
          type1: "$x85",
          type2: "$x86",
          odo: "$x11",
          soc: "$x55",
          total_distance: "$x12",
          battery_type: "$x96",
        },
      },
      {
        $facet: {
          pieChart1: [
            {
              $group: {
                _id: "$type1",
                data: {
                  $push: {
                    _id: "$_id",
                    vehicle_reg_number: "$vehicle_reg_number",
                    odo: "$odo",
                    soc: "$soc",
                    type1: "$type1",
                    type2: "$type2",
                    battery_type: "$battery_type",
                    total_distance: "$total_distance",
                  },
                },
              },
            },
          ],

          pieChart2: [
            {
              $group: {
                _id: "$type2",
                data: {
                  $push: {
                    _id: "$_id",
                    vehicle_reg_number: "$vehicle_reg_number",
                    odo: "$odo",
                    soc: "$soc",
                    type1: "$type1",
                    type2: "$type2",
                    battery_type: "$battery_type",
                    total_distance: "$total_distance",
                  },
                },
              },
            },
          ],

          total_data: [
            {
              $project: {
                _id: 0,
                odo: 1,
                soc: 1,
                vin: "$_id",
                total_distance: 1,
                battery_type: "$battery_type",
              },
            },
          ],
        },
      },
    ]);
    // console.log(query)
    if (!query[0].total_data.length) {
      return res.json({
        status: false,
        code: 401,
        data: "Invalid input parameter",
      });
    }
    let controller_software_version = {
      v305: [],
      v306: [],
      v307: [],
      v308: [],
    };
    let display_software_version = {
      v106: [],
      v107: [],
      v108: [],
      v109: [],
    };
    // let vehicle_color = {
    //   Unknown: [],
    //   "Zesty Orange": [],
    //   Green: [],
    //   "Jet Black": [],
    //   "Pepsi Blue": [],
    // };
    let vehicle_color={
      "Unknown":[],
      "Green": [],
      "White":[],
      "Jet Black":[],
      "Pepsi Blue":[],
      "Zesty Orange":[]
    }
    let battery_types = {
      None: [],
      "Lead Acid pack": [],
      "ACME 57 Ah in parallel": [],
      "ACME 78 Ah in parallel": [],
      "EXICOM 75 Ah in parallel V-1.0": [],
      "EXICOM 75 Ah in parallel V-1.1": [],
      "Prana 11.a 216 Ah single pack": [],
      "EXICOM 10 kWh single pack": [],
      "GreenEvolve 200Ah single pack": [],
      "NextCharge 200Ah single pack": [],
      "Exponent pack - 8kWh": [],
      "Prana 11.a 216 Ah - APL BMS": [],
    };

    query[0].pieChart1.map((item) => {
      if (controller_software_version.hasOwnProperty("v" + item._id)) {
        controller_software_version["v" + item._id] = item.data.map((item2) => {
          return {
            type1: item2.type1,
            type2: item2.type2,
            vin: item2._id.slice(3),
            vehicle_reg_number: VehicleTableData[item2._id]["VehicleRegNo"],
            fleet_name: VehicleTableData[item2._id]["name"],
            soc: item2.soc,
            odo: item2.odo,
            network_type: VehicleTableData[item2._id]["network_type"],
            battery_type: item2.battery_type,
            // color:VehicleTableData[item2._id]['vehicleColor'],
            total_distance: item2.total_distance,
          };
        });
      }else{
        if(item._id!=0){
        controller_software_version["v" + item._id] = item.data.map((item2) => {
          return {
            type1: item2.type1,
            type2: item2.type2,
            vin: item2._id.slice(3),
            vehicle_reg_number: VehicleTableData[item2._id]["VehicleRegNo"],
            fleet_name: VehicleTableData[item2._id]["name"],
            soc: item2.soc,
            odo: item2.odo,
            network_type: VehicleTableData[item2._id]["network_type"],
            battery_type: item2.battery_type,
            // color:VehicleTableData[item2._id]['vehicleColor'],
            total_distance: item2.total_distance,
          };
        });
      }
      }
    });

    query[0].pieChart2.map((item) => {
      if (display_software_version.hasOwnProperty("v" + item._id)) {
        display_software_version["v" + item._id] = item.data.map((item2) => {
          return {
            type1: item2.type1,
            type2: item2.type2,
            vin: item2._id.slice(3),
            vehicle_reg_number: VehicleTableData[item2._id]["VehicleRegNo"],
            fleet_name: VehicleTableData[item2._id]["name"],
            soc: item2.soc,
            odo: item2.odo,
            network_type: VehicleTableData[item2._id]["network_type"],
            battery_type: item2.battery_type,
            // color:VehicleTableData[item2._id]['vehicleColor'],
            total_distance: item2.total_distance,
          };
        })
      }else{
        if(item._id!=0){
        display_software_version["v" + item._id] =item.data.map((item2) => {
          return {
            type1: item2.type1,
            type2: item2.type2,
            vin: item2._id.slice(3),
            vehicle_reg_number: VehicleTableData[item2._id]["VehicleRegNo"],
            fleet_name: VehicleTableData[item2._id]["name"],
            soc: item2.soc,
            odo: item2.odo,
            network_type: VehicleTableData[item2._id]["network_type"],
            battery_type: item2.battery_type,
            // color:VehicleTableData[item2._id]['vehicleColor'],
            total_distance: item2.total_distance,
          };
        })
      }
      }
    });
    VehicleData = query[0].total_data.map((item) => {
      return { ...item, ...VehicleTableData[item.vin] };
    });

    VehicleData.map((item) => {
      let it = {
        vin: item.vin.slice(3),
        VehicleRegNo: item.VehicleRegNo,
        odo: item.odo,
        soc: item.soc,
        total_distance: item.total_distance,
        // battery_type:item.battery_type,
        name: item.name,
        // SIMservicePrName: item.SIMservicePrName,
        network_type: item.network_type,
      };
      // delete it.vehicleColor
      // console.log(it)
      const battery =
        typeof item.battery_type == "string"
          ? item.battery_type
          : batteryObj[item.battery_type + ""];
      if (battery_types.hasOwnProperty(battery)) {
        battery_types[battery].push(it);
      }
    });

    VehicleData.map((item) => {
      // console.log(item.battery_type)
      if (
        item.vehicleColor == "Unknown" ||
        item.vehicleColor == null ||
        item.vehicleColor == ""
      ) {
        vehicle_color["Unknown"].push({
          vin: item.vin.slice(3),
          vehicle_reg_number: item.VehicleRegNo,
          fleet_name: item.name,
          battery_type:
            typeof item.battery_type == "string"
              ? item.battery_type
              : batteryObj[item.battery_type + ""],
          total_distance: item.total_distance,
          soc: item.soc,
          odo: item.odo,
          network_type: item.network_type,
        });
      }
      else{
      if (item.vehicleColor == "Zesty Orange") {
        vehicle_color["Zesty Orange"].push({
          vin: item.vin.slice(3),
          vehicle_reg_number: item.VehicleRegNo,
          fleet_name: item.name,
          battery_type:
            typeof item.battery_type == "string"
              ? item.battery_type
              : batteryObj[item.battery_type + ""],
          total_distance: item.total_distance,
          soc: item.soc,
          odo: item.odo,
          network_type: item.network_type,
        });
      }
      if (item.vehicleColor == "Green") {
        vehicle_color["Green"].push({
          vin: item.vin.slice(3),
          vehicle_reg_number: item.VehicleRegNo,
          fleet_name: item.name,
          battery_type:
            typeof item.battery_type == "string"
              ? item.battery_type
              : batteryObj[item.battery_type + ""],
          total_distance: item.total_distance,
          soc: item.soc,
          odo: item.odo,
          network_type: item.network_type,
        });
      }
      if (item.vehicleColor == "Jet Black") {
        vehicle_color["Jet Black"].push({
          vin: item.vin.slice(3),
          vehicle_reg_number: item.VehicleRegNo,
          fleet_name: item.name,
          battery_type:
            typeof item.battery_type == "string"
              ? item.battery_type
              : batteryObj[item.battery_type + ""],
          total_distance: item.total_distance,
          soc: item.soc,
          odo: item.odo,
          network_type: item.network_type,
        });
      }
      if (item.vehicleColor == "Pepsi Blue") {
        vehicle_color["Pepsi Blue"].push({
          vin: item.vin.slice(3),
          vehicle_reg_number: item.VehicleRegNo,
          fleet_name: item.name,
          battery_type:
            typeof item.battery_type == "string"
              ? item.battery_type
              : batteryObj[item.battery_type + ""],
          total_distance: item.total_distance,
          soc: item.soc,
          odo: item.odo,
          network_type: item.network_type,
        });
      }
      if (item.vehicleColor == "White") {
        vehicle_color["White"].push({
          vin: item.vin.slice(3),
          vehicle_reg_number: item.VehicleRegNo,
          fleet_name: item.name,
          battery_type:
            typeof item.battery_type == "string"
              ? item.battery_type
              : batteryObj[item.battery_type + ""],
          total_distance: item.total_distance,
          soc: item.soc,
          odo: item.odo,
          network_type: item.network_type,
        });
      }
    }
    });
    return res.json({
      status: true,
      code: 200,
      data: {
        controller_software_version,
        display_software_version,
        total_displays: 0,
        vehicle_color,
        battery_types,
      },
    });
  } catch (error) {
    console.log(error)
    return res.json({ status: false, code: 500, data: error });
  }
};

const showVins = async (req, res) => {
  try {
    await connection(url);
    await sequelize.sync();
    const data =
      await sequelize.query(`select distinct v.VIN as vin,v.VehicleRegNo,vs.vinserialnum as VINSERIAL,v.model,v.SIMservicePrName,v.network_type,v.vehicleColor
      from Vehicle v 
      left join VinSerialNum vs on vs.vehicleId=v.vid
      where v.deleteVehicleStatus=0 and 
      (v.vin like 'mq/MD9%' or v.vin like 'mq/P6R%' ) group by v.vin`);
    const dealerVinsList = [];
    VehicleTableData = {};
    let dat = data[0];
    // dat=dat.sort((a,b)=>(a.VINSERIAL,b.VIN))
    dat.map((item) => {
      dealerVinsList.push({
        label: !item.VINSERIAL
          ? item.vin.slice(3) + " | " + item.VehicleRegNo
          : item.vin.slice(3) +
            " | " +
            item.VehicleRegNo +
            " | " +
            item.VINSERIAL,
        value: !item.VINSERIAL
          ? item.vin.slice(3) + " | " + item.VehicleRegNo
          : item.vin.slice(3) +
            " | " +
            item.VehicleRegNo +
            " | " +
            item.VINSERIAL,
      });
    });
    return res.json({ status: true, code: 200, data: dealerVinsList });
  } catch (error) {
    return res.json({ status: false, code: 500, data: error });
  }
};

const vinOnSearchTemp = async (req, res) => {
  try {
    await sequelize.sync();

    let date = moment(new Date()).format("YYYY-MM-DD");

    let query =
      await sequelize.query(`select distinct SUBSTRING(veh.VIN,4) as vin,veh.VehicleRegNo as vehicle_reg_number,veh.model,veh.SIMservicePrName,veh.network_type,
  GROUP_CONCAT(DISTINCT cl.ClientFullName SEPARATOR ',') as name from Client cl 
  join ClientVehicle cv on cl.cid = cv.cid 
  join Vehicle veh on cv.vid = veh.vid where deleteVehicleStatus=0 and 
  (vin like 'mq/MD9%' or vin like 'mq/P6R%' ) group by vin`);

    let data = [];

    let i = 0;

    for (let a of query[0]) {
      i++;

      data.push({
        icon: "ChevronRight",

        id: i,

        isBookmarked: false,

        link: `/vehicle-usage/${a.vin}`,

        target: a.vin + " | " + a.vehicle_reg_number,

        title: a.vin + " | " + a.vehicle_reg_number,
      });
    }
    const result = [];

    result.push({
      data: data,

      groupTitle: "Pages",

      searchLimit: 10,
    });
    data = result[0] ? result[0].data : null;

    return res.json({ status: true, data });
  } catch (error) {
    return res.json({ status: false, data: error });
  }
};

const fleetList = async (req, res) => {
  try {
    await sequelize.sync();
    // let query = await sequelize.query(`select c.name as fleet,count(v.fleet_id) as number from company c
    // join vehicles v on v.fleet_id=c.company_id or v.secondary_fleet_id  like concat( c.company_id , '%') or v.secondary_fleet_id  like concat('%,' , c.company_id , '%')
    // group by c.name order by fleet;`);
    Vehicle.belongsToMany(Client, {
      through: ClientVehicle,
      foreignKey: "vid",
    });
    Client.belongsToMany(Vehicle, {
      through: ClientVehicle,
      foreignKey: "cid",
    });
    // console.log('hi')
    const query = await Client.findAll({
      attributes: [
        "clientCode",
        [sequelize.fn("COUNT", sequelize.col("Vehicles.vid")), "vehicleCount"],
      ],
      include: [
        {
          model: Vehicle,
          attributes: [],
          where: {
            deleteVehicleStatus: 0,
            [Op.or]: [
              { VIN: { [Op.like]: "mq/MD9%" } },
              { VIN: { [Op.like]: "mq/P6R%" } },
            ],
          },
        },
      ],
      group: ["Client.clientCode"],
      raw: true,
    });
    let result = [];
    query.map((item) => {
      if (item.vehicleCount > 0 && !item.clientCode.startsWith("Dealer")) {
        result.push({ label: item.clientCode, value: item.clientCode });
      }
    });
    // console.log(result.length)
    return res.json({ status: true, data: result });
  } catch (error) {
    console.log(error);
    return res.json({ status: false, data: error });
  }
};

const getDates = async (req, res) => {
  try {
    await connection(url);
    let result = await (
      await VehicleDailyData.distinct("date")
    )
      .filter((item) => item > "2023-02-28")
      .map((item) => {
        return {
          label: moment(new Date(item)).format("YYYY-MM-DD"),
          value: moment(new Date(item)).format("YYYY-MM-DD"),
        };
      });
    return res.json({ status: true, data: result });
  } catch (error) {
    console.log(error);
    return res.json({ status: false, data: error });
  }
};

const efficiencyQuery = async (req, res) => {
  try {
    await sequelize.sync();
    let { vin, startDate, endDate } = req.body;
    vin = vin.startsWith("mq/") ? vin : "mq/" + vin;
    // vin=vins.map(item=>item.startsWith("mq/")?item:"mq/"+item)
    await connection(url);
    startDate = moment(startDate).format("YYYY-MM-DD");
    endDate = moment(endDate).format("YYYY-MM-DD");
    let query = await VehicleDailyData.aggregate([
      {
        $match: {
          topic: vin,
          date: { $gte: startDate, $lte: endDate },
          x78: "Running",
          $and: [{ x35: { $ne: "NA" } }, { x35: { $gte: 20, $lte: 220 } }],
        },
      },
      {
        $project: {
          _id: 0,
          date: "$date",
          start_odo: "$x10",
          end_odo: "$x11",
          energy_used: "$x87",
          distance: "$x12",
          avg_speed: "$x13",
          max_speed: "$x14",
          opening_battery_ah: "$x51",
          closing_battery_ah: "$x52",
          battery_soh: "$x53",
          start_soc: "$x54",
          end_soc: "$x55",
          efficiency: "$x35",
          peak_battery_power: "$x17",
          peak_motor_power: "$x18",
          peak_torque: "$x19",
          peak_motor_speed: "$x20",
          max_motor_temperature: "$x21",
          min_motor_temperature: "$x22",
          delta_motor_temperature: "$x23",
          max_inverter_temperature: "$x24",
          min_inverter_temperature: "$x25",
          delta_inverter_temperature: "$x26",
          max_cell_voltage: "$x27",
          min_cell_voltage: "$x28",
          delta_cell_voltage: "$x29",
          max_battery_module_temperature: "$x30",
          min_battery_module_temperature: "$x31",
          delta_battery_module_temperature: "$x32",
          regen: "$x34",
          opening_elevation: "$x60",
          closing_elevation: "$x61",
          min_elevation: "$x62",
          max_elevation: "$x63",
          cumulative_percentage_battery_charged: "$x88",
          cumulative_percentage_battery_discharged: "$x89",
          cumulative_ah_rise: "$x90",
          cumulative_ah_drop: "$x91",
          min_soh: "$x92",
          max_soh: "$x93",
          last_soh: "$x94",
          start_charge_cycle: "$x100",
          end_charge_cycle: "$x101",
          min_day_soc: "$x108",
          max_day_soc: "$x109",
          min_12v_battery: "$x110",
          max_12v_battery: "$x111",
          start_12v_battery: "$x112",
          end_12v_battery: "$x113",
          max_brake_pedal: "$x114",
          min_brake_pedal: "$x115",
          bms_pack_cycles: "$x95",
          max_elevation_gain: "$x64",
          max_elevation_loss: "$x65",
          max_gps_speed: "$x66",
          avg_gps_speed: "$x67",
          mileage: "$x15",
          number_of_mqtt_packets: "$x5",
          total_drive_time: "$x7",
          total_running_time: "$x8",
          total_idle_time: "$x9",
          number_of_sFlash_packets: "$x3",
          DTE: "$x16",
          start_energyKWh: "$x104",
          end_energyKWh: "$x105",
          max_energyKWh: "$x106",
          min_energyKWh: "$x107",
        },
      },
      {
        $sort: {
          date: 1,
        },
      },
    ]);
    return res.json({
      status: true,
      code: 200,
      data: query,
    });
  } catch (error) {
    console.log(error);
    return res.json({
      status: false,
      code: 500,
      error: error,
    });
  }
};
const getBmsFault = async (req, res) => {
  try {
    await connection(url);
    let { startDate, endDate } = req.body;
    startDate = moment(startDate).format("YYYY-MM-DD");
    endDate = moment(endDate).format("YYYY-MM-DD");

    let query = await VehicleDailyData.aggregate([
      {
        $match: {
          date: {
            $gte: startDate,
            $lte: endDate,
          },
          x78: "Running",
          $or: [{ x116: { $gt: 0 } }, { x117: { $gt: 0 } }],
        },
      },
      {
        $project: {
          _id: 0,
          vin: {
            $substr: ["$topic", 3, { $subtract: [{ $strLenCP: "$topic" }, 3] }],
          },
          reg_no: "$x1",
          date: "$date",
          bms_balance_fault: "$x116",
          bms_vtg_fault: "$x117",
          end_charge_cycle_Count: "$x101",
          battery_type: "$x96",
        },
      },
    ]);
    return res.json({
      status: true,
      code: 200,
      data: query,
    });
  } catch (error) {
    console.log(error);
    return res.json({
      status: false,
      code: 500,
      error: error,
    });
  }
};
const efficiencyQueryavg = async (req, res) => {
  try {
    await sequelize.sync();
    let { vin, startDate, endDate } = req.body;
    vin = vin.startsWith("mq/") ? vin : "mq/" + vin;
    // vin=vins.map(item=>item.startsWith("mq/")?item:"mq/"+item)
    await connection(url);
    startDate = moment(startDate).format("YYYY-MM-DD");
    endDate = moment(endDate).format("YYYY-MM-DD");
    let query = await VehicleDailyData.aggregate([
      {
        $match: {
          topic: vin,
          date: { $gte: startDate, $lte: endDate },
          x78: "Running",
          $and: [{ x35: { $ne: "NA" } }, { x35: { $gte: 20, $lte: 220 } }],
        },
      },
      {
        $project: {
          _id: 0,
          date: "$date",
          start_odo: "$x10",
          end_odo: "$x11",
          energy_used: "$x87",
          distance: "$x12",
          avg_speed: "$x13",
          max_speed: "$x14",
          opening_battery_ah: "$x51",
          closing_battery_ah: "$x52",
          battery_soh: "$x53",
          start_soc: "$x54",
          end_soc: "$x55",
          efficiency: "$x35",
          peak_battery_power: "$x17",
          peak_motor_power: "$x18",
          peak_torque: "$x19",
          peak_motor_speed: "$x20",
          max_motor_temperature: "$x21",
          min_motor_temperature: "$x22",
          delta_motor_temperature: "$x23",
          max_inverter_temperature: "$x24",
          min_inverter_temperature: "$x25",
          delta_inverter_temperature: "$x26",
          max_cell_voltage: "$x27",
          min_cell_voltage: "$x28",
          delta_cell_voltage: "$x29",
          max_battery_module_temperature: "$x30",
          min_battery_module_temperature: "$x31",
          delta_battery_module_temperature: "$x32",
          regen: "$x34",
          opening_elevation: "$x60",
          closing_elevation: "$x61",
          min_elevation: "$x62",
          max_elevation: "$x63",
          cumulative_percentage_battery_charged: "$x88",
          cumulative_percentage_battery_discharged: "$x89",
          cumulative_ah_rise: "$x90",
          cumulative_ah_drop: "$x91",
          min_soh: "$x92",
          max_soh: "$x93",
          last_soh: "$x94",
          start_charge_cycle: "$x100",
          end_charge_cycle: "$x101",
          min_day_soc: "$x108",
          max_day_soc: "$x109",
          min_12v_battery: "$x110",
          max_12v_battery: "$x111",
          start_12v_battery: "$x112",
          end_12v_battery: "$x113",
          max_brake_pedal: "$x114",
          min_brake_pedal: "$x115",
          bms_pack_cycles: "$x95",
          max_elevation_gain: "$x64",
          max_elevation_loss: "$x65",
          max_gps_speed: "$x66",
          avg_gps_speed: "$x67",
          mileage: "$x15",
          number_of_mqtt_packets: "$x5",
          total_drive_time: "$x7",
          total_running_time: "$x8",
          total_idle_time: "$x9",
          number_of_sFlash_packets: "$x3",
          DTE: "$x16",
          start_energyKWh: "$x104",
          end_energyKWh: "$x105",
          max_energyKWh: "$x106",
          min_energyKWh: "$x107",
        },
      },
      {
        $sort: {
          date: 1,
        },
      },
    ]);
    let efficiencyQuery = await VehicleDailyData.aggregate([
      {
        $match: {
          topic: vin,
          date: { $gte: startDate, $lte: endDate },
          x78: "Running",
          $and: [{ x35: { $ne: "NA" } }, { x35: { $gte: 20, $lte: 220 } }],
        },
      },
      {
        $addFields: {
          convertedDate: { $toDate: "$date" },
        },
      },
      {
        $group: {
          _id: {
            $dateToString: { format: "%Y-%m", date: "$convertedDate" },
          },
          distance: { $avg: "$x12" },
          avg_speed: { $avg: "$x13" },
          max_speed: { $avg: "$x14" },
          battery_soh: { $avg: "$x53" },
          start_soc: { $avg: "$x54" },
          end_soc: { $avg: "$x55" },
          efficiency: { $avg: "$x35" },
          min_soh: { $avg: "$x92" },
          max_soh: { $avg: "$x93" },
          last_soh: { $avg: "$x94" },
          start_odo: { $first: "$x10" },
          end_odo: { $last: "$x11" },
          energy_used: { $avg: "$x87" },
          opening_battery_ah: { $avg: "$x51" },
          closing_battery_ah: { $avg: "$x52" },
          peak_battery_power: { $avg: "$x17" },
          peak_motor_power: { $avg: "$x18" },
          peak_torque: { $avg: "$x19" },
          peak_motor_speed: { $avg: "$x20" },
          max_motor_temperature: { $avg: "$x21" },
          min_motor_temperature: { $avg: "$x22" },
          delta_motor_temperature: { $avg: "$x23" },
          max_inverter_temperature: { $avg: "$x24" },
          min_inverter_temperature: { $avg: "$x25" },
          delta_inverter_temperature: { $avg: "$x26" },
          max_cell_voltage: { $avg: "$x27" },
          min_cell_voltage: { $avg: "$x28" },
          delta_cell_voltage: { $avg: "$x29" },
          max_battery_module_temperature: { $avg: "$x30" },
          min_battery_module_temperature: { $avg: "$x31" },
          delta_battery_module_temperature: { $avg: "$x32" },
          regen: { $avg: "$x34" },
          opening_elevation: { $avg: "$x60" },
          closing_elevation: { $avg: "$x61" },
          min_elevation: { $avg: "$x62" },
          max_elevation: { $avg: "$x63" },
          cumulative_percentage_battery_charged: { $avg: "$x88" },
          cumulative_percentage_battery_discharged: { $avg: "$x89" },
          cumulative_ah_rise: { $avg: "$x90" },
          cumulative_ah_drop: { $avg: "$x91" },
          start_charge_cycle: { $avg: "$x100" },
          end_charge_cycle: { $avg: "$x101" },
          min_day_soc: { $avg: "$x108" },
          max_day_soc: { $avg: "$x109" },
          min_12v_battery: { $avg: "$x110" },
          max_12v_battery: { $avg: "$x111" },
          start_12v_battery: { $avg: "$x112" },
          end_12v_battery: { $avg: "$x113" },
          max_brake_pedal: { $avg: "$x114" },
          min_brake_pedal: { $avg: "$x115" },
          bms_pack_cycles: { $avg: "$x95" },
          max_elevation_gain: { $avg: "$x64" },
          max_elevation_loss: { $avg: "$x65" },
          max_gps_speed: { $avg: "$x66" },
          avg_gps_speed: { $avg: "$x67" },
          mileage: { $avg: "$x15" },
          number_of_mqtt_packets: { $avg: "$x5" },
          total_drive_time: { $avg: "$x7" },
          total_running_time: { $avg: "$x8" },
          total_idle_time: { $avg: "$x9" },
          number_of_sFlash_packets: { $avg: "$x3" },
          DTE: { $avg: "$x16" },
          start_energyKWh: { $avg: "$x104" },
          end_energyKWh: { $avg: "$x105" },
          max_energyKWh: { $avg: "$x106" },
          min_energyKWh: { $avg: "$x107" },
        },
      },
      {
        $project: {
          _id: 0,
          date: "$_id",
          distance: { $round: ["$distance", 2] },
          avg_speed: { $round: ["$avg_speed", 2] },
          max_speed: { $round: ["$max_speed", 2] },
          battery_soh: { $round: ["$battery_soh", 2] },
          start_soc: { $round: ["$start_soc", 2] },
          end_soc: { $round: ["$end_soc", 2] },
          efficiency: { $round: ["$efficiency", 2] },
          min_soh: { $round: ["$min_soh", 2] },
          max_soh: { $round: ["$max_soh", 2] },
          last_soh: { $round: ["$last_soh", 2] },
          start_odo: { $round: ["$start_odo", 2] },
          end_odo: { $round: ["$end_odo", 2] },
          energy_used: { $round: ["$energy_used", 2] },
          opening_battery_ah: { $round: ["$opening_battery_ah", 2] },
          closing_battery_ah: { $round: ["$closing_battery_ah", 2] },
          peak_battery_power: { $round: ["$peak_battery_power", 2] },
          peak_motor_power: { $round: ["$peak_motor_power", 2] },
          peak_torque: { $round: ["$peak_torque", 2] },
          peak_motor_speed: { $round: ["$peak_motor_speed", 2] },
          max_motor_temperature: { $round: ["$max_motor_temperature", 2] },
          min_motor_temperature: { $round: ["$min_motor_temperature", 2] },
          delta_motor_temperature: { $round: ["$delta_motor_temperature", 2] },
          max_inverter_temperature: {
            $round: ["$max_inverter_temperature", 2],
          },
          min_inverter_temperature: {
            $round: ["$min_inverter_temperature", 2],
          },
          delta_inverter_temperature: {
            $round: ["$delta_inverter_temperature", 2],
          },
          max_cell_voltage: { $round: ["$max_cell_voltage", 2] },
          min_cell_voltage: { $round: ["$min_cell_voltage", 2] },
          delta_cell_voltage: { $round: ["$delta_cell_voltage", 2] },
          max_battery_module_temperature: {
            $round: ["$max_battery_module_temperature", 2],
          },
          min_battery_module_temperature: {
            $round: ["$min_battery_module_temperature", 2],
          },
          delta_battery_module_temperature: {
            $round: ["$delta_battery_module_temperature", 2],
          },
          regen: { $round: ["$regen", 2] },
          opening_elevation: { $round: ["$opening_elevation", 2] },
          closing_elevation: { $round: ["$closing_elevation", 2] },
          min_elevation: { $round: ["$min_elevation", 2] },
          max_elevation: { $round: ["$max_elevation", 2] },
          cumulative_percentage_battery_charged: {
            $round: ["$cumulative_percentage_battery_charged", 2],
          },
          cumulative_percentage_battery_discharged: {
            $round: ["$cumulative_percentage_battery_discharged", 2],
          },
          cumulative_ah_rise: { $round: ["$cumulative_ah_rise", 2] },
          cumulative_ah_drop: { $round: ["$cumulative_ah_drop", 2] },
          start_charge_cycle: { $round: ["$start_charge_cycle", 2] },
          end_charge_cycle: { $round: ["$end_charge_cycle", 2] },
          min_day_soc: { $round: ["$min_day_soc", 2] },
          max_day_soc: { $round: ["$max_day_soc", 2] },
          min_12v_battery: { $round: ["$min_12v_battery", 2] },
          max_12v_battery: { $round: ["$max_12v_battery", 2] },
          start_12v_battery: { $round: ["$start_12v_battery", 2] },
          end_12v_battery: { $round: ["$end_12v_battery", 2] },
          max_brake_pedal: { $round: ["$max_brake_pedal", 2] },
          min_brake_pedal: { $round: ["$min_brake_pedal", 2] },
          bms_pack_cycles: { $round: ["$bms_pack_cycles", 2] },
          max_elevation_gain: { $round: ["$max_elevation_gain", 2] },
          max_elevation_loss: { $round: ["$max_elevation_loss", 2] },
          max_gps_speed: { $round: ["$max_gps_speed", 2] },
          avg_gps_speed: { $round: ["$avg_gps_speed", 2] },
          mileage: { $round: ["$mileage", 2] },
          number_of_mqtt_packets: { $round: ["$number_of_mqtt_packets", 2] },
          total_drive_time: { $round: ["$total_drive_time", 2] },
          total_running_time: { $round: ["$total_running_time", 2] },
          total_idle_time: { $round: ["$total_idle_time", 2] },
          number_of_sFlash_packets: {
            $round: ["$number_of_sFlash_packets", 2],
          },
          DTE: { $round: ["$DTE", 2] },
          start_energyKWh: { $round: ["$start_energyKWh", 2] },
          end_energyKWh: { $round: ["$end_energyKWh", 2] },
          max_energyKWh: { $round: ["$max_energyKWh", 2] },
          min_energyKWh: { $round: ["$min_energyKWh", 2] },
        },
      },
      {
        $sort: {
          date: 1,
        },
      },
    ]);
    return res.json({
      status: true,
      code: 200,
      data: query,
      efficiencyQuery: efficiencyQuery,
    });
  } catch (error) {
    console.log(error);
    return res.json({
      status: false,
      code: 500,
      error: error,
    });
  }
};

const rnfbData = async (req, res) => {
  try {
    await connection(url);
    await sequelize.sync();
    Vehicle.belongsToMany(Client, {
      through: ClientVehicle,
      foreignKey: "vid",
    });
    Client.belongsToMany(Vehicle, {
      through: ClientVehicle,
      foreignKey: "cid",
    });

    const data =
      await sequelize.query(`select distinct veh.VIN as vin,veh.VehicleRegNo,veh.model,veh.SIMservicePrName,veh.network_type,
    GROUP_CONCAT(DISTINCT cl.ClientFullName SEPARATOR ',') as name from Client cl 
    join ClientVehicle cv on cl.cid = cv.cid 
    join Vehicle veh on cv.vid = veh.vid where deleteVehicleStatus=0 and 
    (vin like 'mq/MD9%' or vin like 'mq/P6R%' ) group by vin`);

    let vinsList = [];
    data[0].map((item) => {
      vinsList.push(item.vin);
    });
    let { date } = req.body;

    // console.log(vinsList)

    let queryData = await VehicleDailyData.aggregate([
      {
        $match: {
          topic: {
            $in: vinsList,
          },
          date: date,
          x12: {
            $gt: 0,
            $lte: 500,
          },
        },
      },
      {
        $group: {
          _id: null,
          forward_mode: { $sum: "$x118" },
          boost_mode: { $sum: "$x119" },
          // reverse_mode: { $sum: "$x120" },
        },
      },
      {
        $project: {
          _id: 0,
        },
      },
    ]);

    if (
      !queryData.length ||
      (queryData.length && Object.values(queryData[0]).every((item) => !item))
    )
      return res.json({
        status: false,
        message: "No Data",
      });

    let result = {
      Boost: Number(Number(queryData[0].boost_mode).toFixed(2)),

      ECO: Number(Number(queryData[0].forward_mode).toFixed(2)),
      // Reverse: Number(Number(queryData[0].reverse_mode).toFixed(2)),
    };

    return res.json({ status: true, data: result });
  } catch (error) {
    return res.json(error);
  }
};
module.exports = {
  maxAvg,
  configApis,
  showVins,
  vinOnSearchTemp,
  fleetList,
  getDates,
  efficiencyQuery,
  getBmsFault,
  efficiencyQueryavg,
  rnfbData,
};
