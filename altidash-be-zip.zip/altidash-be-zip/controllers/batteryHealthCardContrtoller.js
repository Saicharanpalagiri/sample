const httpStatus = require('http-status');
const VehicleJobCard  = require('../models/vehicleJobCard');
// const ApiError = require('../utils/ApiError');
const moment=require('moment');
const mongoose = require('mongoose');
const { response } = require('express');
const MonthlyBatteryHealthCardReport=require('../models/MonthlyBatteryHealthCardReport');


connection = (url) => {
    mongoose.connect(url, {useNewUrlParser: true,})
}
const url="mongodb+srv://alti-admin-prod:APL2023ADMIN@mqtt-production.iqeii.mongodb.net/mqttDatabase_aplmq";
const TestService = async (req,res) => {
    try {
        await connection(url);
        const data=await MonthlyBatteryHealthCardReport.find({});
     return res.json(data)
    } catch (error) {
        console.log(error);
        return res.json(error);
    }   
};

module.exports ={TestService}

