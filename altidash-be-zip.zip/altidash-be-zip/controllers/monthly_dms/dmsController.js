const sequelize = require("../../utils/sqldb");
const MonthlyWarrantyDefects=require("../../models/MonthlyWarrantyDefects");
const MonthlyVehicleRepairSLACompilance=require("../../models/MonthlyVehicleRepairSLACompliance");
const MonthlyDmsTickets=require("../../models/MonthlyDmsTickets");



const getDmsDefectData=async(req,res)=>{
    try {
        await sequelize.sync();
        let data=await MonthlyWarrantyDefects.findAll({
            attributes:[
                'month',
                'year',
                'raised_tickets',
                'open_tickets',
                'Parts_in_transit_tickets',
                'under_rca_tickets',
                'closed_tickets',
                'less_than_5k_defects',
                'number_of_vehicles_repaired',
                'created_by'
            ],
            raw:true,
            order:[['year','DESC'],['month','DESC']]
        });
        return res.json({
            status: true,
            code:200,
            data: data
        })
    } catch (error) {
        console.log(error);
        return res.json({
            status: false,
            code:500,
            error: "Internal Server Error"
        })
    }
}

const getMonthlyVehicleRepairSLACompliance=async(req,res)=>{
    try {
        await sequelize.sync();
        let data=await MonthlyVehicleRepairSLACompilance.findAll({
            attributes:[
                'month',
                'year',
                'open_tickets',
                'closed_tickets',
                'less_than_5km_tickets',
                'less_than_48hrs_tickets',
                'avg_closure_tat',
                'number_of_unique_vehicles_repaired',
                'created_by'
            ],
            raw:true,
            order:[['year','DESC'],['month','DESC']]
        });
        return res.json({
            status: true,
            code:200,
            data: data
        })
    } catch (error) {
        console.log(error);
        return res.json({
            status: false,
            code:500,
            error: "Internal Server Error"
        })
    }
}


const getMonthlyDMSTickets=async(req,res)=>{
    try {
        await sequelize.sync();
        let data=await MonthlyDmsTickets.findAll({
            attributes:[
            'month',
            'year',
            'number_of_service_request',
            'number_of_training_and_clarification_tickets',
            'other_tickets',
            'avg_time_taken_to_resolve_service_request',
            'avg_time_taken_to_resolve_training_and_clarification',
            'created_by'
            ],
            raw:true,
            order:[['year','DESC'],['month','DESC']]
        });
        return res.json({
            status: true,
            code:200,
            data: data
        })
    } catch (error) {
        console.log(error);
        return res.json({
            status: false,
            code:500,
            error: "Internal Server Error"
        })
    }
}


const getDmsDefectDataByMonthAndYear=async(req,res)=>{
    try {
        const {month,year}=req.body;
        await sequelize.sync();
        let data=await MonthlyWarrantyDefects.findOne({
            where:{
                month:month,
                year:year
            },
            attributes:[
                'month',
                'year',
                'raised_tickets',
                'open_tickets',
                'Parts_in_transit_tickets',
                'under_rca_tickets',
                'closed_tickets',
                'less_than_5k_defects',
                'number_of_vehicles_repaired',
                'created_by'
            ],
        });
        return res.json({
            status: true,
            code:200,
            data: data
        })
    } catch (error) {
        console.log(error);
        return res.json({
            status: false,
            code:500,
            error: "Internal Server Error"
        })
    }
}


const getMonthlyVehicleRepairSLAComplianceByMonthAndYear=async(req,res)=>{
    try {
        let {month, year} =req.body
        await sequelize.sync();
        let data=await MonthlyVehicleRepairSLACompilance.findOne({
            where:{
                month:month,
                year:year
            },
            attributes:[
                'month',
                'year',
                'open_tickets',
                'closed_tickets',
                'less_than_5km_tickets',
                'less_than_48hrs_tickets',
                'avg_closure_tat',
                'number_of_unique_vehicles_repaired',
                'created_by'
            ]
        });
        return res.json({
            status: true,
            code:200,
            data: data
        })
    } catch (error) {
        console.log(error);
        return res.json({
            status: false,
            code:500,
            error: "Internal Server Error"
        })
    }
}

const getMonthlyDMSTicketsByMonthAndYear=async(req,res)=>{
    try {
        let {month, year} = req.body;
        await sequelize.sync();
        let data=await MonthlyDmsTickets.findOne({
            where:{
                month:month,
                year:year
            },
            attributes:[
            'month',
            'year',
            'number_of_service_request',
            'number_of_training_and_clarification_tickets',
            'other_tickets',
            'avg_time_taken_to_resolve_service_request',
            'avg_time_taken_to_resolve_training_and_clarification',
            'created_by'
            ]
        });
        return res.json({
            status: true,
            code:200,
            data: data
        })
    } catch (error) {
        console.log(error);
        return res.json({
            status: false,
            code:500,
            error: "Internal Server Error"
        })
    }
}


const addMonthlyWarrantyDefects = async (req, res) => {
    try {
        await sequelize.sync();

        const {
            created_by,
            month,
            year,
            raised_tickets,
            open_tickets,
            Parts_in_transit_tickets,
            under_rca_tickets,
            closed_tickets,
            less_than_5k_defects,
            number_of_vehicles_repaired
        } = req.body;

        // Define the data to upsert
        const data = {
            created_by,
            month,
            year,
            raised_tickets,
            open_tickets,
            Parts_in_transit_tickets,
            under_rca_tickets,
            closed_tickets,
            less_than_5k_defects,
            number_of_vehicles_repaired
        };
        // Perform the upsert operation
        const [record, created] = await MonthlyWarrantyDefects.upsert(data, {
            returning: true
        })

        return res.json({
            status: true,
            code: 200,
            data: record,
            created
        });

    } catch (error) {
        console.log(error);
        return res.json({
            status: false,
            code: 500,
            error: "Internal Server Error"
        });
    }
};


const addMonthlyVehicleRepairSLACompliance = async (req, res) => {
    try {
        await sequelize.sync();
        const {
            created_by,
            month,
            year,
            open_tickets,
            closed_tickets,
            less_than_5km_tickets,
            less_than_48hrs_tickets,
            avg_closure_tat,
            number_of_unique_vehicles_repaired
        } = req.body;

        const [record, created] = await MonthlyVehicleRepairSLACompilance.upsert({
            created_by,
            month,
            year,
            open_tickets,
            closed_tickets,
            less_than_5km_tickets,
            less_than_48hrs_tickets,
            avg_closure_tat,
            number_of_unique_vehicles_repaired
        }, {
            returning: true 
        });

        return res.json({
            status: true,
            code: 200, 
            data: record,
            created 
        });

    } catch (error) {
        console.log(error);
        return res.json({
            status: false,
            code: 500,
            error: "Internal Server Error"
        });
    }
};


const addMonthlyDMSTickets = async (req, res) => {
    try {
        await sequelize.sync();
        const {
            created_by,
            month,
            year,
            number_of_service_request,
            number_of_training_and_clarification_tickets,
            other_tickets,
            avg_time_taken_to_resolve_service_request,
            avg_time_taken_to_resolve_training_and_clarification
        } = req.body;

        const [record, created] = await MonthlyDmsTickets.upsert({
            created_by,
            month,
            year,
            number_of_service_request,
            number_of_training_and_clarification_tickets,
            other_tickets,
            avg_time_taken_to_resolve_service_request,
            avg_time_taken_to_resolve_training_and_clarification
        }, {
            returning: true 
        });

        return res.json({
            status: true,
            code: 200, 
            data: record,
            created 
        });

    } catch (error) {
        console.log(error);
        return res.json({
            status: false,
            code: 500,
            error: "Internal Server Error"
        });
    }
};



module.exports = {
    getDmsDefectData,
    addMonthlyWarrantyDefects,
    addMonthlyVehicleRepairSLACompliance,
    addMonthlyDMSTickets,
    getMonthlyVehicleRepairSLACompliance,
    getMonthlyDMSTickets,
    getDmsDefectDataByMonthAndYear,
    getMonthlyVehicleRepairSLAComplianceByMonthAndYear,
    getMonthlyDMSTicketsByMonthAndYear
}