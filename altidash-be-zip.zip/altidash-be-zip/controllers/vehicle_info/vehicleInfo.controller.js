const mongoose = require("mongoose");
const { response } = require("express");
const driveScore = require("../../models/driveScore");
const Vehicle = require("../../models/vehicle");
const sequelize = require("../../utils/sqldb");
const Mqtt = require("../../models/mqttSecure");
const VehicleDailyData = require("../../models/vehicleDailyData");
const { format, addDays } = require("date-fns");
const {
  CAN_KEY_MAPPING,
  canKeyConfigurer,
  stateCodes,
  monthsObject,
  stateCodeObject,
  getCurrentTime,
} = require("../../utils/constants");
const { unixtime } = require("../../utils/helpers/unixTimeStamp");
const MonthlyBatteryHealthCardReport = require("../../models/MonthlyBatteryHealthCardReport");
const Client = require("../../models/client");
const ClientVehicle = require("../../models/client-vehicle");
const VehicleSaleStatement = require("../../models/VehicleSaleStatement");
const dealerDetails = require("../../models/dealerDetails");
const moment = require("moment");
const VinSerialNum = require("../../models/VinSerialNum");

const { Op, ConnectionError } = require("sequelize");
const { Sequelize, literal } = require("sequelize");
const VehicleLockUnlock = require("../../models/vehicleLockUnlock");
const { errorHandler } = require("../../utils/helpers/error-handler");
const AplJobCards = require("../../models/AplJobCards");
const FleetAnomalies = require("../../models/fleetWiseAnomalies");
const VehicleFaultCodes = require("../../models/vehicleFaultCodes");

connection = (url) => {
  mongoose.connect(url, { useNewUrlParser: true });
};

const url =
  "mongodb+srv://alti-admin-prod:APL2023ADMIN@mqtt-production.iqeii.mongodb.net/mqttDatabase_aplmq";
const batteryObj = {
  0: "None",
  1: "Lead Acid pack",
  2: "ACME 57 Ah in parallel",
  3: "ACME 78 Ah in parallel",
  4: "EXICOM 75 Ah in parallel V-1.0",
  5: "EXICOM 75 Ah in parallel V-1.1",
  6: "Prana 11.a 216 Ah single pack",
  7: "EXICOM 10 kWh single pack",
  8: "GreenEvolve 200Ah single pack",
  9: "NextCharge 200Ah single pack",
  10: "Exponent pack - 8kWh",
  11: "Prana 11.a 216 Ah - APL BMS",
};
const getMongoData = async (url, VIN, filter) => {
  // console.log({url,VIN,filter})
  await connection(url);
  let mongoData;
  try {
    // console.log(VIN)
    // const currentDate = new Date();
    // const isoString = currentDate.toISOString();
    const currentDate = new Date(); // Get the current date and time
    const nextDate = new Date(currentDate);
    nextDate.setDate(currentDate.getDate() + 1); // Add one day to the current date
    const nextIsoString = nextDate.toISOString();

    mongoData = await Mqtt.findOne(
      { topic: VIN, RTC: { $lte: nextIsoString }, ...filter },
      { _id: 0 }
    )
      .sort({ RTC: -1 })
      .limit(1)
      .lean();
  } catch (err) {
    mongoData = [];
  }
  return mongoData;
};

const getVehicleRunningStatus = (vData) => {
  let status = "NotRunning";
  var driveEnable = vData.C5 & 0x0020;
  var ignitionEnable = vData.C5 & 0x0800;
  if (ignitionEnable === 0x0800) {
    if (driveEnable === 0x0020) {
      var odo = (vData.C20 * 65536 + vData.C21) / 10;
      if (odo > 0) {
        status = "Running";
      }
    }
  }
  return status;
};

const getAllVehicles = async (req, res) => {
  // try {
  //   await connection(url);
  //   let data = [];

  //   const fleetVehicls = await sequelize.query(`select GROUP_CONCAT(DISTINCT cl.ClientFullName SEPARATOR ',') as fleetName,cv.vid,veh.VIN as vin, veh.VehicleRegNo, veh.model from Client cl
  //   join ClientVehicle cv on cl.cid = cv.cid
  //   join Vehicle veh on cv.vid = veh.vid where veh.deleteVehicleStatus=0 and (veh.VIN like "mq/MD9%" or veh.VIN like "mq/P6R%") group by vin`)

  //   for (const i of fleetVehicls[0]) {
  //     console.log(i.vin);
  //       let obj;

  //       let vData = await getMongoData(url, i.vin)
  //       if(!vData){
  //         obj = {
  //           "vin_id": i.vin.startsWith('mq/') ? i.vin.slice(3, ) : i.vin,
  //           "description":"No Data is Available for this VIN"
  //         }

  //         continue;
  //       }

  //           obj = {
  //             "vin": i.vin.startsWith('mq/') ? i.vin.slice(3, ) : i.vin,
  //             "vehicle_reg_number":i.VehicleRegNo,
  //             // "utc": unixtime(vData.RTC).toString(),
  //             // "rtc": vData.RTC,
  //             // "latitude": vData.lat.toFixed(6),
  //             // "latitude_side": vData.G3,
  //             // "longitude": vData.lng.toFixed(6),
  //             // "longitude_side": vData.G5,
  //             "fleet": i.fleetName,
  //             "soc":canKeyConfigurer({can: CAN_KEY_MAPPING.BATTERY_SOC48, value: vData[CAN_KEY_MAPPING.BATTERY_SOC48]}),
  //               "odometer": (canKeyConfigurer({can: CAN_KEY_MAPPING.ODOMETER_HIGH, value: vData[CAN_KEY_MAPPING.ODOMETER_HIGH]}) << 16 | canKeyConfigurer({can: CAN_KEY_MAPPING.ODOMETER_LOW, value: vData[CAN_KEY_MAPPING.ODOMETER_LOW]})) / 10,//fix

  //           }

  //       data.push(obj)

  //   }

  //   console.log(data.length);
  //   return res.json({
  //     "status": true,
  //     "code": 200,
  //     "values": data
  //   })
  // } catch (error) {
  //   console.log(error, "err");
  //   return res.json({
  //     status: false,
  //     code: 500,
  //     values: "Internal Server Error",
  //   });
  // }

  Client.belongsToMany(Vehicle, { through: ClientVehicle, foreignKey: "cid" });
  Vehicle.belongsToMany(Client, { through: ClientVehicle, foreignKey: "vid" });

  await connection(url);

  try {
    await sequelize.sync();

    // const { startOdo, endOdo } = req.body;

    let segmentResult = await VehicleDailyData.aggregate([
      {
        $match: {
          x11: {
            $gte: 0,
          },
          x11: {
            $ne: "NA",
          },
        },
      },
      {
        $sort: {
          date: -1, // Sort by date in descending order to get the latest dates first
        },
      },
      {
        $group: {
          _id: "$topic",
          end_odo: { $first: "$x11" },
          last_driven: { $first: "$date" },
        },
      },
    ],{allowDiskUse: true});

    console.log(segmentResult.length);
    let vinBla = segmentResult.map((item) => item._id);

    if (!segmentResult.length) {
      return res.status(200).json({
        status: false,
        data: [],
      });
    }

    vehiclesList = await Vehicle.findAll({
      attributes: ["VIN", "VehicleRegNo"],
      where: {
        deleteVehicleStatus: 0,
        [Op.or]: [
          { VIN: { [Op.like]: "mq/MD9%" } },
          { VIN: { [Op.like]: "mq/P6R%" } },
        ],
        VIN: {
          [Op.in]: segmentResult.map((item) => item._id),
        },
      },
      nest: true,
      include: [
        {
          model: Client,
          attributes: ["clientCode"],
          through: { attributes: [] },
        },
      ],
    });

    let vinDummy = vehiclesList.map((item) => item.VIN);

    result = vehiclesList.map((item) => ({
      // ...item.dataValues,
      vin: item.VIN.slice(3),
      vehicle_reg_number: item.VehicleRegNo,
      fleet: item["Clients"]
        .map((client) => client.dataValues.clientCode)
        .join(","),

      odometer:
        segmentResult.find((item1) => item1._id === item.VIN) !== undefined
          ? segmentResult.find((item1) => item1._id === item.VIN).end_odo
          : "No data",
      last_pinged:
        segmentResult.find((item1) => item1._id === item.VIN) !== undefined
          ? segmentResult.find((item1) => item1._id === item.VIN).last_driven
          : "No data",
    }));

    console.log(result.length);

    // return res.json({vinBla, vinDummy})

    return res.json({ status: true, code: 200, values: result });
  } catch (error) {
    console.log(error, "err");
    return res.json({
      status: false,
      code: 500,
      values: "Internal Server Error",
    });
  }
};

const vehicleUsage = async (req, res) => {
  try {
    await connection(url);

    let vin = req.body.vin;
    let dVin;

    if (!vin.startsWith("mq/")) {
      vin = "mq/" + vin;
      dVin = req.body.vin;
    } else {
      dVin = vin.slice(3);
    }

    const vehicleDailyData = await VehicleDailyData.find({
      $and: [{ topic: vin }, { x78: "Running" }],
    })
      .sort({ date: -1 })
      .limit(60);

    let data = [];
    for (const vData of vehicleDailyData) {
      data.push({
        date: vData.date,
        start_time: vData.x81 ? vData.x81 : "NA",
        end_time: vData.x82 ? vData.x82 : "NA",
        distance: vData.x12 ? Number(Number(vData.x12).toFixed(2)) : 0,
        start_odo: vData.x10 ? vData.x10 : 0,
        end_odo: vData.x11 ? vData.x11 : 0,
        start_soc: vData.x54 ? vData.x54 : 0,
        end_soc: vData.x55 ? vData.x55 : 0,
        energy_used: vData.x87 ? vData.x87 : 0,
        efficiency: vData.x35 ? vData.x35 : 0,
        avg_soh: vData.x53 ? vData.x53 : 0,
        max_im_temp: vData.x21 ? vData.x21 : 0,
        max_inv_temp: vData.x24 ? vData.x24 : 0,
        max_speed: vData.x14 ? vData.x14 : 0,
        avg_speed: vData.x13 ? vData.x13 : 0,
        regen: vData.x34 ? vData.x34 : 0, //x34
        // eEfficiency: vData.x35 ? vData.x35 : 0,
      });
    }

    return res.json({
      status: true,
      code: 200,
      values: data,
    });
  } catch (error) {
    console.log(error, "err");
    return res.json({
      status: false,
      code: 500,
      values: "Internal Server Error",
    });
  }
};

const vehicleDateRangeUsage = async (req, res) => {
  try {
    await connection(url);

    let { vin, startDate, endDate } = req.body;

    let dVin;

    if (!vin.startsWith("mq/")) {
      vin = "mq/" + vin;
      dVin = req.body.vin;
    } else {
      dVin = vin.slice(3);
    }
    console.log(dVin);

    const driveScore30DaysData = await driveScore
      .find({ vin: dVin })
      .sort({ Date: -1 })
      .limit(60)
      .select({
        _id: 0,
        vin: 1,
        Date: 1,
        drive_score: 1,
        // percentage_agressive_acceleration: 1,
        // percentage_agressive_turning: 1,
        eEfficiency: 1,
        // percentage_agressive_braking: 1,
        city: 1,
        // normalised_throttle_position: 1,
        // brake_pedal_percentage: 1,
        regen: 1,
      });

    // const vehicleDailyData = await VehicleDailyData.find({
    //   topic: vin,
    //   date: { $gte: startDate, $lte: endDate },
    // }).sort({ date: -1 });

    const vehicleDailyData = await VehicleDailyData.find({
      $and: [
        { topic: vin },
        { date: { $gte: startDate, $lte: endDate } },
        { x78: "Running" },
      ],
    }).sort({ date: -1 });

    let data = [];
    for (const vData of vehicleDailyData) {
      data.push({
        date: vData.date,
        start_time: vData.x81 ? vData.x81 : "NA",
        end_time: vData.x82 ? vData.x82 : "NA",
        distance: vData.x12 ? Number(Number(vData.x12).toFixed(2)) : 0,
        start_odo: vData.x10 ? vData.x10 : 0,
        end_odo: vData.x11 ? vData.x11 : 0,
        start_soc: vData.x54 ? vData.x54 : 0,
        end_soc: vData.x55 ? vData.x55 : 0,
        energy_used: vData.x87 ? vData.x87 : 0,
        efficiency: vData.x35 ? vData.x35 : 0,
        avg_soh: vData.x53 ? vData.x53 : 0,
        max_im_temp: vData.x21 ? vData.x21 : 0,
        max_inv_temp: vData.x24 ? vData.x24 : 0,
        max_speed: vData.x14 ? vData.x14 : 0,
        avg_speed: vData.x13 ? vData.x13 : 0,
        // drive_score: "NA",
        // percentage_agressive_acceleration: "NA",
        // percentage_agressive_braking: "NA",
        // percentage_agressive_turning: "NA",
        regen: vData.x34 ? vData.x34 : 0, //x34
        // eEfficiency: vData.x35 ? vData.x35 : 0,
      });
    }

    return res.json({
      status: true,
      code: 200,
      values: data,
    });
  } catch (error) {
    console.log(error, "err");
    return res.json({
      status: false,
      code: 500,
      values: "Internal Server Error",
    });
  }
};

const getDaysInMonth = (year, month) => {
  const startDate = new Date(year, month - 1, 1);
  const endDate = new Date(year, month, 0);
  const presentDate = new Date();
  const formattedDate = presentDate.toISOString().split("T")[0];
  let formattedDate2 = startDate.toISOString().split("T")[0];

  const days = [];
  let currentDate = startDate;

  while (currentDate <= endDate) {
    if (formattedDate > formattedDate2) {
      days.push(format(currentDate, "yyyy-MM-dd"));
    }
    currentDate = addDays(currentDate, 1);
    formattedDate2 = currentDate.toISOString().split("T")[0];
  }

  return days;
};

const formatterChartData1 = (vData) => {
  let obj = {
    date: "",
    vehiclesNotDriven: 0,
    vehiclesWithLowDistance: 0,
    vehiclesWithSignificantDistance: 0,
    totalVehicles: 0,
  };
  for (const i of vData) {
    obj.date = i.date;
    if (i.x12 == 0) {
      obj.vehiclesNotDriven++;
    }
    if (i.x12 > 0 && i.x12 <= 5) {
      obj.vehiclesWithLowDistance++;
    }
    if (i.x12 > 5 && i.x12 < 500) {
      obj.vehiclesWithSignificantDistance++;
    }
    if (i.x12 >= 0 && i.x12 <= 500) {
      obj.totalVehicles++;
    }
  }
  return obj;
};

const formatterChartData2 = (vData) => {
  let obj1 = {
    date: "",
    avgDistance: 0,
    maxDistance: 0,
  };

  let obj2 = {
    date: "",
    totalDistanceDriven: 0,
    maxDistance: 0,
  };

  let sumDistance = 0;
  let count = 0;
  for (const i of vData) {
    obj1.date = i.date;
    obj2.date = i.date;
    if (i.x12 >= 0 && i.x12 <= 500) {
      sumDistance += i.x12;
      count++;
      if (obj1.maxDistance < i.x12) {
        obj1.maxDistance = i.x12;
      }
    }
  }
  obj1.avgDistance = Number((sumDistance / count).toFixed(2));
  obj2.totalDistanceDriven = Number(sumDistance.toFixed(2));
  obj2.maxDistance = obj1.maxDistance;

  return { obj1, obj2 };
};

const vehicleChartData = async (req, res) => {
  try {
    await connection(url);

    const month = req.body.month;

    const year = parseInt(month.substring(0, 4));
    const monthNumber = parseInt(month.substring(5));

    const allDaysInMonth = getDaysInMonth(year, monthNumber);

    let vehicleStatus = [];
    let cumulativeMaxDistance = [];
    let avgMaxDistance = [];

    for (const date of allDaysInMonth) {
      const vehicleDailyData = await VehicleDailyData.find({
        date: date,
        $or: [
          { topic: { $regex: /^mq\/MD9/ } },
          { topic: { $regex: /^mq\/P6R/ } },
        ],
      }).select({ topic: 1, date: 1, x12: 1 });

      let result = formatterChartData1(vehicleDailyData);
      vehicleStatus.push(result);

      let result2 = formatterChartData2(vehicleDailyData);
      cumulativeMaxDistance.push(result2.obj2);
      avgMaxDistance.push(result2.obj1);
    }

    let data = {
      vehicleStatus: vehicleStatus,
      cumulativeMaxDistance: cumulativeMaxDistance,
      avgMaxDistance: avgMaxDistance,
    };

    return res.json({
      status: true,
      code: 200,
      values: data,
    });
  } catch (error) {
    console.log(error, "err");
    return res.json({
      status: false,
      code: 500,
      values: "Internal Server Error",
    });
  }
};

const anamolyData = async (req, res) => {
  try {
    await connection(url);
    await sequelize.sync();
    const { date } = req.body;
    const vehicleData =await sequelize.query(`select distinct veh.VIN as vin,veh.VehicleRegNo,veh.model,veh.SIMservicePrName,veh.network_type,veh.vehicleColor,
      GROUP_CONCAT(DISTINCT cl.ClientFullName SEPARATOR ',') as name,vs.vinserialnum,vs.type from Client cl 
      join ClientVehicle cv on cl.cid = cv.cid 
      join Vehicle veh on cv.vid = veh.vid 
      left join VinSerialNum vs on vs.vehicleId=veh.vid 
      where veh.deleteVehicleStatus=0 and 
      (veh.vin like 'mq/MD9%' or veh.vin like 'mq/P6R%' ) group by veh.vin`);
      // console.log(data[0],'dat')
    const vinsList = [];
    vehicleData[0].map((item) => {
      vinsList.push(item.vin);
    });
    // console.log(vinsList,'vinsList')
    // const conditions = [
    //   { $expr: { $gt: ["$x87", 30000] } }, //energy_used
    //   { $expr: { $lte: ["$x53", 0] } }, // avg_soh
    //   { $expr: { $gt: ["$x12", 500] } }, // distance
    //   { $expr: { $or: [{$eq: ["$x51", "NA"] }, {$eq: ["$x51", 0] }] }}, //start_ah
    //   { $expr: { $eq: ["$x52", 0] } }, // end_ah
    //   { $expr: { $gt: ["$x24", 75] } }, // max_inv_temp
    //   { $expr: { $gt: ["$x21", 160] } }, //max_im_temp
    //   { $expr: { $gt: ["$x35", 200] } }, // efficiency
    //   { $expr: { $and: [{ $lt: ["$x35", 60] }, { $gt: ["$x12", 5] }] } },
    //   { $expr: { $gt: ["$x100", "$x101"] } }, //start_charge_cycle_count end_charge_cycle_count
    //   { $expr: { $gt: ["$x10", "$x11"] } }, //start_odo end_odo
    //   // { $expr: { $gt: ["$x10", "$x11"] } },
    //   { $expr: { $gt: ["$x29", 0.3] } }, // max_delta_cell_voltage
    // ];

    // const vehicleDailyData = await VehicleDailyData.find({
    //   date: date,
    //   $and: [{ $or: conditions }, { x78: "Running" }],
    // }).select({
    //   _id: 0,
    //   topic: 1,
    //   date: 1,
    //   x78: 1,
    //   x1: 1,
    //   x96: 1,
    //   x87: 1,
    //   x53: 1,
    //   x12: 1,
    //   x51: 1,
    //   x52: 1,
    //   x24: 1,
    //   x21: 1,
    //   x35: 1,
    //   x100: 1,
    //   x101: 1,
    //   x10: 1,
    //   x11: 1,
    //   x29: 1,
    // });

    const conditions = [
      {
        $match: {
          date: date,
          x78: "Running",
          topic:{$in:vinsList},
          $or: [
            {
              $expr: {
                $and: [{ $gt: ["$x87", 30000] }, { $ne: ["$x87", "NA"] }],
              },
            }, //energy_used
            { $expr: { $lte: ["$x53", 0] } }, // avg_soh
            { $expr: { $gt: ["$x12", 500] } }, // distance
            { $expr: { $or: [{ $eq: ["$x51", "NA"] }, { $eq: ["$x51", 0] }] } }, //start_ah
            { $expr: { $eq: ["$x52", 0] } }, // end_ah
            { $expr: { $gt: ["$x24", 75] } }, // max_inv_temp
            { $expr: { $gt: ["$x21", 160] } }, //max_im_temp
            {
              $expr: {
                $and: [{ $gt: ["$x35", 200] }, { $ne: ["$x35", "NA"] }],
              },
            }, // efficiency
            {
              $expr: {
                $and: [{ $lt: ["$x35", 60] }, { $gt: ["$x12", 5] }],
              },
            },
            { $expr: { $gt: ["$x100", "$x101"] } }, //start_charge_cycle_count end_charge_cycle_count
            { $expr: { $gt: ["$x10", "$x11"] } }, //start_odo end_odo
            // { $expr: { $gt: ["$x10", "$x11"] } },
            { $expr: { $gt: ["$x29", 0.3] } }, // max_delta_cell_voltage
            { $expr: { $and: [{ $eq: ["$x59", "NA"] }] } },
            { $expr: { $and: [{ $lt: ["$x114", 10] }] } },
            {$expr:{$and:[{$gt:["$x12",1]},{$lt:["$x111",11]}]}}//maxBatteryData
          ],
        },
      },
      {
        $project: {
          _id: 0,
          topic: 1,
          date: 1,
          x78: 1,
          x1: 1,
          x96: 1,
          x87: 1,
          x53: 1,
          x12: 1,
          x51: 1,
          x52: 1,
          x24: 1,
          x21: 1,
          x35: 1,
          x100: 1,
          x101: 1,
          x10: 1,
          x11: 1,
          x29: 1,
          x58: 1,
          x59: 1,
          x114: 1,
          x111:1
        },
      },
    ];

    const vehicleDailyData = await VehicleDailyData.aggregate(conditions);

    // return res.json({vehicleDailyData})

    // const energy=vehicleDailyData.filter(item=>item.x87>30000)
    // return res.json({energy})
    // console.log(vehicleDailyData.length);
    const energyConsumptionAnamoly = [],
      chargeCycleAnamoly = [],
      distanceAnamoly = [],
      inverterTemperatureAnamoly = [],
      motorTempAnamoly = [],
      sohAnamoly = [],
      startAh = [],
      endAh = [],
      odoMeterAnamoly = [],
      energyUsedAnamoly = [],
      maxDeltaCellVoltage = [],
      geoCodeAnomaly = [],
      brakePedalAnomaly = [],
      maxBatteryData=[];

    // and  and (veh.vin like 'MD9%' or veh.vin like 'P6R%')

    for (let element of vehicleDailyData) {
      if ((element.x35 < 60 && element.x12 > 5) || element.x35 > 200) {
        energyConsumptionAnamoly.push({
          vin: element.topic.startsWith("mq/")
            ? element.topic.slice(3)
            : element.topic,
          vehicle_reg_number: element.x1,
          efficiency: element.x35,
          distance: element.x12,
          battery_type: element.x96,
        });
      }
      if (element.x51 == 0 || element.x51 === "NA") {
        // console.log(element.topic)
        startAh.push({
          vin: element.topic.startsWith("mq/")
            ? element.topic.slice(3)
            : element.topic,
          vehicle_reg_number: element.x1,
          start_ah: element.x51 ? element.x51 : "NA",
          battery_type: element.x96,
        });
      }

      if (element.x59 === "NA" && element.x12 > 0 && element.x12 <= 500) {
        // console.log(element.topic)
        geoCodeAnomaly.push({
          vin: element.topic.startsWith("mq/")
            ? element.topic.slice(3)
            : element.topic,
          vehicle_reg_number: element.x1,
          distance: element.x12,

          geo_code: element.x59,

          battery_type: element.x96,
        });
      }

      if (element.x114 < 10 && element.x12 > 0 && element.x12 <= 500) {
        // console.log(element.topic)
        brakePedalAnomaly.push({
          vin: element.topic.startsWith("mq/")
            ? element.topic.slice(3)
            : element.topic,
          vehicle_reg_number: element.x1,
          distance: element.x12,
          max_brake_pedal: element.x114,
        });
      }
      if (element.x52 == 0 || element.x52 === "NA") {
        endAh.push({
          vin: element.topic.startsWith("mq/")
            ? element.topic.slice(3)
            : element.topic,
          vehicle_reg_number: element.x1,
          end_ah: element.x52 ? element.x52 : "NA",
          battery_type: element.x96,
        });
      }
      if (element.x24 > 75) {
        inverterTemperatureAnamoly.push({
          vin: element.topic.startsWith("mq/")
            ? element.topic.slice(3)
            : element.topic,
          vehicle_reg_number: element.x1,
          max_inv_temp: element.x24,
          battery_type: element.x96,
        });
      }
      if (element.x21 > 160) {
        motorTempAnamoly.push({
          vin: element.topic.startsWith("mq/")
            ? element.topic.slice(3)
            : element.topic,
          vehicle_reg_number: element.x1,
          max_im_temp: element.x21,
          battery_type: element.x96,
        });
      }
      if (element.x100 > element.x101) {
        chargeCycleAnamoly.push({
          vin: element.topic.startsWith("mq/")
            ? element.topic.slice(3)
            : element.topic,
          vehicle_reg_number: element.x1,
          start_charge_cycle_count: element.x100,
          end_charge_cycle_count: element.x101,
          battery_type: element.x96,
        });
      }
      if (element.x12 > 300) {
        distanceAnamoly.push({
          vin: element.topic.startsWith("mq/")
            ? element.topic.slice(3)
            : element.topic,
          vehicle_reg_number: element.x1,
          distance: element.x12,
          battery_type: element.x96,
          start_odo: element.x10,
          end_odo: element.x11,
        });
      }
      if (element.x12 < 0 || element.x10 > element.x11) {
        odoMeterAnamoly.push({
          vin: element.topic.startsWith("mq/")
            ? element.topic.slice(3)
            : element.topic,
          vehicle_reg_number: element.x1,
          distance: element.x12,
          start_odo: element.x10,
          end_odo: element.x11,
          battery_type: element.x96,
        });
      }
      if (element.x53 == 0) {
        sohAnamoly.push({
          vin: element.topic.startsWith("mq/")
            ? element.topic.slice(3)
            : element.topic,
          vehicle_reg_number: element.x1,
          soh: element.x53,
          battery_type: element.x96,
        });
      }
      if (element.x87 > 30000) {
        // console.log(element.topic)
        energyUsedAnamoly.push({
          vin: element.topic.startsWith("mq/")
            ? element.topic.slice(3)
            : element.topic,
          vehicle_reg_number: element.x1,
          energy_used: element.x87,
          battery_type: element.x96,
        });
      }
      if (element.x29 > 0.3) {
        maxDeltaCellVoltage.push({
          vin: element.topic.startsWith("mq/")
            ? element.topic.slice(3)
            : element.topic,
          vehicle_reg_number: element.x1,
          max_delta_cell_voltage: element.x29,
          battery_type: element.x96,
        });
      }
      if(element.x12>=1 && element.x111<=11){
        maxBatteryData.push({
          vin: element.topic.startsWith("mq/")
            ? element.topic.slice(3)
            : element.topic,
          vehicle_reg_number: element.x1,
          battery_type: element.x96,
          max_battery_data: element.x111,
        });
      }
    }

    let data = {
      sohAnamoly: sohAnamoly,
      odoMeterAnamoly: odoMeterAnamoly,
      distanceAnamoly: distanceAnamoly,
      motorTempAnamoly: motorTempAnamoly,
      inverterTemperatureAnamoly: inverterTemperatureAnamoly,
      energyConsumptionAnamoly: energyConsumptionAnamoly,
      energyUsedAnamoly: energyUsedAnamoly,
      startAh: startAh,
      endAh: endAh,
      chargeCycleAnamoly: chargeCycleAnamoly,
      //totalAnamolies:result[0],
      maxDeltaCellVoltage: maxDeltaCellVoltage,
      geoCodeAnomaly: geoCodeAnomaly,
      brakePedalAnomaly: brakePedalAnomaly,
      maxBatteryData:maxBatteryData
      // totalAnamoliesLength: vehicleDailyData.length,
    };

    return res.json({
      status: true,
      code: 200,
      values: data,
    });
  } catch (error) {
    console.log(error, "err");
    return res.json({
      status: false,
      code: 500,
      values: "Internal Server Error",
    });
  }
};

function getYesterdayDate() {
  const today = new Date();
  const yesterday = new Date(today);
  yesterday.setDate(today.getDate() - 1);

  const year = yesterday.getFullYear();
  const month = String(yesterday.getMonth() + 1).padStart(2, "0"); // Months are zero-based
  const day = String(yesterday.getDate()).padStart(2, "0");

  const yesterdayFormatted = `${year}-${month}-${day}`;
  return yesterdayFormatted;
}

const fleetSegmentation = async (req, res) => {
  try {
    await connection(url);

    Client.belongsToMany(Vehicle, {
      through: ClientVehicle,
      foreignKey: "cid",
    });
    Vehicle.belongsToMany(Client, {
      through: ClientVehicle,
      foreignKey: "vid",
    });

    await sequelize.sync();

    const { fleet } = req.body;
    const today = moment().subtract(1, "days").format("YYYY-MM-DD");

    let result = {
      total_vehicles: [],
      todayDrivenVehicles: [],
      todayDistanceCovered: 0,
      topDistance: [],
      topOdo: [],
    };

    let vehiclesList;

    console.log("a");

    vehiclesList = await Vehicle.findAll({
      attributes: [
        ["VIN", "vin"],
        ["VehicleRegNo", "vehicle_reg_number"],
        "model",
        "SIMservicePrName",
        "network_type",
      ],
      where: {
        deleteVehicleStatus: 0,
        [Op.or]: [
          { VIN: { [Op.like]: "mq/MD9%" } },
          { VIN: { [Op.like]: "mq/P6R%" } },
        ],
      },
      nest: true,
      include: [
        {
          model: Client,
          attributes: [[sequelize.literal("TRIM(`clientCode`)"), "clientCode"]],
          through: {
            attributes: [],
          },
          where: {
            clientCode: {
              [Op.like]: `${fleet.trim()}`,
            },
          },
        },
      ],
    });

    if (!vehiclesList.length)
      return res.json({
        status: false,
        error: "No vehicles found",
      });

    console.log("");

    vehiclesList = vehiclesList.map((item) => ({
      vin: item.dataValues.vin.slice(3),
      vehicle_reg_number: item.dataValues.vehicle_reg_number,
      fleets: item["Clients"]
        .map((client) => client.dataValues.clientCode)
        .join(","),
      model: item.dataValues.model,
      SIMservicePrName: item.dataValues.SIMservicePrName,
      network_type: item.dataValues.network_type,
    }));

    console.log("c");

    let totalVehicles = await VehicleDailyData.aggregate([
      {
        $match: {
          topic: {
            $in: vehiclesList.map((vehicle) => "mq/" + vehicle.vin),
          },
          x78: "Running",
          x12: {
            $gt: 0,
            $lte: 500,
          },
          date: {
            $lte: today,
          },
        },
      },
      {
        $project: {
          topic: 1,
          date: 1,
          x12: 1,
          x11: 1,
        },
      },
      {
        $group: {
          _id: "$topic",
          topic: { $last: "$topic" },
          date: { $last: "$date" },
          x12: { $last: "$x12" },
          x11: { $last: "$x11" },
        },
      },
    ]);

    vehiclesList.forEach((cum) => {
      let vehicle = totalVehicles.find((v) => `mq/${cum.vin}` === v.topic);

      if (vehicle !== undefined) {
        let vehicleModified = {
          vin: cum.vin,
          vehicle_reg_number: cum.vehicle_reg_number,
          vehicle_reg_number: vehicle.vehicle_reg_number,
          fleets: cum.fleets,
          odometer: vehicle.x11,
          model: cum.model,
          SIMservicePrName: cum.SIMservicePrName,
          network_type: cum.network_type,
        };

        result.total_vehicles.push(vehicleModified);

        if (vehicle.date === today)
          result.todayDrivenVehicles.push({
            vin: cum.vin,
            vehicle_reg_number: cum.vehicle_reg_number,
            fleets: cum.fleets,
            distance: vehicle.x12,
            odometer: vehicle.x11,
            model: cum.model,
            SIMservicePrName: cum.SIMservicePrName,
            network_type: cum.network_type,
          });
        // console.log( result.todayDistanceCovered)

        // console.log(cum.vin, vehicle.x12)
      } else {
        // console.log(cum)
        let vehicleModified = {
          vin: cum.vin,
          vehicle_reg_number: cum.vehicle_reg_number,
          fleets: cum.fleets,
          end_odo: "NA",
          model: cum.model,
          SIMservicePrName: cum.SIMservicePrName,
          network_type: cum.network_type,
        };

        result.total_vehicles.push(vehicleModified);
      }
    });

    result.todayDistanceCovered = result.todayDrivenVehicles.reduce(
      (acc, cum) => acc + cum.distance,
      0
    );

    result.topDistance = [...result.todayDrivenVehicles]
      .sort((a, b) => b.distance - a.distance)
      .slice(0, 3)
      .map((vehicle) => ({
        vin: vehicle.vin,
        vehicle_reg_number: vehicle.vehicle_reg_number,
        distance: vehicle.distance,
        name: vehicle.fleets,
        model: vehicle.model,
      }));

    result.topOdo = [...result.todayDrivenVehicles]
      .sort((a, b) => b.odometer - a.odometer)
      .slice(0, 3)
      .map((vehicle) => ({
        vin: vehicle.vin,
        vehicle_reg_number: vehicle.vehicle_reg_number,
        odo: vehicle.odometer,
        name: vehicle.fleets,
        model: vehicle.model,
      }));

    console.log(result.todayDistanceCovered);

    return res.json({
      status: true,
      code: 200,
      values: result,
    });
  } catch (error) {
    console.log(error, "err");
    return res.json({
      status: false,
      code: 500,
      values: "Internal Server Error",
    });
  }
};

const fleetSegmentationMonthWise = async (req, res) => {
  try {
    await connection(url);

    Client.belongsToMany(Vehicle, {
      through: ClientVehicle,
      foreignKey: "cid",
    });
    Vehicle.belongsToMany(Client, {
      through: ClientVehicle,
      foreignKey: "vid",
    });

    await sequelize.sync();

    const { fleet, yearMonth } = req.body;
    let result = {
      total_distance_till_date: 0,
      total_vehicles_available: [],
      total_vehicles_driven: [],
      total_distance_covered: 0,
      topDistance: null,
      topOdo: null,
      state_wise_vehicles: {},
      state_wise_vehicles_driven: {},
      total_vehicle_days: 0,
      total_vehicle_days_gt60: 0,
      total_vehicle_days_gt80: 0,
      total_vehicle_days_gt100: 0,
      total_vehicle_days_gt150: 0,
      total_vehicle_days_gt200: 0,
      top20Distance: [],
      speedComparison: null,
      co2Saved: null,
      treesPlanted: null,
      rnfbData: null,
      chargingData: null,
    };
    let vehiclesList;
    let yesterday = moment().subtract("days", 1).format("YYYY-MM-DD");

    vehiclesList = await Vehicle.findAll({
      attributes: [
        ["VIN", "vin"],
        ["VehicleRegNo", "vehicle_reg_number"],
        "model",
        "SIMservicePrName",
        "network_type",
      ],
      where: {
        deleteVehicleStatus: 0,
        [Op.or]: [
          { VIN: { [Op.like]: "mq/MD9%" } },
          { VIN: { [Op.like]: "mq/P6R%" } },
        ],
      },
      nest: true,
      include: [
        {
          model: Client,
          attributes: [[sequelize.literal("TRIM(`clientCode`)"), "clientCode"]],
          through: {
            attributes: [],
          },
          where: {
            clientCode: {
              [Op.like]: `${fleet.trim()}`,
            },
          },
        },
      ],
    });

    if (!vehiclesList.length)
      return res.json({
        status: false,
        error: "No vehicles found",
      });

    vehiclesList = vehiclesList.map((item) => ({
      vin: item.dataValues.vin.slice(3),
      vehicle_reg_number: item.dataValues.vehicle_reg_number,
      fleets: item["Clients"]
        .map((client) => client.dataValues.clientCode)
        .join(","),
      model: item.dataValues.model,
      SIMservicePrName: item.dataValues.SIMservicePrName,
      network_type: item.dataValues.network_type,
    }));

    let vehiclesWithDistanceGT100 = await VehicleDailyData.aggregate([
      {
        $match: {
          topic: {
            $in: vehiclesList.map((vehicle) => "mq/" + vehicle.vin),
          },
          x78: "Running",
          date: {
            $regex: new RegExp(`^${yearMonth}`),
          },
          x12: {
            $gt: 0,
            $lte: 500,
          },
        },
      },
      {
        $group: {
          _id: "$topic",
          distance: { $sum: "$x12" },
          end_odo: { $last: "$x11" },
        },
      },
      {
        $match: {
          distance: {
            $gte: 100,
          },
        },
      },
    ]);

    let totalDistanceTillDate = await VehicleDailyData.aggregate([
      {
        $match: {
          x78: "Running",
          x11: { $lte: 200000 },
          // date: {
          //   $lte: yesterday,
          // },
          topic: {
            $in: vehiclesList.map((vehicle) => "mq/" + vehicle.vin),
          },
          // x78: "Running",
        },
      },
      {
        $group: {
          _id: "$topic",
          end_odo: { $last: "$x11" },
          last_driven: { $last: "$date" },
        },
      },
      {
        $group: {
          _id: null,
          totalDistance: { $sum: "$end_odo" },
        },
      },
    ]);

    if (totalDistanceTillDate.length) {
      result.total_distance_till_date = totalDistanceTillDate[0].totalDistance;
    }
    vehicleDistancegreaterThan100 = [];
    vehiclesWithDistanceGT100.map((item) => {
      let vehicle = vehiclesList.find((v) => `mq/${v.vin}` === item._id);
      if (vehicle != undefined) {
        vehicleDistancegreaterThan100.push({
          vin: vehicle.vin,
          vehicle_reg_number: vehicle.vehicle_reg_number,
          fleets: vehicle.fleets,
          distance: item.distance,
          odometer: item.end_odo,
          model: vehicle.model,
          SIMservicePrName: vehicle.SIMservicePrName,
          network_type: vehicle.network_type,
        });
      }
    });
    result.vehicleDistancegreaterThan100 = vehicleDistancegreaterThan100;
    vehiclesWithDistanceGT100 = vehiclesWithDistanceGT100.map(
      (item) => item._id
    );
    let totalVehiclesWithFacet = await VehicleDailyData.aggregate([
      {
        $match: {
          topic: {
            $in: vehiclesList.map((vehicle) => "mq/" + vehicle.vin),
          },
          x78: "Running",
        },
      },

      {
        $facet: {
          total_vehicles: [
            {
              $group: {
                _id: "$topic",
                topic: { $last: "$topic" },
                x12: { $sum: "$x12" },
                x11: { $last: "$x11" },
                x1: { $last: "$x1" },
              },
            },
          ],
          total_vehicles_driven: [
            {
              $match: {
                date: {
                  $regex: new RegExp(`^${yearMonth}`),
                },
                x12: {
                  $gt: 0,
                  $lte: 500,
                },
                x78: "Running",
              },
            },
            {
              $group: {
                _id: "$topic",
                topic: { $last: "$topic" },
                x12: { $sum: "$x12" },
                x11: { $max: "$x11" },
                x1: { $last: "$x1" },
                avgDistance: { $avg: "$x12" },
                maxDistance: { $max: "$x12" },
                minDistance: { $min: "$x12" },
                countX12GreaterThan1: {
                  $sum: {
                    $cond: [{ $gt: ["$x12", 1] }, 1, 0],
                  },
                },
              },
            },
          ],
          vehicle_days: [
            {
              $match: {
                topic: {
                  $in: vehiclesWithDistanceGT100,
                },
                date: {
                  $regex: new RegExp(`^${yearMonth}`),
                },
                x12: {
                  $gt: 0,
                  $lte: 500,
                },
              },
            },
            {
              $group: {
                _id: null,
                total_vehicle_days_gt_zero: {
                  $sum: {
                    $cond: {
                      if: { $gt: ["$x12", 1] },
                      then: 1,
                      else: 0,
                    },
                  },
                },
                total_vehicle_days_gt60: {
                  $sum: {
                    $cond: {
                      if: { $gt: ["$x12", 60] },
                      then: 1,
                      else: 0,
                    },
                  },
                },
                total_vehicle_days_gt80: {
                  $sum: {
                    $cond: {
                      if: { $gt: ["$x12", 80] },
                      then: 1,
                      else: 0,
                    },
                  },
                },
                total_vehicle_days_gt100: {
                  $sum: {
                    $cond: {
                      if: { $gt: ["$x12", 100] },
                      then: 1,
                      else: 0,
                    },
                  },
                },
                total_vehicle_days_gt150: {
                  $sum: {
                    $cond: {
                      if: { $gt: ["$x12", 150] },
                      then: 1,
                      else: 0,
                    },
                  },
                },
                total_vehicle_days_gt200: {
                  $sum: {
                    $cond: {
                      if: { $gt: ["$x12", 200] },
                      then: 1,
                      else: 0,
                    },
                  },
                },
              },
            },
          ],
          // vehiclesTravelledGT100: [
          //   {
          //     $match: {
          //       date: {
          //         $regex: new RegExp(`^${yearMonth}`),
          //       },
          //       x12: {
          //         $gt: 0,
          //         $lte: 500,
          //       },
          //     },
          //   },
          //   {
          //     $group: {
          //       _id: "$topic",
          //       totalDistance: {$sum: "$x12"}
          //     }
          //   }
          // ],
          top20Distance: [
            {
              $match: {
                date: {
                  $regex: new RegExp(`^${yearMonth}`),
                },
                x12: {
                  $gt: 0,
                  $lte: 500,
                },
              },
            },

            // {
            //   $group: {
            //     _id: "$topic",
            //     reg_no: { $first: "$x1" },
            //     date: { $first: "$date" },
            //     distance: { $first: "$x12" },
            //     end_odo: { $first: "$x11" },
            //     efficiency: { $first: "$x35" },
            //   },
            // },
            {
              $sort: {
                x12: -1,
              },
            },
            {
              $limit: 20,
            },
          ],
          speedComparison: [
            {
              $match: {
                x12: { $gt: 10 },
                date: {
                  $regex: new RegExp(`^${yearMonth}`),
                },
              },
            },
            {
              $group: {
                _id: null,
                "Speed < 10 KM/hr": { $sum: "$x41" },
                "Speed 10-20 Km/hr": { $sum: "$x42" },
                "Speed 20-30 Km/hr": { $sum: "$x43" },
                "Speed 30-40 Km/hr": { $sum: "$x44" },
                "Speed > 40 Km/hr": { $sum: "$x45" },
              },
            },
          ],
          rnfbData: [
            {
              $match: {
                date: {
                  $regex: new RegExp(`^${yearMonth}`),
                },
                x12: {
                  $gt: 0,
                  $lte: 500,
                },
              },
            },
            {
              $group: {
                _id: null,
                forward_mode: { $sum: "$x118" },
                boost_mode: { $sum: "$x119" },
                // reverse_mode: { $sum: "$x120" },
              },
            },
            {
              $project: {
                _id: 0,
              },
            },
          ],
          chargingData: [
            {
              $match: {
                date: {
                  $regex: new RegExp(`^${yearMonth}`),
                },
                x121: {
                  $ne: null,
                },
              },
            },
            {
              $group: {
                _id: null,
                total_count: { $sum: 1 },
                total_fast_charged: {
                  $sum: {
                    $cond: [
                      {
                        $and: [
                          { $eq: ["$x121", true] },
                          { $ne: ["$x122", true] }
                        ]
                      },
                      1,
                      0
                    ]
                  },
                },
                total_slow_charged: {
                  $sum: {
                    $cond: [
                      {
                        $and: [
                          { $eq: ["$x122", true] },
                          { $ne: ["$x121", true] }
                        ]
                      },
                      1,
                      0
                    ]
                  },
                },
                both_charged: {
                  $sum: {
                    $cond: [
                      {
                        $and: [
                          { $eq: ["$x122", true] },
                          { $eq: ["$x121", true] }
                        ]
                      },
                      1,
                      0
                    ]
                  },
                },
                vehicle_charging: {
                  $sum: "$x123",
                },
                vehicle_discharging: {
                  $sum: "$x124",
                },
              },
            },
          ],
        },
      },
    ]);

    totalVehiclesWithFacet = totalVehiclesWithFacet[0];

    vehiclesList.forEach((cum) => {
      // console.log(cum);
      let vehicle = totalVehiclesWithFacet.total_vehicles.find(
        (v) => `mq/${cum.vin}` === v.topic
      );

      if (vehicle !== undefined) {
        // console.log(cum)
        let vehicleModified = {
          vin: cum.vin,
          vehicle_reg_number: cum.vehicle_reg_number,
          // vehicle_reg_number: cum.x1,
          reg_no:cum.vehicle_reg_number,
          fleets: cum.fleets,
          end_odo: vehicle.x11,
          model: cum.model,
          SIMservicePrName: cum.SIMservicePrName,
          network_type: cum.network_type,
        };
        console.log(cum,vehicleModified,'first')
        result.total_vehicles_available.push(vehicleModified);

        let stateCode = stateCodes.find(
          (item) => item.code === cum.vehicle_reg_number.slice(0, 2)
        );

        if (stateCode !== undefined) {
          if (result.state_wise_vehicles.hasOwnProperty(stateCode.state)) {
            result.state_wise_vehicles[stateCode.state].push(vehicleModified);
          } else {
            result.state_wise_vehicles[stateCode.state] = [vehicleModified];
          }
        }
      } else {
        // console.log(cum)
        let vehicleModified = {
          vin: cum.vin,
          // vehicle_reg_number: cum.vehicle_reg_number,
          reg_no:cum.vehicle_reg_number,
          fleets: cum.fleets,
          end_odo: "NA",
          model: cum.model,
          SIMservicePrName: cum.SIMservicePrName,
          network_type: cum.network_type,
        };
        console.log(cum,vehicleModified,'second')
        result.total_vehicles_available.push(vehicleModified);
      }
    });

    totalVehiclesWithFacet.total_vehicles_driven.forEach((cum) => {
      let vehicle = vehiclesList.find((v) => `mq/${v.vin}` === cum.topic);
      if (vehicle !== undefined) {
        let vehicleModified = {
          vin: vehicle.vin,
          vehicle_reg_number: vehicle.vehicle_reg_number,
          fleets: vehicle.fleets,
          distance: cum.x12,
          end_odo: cum.x11,
          model: vehicle.model,
          SIMservicePrName: vehicle.SIMservicePrName,
          network_type: vehicle.network_type,
          "Total days(vehicle driven > 1 km)":cum.countX12GreaterThan1,
          'Avg Distance': cum.avgDistance.toFixed(2),
          'Max Distance': cum.maxDistance,
          'Min Distance': cum.minDistance,
        };

        result.total_vehicles_driven.push(vehicleModified);

        let stateCode = stateCodes.find(
          (item) => item.code === vehicle.vehicle_reg_number.slice(0, 2)
        );
        if (stateCode !== undefined) {
          if (
            result.state_wise_vehicles_driven.hasOwnProperty(stateCode.state)
          ) {
            result.state_wise_vehicles_driven[stateCode.state].push(
              vehicleModified
            );
          } else {
            result.state_wise_vehicles_driven[stateCode.state] = [
              vehicleModified,
            ];
          }
        }

        // result.total_distance_covered += vehicleModified.distance;
      }
    });

    result.total_distance_covered =
      totalVehiclesWithFacet.total_vehicles_driven.reduce(
        (acc, cum) => acc + cum.x12,
        0
      );

    let topDistance = [...totalVehiclesWithFacet.total_vehicles_driven].sort(
      (a, b) => b.x12 - a.x12
    );
    result.topDistance = topDistance.slice(0, 5).reduce((acc, cum) => {
      let vehicle = vehiclesList.find((v) => `mq/${v.vin}` === cum.topic);
      if (vehicle !== undefined) {
        return [
          ...acc,
          {
            vin: vehicle.vin,
            vehicle_reg_number: vehicle.vehicle_reg_number,
            name: vehicle.fleets,
            distance: cum.x12,
            model: vehicle.model,
            SIMservicePrName: vehicle.SIMservicePrName,
            network_type: vehicle.network_type,
          },
        ];
      } else return acc;
    }, []);

    let topOdo = [...totalVehiclesWithFacet.total_vehicles_driven].sort(
      (a, b) => b.x11 - a.x11
    );
    result.topOdo = topOdo.slice(0, 5).reduce((acc, cum) => {
      let vehicle = vehiclesList.find((v) => `mq/${v.vin}` === cum.topic);
      if (vehicle !== undefined) {
        return [
          ...acc,
          {
            vin: vehicle.vin,
            vehicle_reg_number: vehicle.vehicle_reg_number,
            name: vehicle.fleets,
            odo: cum.x11,
            model: vehicle.model,
            SIMservicePrName: vehicle.SIMservicePrName,
            network_type: vehicle.network_type,
          },
        ];
      } else return acc;
    }, []);

    Object.keys(result.state_wise_vehicles).map((state) => {
      if (
        Object.keys(!result.state_wise_vehicles_driven).hasOwnProperty(state)
      ) {
        result.state_wise_vehicles_driven = {
          ...result.state_wise_vehicles_driven,
          [state]: [],
        };
      }
    });

    result.state_wise_vehicles = Object.fromEntries(
      Object.entries(result.state_wise_vehicles).sort(
        (a, b) => b[1].length - a[1].length
      )
    );

    result.state_wise_vehicles_driven = Object.fromEntries(
      Object.entries(result.state_wise_vehicles).map(([key, value]) => {
        return [key, result.state_wise_vehicles_driven[key]];
      })
    );

    // let vehicles_with_distance_gt100 = totalVehiclesWithFacet.vehiclesTravelledGT100.map(item=>item._id);

    // console.log(totalVehiclesWithFacet.vehicle_days)
    if (totalVehiclesWithFacet.vehicle_days.length) {
      result.total_vehicle_days =
        totalVehiclesWithFacet.vehicle_days[0].total_vehicle_days_gt_zero;
      result.total_vehicle_days_gt60 =
        totalVehiclesWithFacet.vehicle_days[0].total_vehicle_days_gt60;
      result.total_vehicle_days_gt80 =
        totalVehiclesWithFacet.vehicle_days[0].total_vehicle_days_gt80;
      result.total_vehicle_days_gt100 =
        totalVehiclesWithFacet.vehicle_days[0].total_vehicle_days_gt100;
      result.total_vehicle_days_gt150 =
        totalVehiclesWithFacet.vehicle_days[0].total_vehicle_days_gt150;
      result.total_vehicle_days_gt200 =
        totalVehiclesWithFacet.vehicle_days[0].total_vehicle_days_gt200;
    }

    if (totalVehiclesWithFacet.top20Distance.length) {
      result.top20Distance = totalVehiclesWithFacet.top20Distance.map(
        (item) => ({
          vin: item.topic.slice(3),
          "Vehicle Reg Number": item.x1,
          Date: item.date,
          distance: item.x12,
          Odometer: item.x11,
          Efficiency: item.x35,
        })
      );
    }

    result.speedComparison = totalVehiclesWithFacet.speedComparison[0];
    delete result.speedComparison._id;

    result.speedComparison = Object.fromEntries(
      Object.entries(result.speedComparison).map(([key, value]) => [
        key,
        Number(Number(value).toFixed(2)),
      ])
    );

    let x = result.total_distance_covered / 25;
    result.co2Saved = Number(((x * 2.64) / 1000).toFixed(2));
    if (result.co2Saved)
      result.treesPlanted = (Number(result.co2Saved) / 22) * 1000;

    if (
      totalVehiclesWithFacet.rnfbData.length &&
      totalVehiclesWithFacet.rnfbData.length &&
      Object.values(totalVehiclesWithFacet.rnfbData[0]).some((item) => item)
    ) {
      let rnfb = {
        Boost: Number(
          Number(totalVehiclesWithFacet.rnfbData[0].boost_mode).toFixed(2)
        ),

        ECO: Number(
          Number(totalVehiclesWithFacet.rnfbData[0].forward_mode).toFixed(2)
        ),
        // Reverse: Number(Number(queryData[0].reverse_mode).toFixed(2)),
      };

      result.rnfbData = rnfb;
    }

    if (totalVehiclesWithFacet.chargingData.length) {
      let cData = totalVehiclesWithFacet.chargingData[0];
      total_count=cData.total_fast_charged+cData.total_slow_charged+cData.both_charged;
      console.log(cData.total_count,cData.total_fast_charged,cData.total_slow_charged,cData.both_charged )
      // let percentOfFastCharged = Number(
      //   (cData.total_fast_charged / cData.total_count) * 100
      // ).toFixed(2);
      // let percentOfSlowCharged = Number(
      //   (cData.total_slow_charged / cData.total_count) * 100
      // ).toFixed(2);
      let percentOfFastCharged = Number(
        (cData.total_fast_charged / total_count) * 100
      ).toFixed(2);
      let percentOfSlowCharged = Number(
        (cData.total_slow_charged / total_count) * 100
      ).toFixed(2);
      let percentOfBothCharged = Number(
        (cData.both_charged / total_count) * 100
      ).toFixed(2);

      console.log(cData);
      let totalSeconds = cData.vehicle_charging + cData.vehicle_discharging;
      // let percentChargedSeconds = Number((cData.vehicle_charging/totalSeconds)*100).toFixed(2);
      // let percentDischargedSeconds = Number((cData.vehicle_discharging/totalSeconds)*100).toFixed(2);

      result.chargingData = {
        "Fast Charged": Number(percentOfFastCharged),
        "Slow Charged": Number(percentOfSlowCharged),
        "Both Charged": Number(percentOfBothCharged)
      };
    }

    return res.json({
      status: true,
      code: 200,
      values: result,
    });
  } catch (error) {
    console.log(error, "err");
    return res.json({
      status: false,
      code: 500,
      values: "Internal Server Error",
    });
  }
};

function calculateStartEndDates(yearMonth) {
  const startDate = moment(yearMonth, "YYYY-MM")
    .startOf("month")
    .subtract(2, "months")
    .format("YYYY-MM-DD");
  const endDate = moment(yearMonth, "YYYY-MM")
    .endOf("month")
    .format("YYYY-MM-DD");
  return { startDate, endDate };
}

const fleetMonthData = async (
  vehiclesList,
  startDate,
  endDate,
  type,
  fleetAnomaliesData
) => {
  try {
    if (type === "bm") {
      let vehicleList = await vehicleListData("Altigreen");

      vehicleList = vehicleList.map((item) => item.dataValues.vin);

      //    console.log(vehicleList);

      const vehicleSalesVins = await VehicleSaleStatement.aggregate([
        { $group: { _id: "$chassis_no" } },
      ]);
      await connection(url);
      let vinsList = vehiclesList.map((i) =>
        !i.vin.startsWith("mq/") ? "mq/" + i.vin : i.vin
      );

      vehicleList = vehicleList.filter((vin) => !fleetAnomaliesData.includes(vin));

      console.log(vehicleList.find(item=>item === "mq/MD93WD6CGPB515111"),'abcd')

      const vehiclesDistanceGreaterThanHundred =
        await VehicleDailyData.aggregate([
          {
            $match: {
              topic: {
                $in: vinsList,
              },
              x78: "Running",
              date: {
                $gte: startDate,
                $lte: endDate,
              },
              x12: {
                $gt: 0,
                $lte: 500,
              },
            },
          },
          {
            $group: {
              _id: "$topic",
              distance: { $sum: "$x12" },
            },
          },
          {
            $match: {
              distance: {
                $gte: 100,
              },
            },
          },
        ]);
      const vinsListOfVehicleDays = vehiclesDistanceGreaterThanHundred.map(
        (i) => i._id
      );
      const data = await VehicleDailyData.aggregate([
        {
          $match: {
            date: {
              $gte: startDate,
              $lte: endDate,
            },
            // topic: {
            //   $in: vinsList,
            // },
            x12: { $gte: 0, $lte: 500 },
            // topic: {
            //   $in: vehicleList.filter(item=>vehicleSalesVins.find(item1=>item1._id === item.slice(3)))
            // }
          },
        },
        {
          $facet: {
            vehicletotalHighestDistance: [
              {
                $match: {
                  x78: "Running",
                  x12: {
                    $gt: 0,
                    $lte: 500,
                  },
                  // x35: {
                  //   $gte: 60,
                  //   $lte: 220,
                  // },
                  topic: {
                    $in: vehicleList.filter((item) =>
                      vehicleSalesVins.find(
                        (item1) => item1._id === item.slice(3)
                      )
                    ),
                  },
                },
              },
              {
                $group: {
                  _id: "$topic",
                  total_distance_covered: {
                    $sum: "$x12",
                  },
                  maxDistance: {
                    $max: "$x12",
                  },
                },
              },
              {
                $project: {
                  _id: 0,
                  total_distance_covered: "$total_distance_covered",
                  maxDistance: "$maxDistance",
                },
              },
            ],
            vehicleDistanceGreaterThanSixty: [
              {
                $match: {
                  $and: [
                    {
                      topic: {
                        $in: vinsList,
                      },
                      topic: { $in: vinsListOfVehicleDays },
                    },
                  ],

                  x78: "Running",
                },
              },
              {
                $group: {
                  _id: null,
                  total_vehicle_days_gt_zero: {
                    $sum: {
                      $cond: {
                        if: { $gt: ["$x12", 1] },
                        then: 1,
                        else: 0,
                      },
                    },
                  },
                  distanceGreaterThanSixty: {
                    $sum: {
                      $cond: {
                        if: { $gt: ["$x12", 60] },
                        then: 1,
                        else: 0,
                      },
                    },
                  },
                  distanceGreaterThanEighty: {
                    $sum: {
                      $cond: {
                        if: { $gt: ["$x12", 80] },
                        then: 1,
                        else: 0,
                      },
                    },
                  },
                  distanceGreaterThanHundred: {
                    $sum: {
                      $cond: {
                        if: { $gt: ["$x12", 100] },
                        then: 1,
                        else: 0,
                      },
                    },
                  },
                },
              },
            ],
            avgEfficiency: [
              {
                $match: {
                  $and: [
                    {
                      topic: {
                        $in: vinsList,
                      },
                      topic: { $in: vinsListOfVehicleDays },
                    },
                  ],

                  x78: "Running",
                  x12: {
                    $gt: 10,
                  },
                },
              },
              {
                $group: {
                  _id: null,
                  efficiency: { $avg: "$x35" },
                },
              },
            ],
            vehiclesSendingData: [
              {
                $match: {
                  x12: {
                    $gte: 0,
                    $lte: 500,
                  },
                  x78: "Running",
                  topic: {
                    $in: vinsList,
                  },
                },
              },
              {
                $group: {
                  _id: "$topic",
                  countOfVehicles: {
                    $sum: 1,
                  },
                },
              },
              {
                $count: "total_vehicles",
              },
            ],
            vehicleNotSendingData: [
              {
                $match: {
                  x78: { $in: ["NoData"] },
                  topic: {
                    $in: vinsList,
                  },
                },
              },
              {
                $group: {
                  _id: null,
                  countOfVehicles: {
                    $sum: 1,
                  },
                },
              },
              {
                $limit: 1,
              },
            ],
            vehicleCount: [
              {
                $match: {
                  x12: {
                    $gt: 0,
                    $lte: 500,
                  },
                  topic: {
                    $in: vinsList,
                  },
                },
              },
              {
                $group: {
                  _id: "$topic",
                  distance: {
                    $sum: "$x12",
                  },
                },
              },
            ],
          },
        },
      ]);
      let totalHighestDistance = 0,
        totalSumDistance = 0,
        percentageGreaterThanSixty = 0,
        percentageGreaterThanEighty = 0,
        percentageVehicleSendingData = 0,
        percentageVehicleUtilisation = 0,
        averageEfficiency = 0;
      let greaterThanSixty = null;
      let distanceGreaterThanHundredCount = 0,
        distanceCount = 0;
      if (data.length) {
        greaterThanSixty = data[0].vehicleDistanceGreaterThanSixty;
        averageEfficiency = data[0].avgEfficiency[0].efficiency;
        data[0].vehicleCount.map((i) => {
          if (i.distance > 100) {
            distanceGreaterThanHundredCount++;
          }
          distanceCount++;
        });
        data[0].vehicletotalHighestDistance.map(
          (i) =>
            (totalHighestDistance = Math.max(
              totalHighestDistance,
              i.total_distance_covered
            ))
        );
        data[0].vehicletotalHighestDistance.map(
          (i) => (totalSumDistance = Math.max(totalSumDistance, i.maxDistance))
        );
        percentageGreaterThanSixty = greaterThanSixty
          ? greaterThanSixty[0].distanceGreaterThanSixty /
            greaterThanSixty[0].total_vehicle_days_gt_zero
          : percentageGreaterThanSixty;
        percentageGreaterThanEighty = greaterThanSixty
          ? greaterThanSixty[0].distanceGreaterThanEighty /
            greaterThanSixty[0].total_vehicle_days_gt_zero
          : percentageGreaterThanEighty;
        percentageGreaterThanSixty = Number(
          (percentageGreaterThanSixty * 100).toFixed(2)
        );
        percentageGreaterThanEighty = Number(
          (percentageGreaterThanEighty * 100).toFixed(2)
        );

        // console.log(vinsList.length)

        // console.log(data[0].vehiclesSendingData[0].total_vehicles)
        percentageVehicleSendingData =
          data[0].vehiclesSendingData[0].total_vehicles / vinsList.length;
        percentageVehicleSendingData = Number(
          (percentageVehicleSendingData * 100).toFixed(2)
        );
        percentageVehicleUtilisation = vehiclesDistanceGreaterThanHundred.length
          ? vehiclesDistanceGreaterThanHundred.length
          : 0;
        // console.log(percentageVehicleUtilisation,'percentageVehicleUtilisation')
        percentageVehicleUtilisation = Number(
          (
            (percentageVehicleUtilisation /
              data[0].vehiclesSendingData[0].total_vehicles) *
            100
          ).toFixed(2)
        );
      }

      // console.log(percentageVehicleSendingData)
      return {
        totalHighestDistance: totalHighestDistance,
        totalSumDistance: totalSumDistance,
        percentageGreaterThanSixty,
        percentageGreaterThanEighty,
        percentageVehicleSendingData,
        percentageVehicleUtilisation,
        averageEfficiency,
        // vehicleUtilisation
        // data:data
        // vehiclesDistanceGreaterThanHundred:vinsListOfVehicleDays.length,
        // data:data,
        // greaterThanSixty:greaterThanSixty
      };
    } else {
      await connection(url);
      let vinsList = vehiclesList.map((i) =>
        !i.vin.startsWith("mq/") ? "mq/" + i.vin : i.vin
      );

      vinsList = vinsList.filter((vin) => !fleetAnomaliesData.includes(vin));

      const vehiclesDistanceGreaterThanHundred =
        await VehicleDailyData.aggregate([
          {
            $match: {
              topic: {
                $in: vinsList,
              },
              x78: "Running",
              date: {
                $gte: startDate,
                $lte: endDate,
              },
              x12: {
                $gt: 0,
                $lte: 500,
              },
            },
          },
          {
            $group: {
              _id: "$topic",
              distance: { $sum: "$x12" },
            },
          },
          {
            $match: {
              distance: {
                $gte: 100,
              },
            },
          },
        ]);
      const vinsListOfVehicleDays = vehiclesDistanceGreaterThanHundred.map(
        (i) => i._id
      );
      const data = await VehicleDailyData.aggregate([
        {
          $match: {
            date: {
              $gte: startDate,
              $lte: endDate,
            },
            topic: {
              $in: vinsList,
            },
            x12: { $gte: 0, $lte: 500 },
          },
        },
        {
          $facet: {
            vehicletotalHighestDistance: [
              {
                $match: {
                  x78: "Running",
                  // x35: {
                  //   $gte: 60,
                  //   $lte: 220,
                  // },
                  // x12: {
                  //   $gt: 0, $lte: 500
                  // }
                },
              },
              {
                $group: {
                  _id: "$topic",
                  total_distance_covered: {
                    $sum: "$x12",
                  },
                  maxDistance: {
                    $max: "$x12",
                  },
                },
              },
              {
                $project: {
                  _id: 0,
                  total_distance_covered: "$total_distance_covered",
                  maxDistance: "$maxDistance",
                },
              },
            ],
            vehicleDistanceGreaterThanSixty: [
              {
                $match: {
                  $and: [
                    {
                      topic: {
                        $in: vinsList,
                      },
                      topic: { $in: vinsListOfVehicleDays },
                    },
                  ],

                  x78: "Running",
                },
              },
              {
                $group: {
                  _id: null,
                  total_vehicle_days_gt_zero: {
                    $sum: {
                      $cond: {
                        if: { $gt: ["$x12", 1] },
                        then: 1,
                        else: 0,
                      },
                    },
                  },
                  distanceGreaterThanSixty: {
                    $sum: {
                      $cond: {
                        if: { $gt: ["$x12", 60] },
                        then: 1,
                        else: 0,
                      },
                    },
                  },
                  distanceGreaterThanEighty: {
                    $sum: {
                      $cond: {
                        if: { $gt: ["$x12", 80] },
                        then: 1,
                        else: 0,
                      },
                    },
                  },
                  distanceGreaterThanHundred: {
                    $sum: {
                      $cond: {
                        if: { $gt: ["$x12", 100] },
                        then: 1,
                        else: 0,
                      },
                    },
                  },
                },
              },
            ],
            avgEfficiency: [
              {
                $match: {
                  $and: [
                    {
                      topic: {
                        $in: vinsList,
                      },
                      topic: { $in: vinsListOfVehicleDays },
                    },
                  ],

                  x78: "Running",
                  x12: {
                    $gt: 10,
                  },
                },
              },
              {
                $group: {
                  _id: null,
                  efficiency: { $avg: "$x35" },
                },
              },
            ],
            vehiclesSendingData: [
              {
                $match: {
                  x12: {
                    $gte: 0,
                    $lte: 500,
                  },
                  x78: "Running",
                  topic: {
                    $in: vinsList,
                  },
                },
              },
              {
                $group: {
                  _id: "$topic",
                },
              },
              {
                $count: "total_vehicles",
              },
            ],
            vehicleNotSendingData: [
              {
                $match: {
                  x78: { $in: ["NoData"] },
                  topic: {
                    $in: vinsList,
                  },
                },
              },
              {
                $group: {
                  _id: null,
                  countOfVehicles: {
                    $sum: 1,
                  },
                },
              },
              {
                $limit: 1,
              },
            ],
            vehicleCount: [
              {
                $match: {
                  x12: {
                    $gt: 0,
                    $lte: 500,
                  },
                  topic: {
                    $in: vinsList,
                  },
                },
              },
              {
                $group: {
                  _id: "$topic",
                  distance: {
                    $sum: "$x12",
                  },
                },
              },
            ],
          },
        },
      ]);
      let totalHighestDistance = 0,
        totalSumDistance = 0,
        percentageGreaterThanSixty = 0,
        percentageGreaterThanEighty = 0,
        percentageVehicleSendingData = 0,
        percentageVehicleUtilisation = 0;
      let greaterThanSixty = null;
      let distanceGreaterThanHundredCount = 0,
        distanceCount = 0;
      if (data.length) {
        // console.log('driven vehicles', data[0].vehicleCount.length)
        greaterThanSixty = data[0].vehicleDistanceGreaterThanSixty;
        averageEfficiency = data[0].avgEfficiency[0].efficiency;

        data[0].vehicleCount.map((i) => {
          if (i.distance > 100) {
            distanceGreaterThanHundredCount++;
          }
          distanceCount++;
        });
        data[0].vehicletotalHighestDistance.map(
          (i) =>
            (totalHighestDistance = Math.max(
              totalHighestDistance,
              i.total_distance_covered
            ))
        );
        data[0].vehicletotalHighestDistance.map(
          (i) => (totalSumDistance = Math.max(totalSumDistance, i.maxDistance))
        );
        percentageGreaterThanSixty = greaterThanSixty
          ? greaterThanSixty[0].distanceGreaterThanSixty /
            greaterThanSixty[0].total_vehicle_days_gt_zero
          : percentageGreaterThanSixty;
        percentageGreaterThanEighty = greaterThanSixty
          ? greaterThanSixty[0].distanceGreaterThanEighty /
            greaterThanSixty[0].total_vehicle_days_gt_zero
          : percentageGreaterThanEighty;
        percentageGreaterThanSixty = Number(
          (percentageGreaterThanSixty * 100).toFixed(2)
        );
        percentageGreaterThanEighty = Number(
          (percentageGreaterThanEighty * 100).toFixed(2)
        );
        // console.log('fleet', data[0].vehiclesSendingData[0].total_vehicles);
        // console.log('fleet', vinsList.length)
        percentageVehicleSendingData =
          data[0].vehiclesSendingData[0].total_vehicles / vinsList.length;
        percentageVehicleSendingData = Number(
          (percentageVehicleSendingData * 100).toFixed(2)
        );
        // console.log(vehiclesDistanceGreaterThanHundred.length, distanceCount, )
        percentageVehicleUtilisation = vehiclesDistanceGreaterThanHundred.length
          ? vehiclesDistanceGreaterThanHundred.length
          : 0;
        // console.log(percentageVehicleUtilisation,'percentageVehicleUtilisation')
        percentageVehicleUtilisation = Number(
          (
            (percentageVehicleUtilisation /
              data[0].vehiclesSendingData[0].total_vehicles) *
            100
          ).toFixed(2)
        );
      }

      // console.log(percentageVehicleSendingData)
      return {
        totalHighestDistance: totalHighestDistance,
        totalSumDistance: totalSumDistance,
        percentageGreaterThanSixty,
        percentageGreaterThanEighty,
        percentageVehicleSendingData,
        percentageVehicleUtilisation,
        averageEfficiency,
        // vehicleUtilisation
        // data:data
        // vehiclesDistanceGreaterThanHundred:vinsListOfVehicleDays.length,
        // data:data,
        // greaterThanSixty:greaterThanSixty
      };
    }
  } catch (error) {
    console.log(error, "err");
  }
};

const vehicleListData = async (fleet) => {
  try {
    await sequelize.sync();
    Client.belongsToMany(Vehicle, {
      through: ClientVehicle,
      foreignKey: "cid",
    });
    Vehicle.belongsToMany(Client, {
      through: ClientVehicle,
      foreignKey: "vid",
    });
    vehiclesList = await Vehicle.findAll({
      attributes: [
        ["VIN", "vin"],
        ["VehicleRegNo", "vehicle_reg_number"],
        "model",
        "SIMservicePrName",
        "network_type",
      ],
      where: {
        deleteVehicleStatus: 0,
        [Op.or]: [
          { VIN: { [Op.like]: "mq/MD9%" } },
          { VIN: { [Op.like]: "mq/P6R%" } },
        ],
      },
      nest: true,
      include: [
        {
          model: Client,
          attributes: [[sequelize.literal("TRIM(`clientCode`)"), "clientCode"]],
          through: {
            attributes: [],
          },
          where: {
            clientCode: {
              [Op.like]: `${fleet.trim()}`,
            },
          },
        },
      ],
    });

    return vehiclesList;
  } catch (error) {
    console.log(error, "err");
    return error;
  }
};

const fleetWisePdfData = async (req, res) => {
  try {
    await connection(url);
    const {
      fleet,
      yearMonth,
      bmFleet,
      free_service_due,
      paid_service_due,
      sendAnamolyVehicles,
    } = req.body;
    // console.log(sendAnamolyVehicles,'sendAnamolyVehicles')
    const startD = moment(yearMonth, "YYYY-MM")
      .startOf("month")
      .format("YYYY-MM-DD");
    const endD = moment(yearMonth, "YYYY-MM")
      .endOf("month")
      .format("YYYY-MM-DD");
      let previousYearMonth = moment(yearMonth, 'YYYY-MM').subtract(1, 'months');

// Format the date back to "YYYY-MM"
previousYearMonth = previousYearMonth.format('YYYY-MM');
    // console.log(startD, endD, yearMonth)
    const { startDate, endDate } = calculateStartEndDates(yearMonth);
    let vehiclesList = await vehicleListData(fleet);
    // console.log(vehiclesList,'vehicleList')
    if (!vehiclesList.length)
      return res.json({
        status: false,
        error: "No vehicles found",
      });

    vehiclesList = vehiclesList.map((item) => ({
      vin: item.dataValues.vin.slice(3),
      vehicle_reg_number: item.dataValues.vehicle_reg_number,
      fleets: item["Clients"]
        .map((client) => client.dataValues.clientCode)
        .join(","),
      model: item.dataValues.model,
      SIMservicePrName: item.dataValues.SIMservicePrName,
      network_type: item.dataValues.network_type,
    }));
    let vinsList = vehiclesList.map((vehicle) => "mq/" + vehicle.vin);

  

    let fleetAnomaliesData = await FleetAnomalies.findOne({
      where: { monthYear: yearMonth },
      raw: true,
      attributes: ["vins"],
    });

    let fleetAnomaliesDataPrev = await FleetAnomalies.findOne({
      where: { monthYear: previousYearMonth },
      raw: true,
      attributes: ["vins"],
    });

    if (!fleetAnomaliesData) {
      fleetAnomaliesData = {
        vins: ['mq/MD93WD6CZNL515009','mq/MD93WD6CZND515263'],
      };
    }
    else{
      console.log(fleetAnomaliesData)
      fleetAnomaliesData = {
        vins: [...fleetAnomaliesData.vins.split(','),'mq/MD93WD6CZNL515009','mq/MD93WD6CZND515263'],
      };
    }

    if (!fleetAnomaliesDataPrev) {
      fleetAnomaliesDataPrev = {
        vins: ['mq/MD93WD6CZNL515009','mq/MD93WD6CZND515263'],
      };
    }
    else{
      console.log(fleetAnomaliesData)
      fleetAnomaliesDataPrev = {
        vins: [...fleetAnomaliesDataPrev.vins.split(','), 'mq/MD93WD6CZNL515009','mq/MD93WD6CZND515263'],
      };
    }

    let mongoQuery = await VehicleDailyData.aggregate([
      {
        $match: {
          topic: {
            $in: vinsList,
          },
          x78: "Running",

          date: {
            $gte: startD,
            $lte: endD,
          },
          x12: {
            $gt: 0,
            $lte: 500,
          },
        },
      },
      {
        $facet: {
          page1: [
            {
              $match: {
                topic: {
                  $nin: fleetAnomaliesData.vins,
                },
              },
            },
            {
              $group: {
                _id: null,
                total_distance: { $sum: "$x12" },
              },
            },
          ],
          page3: [
            {
              $match: {
                x78: "Running",
              },
            },
            {
              $project: {
                _id: 0,
                x1: 1,
                x11: 1,
                x12: 1,
                x13: 1,
              },
            },
          ],
          page3Graph: [
            {
              $group: {
                _id: null,
                Eco: { $sum: "$x118" },
                Boost: { $sum: "$x119" },
              },
            },
            {
              $project: {
                _id: 0,
                Boost: 1,
                Eco: 1,
              },
            },
          ],
          page3VehicleSpeedGraph: [
            {
              $match: {
                x12: { $gt: 10 },
                date: {
                  $regex: new RegExp(`^${yearMonth}`),
                },
              },
            },
            {
              $group: {
                _id: null,
                "Speed < 10 KM/hr": { $sum: "$x41" },
                "Speed 10-20 Km/hr": { $sum: "$x42" },
                "Speed 20-30 Km/hr": { $sum: "$x43" },
                "Speed 30-40 Km/hr": { $sum: "$x44" },
                "Speed > 40 Km/hr": { $sum: "$x45" },
              },
            },
            {
              $project: {
                _id: 0,
                "Speed < 10 KM/hr": 1,
                "Speed 10-20 Km/hr": 1,
                "Speed 20-30 Km/hr": 1,
                "Speed 30-40 Km/hr": 1,
                "Speed > 40 Km/hr": 1,
              },
            },
          ],
          geoNotSent: [
            {
              $match: {
                x59: "NA",
              },
            },
            {
              $group: {
                _id: "$topic",
              },
            },
          ],
          maxBrakePedalAnomalies: [
            {
              $match: {
                x114: {
                  $lt: 10,
                },
              },
            },
            {
              $group: {
                _id: "$topic",
              },
            },
          ],
        },
      },
    ]);

    if (!mongoQuery.length)
      return res.json({
        status: false,
        message: "No data",
      });

    let page1Data = mongoQuery[0].page1[0];
    let graphPage3 = mongoQuery[0].page3;
    let graph2 = mongoQuery[0].page3Graph;
    let vehicleSpeedGraph = mongoQuery[0].page3VehicleSpeedGraph;
    // console.log(graph2);

    let lastTable = {
      geoNotSent: mongoQuery[0].geoNotSent.length,
      maxBrakePedalAnomalies: mongoQuery[0].maxBrakePedalAnomalies.length,
    };

    let mongoQuery1 = await VehicleDailyData.aggregate([
      {
        $match: {
          topic: {
            $in: vinsList,
            $nin: fleetAnomaliesData.vins,
          },
          date: {
            $gte: startDate,
            $lte: endDate,
          },
          x12: {
            $gte: 0,
            $lte: 500,
          },
          x78: "Running",
        },
      },
      {
        $project: {
          month: { $substr: ["$date", 0, 7] },
          x12: 1,
        },
      },
      {
        $group: {
          _id: "$month",
          totalDistance: { $sum: "$x12" },
        },
      },
      {
        $project: {
          _id: 0,
          month: "$_id",
          totalDistance: 1,
        },
      },
      {
        $sort: { month: 1 },
      },
    ]);

    let mongoQuery2 = await VehicleDailyData.aggregate([
      {
        $match: {
          topic: {
            $in: vinsList,
          },
          x78: "Running",
          date: {
            $gte: startD,
            $lte: endD,
          },
          x12: { $gt: 0, $lte: 500 },
          x35: {
            $gte: 60,
            $lte: 220,
          },
        },
      },
      {
        $facet: {
          distance: [
            {
              $match: {
                topic: {
                  $nin: fleetAnomaliesData.vins,
                },
              },
            },
            {
              $group: {
                _id: "$x1",
                totalDistance: { $sum: "$x12" },
              },
            },
            {
              $project: {
                _id: 0,
                vehicle_reg_number: "$_id",
                totalDistance: 1,
              },
            },
            {
              $sort: { totalDistance: -1 },
            },
            {
              $limit: 5,
            },
          ],
          odo: [
            {
              $match: {
                topic: {
                  $nin: fleetAnomaliesData.vins,
                },
              },
            },
            {
              $group: {
                _id: "$x1",
                totalOdo: { $max: "$x11" },
              },
            },
            {
              $project: {
                _id: 0,
                vehicle_reg_number: "$_id",
                totalOdo: 1,
              },
            },
            {
              $sort: { totalOdo: -1 },
            },
            {
              $limit: 5,
            },
          ],
        },
      },
    ]);

    let objData = {
      "<10km/hr": 0,
      "10-20km/hr": 0,
      "20-30km/hr": 0,
      "30-40km/hr": 0,
      ">40km/hr": 0,
    };

    for (let i of graphPage3) {
      if (i.x13 <= 10) {
        objData["<10km/hr"]++;
      } else if (i.x13 > 10 && i.x13 <= 20) {
        objData["10-20km/hr"]++;
      } else if (i.x13 > 20 && i.x13 <= 30) {
        objData["20-30km/hr"]++;
      } else if (i.x13 > 30 && i.x13 <= 40) {
        objData["30-40km/hr"]++;
      } else if (i.x13 > 40) {
        objData[">40km/hr"]++;
      }
    }

    let x = page1Data["total_distance"] / 25;
    let co2reduced = Number(((x * 2.64) / 1000).toFixed(2));
    let treeYearPlanted = (Number(co2reduced) / 22) * 1000;

    page1Data["tot_co2_saved"] = co2reduced;
    page1Data["tot_vehicles"] = vehiclesList.length;
    page1Data["num_of_trees"] = Math.ceil(treeYearPlanted);
    page1Data["total_distance"] = Math.round(page1Data["total_distance"]);
    page1Data["table_data"] = mongoQuery1;

    const topFiveVehicleData = await VehicleDailyData.aggregate([
      {
        $match: {
          date: {
            $gte: startD,
            $lte: endD,
          },
          topic: {
            $in: vinsList,
          },
          x12: { $gt: 0, $lte: 500 },
          x35: {
            $gte: 60,
            $lte: 220,
          },
        },
      },
      {
        $match: {
          topic: {
            $nin: fleetAnomaliesData.vins,
          },
        },
      },

      {
        $sort: {
          x12: -1,
        },
      },
      {
        $limit: 5,
      },

      {
        $project: {
          _id: 0,
          vehicle_reg_number: "$x1",
          distance: "$x12",
          date: 1,
        },
      },
    ]);
    const previousMonthStartDate = moment(startD)
      .subtract(1, "months")
      .startOf("month")
      .format("YYYY-MM-DD");
    const previousMonthEndDate = moment(startD)
      .subtract(1, "months")
      .endOf("month")
      .format("YYYY-MM-DD");
    const currentMonthFleet = await fleetMonthData(
      vehiclesList,
      startD,
      endD,
      "",
      fleetAnomaliesData.vins
    );
    const prevMonthFleet = await fleetMonthData(
      vehiclesList,
      previousMonthStartDate,
      previousMonthEndDate,
      "",
      fleetAnomaliesDataPrev.vins
    );
    let BmVehicleList = await vehicleListData(bmFleet);
    const BmVehicleVins = BmVehicleList.map((i) => i.dataValues);

    const currentMonthBMFleet = await fleetMonthData(
      BmVehicleVins,
      startD,
      endD,
      "bm",
      fleetAnomaliesData.vins
    );

    const startDmy = moment(yearMonth, "YYYY-MM")
      .startOf("month")
      .format("DD-MM-YYYY");
    const endDmy = moment(yearMonth, "YYYY-MM")
      .endOf("month")
      .format("DD-MM-YYYY");

    // console.log(startDmy, endDmy);

    let serviceDetails = await AplJobCards.aggregate([
      {
        $match: {
          vin: {
            $in: vehiclesList.map((item) => item.vin),
          },
          repair_order_date: {
            $regex: new RegExp(yearMonth.split("-").reverse().join("-")),
          },
        },
      },
      {
        $facet: {
          free_service: [
            {
              $match: {
                repair_type: {
                  $in: [
                    "First Free Service",
                    "Second Free Service",
                    "Third Free Service",
                    "Fourth Free Service",
                  ],
                },
              },
            },
            {
              $group: {
                _id: "$vin",
              },
            },
            {
              $count: "total_free_services",
            },
          ],
          paid_service: [
            {
              $match: {
                repair_type: {
                  $in: ["Paid"],
                },
                part_description: {
                  $in: ['Paid Service Non AMC', 'Paid Service AMC']
                }
              },
            },
            {
              $group: {
                _id: "$vin",
              },
            },
            {
              $count: "total_paid_services",
            },
          ],
        },
      },
    ]);

    // console.log(serviceDetails)

    let blaObje = [
      {
        "Service Type": "Free Servce",
        Due: free_service_due,
        Done: serviceDetails[0]["free_service"].length
          ? serviceDetails[0]["free_service"][0]["total_free_services"]
          : 0,
      },
      {
        "Service Type": "Paid Service",
        Due: paid_service_due,
        Done: serviceDetails[0]["paid_service"].length
          ? serviceDetails[0]["paid_service"][0]["total_paid_services"]
          : 0,
      },
    ];

    let responseData = {
      page1Data,
      page3TableData: mongoQuery2,
      page3GtaphData: { graph1: vehicleSpeedGraph[0], graph2 },
      topFiveVehicleData: topFiveVehicleData,
      // page2Data:currentMonthFleet,
      vehicleFleetData: {
        currentMonthFleet: currentMonthFleet,
        prevMonthFleet: prevMonthFleet,
        currentMonthBMFleet: currentMonthBMFleet,
        serviceDetails: blaObje,
        ...lastTable,
      },
    };

    if (sendAnamolyVehicles) {
      geoNotSentVehicles = mongoQuery[0].geoNotSent.map((i) =>
        i["_id"].slice(3)
      );
      maxBrakePedalAnomalies = mongoQuery[0].maxBrakePedalAnomalies.map((i) =>
        i["_id"].slice(3)
      );
      if (geoNotSentVehicles.length != 0 || maxBrakePedalAnomalies.length != 0)
        responseData["anamolyData"] = {
          geoNotSentVehicles,
          maxBrakePedalAnomalies,
        };
    }
    return res.json({
      status: true,
      code: 200,
      data: responseData,
    });
  } catch (error) {
    console.log(error, "err");
    return res.json({
      status: false,
      code: 500,
      values: "Internal Server Error",
    });
  }
};

const fleetSegmentationConfiguration = async (req, res) => {
  try {
    await connection(url);
    await sequelize.sync();
    Vehicle.belongsToMany(Client, {
      through: ClientVehicle,
      foreignKey: "vid",
    });
    Client.belongsToMany(Vehicle, {
      through: ClientVehicle,
      foreignKey: "cid",
    });

    let { fleet } = req.body;

    const data =
      await sequelize.query(`select distinct veh.VIN as vin,veh.VehicleRegNo,veh.model,veh.SIMservicePrName,veh.network_type,veh.vehicleColor,
      GROUP_CONCAT(DISTINCT cl.ClientFullName SEPARATOR ',') as name,vs.vinserialnum,vs.type from Client cl 
      join ClientVehicle cv on cl.cid = cv.cid 
      join Vehicle veh on cv.vid = veh.vid 
      left join VinSerialNum vs on vs.vehicleId=veh.vid 
      where veh.deleteVehicleStatus=0 and 
      (veh.vin like 'mq/MD9%' or veh.vin like 'mq/P6R%' ) and cl.ClientFullName like '${fleet}' group by veh.vin`);
      // console.log(data[0],'dat')
    const vinsList = [];
    VehicleTableData = {};
    const VehicleModelObject={neEv:[],BHAI:[],TEZ:[],RAHI:[]}
    data[0].map((item) => {
      vinsList.push(item.vin);
      VehicleTableData[item.vin] = item;
    });
    // console.log(VehicleModelObject)
    let yesterday = moment().subtract("days", 1).format("YYYY-MM-DD");
    


    let query = await VehicleDailyData.aggregate([
      {
        $match: {
          date: { $lte: yesterday },
          topic: { $in: vinsList },
          x12: { $gt: 0, $lte: 500, $ne: "NA" },
          x96: { $ne: null },
          x86: { $ne: 0 },
          x85: { $ne: 0 },
        },
      },
      {
        $group: {
          _id: "$topic",
          vehicle_reg_number: { $last: "$x1" },
          date: { $last: "$date" },
          controller_software_version: { $last: "$x85" },
          display_software_version: { $last: "$x86" },
          odo: { $last: "$x11" },
          soc: { $last: "$x55" },
          total_distance: { $last: "$x12" },
          battery_type: { $last: "$x96" },
          end_geo_code: { $last: "$x59" },
          max_brake_pedal: { $last: "$x114" },
        },
      },
    ]);

    let vehicleNotPinged = await VehicleDailyData.aggregate(
      [
        {
          $match: {
            date: {
              $lte: yesterday,
            },
            topic: {
              $in: vinsList,
            },
          },
        },
        {
          $project: {
            _id: 0,
            date: 1,
            topic: 1,
            x78: 1,
            x1: 1,
          },
        },
        {
          $sort: {
            date: -1, // Sort by date descending
          },
        },
        {
          $group: {
            _id: "$topic", // Group by VIN
            docs: { $push: "$$ROOT" }, // Push each document into an array
          },
        },
        {
          $project: {
            _id: 0, // Exclude _id field
            topic: "$_id", // Rename _id to topic
            docs: { $slice: ["$docs", 10] }, // Take only the first 10 documents for each group (VIN)
          },
        },
      ],
      { allowDiskUse: true }
    );

    if (!query.length) {
      return res.json({
        status: false,
        code: 401,
        data: "No Data",
      });
    }

    let maxBatteryData=await VehicleDailyData.aggregate([
      {
        $match:{
          date:yesterday,
          topic:{
            $in:vinsList
          },
          x12:{$gt:1},
          x111:{$lt:11}
        }
      },
      {
        $project:{
          _id:0,
          vin:'$topic',
          VehicleRegNo:'$x1',
          max_12v_battery:'$x111',
          min_12v_battery:'$x110',
          end_odo:'$x11',
        }
      }
    ])

    let result = query.reduce(
      (acc, cur) => {
        let returnObject = { ...acc };
        //console.log(VehicleTableData[cur._id]['type'],cur,'ele')
        VehicleModelObject[VehicleTableData[cur._id]['type']]?VehicleModelObject[VehicleTableData[cur._id]['type']].push({
        vin: cur._id.slice(3),
        vehicle_reg_number: cur.vehicle_reg_number,
        vinserialnum:VehicleTableData[cur._id]['vinserialnum'],
        type:VehicleTableData[cur._id]['type'],
        end_odo: cur.odo,
      }):""

        //controller software version
        if (
          acc.controller_software_version.hasOwnProperty(
            `v${cur.controller_software_version}`
          )
        ) {
          returnObject.controller_software_version[
            `v${cur.controller_software_version}`
          ].push({
            vin: cur._id.slice(3),
            vehicle_reg_number: cur.vehicle_reg_number,
            controller_software_version: cur.controller_software_version,
            end_soc: cur.soc,
            end_odo: cur.odo,
          });
        } else {
          returnObject.controller_software_version[
            `v${cur.controller_software_version}`
          ] = [
            {
              vin: cur._id.slice(3),
              vehicle_reg_number: cur.vehicle_reg_number,
              controller_software_version: cur.controller_software_version,
              end_soc: cur.soc,
              end_odo: cur.odo,
            },
          ];
        }

        //display software version
        if (
          acc.display_software_version.hasOwnProperty(
            `v${cur.display_software_version}`
          )
        ) {
          returnObject.display_software_version[
            `v${cur.display_software_version}`
          ].push({
            vin: cur._id.slice(3),
            vehicle_reg_number: cur.vehicle_reg_number,
            display_software_version: cur.display_software_version,
            end_soc: cur.soc,
            end_odo: cur.odo,
          });
        } else {
          returnObject.display_software_version[
            `v${cur.display_software_version}`
          ] = [
            {
              vin: cur._id.slice(3),
              vehicle_reg_number: cur.vehicle_reg_number,
              display_software_version: cur.display_software_version,
              end_soc: cur.soc,
              end_odo: cur.odo,
            },
          ];
        }

        //battery type
        if (acc.battery_type.hasOwnProperty(`${cur.battery_type}`)) {
          returnObject.battery_type[`${cur.battery_type}`].push({
            vin: cur._id.slice(3),
            vehicle_reg_number: cur.vehicle_reg_number,
            battery_type: cur.battery_type,
            end_soc: cur.soc,
            end_odo: cur.odo,
          });
        } else {
          returnObject.battery_type[`${cur.battery_type}`] = [
            {
              vin: cur._id.slice(3),
              vehicle_reg_number: cur.vehicle_reg_number,
              battery_type: cur.battery_type,
              end_soc: cur.soc,
              end_odo: cur.odo,
            },
          ];
        }

        //max brake pedal and geo location anomalies
        // if (cur.date === yesterday) {
        //max brake pedal
        if (
          cur.max_brake_pedal !== null &&
          cur.max_brake_pedal !== "NA" &&
          cur.max_brake_pedal !== "" &&
          cur.max_brake_pedal < 10
        )
          returnObject.maxBrakePedal.push({
            vin: cur._id.slice(3),
            vehicle_reg_number: cur.vehicle_reg_number,
            max_brake_pedal: cur.max_brake_pedal,
            end_soc: cur.soc,
            end_odo: cur.odo,
          });

        //geo anomalies
        if (cur.end_geo_code === "NA")
          returnObject.geoNotSent.push({
            vin: cur._id.slice(3),
            vehicle_reg_number: cur.vehicle_reg_number,
            end_geo: cur.end_geo,
            end_soc: cur.soc,
            end_odo: cur.odo,
          });
        // }

        return returnObject;
      },
      {
        controller_software_version: {},
        display_software_version: {},
        battery_type: {},
        geoNotSent: [],
        maxBrakePedal: [],
      }
    );

    let vehicle_not_pinged = vehicleNotPinged.reduce((acc, curr) => {
      const allNADocs = curr.docs.every((doc) => doc.x78 === "NoData");
      if (allNADocs) {
        acc.push({
          vin: curr.topic.slice(3),
          vehicle_reg_number: curr.docs[0].x1,
        });
      }
      return acc;
    }, []);

    return res.json({
      status: true,
      code: 200,
      data: {
        ...result,
        vehicle_not_pinged,
        VehicleModelObject,
        maxBatteryData
      },
    });
  } catch (error) {
    console.log(error);
    return res.json({ status: false, code: 500, data: error });
  }
};

const fleetSegmentationDriveScore = async (req, res) => {
  try {
    await connection(url);

    Client.belongsToMany(Vehicle, {
      through: ClientVehicle,
      foreignKey: "cid",
    });
    Vehicle.belongsToMany(Client, {
      through: ClientVehicle,
      foreignKey: "vid",
    });

    await sequelize.sync();

    const { fleet, yearMonth } = req.body;
    let result = {
      topdriveScore: [],
      leastdriveScore: [],
      aggressiveLeastAcceleration: null,
      aggressiveLeastBraking: null,
      aggressiveLeastEfficiency: null,
      aggressiveTopAcceleration: null,
      aggressiveTopBraking: null,
      aggressiveTopEfficiency: null,
    };
    let vehiclesList;

    vehiclesList = await Vehicle.findAll({
      attributes: [
        ["VIN", "vin"],
        ["VehicleRegNo", "vehicle_reg_number"],
        "model",
        "SIMservicePrName",
        "network_type",
      ],
      where: {
        deleteVehicleStatus: 0,
        [Op.or]: [
          { VIN: { [Op.like]: "mq/MD9%" } },
          { VIN: { [Op.like]: "mq/P6R%" } },
        ],
      },
      nest: true,
      include: [
        {
          model: Client,
          attributes: [[sequelize.literal("TRIM(`clientCode`)"), "clientCode"]],
          through: {
            attributes: [],
          },
          where: {
            clientCode: {
              [Op.like]: `${fleet.trim()}`,
            },
          },
        },
      ],
    });

    if (!vehiclesList.length)
      return res.json({
        status: false,
        error: "No vehicles found",
      });

    vehiclesList = vehiclesList.map((item) => ({
      vin: item.dataValues.vin.slice(3),
      vehicle_reg_number: item.dataValues.vehicle_reg_number,
      fleets: item["Clients"]
        .map((client) => client.dataValues.clientCode)
        .join(","),
      model: item.dataValues.model,
      SIMservicePrName: item.dataValues.SIMservicePrName,
      network_type: item.dataValues.network_type,
    }));

    let queryResult = await driveScore.aggregate([
      {
        $match: {
          vin: {
            $in: vehiclesList.map((item) => item.vin),
          },
          Date: {
            $regex: new RegExp(`^${yearMonth}`),
          },
        },
      },
    ]);

    result.topdriveScore = [...queryResult]
      .sort((a, b) => b.drive_score - a.drive_score)
      .slice(0, 10)
      .map((item) => ({
        vin: item.vin,
        // vehicle_reg_number: item.x1,
        date: item.Date,
        eEfficiency: item.eEfficiency,
        percentage_agressive_acceleration:
          item.percentage_agressive_acceleration,
        percentage_agressive_braking: item.percentage_agressive_braking,
        driveScore: item.drive_score,
        fleets: vehiclesList.find((vehicle) => vehicle.vin === item.vin)[
          "fleets"
        ],
        model: vehiclesList.find((vehicle) => vehicle.vin === item.vin)[
          "model"
        ],
      }));
    result.leastdriveScore = [...queryResult]
      .sort((a, b) => a.drive_score - b.drive_score)
      .slice(0, 10)
      .map((item) => ({
        vin: item.vin,
        // vehicle_reg_number: item.x1,
        date: item.Date,
        driveScore: item.drive_score,
        eEfficiency: item.eEfficiency,
        percentage_agressive_acceleration:
          item.percentage_agressive_acceleration,
        percentage_agressive_braking: item.percentage_agressive_braking,
        fleets: vehiclesList.find((vehicle) => vehicle.vin === item.vin)[
          "fleets"
        ],
        model: vehiclesList.find((vehicle) => vehicle.vin === item.vin)[
          "model"
        ],
      }));

    const avgData = queryResult.reduce((acc, cur) => {
      if (acc.hasOwnProperty(cur.vin)) {
        acc[cur.vin].driveScore = acc[cur.vin].driveScore + cur.drive_score;
        acc[cur.vin].noOfDays = acc[cur.vin].noOfDays + 1;
        acc[cur.vin]["driveScoreData"].push(cur.drive_score);
      } else {
        acc[cur.vin] = {
          vin: cur.vin,
          driveScore: cur.drive_score,
          noOfDays: 1,
          driveScoreData: [cur.drive_score],
        };
      }
      return acc;
    }, {});

    const avgDriveData = {
      "0 to 10": [],
      "10 to 20": [],
      "20 to 30": [],
      "30 to 40": [],
      "40 to 50": [],
      "50 to 60": [],
      "60 to 70": [],
      "70 to 80": [],
      "80 to 90": [],
      "90 to 100": [],
    };
    let totalAvgDriveScoreSum = 0;
    Object.values(avgData).map((item) => {
      // console.log(item.vin,item.driveScore,'before')
      let object = {
        vin: item.vin,
        noOfDays: Number(item.noOfDays),
        driveScore: Number(item.driveScore.toFixed(2)),
        avgDriveScore: Number((item.driveScore / item.noOfDays).toFixed(2)),
      };
      totalAvgDriveScoreSum += object.avgDriveScore;
      // console.log(object.vin,object.avgDriveScore,'after')
      if (object.avgDriveScore >= 0 && object.avgDriveScore < 10) {
        avgDriveData["10 to 20"].push(object);
      } else if (object.avgDriveScore >= 10 && object.avgDriveScore < 20) {
        avgDriveData["10 to 20"].push(object);
      } else if (object.avgDriveScore >= 20 && object.avgDriveScore < 30) {
        avgDriveData["20 to 30"].push(object);
      } else if (object.avgDriveScore >= 30 && object.avgDriveScore < 40) {
        avgDriveData["30 to 40"].push(object);
      } else if (object.avgDriveScore >= 40 && object.avgDriveScore < 50) {
        avgDriveData["40 to 50"].push(object);
      } else if (object.avgDriveScore >= 50 && object.avgDriveScore < 60) {
        avgDriveData["50 to 60"].push(object);
      } else if (object.avgDriveScore >= 60 && object.avgDriveScore < 70) {
        avgDriveData["60 to 70"].push(object);
      } else if (object.avgDriveScore >= 70 && object.avgDriveScore < 80) {
        avgDriveData["70 to 80"].push(object);
      } else if (object.avgDriveScore >= 80 && object.avgDriveScore < 90) {
        avgDriveData["80 to 90"].push(object);
      } else if (object.avgDriveScore >= 90 && object.avgDriveScore < 100) {
        avgDriveData["80 to 90"].push(object);
      }
    });

    let topValues = result.topdriveScore.reduce(
      (acc, cur) => {
        // console.log(cur);
        let resultObj = {
          ...acc,
          aggressiveTopEfficiency: cur.eEfficiency
            ? acc.aggressiveTopEfficiency + cur.eEfficiency
            : acc.aggressiveTopEfficiency,
          aggressiveTopAcceleration:
            acc.aggressiveTopAcceleration +
            cur.percentage_agressive_acceleration,
          aggressiveTopBraking:
            acc.aggressiveTopBraking + cur.percentage_agressive_braking,
        };

        return resultObj;
      },
      {
        aggressiveTopEfficiency: 0,
        aggressiveTopAcceleration: 0,
        aggressiveTopBraking: 0,
      }
    );

    let leastValues = result.leastdriveScore.reduce(
      (acc, cur) => {
        let resultObj = {
          ...acc,
          aggressiveLeastEfficiency: cur.eEfficiency
            ? acc.aggressiveLeastEfficiency + cur.eEfficiency
            : acc.aggressiveLeastEfficiency,
          aggressiveLeastAcceleration:
            acc.aggressiveLeastAcceleration +
            cur.percentage_agressive_acceleration,
          aggressiveLeastBraking:
            acc.aggressiveLeastBraking + cur.percentage_agressive_braking,
        };
        return resultObj;
      },
      {
        aggressiveLeastEfficiency: 0,
        aggressiveLeastAcceleration: 0,
        aggressiveLeastBraking: 0,
      }
    );

    // console.log(topValues);
    // console.log(leastValues);

    result = {
      ...result,
      aggressiveTopEfficiency:
        topValues["aggressiveTopEfficiency"] / result.topdriveScore.length,
      aggressiveTopAcceleration:
        topValues["aggressiveTopAcceleration"] / result.topdriveScore.length,
      aggressiveTopBraking:
        topValues["aggressiveTopBraking"] / result.topdriveScore.length,
      aggressiveLeastEfficiency:
        leastValues["aggressiveLeastEfficiency"] /
        result.leastdriveScore.length,
      aggressiveLeastAcceleration:
        leastValues["aggressiveLeastAcceleration"] /
        result.leastdriveScore.length,
      aggressiveLeastBraking:
        leastValues["aggressiveLeastBraking"] / result.leastdriveScore.length,
      avgData: avgDriveData,
      totalAvgDriveScore: Number(
        (totalAvgDriveScoreSum / Object.keys(avgData).length).toFixed(2)
      ),
    };
    return res.json({
      status: true,
      data: result,
    });

    // return res.json(resultObject)
  } catch (error) {
    console.log(error, "err");
    return res.json({
      status: false,
      code: 500,
      values: "Internal Server Error",
    });
  }
};

const avgDriveScoreData = async (req, res) => {
  try {
    await connection(url);

    Client.belongsToMany(Vehicle, {
      through: ClientVehicle,
      foreignKey: "cid",
    });
    Vehicle.belongsToMany(Client, {
      through: ClientVehicle,
      foreignKey: "vid",
    });

    await sequelize.sync();

    const { fleet, yearMonth } = req.body;
    let vehiclesList;

    vehiclesList = await Vehicle.findAll({
      attributes: [
        ["VIN", "vin"],
        ["VehicleRegNo", "vehicle_reg_number"],
        "model",
        "SIMservicePrName",
        "network_type",
      ],
      where: {
        deleteVehicleStatus: 0,
        [Op.or]: [
          { VIN: { [Op.like]: "mq/MD9%" } },
          { VIN: { [Op.like]: "mq/P6R%" } },
        ],
      },
      nest: true,
      include: [
        {
          model: Client,
          attributes: [[sequelize.literal("TRIM(`clientCode`)"), "clientCode"]],
          through: {
            attributes: [],
          },
          where: {
            clientCode: {
              [Op.like]: `${fleet.trim()}`,
            },
          },
        },
      ],
    });

    const vehicleObject = {};
    vehiclesList.map((item) => {
      vehicleObject[item.dataValues.vin] = item.dataValues;
    });
    // console.log(vehicleObject,'evh')

    if (!vehiclesList.length)
      return res.json({
        status: false,
        error: "No vehicles found",
      });

    vehiclesList = vehiclesList.map((item) => ({
      vin: item.dataValues.vin.slice(3),
      vehicle_reg_number: item.dataValues.vehicle_reg_number,
      fleets: item["Clients"]
        .map((client) => client.dataValues.clientCode)
        .join(","),
      model: item.dataValues.model,
      SIMservicePrName: item.dataValues.SIMservicePrName,
      network_type: item.dataValues.network_type,
    }));

    let queryResult = await driveScore.aggregate([
      {
        $match: {
          vin: {
            $in: vehiclesList.map((item) => item.vin),
          },
          Date: {
            $regex: new RegExp(`^${yearMonth}`),
          },
        },
      },
    ]);
    const avgData = queryResult.reduce((acc, cur) => {
      if (acc.hasOwnProperty(cur.vin)) {
        acc[cur.vin].driveScore = acc[cur.vin].driveScore + cur.drive_score;
        acc[cur.vin].noOfDays = acc[cur.vin].noOfDays + 1;
        acc[cur.vin]["driveScoreData"].push(cur.drive_score);
      } else {
        acc[cur.vin] = {
          vin: cur.vin,
          driveScore: cur.drive_score,
          noOfDays: 1,
          driveScoreData: [cur.drive_score],
        };
      }
      return acc;
    }, {});

    const avgDriveData = {
      "0 to 10": [],
      "10 to 20": [],
      "20 to 30": [],
      "30 to 40": [],
      "40 to 50": [],
      "50 to 60": [],
      "60 to 70": [],
      "70 to 80": [],
      "80 to 90": [],
      "90 to 100": [],
    };
    Object.values(avgData).map((item) => {
      let object = {
        vin: item.vin,
        No_of_days_driven: Number(item.noOfDays),
        vehicle_reg_numvber:
          vehicleObject["mq/" + item.vin]["vehicle_reg_number"],
        avg_driveScore: Number((item.driveScore / item.noOfDays).toFixed(2)),
        fleet: vehicleObject["mq/" + item.vin]["Clients"]
          .map((i) => i.clientCode)
          .join(","),
      };
      if (object.avg_driveScore >= 0 && object.avg_driveScore < 10) {
        avgDriveData["0 to 10"].push(object);
      } else if (object.avg_driveScore >= 10 && object.avg_driveScore < 20) {
        avgDriveData["10 to 20"].push(object);
      } else if (object.avg_driveScore >= 20 && object.avg_driveScore < 30) {
        avgDriveData["20 to 30"].push(object);
      } else if (object.avg_driveScore >= 30 && object.avg_driveScore < 40) {
        avgDriveData["30 to 40"].push(object);
      } else if (object.avg_driveScore >= 40 && object.avg_driveScore < 50) {
        avgDriveData["40 to 50"].push(object);
      } else if (object.avg_driveScore >= 50 && object.avg_driveScore < 60) {
        avgDriveData["50 to 60"].push(object);
      } else if (object.avg_driveScore >= 60 && object.avg_driveScore < 70) {
        avgDriveData["60 to 70"].push(object);
      } else if (object.avg_driveScore >= 70 && object.avg_driveScore < 80) {
        avgDriveData["70 to 80"].push(object);
      } else if (object.avg_driveScore >= 80 && object.avg_driveScore < 90) {
        avgDriveData["80 to 90"].push(object);
      } else if (object.avg_driveScore >= 90 && object.avg_driveScore < 100) {
        avgDriveData["90 to 100"].push(object);
      }
    });

    return res.json({ status: true, data: avgDriveData });
  } catch (error) {
    console.log(error, "etr");
    return res.json({ status: false, code: 500, error: error });
  }
};

const lastLocationData = async (req, res) => {
  // try {
  //   await connection(url);
  //   let data = [];

  //   const fleetVehicls = await sequelize.query(`select GROUP_CONCAT(DISTINCT cl.ClientFullName SEPARATOR ',') as fleetName,cv.vid,veh.VIN as vin, veh.VehicleRegNo, veh.model from Client cl
  //   join ClientVehicle cv on cl.cid = cv.cid
  //   join Vehicle veh on cv.vid = veh.vid where veh.deleteVehicleStatus=0 and (veh.VIN like "mq/MD9%" or veh.VIN like "mq/P6R%") group by vin`)

  //   for (const i of fleetVehicls[0]) {
  //     console.log(i.vin);
  //       let obj;
  //       // vSqlData = await Vehicle.findOne({
  //       //   where: {VIN: i},
  //       //   attributes: ['VehicleRegNo','vDisplayName']
  //       // })
  //       let vData = await getMongoData(url, i.vin)
  //       if(!vData){
  //         obj = {
  //           "vin_id": i.vin.startsWith('mq/') ? i.vin.slice(3, ) : i.vin,
  //           "description":"No Data is Available for this VIN"
  //         }
  //         // data.push(obj)
  //         continue;
  //       }

  //           obj = {
  //             "vin": i.vin.startsWith('mq/') ? i.vin.slice(3, ) : i.vin,
  //             "vehicle_reg_number":i.VehicleRegNo,
  //             "utc": unixtime(vData.RTC).toString(),
  //             "rtc": vData.RTC,
  //             "latitude": vData.lat.toFixed(6),
  //             "latitude_side": vData.G3,
  //             "longitude": vData.lng.toFixed(6),
  //             "longitude_side": vData.G5,
  //             "soc":canKeyConfigurer({can: CAN_KEY_MAPPING.BATTERY_SOC48, value: vData[CAN_KEY_MAPPING.BATTERY_SOC48]}),
  //               "odometer": (canKeyConfigurer({can: CAN_KEY_MAPPING.ODOMETER_HIGH, value: vData[CAN_KEY_MAPPING.ODOMETER_HIGH]}) << 16 | canKeyConfigurer({can: CAN_KEY_MAPPING.ODOMETER_LOW, value: vData[CAN_KEY_MAPPING.ODOMETER_LOW]})) / 10,//fix

  //           }

  //       data.push(obj)

  //   }
  //   return res.json({
  //     "status": true,
  //     "code": 200,
  //     "values": data
  //   })
  // } catch (error) {
  //   console.log(error, "err");
  //   return res.json({
  //     status: false,
  //     code: 500,
  //     values: "Internal Server Error",
  //   });
  // }

  Client.belongsToMany(Vehicle, { through: ClientVehicle, foreignKey: "cid" });
  Vehicle.belongsToMany(Client, { through: ClientVehicle, foreignKey: "vid" });

  await connection(url);

  try {
    await sequelize.sync();

    // const { startOdo, endOdo } = req.body;

    let segmentResult = await VehicleDailyData.aggregate([
      {
        $match: {
          x11: {
            $gte: 0,
          },
          x11: {
            $ne: "NA",
          },
          x59: {
            $ne: "NA",
          },
        },
      },
      // {
      //   $sort: {
      //     date: -1, // Sort by date in descending order to get the latest dates first
      //   },
      // },
      {
        $group: {
          _id: "$topic",
          end_odo: { $last: "$x11" },
          last_driven: { $last: "$date" },
          x59: { $last: "$x59" },

          soc: { $last: "$x54" },
          rtc: { $last: "$x82" },
        },
      },
      // {
      //   $match: {
      //     end_odo: {
      //       $gte: startOdo,
      //       $lte: endOdo,
      //     }
      //   }
      // }
    ]);

    console.log(segmentResult.length);

    if (!segmentResult.length) {
      return res.status(200).json({
        status: false,
        data: [],
      });
    }

    vehiclesList = await Vehicle.findAll({
      attributes: ["VIN", "VehicleRegNo"],
      where: {
        deleteVehicleStatus: 0,
        [Op.or]: [
          { VIN: { [Op.like]: "mq/MD9%" } },
          { VIN: { [Op.like]: "mq/P6R%" } },
        ],
        VIN: {
          [Op.in]: segmentResult.map((item) => item._id),
        },
      },
      nest: true,
      include: [
        {
          model: Client,
          attributes: ["clientCode"],
          through: { attributes: [] },
        },
      ],
    });

    result = vehiclesList.map((item) => ({
      // ...item.dataValues,
      vin: item.VIN.slice(3),
      vehicle_reg_number: item.VehicleRegNo,
      fleet: item["Clients"]
        .map((client) => client.dataValues.clientCode)
        .join(","),

      lattiude:
        segmentResult.find((item1) => item1._id === item.VIN) !== undefined
          ? segmentResult.find((item1) => item1._id === item.VIN).x59.lat
          : "No data",
      longitude:
        segmentResult.find((item1) => item1._id === item.VIN) !== undefined
          ? segmentResult.find((item1) => item1._id === item.VIN).x59.lng
          : "No data",

      end_odo:
        segmentResult.find((item1) => item1._id === item.VIN) !== undefined
          ? segmentResult.find((item1) => item1._id === item.VIN).end_odo
          : "No data",
      // last_driven:
      //   segmentResult.find((item1) => item1._id === item.VIN) !==
      //     undefined
      //     ? segmentResult.find((item1) => item1._id === item.VIN)
      //         .last_driven
      //     : "No data",
      rtc:
        segmentResult.find((item1) => item1._id === item.VIN) !== undefined
          ? segmentResult.find((item1) => item1._id === item.VIN).rtc
          : "No data",
      soc:
        segmentResult.find((item1) => item1._id === item.VIN) !== undefined
          ? segmentResult.find((item1) => item1._id === item.VIN).soc
          : "No data",
    }));

    return res.json({ status: true, code: 200, values: result });
  } catch (error) {
    console.log(error, "err");
    return res.json({
      status: false,
      code: 500,
      values: "Internal Server Error",
    });
  }
};

const monthlyBatteryHealthCard = async (req, res) => {
  try {
    await connection(url);
    const { yearMonth } = req.body;

    let year = parseInt(yearMonth.split("-")[0]);

    let month = parseInt(yearMonth.split("-")[1]);

    // const batteryHealthCardData = await MonthlyBatteryHealthCardReport.find({
    //   $and: [{ year: year }, { month: month }],
    // });

    const batteryHealthCardData =
      await MonthlyBatteryHealthCardReport.aggregate([
        {
          $match: {
            $or: [
              { year: { $lt: year } },
              {
                $and: [{ year: year }, { month: { $lte: month } }],
              },
            ],
          },
        },
        {
          $sort: {
            year: 1,
            month: 1,
          },
        },
        {
          $group: {
            _id: "$vin",
            latestData: { $last: "$$ROOT" },
          },
        },
        {
          $replaceRoot: { newRoot: "$latestData" },
        },
        {
          $project: {
            _id: 0,
            id: 0,
            vehicle_id: 0,
            creation_date: 0,
          },
        },
      ]);

    return res.json({
      status: true,
      code: 200,
      values: batteryHealthCardData.map((item) => ({
        ...item,
        month: monthsObject[item.month],
      })),
    });
  } catch (error) {
    console.log(error, "err");
    return res.json({
      status: false,
      code: 500,
      values: "Internal Server Error",
    });
  }
};

function maintenanceFormatter(result) {
  let obj = {
    free_service: {
      first_free_service: [],
      second_free_service: [],
      third_free_service: [],
      fourth_free_service: [],
    },
    paid_service: {},
  };
  let today = new Date();
  // console.log(today);
  let oneMonthBeforeDate = moment(today)
    .subtract(1, "months")
    .format("YYYY-MM-DD");
  let twoMonthBeforeDate = moment(today)
    .subtract(2, "months")
    .format("YYYY-MM-DD");
  let threeMonthBeforeDate = moment(today)
    .subtract(3, "months")
    .format("YYYY-MM-DD");
  let fourthMonthBeforeDate = moment(today)
    .subtract(4, "months")
    .format("YYYY-MM-DD");

  for (let i of result) {
    if (
      (i.end_odo >= 1500 && i.end_odo <= 2000) ||
      (i.sold_date <= oneMonthBeforeDate && i.sold_date > twoMonthBeforeDate)
    ) {
      obj["free_service"].first_free_service.push(i);
    } else if (
      (i.end_odo >= 4000 && i.end_odo <= 5000) ||
      (i.sold_date <= twoMonthBeforeDate && i.sold_date > threeMonthBeforeDate)
    ) {
      obj["free_service"].second_free_service.push(i);
    } else if (
      (i.end_odo >= 9000 && i.end_odo <= 10000) ||
      (i.sold_date <= threeMonthBeforeDate &&
        i.sold_date > fourthMonthBeforeDate)
    ) {
      obj["free_service"].third_free_service.push(i);
    } else if (
      (i.end_odo >= 19000 && i.end_odo <= 20000) ||
      i.sold_date <= fourthMonthBeforeDate
    ) {
      obj["free_service"].fourth_free_service.push(i);
    }
  }
  return obj;
}

const vehicleServiceData = async (req, res) => {
  // try {
  //   await connection(url);
  //   let data = [];

  //   const fleetVehicls = await sequelize.query(`select GROUP_CONCAT(DISTINCT cl.ClientFullName SEPARATOR ',') as fleetName,cv.vid,veh.VIN as vin, veh.VehicleRegNo, veh.model from Client cl
  //   join ClientVehicle cv on cl.cid = cv.cid
  //   join Vehicle veh on cv.vid = veh.vid where veh.deleteVehicleStatus=0 and (veh.VIN like "mq/MD9%" or veh.VIN like "mq/P6R%") group by vin`)

  //   for (const i of fleetVehicls[0]) {
  //     console.log(i.vin);
  //       let obj;
  //       // vSqlData = await Vehicle.findOne({
  //       //   where: {VIN: i},
  //       //   attributes: ['VehicleRegNo','vDisplayName']
  //       // })
  //       let vData = await getMongoData(url, i.vin)
  //       if(!vData){
  //         obj = {
  //           "vin_id": i.vin.startsWith('mq/') ? i.vin.slice(3, ) : i.vin,
  //           "description":"No Data is Available for this VIN"
  //         }
  //         // data.push(obj)
  //         continue;
  //       }

  //           obj = {
  //             "vin": i.vin.startsWith('mq/') ? i.vin.slice(3, ) : i.vin,
  //             "vehicle_reg_number":i.VehicleRegNo,
  //             // "utc": unixtime(vData.RTC).toString(),
  //             "latitude": vData.lat.toFixed(6),
  //             "longitude": vData.lng.toFixed(6),
  //               "end_odo": (canKeyConfigurer({can: CAN_KEY_MAPPING.ODOMETER_HIGH, value: vData[CAN_KEY_MAPPING.ODOMETER_HIGH]}) << 16 | canKeyConfigurer({can: CAN_KEY_MAPPING.ODOMETER_LOW, value: vData[CAN_KEY_MAPPING.ODOMETER_LOW]})) / 10,//fix
  //               "fleet_name": i.fleetName,
  //             "last_pinged_date": vData.RTC,
  //           }

  //       data.push(obj)

  //   }
  //   return res.json({
  //     "status": true,
  //     "code": 200,
  //     "values": maintenanceFormatter(data)
  //   })
  // } catch (error) {
  //   console.log(error, "err");
  //   return res.json({
  //     status: false,
  //     code: 500,
  //     values: "Internal Server Error",
  //   });
  // }

  let result = null;
  let vehiclesList;

  Client.belongsToMany(Vehicle, { through: ClientVehicle, foreignKey: "cid" });
  Vehicle.belongsToMany(Client, { through: ClientVehicle, foreignKey: "vid" });

  await connection(url);

  try {
    await sequelize.sync();

    // const { startDate, endDate } = req.body;

    let segmentResult = await VehicleSaleStatement.aggregate([
      // {
      //   $match: {
      //     document_date: {
      //       $gte: startDate,
      //       $lte: endDate,
      //     },
      //   },
      // },
      {
        $lookup: {
          from: "vehicleDailyData",
          let: { localValue: { $concat: ["mq/", "$chassis_no"] } },
          pipeline: [
            {
              $match: {
                $expr: {
                  $eq: ["$topic", "$$localValue"],
                },
                x11: {
                  $gt: 0,
                },
                // x12: { $gt: 0 }
                x78: "Running",
              },
            },

            {
              $sort: {
                x11: -1,
              },
            },
            {
              $limit: 1,
            },
            // Add more pipeline stages if needed
          ],
          as: "joinedData",
        },
      },
      {
        $project: {
          _id: 0,
          document_date: 1,
          "joinedData.topic": 1, // Include specific fields from the joined collection
          chassis_no: 1,
          "joinedData.x11": 1,
          "joinedData.date": 1,
          customer: 1,

          // Add more fields as needed
        },
      },
      {
        $group: {
          _id: "$chassis_no",
          document_date: { $first: "$document_date" },
          end_odo: { $first: "$joinedData.x11" },
          date: { $first: "$joinedData.date" },
          customer: { $first: "$customer" },
        },
      },
    ]);

    if (!segmentResult.length) {
      return res.status(200).json({
        status: false,
        data: [],
      });
    }

    vehiclesList = await Vehicle.findAll({
      attributes: ["VIN", "VehicleRegNo"],
      where: {
        deleteVehicleStatus: 0,
        [Op.or]: [
          { VIN: { [Op.like]: "mq/MD9%" } },
          { VIN: { [Op.like]: "mq/P6R%" } },
        ],
        VIN: {
          [Op.in]: segmentResult.map((item) => "mq/" + item._id),
        },
      },
      nest: true,
      include: [
        {
          model: Client,
          attributes: ["clientCode"],
          through: { attributes: [] },
        },
      ],
    });

    result = vehiclesList.map((item) => ({
      // ...item.dataValues,
      vin: item.VIN.slice(3),
      vehicle_reg_number: item.VehicleRegNo,
      fleet: item["Clients"]
        .map((client) => client.dataValues.clientCode)
        .join(","),
      sold_date:
        segmentResult.find((item1) => "mq/" + item1._id === item.VIN) !==
        undefined
          ? segmentResult.find((item1) => "mq/" + item1._id === item.VIN)
              .document_date
          : "No date",
      end_odo:
        segmentResult.find((item1) => "mq/" + item1._id === item.VIN) !==
          undefined &&
        segmentResult.find((item1) => "mq/" + item1._id === item.VIN).end_odo
          .length
          ? segmentResult.find((item1) => "mq/" + item1._id === item.VIN)
              .end_odo[0]
          : "No data",
      last_pinged:
        segmentResult.find((item1) => "mq/" + item1._id === item.VIN) !==
          undefined &&
        segmentResult.find((item1) => "mq/" + item1._id === item.VIN).date
          .length
          ? segmentResult.find((item1) => "mq/" + item1._id === item.VIN)
              .date[0]
          : "No data",
      customer:
        segmentResult.find((item1) => "mq/" + item1._id === item.VIN) !==
        undefined
          ? segmentResult.find((item1) => "mq/" + item1._id === item.VIN)
              .customer
          : "No date",
    }));

    return res.json({
      status: true,
      code: 200,
      values: maintenanceFormatter(result),
    });
  } catch (error) {
    console.log(error, "err");
    return res.json({
      status: false,
      code: 500,
      values: "Internal Server Error",
    });
  }
};

const notPingedVehicles = async (req, res) => {
  try {
    let result = null;
    let vehiclesList;

    const { days } = req.body;

    Client.belongsToMany(Vehicle, {
      through: ClientVehicle,
      foreignKey: "cid",
    });
    Vehicle.belongsToMany(Client, {
      through: ClientVehicle,
      foreignKey: "vid",
    });

    await connection(url);

    await sequelize.sync();

    let segmentResult = await VehicleDailyData.aggregate([
      {
        $match: {
          x11: {
            $gte: 0,
          },
          x11: {
            $ne: "NA",
          },
        },
      },
      {
        $sort: {
          date: -1, // Sort by date in descending order to get the latest dates first
        },
      },
      {
        $group: {
          _id: "$topic",
          end_odo: { $first: "$x11" },
          last_driven: { $first: "$date" },
        },
      },
    ]);

    console.log(segmentResult.length);
    let vinBla = segmentResult.map((item) => item._id);

    if (!segmentResult.length) {
      return res.status(200).json({
        status: false,
        data: [],
      });
    }

    vehiclesList = await Vehicle.findAll({
      attributes: ["VIN", "VehicleRegNo", "SIMservicePrName", "network_type"],
      where: {
        deleteVehicleStatus: 0,
        [Op.or]: [
          { VIN: { [Op.like]: "mq/MD9%" } },
          { VIN: { [Op.like]: "mq/P6R%" } },
        ],
        VIN: {
          [Op.in]: segmentResult.map((item) => item._id),
        },
      },
      nest: true,
      include: [
        {
          model: Client,
          attributes: ["clientCode"],
          through: { attributes: [] },
        },
      ],
    });

    // for(const i of vehiclesList){
    //   console.log(i.dataValues);
    // }
    // vehiclesList.map(item => console.log(item.network_type))

    result = vehiclesList.map((item) => ({
      // ...item.dataValues,
      vin: item.VIN.slice(3),
      vehicle_reg_number: item.VehicleRegNo,
      fleet: item["Clients"]
        .map((client) => client.dataValues.clientCode)
        .join(","),

      end_odo:
        segmentResult.find((item1) => item1._id === item.VIN) !== undefined
          ? segmentResult.find((item1) => item1._id === item.VIN).end_odo
          : "No data",
      last_driven:
        segmentResult.find((item1) => item1._id === item.VIN) !== undefined
          ? segmentResult.find((item1) => item1._id === item.VIN).last_driven
          : "No data",

      network_type: item.dataValues.network_type,
      sim_service_provider: item.SIMservicePrName,
    }));

    let obj = [];
    for (const i of result) {
      let yesterday = new Date(getYesterdayDate());
      let vinDate = new Date(i.last_driven);

      var timeDifference = yesterday - vinDate;

      var numberOfDays = Math.floor(timeDifference / (1000 * 60 * 60 * 24));
      if (numberOfDays == days) {
        obj.push(i);
      }
    }
    console.log(obj.length);

    return res.json({
      status: true,
      code: 200,
      values: obj,
    });
  } catch (error) {
    console.log(error, "err");
    return res.json({
      status: false,
      code: 500,
      values: "Internal Server Error",
    });
  }
};

const notPingedVehiclesFleet = async (req, res) => {
  try {
    let result = null;
    let vehiclesList;

    const { fleet } = req.body;

    Client.belongsToMany(Vehicle, {
      through: ClientVehicle,
      foreignKey: "cid",
    });
    Vehicle.belongsToMany(Client, {
      through: ClientVehicle,
      foreignKey: "vid",
    });

    await connection(url);

    await sequelize.sync();

    let segmentResult = await VehicleDailyData.aggregate([
      {
        $match: {
          x11: {
            $gte: 0,
          },
          x11: {
            $ne: "NA",
          },
        },
      },
      {
        $sort: {
          date: -1, // Sort by date in descending order to get the latest dates first
        },
      },
      {
        $group: {
          _id: "$topic",
          end_odo: { $first: "$x11" },
          last_driven: { $first: "$date" },
        },
      },
    ]);

    console.log(segmentResult.length);
    let vinBla = segmentResult.map((item) => item._id);

    if (!segmentResult.length) {
      return res.status(200).json({
        status: false,
        data: [],
      });
    }

    vehiclesList = await Vehicle.findAll({
      attributes: ["VIN", "VehicleRegNo", "SIMservicePrName", "network_type"],
      where: {
        deleteVehicleStatus: 0,
        [Op.or]: [
          { VIN: { [Op.like]: "mq/MD9%" } },
          { VIN: { [Op.like]: "mq/P6R%" } },
        ],
        VIN: {
          [Op.in]: segmentResult.map((item) => item._id),
        },
      },
      nest: true,
      include: [
        {
          model: Client,
          attributes: ["clientCode"],
          through: { attributes: [] },
          where: {
            ClientFullName: {
              [Op.like]: `%${fleet}%`,
            },
          },
        },
      ],
    });

    result = vehiclesList.map((item) => ({
      // ...item.dataValues,
      vin: item.VIN.slice(3),
      vehicle_reg_number: item.VehicleRegNo,
      fleet: item["Clients"]
        .map((client) => client.dataValues.clientCode)
        .join(","),

      end_odo:
        segmentResult.find((item1) => item1._id === item.VIN) !== undefined
          ? segmentResult.find((item1) => item1._id === item.VIN).end_odo
          : "No data",
      last_driven:
        segmentResult.find((item1) => item1._id === item.VIN) !== undefined
          ? segmentResult.find((item1) => item1._id === item.VIN).last_driven
          : "No data",

      network_type: item.dataValues.network_type,
      sim_service_provider: item.SIMservicePrName,
    }));

    let obj = [];
    for (const i of result) {
      let yesterday = new Date(getYesterdayDate());
      let vinDate = new Date(i.last_driven);

      var timeDifference = yesterday - vinDate;

      var numberOfDays = Math.floor(timeDifference / (1000 * 60 * 60 * 24));
      if (numberOfDays != -1 && numberOfDays > 0) {
        obj.push({ ...i, last_driven: numberOfDays + " Days before" });
      }
    }
    console.log(result.length);

    return res.json({
      status: true,
      code: 200,
      values: obj,
    });
  } catch (error) {
    console.log(error, "err");
    return res.json({
      status: false,
      code: 500,
      values: "Internal Server Error",
    });
  }
};

const vehicleMoreInfo = async (req, res) => {
  try {
    Client.belongsToMany(Vehicle, {
      through: ClientVehicle,
      foreignKey: "cid",
    });
    Vehicle.belongsToMany(Client, {
      through: ClientVehicle,
      foreignKey: "vid",
    });

    await connection(url);

    let vin = req.body.vin;
    let dVin;

    if (!vin.startsWith("mq/")) {
      vin = "mq/" + vin;
      dVin = req.body.vin;
    } else {
      dVin = vin.slice(3);
    }
    console.log(dVin);

    const fleetVehicle = await Vehicle.findOne({
      // attributes: [],
      where: {
        // deleteVehicleStatus: 0,
        // [Op.or]: [
        //   { VIN: { [Op.like]: "mq/MD9%" } },
        //   { VIN: { [Op.like]: "mq/P6R%" } },
        // ],
        VIN: vin,
      },
      nest: true,
      include: [
        {
          model: Client,
          attributes: ["clientCode"],
          through: { attributes: [] },
        },
      ],
    });

    const vehicleDailyData = await VehicleDailyData.find({
      $and: [
        { topic: fleetVehicle.VIN },
        { x78: "Running" },
        { x11: { $ne: 0 } },
      ],
    })
      .sort({ date: -1 })
      .limit(1)
      .select({
        x11: 1,
        x12: 1,
        topic: 1,
        date: 1,
        x96: 1,
        x78: 1,
        x101: 1,
        x85: 1,
        x86: 1,
      });

    console.log(dVin);

    const vehicleSaleStatement = await VehicleSaleStatement.findOne({
      chassis_no: dVin,
    }).sort({ document_date: -1 });

    console.log(vehicleSaleStatement);

    let dealer;

    if (vehicleSaleStatement) {
      dealer = await dealerDetails.findOne({
        dealer_code: vehicleSaleStatement.dealer_code,
      });
    }

    // console.log(vehicleDailyData);

    // console.log(vehicleDailyData[0].x86);

    let result;
    if (fleetVehicle) {
      result = {
        Vin: fleetVehicle.VIN.slice(3),
        "Kit id": fleetVehicle.Kit_ID,
        "Vehicle reg number": fleetVehicle.VehicleRegNo,
        "Chassis number": fleetVehicle.chassisSrNo,
        "Vehicle display name": fleetVehicle.vDisplayName,
        "Display software version":
          vehicleDailyData && vehicleDailyData.length > 0
            ? vehicleDailyData[0].x86
            : null,
        "Controller software version":
          vehicleDailyData && vehicleDailyData.length > 0
            ? vehicleDailyData[0].x85
            : null,
        Fleet: fleetVehicle["Clients"]
          .map((client) => client.dataValues.clientCode)
          .join(","),
        "Sim service provider name": fleetVehicle.SIMservicePrName,
        "Network type": fleetVehicle.network_type,
        "IMEI number": fleetVehicle.imei_number,
        "Sim serial number": fleetVehicle.SIMsrNo,
        City:
          vehicleSaleStatement && vehicleSaleStatement.city
            ? vehicleSaleStatement.city
            : null,
        "Sold date":
          vehicleSaleStatement && vehicleSaleStatement.document_date
            ? vehicleSaleStatement.document_date
            : null,
        Customer:
          vehicleSaleStatement && vehicleSaleStatement.customer
            ? vehicleSaleStatement.customer
            : null,
        "Dealer name": dealer && dealer.dealer_name ? dealer.dealer_name : null,
        "Vehicle color":
          vehicleSaleStatement && vehicleSaleStatement.color
            ? vehicleSaleStatement.color
            : fleetVehicle.vehicleColor,
        "Battery capacity": fleetVehicle.batteryCapacity,
        Model: fleetVehicle.model,
        "Display hardware version": "Coming Soon",
        Odo:
          vehicleDailyData && vehicleDailyData.length > 0
            ? vehicleDailyData[0].x11
            : null,
        LastPingedDate:
          vehicleDailyData && vehicleDailyData.length > 0
            ? vehicleDailyData[0].date
            : null,
        "End charge cycle count":
          vehicleDailyData && vehicleDailyData.length > 0
            ? vehicleDailyData[0].x101
            : null,
        "Vehicle status":
          vehicleDailyData && vehicleDailyData.length > 0
            ? vehicleDailyData[0].x78
            : "None",
        "Manufacturing date":
          fleetVehicle.mfgyear && fleetVehicle.mfgmonth
            ? new Date(
                fleetVehicle.mfgyear,
                fleetVehicle.mfgmonth - 1,
                1
              ).toLocaleString("en-US", { month: "long" }) +
              " " +
              fleetVehicle.mfgyear
            : "No data",
      };
    }

    return res.json({
      status: true,
      code: 200,
      values: result,
    });
  } catch (error) {
    console.log(error, "err");
    return res.json({
      status: false,
      code: 500,
      values: "Internal Server Error",
    });
  }
};

const vehicleLocator = async (req, res) => {
  try {
    Client.belongsToMany(Vehicle, {
      through: ClientVehicle,
      foreignKey: "cid",
    });
    Vehicle.belongsToMany(Client, {
      through: ClientVehicle,
      foreignKey: "vid",
    });

    await connection(url);
    await sequelize.sync();

    const { date } = req.body;

    const vehicleDailyData = await VehicleDailyData.find({
      date: date,
      $and: [{ x12: { $gt: 0 } }, { x78: "Running" }],
    });

    const vehiclesList = await Vehicle.findAll({
      attributes: ["VIN", "VehicleRegNo"],
      where: {
        deleteVehicleStatus: 0,
        [Op.or]: [
          { VIN: { [Op.like]: "mq/MD9%" } },
          { VIN: { [Op.like]: "mq/P6R%" } },
        ],
        VIN: {
          [Op.in]: vehicleDailyData.map((item) => item.topic),
        },
      },
      nest: true,
      include: [
        {
          model: Client,
          attributes: ["clientCode"],
          through: { attributes: [] },
        },
      ],
    });

    let data = [];

    for (const i of vehiclesList) {
      const foundVehicle = vehicleDailyData.find(
        (score) => score.topic === i.VIN
      );
      if (foundVehicle) {
        data.push({
          vin: i.VIN.slice(3),
          vehicle_reg_number: i.VehicleRegNo,
          date: foundVehicle.date,
          ignition_start_time: foundVehicle.x102,
          start_time: foundVehicle.x81,
          ignition_end_time: foundVehicle.x103,
          end_time: foundVehicle.x82,
          start_odo: foundVehicle.x10,
          end_odo: foundVehicle.x11,
          distance: foundVehicle.x12,
          start_soc: foundVehicle.x54,
          end_soc: foundVehicle.x55,
          efficiency: foundVehicle.x35,
          energy_used: foundVehicle.x87,
          soh: foundVehicle.x53,
          display_software_version: foundVehicle.x86,
          controller_software_version: foundVehicle.x85,
          max_speed: foundVehicle.x14,
          avg_speed: foundVehicle.x13,
          regen: foundVehicle.x34,
          charging_status: "",
          start_geo_code: foundVehicle.x58.lat + "," + foundVehicle.x58.lng,
          end_geo_code: foundVehicle.x59.lat + "," + foundVehicle.x59.lng,
        });
      }
    }

    return res.json({
      status: true,
      code: 200,
      values: data,
    });
  } catch (error) {
    console.log(error);
    return res.json({
      status: false,
      code: 500,
      values: "Internal Server Error",
    });
  }
};

const customLocationDetails = async (req, res) => {
  try {
    Client.belongsToMany(Vehicle, {
      through: ClientVehicle,
      foreignKey: "cid",
    });
    Vehicle.belongsToMany(Client, {
      through: ClientVehicle,
      foreignKey: "vid",
    });

    await connection(url);

    await sequelize.sync();

    const { startDate, endDate } = req.body;

    let vehicleDailyData = await VehicleDailyData.aggregate([
      {
        $match: {
          x11: {
            $gte: 0,
          },
          x11: {
            $ne: "NA",
          },
          x59: {
            $ne: "NA",
          },
          date: {
            $lte: endDate,
            $gte: startDate,
          },
        },
      },
      {
        $sort: {
          date: -1, // Sort by date in descending order to get the latest dates first
        },
      },
      {
        $group: {
          _id: "$topic",
          end_odo: { $first: "$x11" },
          distance: { $first: "$x12" },
          last_driven: { $first: "$date" },
          end_time: { $first: "$x82" },
          end_soc: { $first: "$x55" },
          location: { $first: "$x59" }, //end geo Code
        },
      },
      // {
      //   $match: {
      //     end_odo: {
      //       $gte: startOdo,
      //       $lte: endOdo,
      //     }
      //   }
      // }
    ]);

    console.log(vehicleDailyData.length);

    if (!vehicleDailyData.length) {
      return res.status(200).json({
        status: false,
        data: [],
      });
    }

    const vehiclesList = await Vehicle.findAll({
      attributes: ["VIN", "VehicleRegNo"],
      where: {
        deleteVehicleStatus: 0,
        [Op.or]: [
          { VIN: { [Op.like]: "mq/MD9%" } },
          { VIN: { [Op.like]: "mq/P6R%" } },
        ],
        VIN: {
          [Op.in]: vehicleDailyData.map((item) => item._id),
        },
      },
      nest: true,
      include: [
        {
          model: Client,
          attributes: ["clientCode"],
          through: { attributes: [] },
        },
      ],
    });

    // moment(item.end_time).format('ddd MMM D YYYY HH:mm:ss')

    let details = [];
    let vinList = [];
    for (const i of vehiclesList) {
      const foundVehicle = vehicleDailyData.find(
        (score) => score._id === i.VIN
      );
      if (foundVehicle) {
        details.push({
          VIN: i.VIN.slice(3),
          "Reg NO": i.VehicleRegNo,
          "End day distance": foundVehicle.distance + "kms",
          "End day Odometer": foundVehicle.end_odo + "kms",
          "End day SoC": foundVehicle.end_soc + "%",
          "Last updated at": moment(foundVehicle.end_time).format(
            "ddd MMM D YYYY HH:mm:ss"
          ),
          location: foundVehicle.location,
        });

        vinList.push({
          label: i.VIN.slice(3) + " | " + i.VehicleRegNo,
          value: i.VIN.slice(3),
        });
      }
    }

    return res.json({
      status: true,
      code: 200,
      values: { details, vinList },
    });
  } catch (error) {
    console.log(error);
    return res.json({
      status: false,
      code: 500,
      values: "Internal Server Error",
    });
  }
};

const dummy = async (req, res) => {
  Client.belongsToMany(Vehicle, { through: ClientVehicle, foreignKey: "cid" });
  Vehicle.belongsToMany(Client, { through: ClientVehicle, foreignKey: "vid" });

  await connection(url);

  try {
    await sequelize.sync();

    // const { startOdo, endOdo } = req.body;

    let segmentResult = await VehicleDailyData.aggregate([
      {
        $match: {
          x11: {
            $gte: 0,
          },
          x11: {
            $ne: "NA",
          },
        },
      },
      {
        $sort: {
          date: -1, // Sort by date in descending order to get the latest dates first
        },
      },
      {
        $group: {
          _id: "$topic",
          end_odo: { $first: "$x11" },
          last_driven: { $first: "$date" },
        },
      },
      // {
      //   $match: {
      //     end_odo: {
      //       $gte: startOdo,
      //       $lte: endOdo,
      //     }
      //   }
      // }
    ]);

    console.log(segmentResult.length);

    if (!segmentResult.length) {
      return res.status(200).json({
        status: false,
        data: [],
      });
    }

    vehiclesList = await Vehicle.findAll({
      attributes: ["VIN", "VehicleRegNo"],
      where: {
        deleteVehicleStatus: 0,
        [Op.or]: [
          { VIN: { [Op.like]: "mq/MD9%" } },
          { VIN: { [Op.like]: "mq/P6R%" } },
        ],
        VIN: {
          [Op.in]: segmentResult.map((item) => item._id),
        },
      },
      nest: true,
      include: [
        {
          model: Client,
          attributes: ["clientCode"],
          through: { attributes: [] },
        },
      ],
    });

    result = vehiclesList.map((item) => ({
      ...item.dataValues,
      VIN: item.VIN.slice(3),
      Clients: item["Clients"]
        .map((client) => client.dataValues.clientCode)
        .join(","),

      end_odo:
        segmentResult.find((item1) => item1._id === item.VIN) !== undefined
          ? segmentResult.find((item1) => item1._id === item.VIN).end_odo
          : "No data",
      last_driven:
        segmentResult.find((item1) => item1._id === item.VIN) !== undefined
          ? segmentResult.find((item1) => item1._id === item.VIN).last_driven
          : "No data",
    }));

    return res.json({ status: true, code: 200, values: result });
  } catch (error) {
    console.log(error, "err");
    return res.json({
      status: false,
      code: 500,
      values: "Internal Server Error",
    });
  }
};

const vehicleSerial = async (req, res) => {
  try {
    const {getOdo}=req.body;
    await sequelize.sync();
    await connection(url);
    Vehicle.hasOne(VinSerialNum, {
      foreignKey: "vehicleId",
      sourceKey: "vid",
    });

    VinSerialNum.belongsTo(Vehicle, {
      foreignKey: "vehicleId",
      targetKey: "vid",
    });

    const data = await VinSerialNum.findAll({
      attributes: ["vinserialnum", "type", "mfgmonth", "mfgyear"],
      include: [
        {
          model: Vehicle,
          attributes: ["VIN", "VehicleRegNo"],
        },
      ],
      order: [["id"]],
    });

    let formattedData = data.map((item) => {
      return {
        vin: item.Vehicle.VIN.slice(3),
        vehicle_reg_number: item.Vehicle.VehicleRegNo,
        vin_serial: item.vinserialnum,
        model: item.type,
        manufactured_month: item.mfgmonth,
        manufactured_year: item.mfgyear,
      };
    });
    if(getOdo){
    const formattedDataVins=formattedData.map(i=>'mq/'+i.vin)
    const OdoQuery=await VehicleDailyData.aggregate([
      {
        $match:{
          topic:{
            $in:formattedDataVins
          },
          x12:{$gte:0},
          x11:{$ne:"NA"},
          x78:"Running",
          date:{$gte:"2023-01-01"}
        }
      },
      {
        $group:{
          _id:"$topic",
          latestOdo:{$last:"$x11"}
        }
      }
    ])
    const vinObject={}
    // console.log(OdoQuery.length)
    // console.log(formattedData.length)
    OdoQuery.map(i=>vinObject[i._id.slice(3)]=i.latestOdo)
    formattedData=formattedData.map(i=>{
      return {
        vin:i.vin,
        vehicle_reg_number:i.vehicle_reg_number,
        vin_serial:i.vin_serial,
        last_odo:vinObject.hasOwnProperty(i.vin)?vinObject[i.vin]:"NA",
        model:i.model,
        manufactured_month:i.manufactured_month,
        manufactured_year:i.manufactured_year,
      }
    })

   
  }
    return res.json({ status: true, code: 200, data: formattedData });
  } catch (error) {
    console.log(error);
    return res.json({
      status: false,
      code: 500,
      data: "Internal Server Error",
    });
  }
};

function getLastDateOfMonth(inputMonth) {
  // Parse inputMonth (e.g., '2023-11')
  const [year, month] = inputMonth.split("-").map(Number);

  // Create a Date object for the first day of the next month
  const firstDayOfNextMonth = new Date(year, month, 1);

  // Subtract one day to get the last day of the current month
  const lastDateOfMonth = new Date(firstDayOfNextMonth - 1);

  // Format the last date as 'YYYY-MM-DD'
  const formattedLastDate = lastDateOfMonth.toISOString().split("T")[0];

  return formattedLastDate;
}

function getFirstDateOfMonth(inputMonth) {
  // Parse inputMonth (e.g., '2023-11')
  const [year, month] = inputMonth.split("-").map(Number);

  // Create a Date object for the first day of the specified month
  const firstDateOfMonth = new Date(year, month - 1, 1); // Month is 0-indexed in JavaScript Date object

  // Format the first date as 'YYYY-MM-DD'
  const formattedFirstDate = firstDateOfMonth.toISOString().split("T")[0];

  return formattedFirstDate;
}

const fleetWiseBatteryHealthCard = async (req, res) => {
  try {
    await connection(url);

    Client.belongsToMany(Vehicle, {
      through: ClientVehicle,
      foreignKey: "cid",
    });
    Vehicle.belongsToMany(Client, {
      through: ClientVehicle,
      foreignKey: "vid",
    });

    await sequelize.sync();

    const { fleet, yearMonth } = req.body;
    const today = moment(new Date()).format("YYYY-MM-DD");

    let vehiclesList;

    console.log("a");

    const sqlResults = await Vehicle.findAll({
      attributes: ["VIN", "VehicleRegNo", "Kit_ID", "batterySrNo"],
      where: {
        deleteVehicleStatus: 0,
        [Op.or]: [
          { VIN: { [Op.like]: "mq/MD9%" } },
          { VIN: { [Op.like]: "mq/P6R%" } },
        ],
      },
      nest: true,
      include: [
        {
          model: Client,
          attributes: ["clientCode"],
          where: {
            clientCode: {
              [Op.like]: `%${fleet}%`,
            },
          },
          through: { attributes: [] },
        },
      ],
    });

    if (!sqlResults.length)
      return res.json({
        status: false,
        error: "No vehicles found",
      });

    const lastDate = getLastDateOfMonth(yearMonth);

    const mongoResults = await VehicleDailyData.aggregate(
      [
        {
          $match: {
            x11: { $gt: 0 },
            x11: { $ne: "NA" },
            x53: { $gt: 70 },
            x101: { $gt: 0 },
            date: { $lte: lastDate },
          },
        },
        {
          $sort: { date: -1 },
        },
        {
          $group: {
            _id: "$topic",
            batteryType: { $first: "$x96" },
            vehicleRegNumber: { $first: "$x1" },
            kidId: { $first: "$x4" },
            bMinSoh: { $first: "$x92" },
            bMaxSoh: { $first: "$x93" },
            bAvgSoh: { $first: "$x53" },
            bEndAvg: { $first: "$x53" }, //x94
            cMinVolt: { $first: "$x28" },
            cMaxVolt: { $first: "$x27" },
            cAvgMinVolt: { $avg: "$x28" },
            cAvgMaxVolt: { $avg: "$x27" },
            cMaxDelta: { $first: "$x29" },
            bMinTemp: { $first: "$x31" },
            bMaxTemp: { $first: "$x30" },
            bAvgMinTemp: { $first: "$x31" },
            bAvgMaxTemp: { $first: "$x30" },
            bMaxDeltaTemp: { $first: "$x32" },
            peakBattery: { $first: "$x17" },
            startCycle: { $first: "$x100" },
            endCycle: { $first: "$x101" },
            conSoftVer: { $first: "$x85" },
            disSoftVer: { $first: "$x86" },
            startOdo: { $first: "$x10" },
            endOdo: { $first: "$x11" },
          },
        },
      ],
      { allowDiskUse: true }
    );

    console.log(mongoResults.length);

    const matchingPairs = [];

    for (const sqlResult of sqlResults) {
      for (const mongoResult of mongoResults) {
        if (
          sqlResult["VIN"] === mongoResult["_id"] &&
          String(mongoResult["_id"]) === String(sqlResult["VIN"])
        ) {
          let calculatedSoh = 0;
          let start = 0;
          let end = 0;

          if (mongoResult["batteryType"] === "Prana 11.a 216 Ah single pack") {
            start = mongoResult["startCycle"] / 2;
            end = mongoResult["endCycle"] / 2;
            const u = (mongoResult["endCycle"] / 4) * 0.01;
            calculatedSoh = 0.021711 * u * u - 1.171193 * u + 99.463824;
          } else if (mongoResult["batteryType"] === "Exponent pack - 8kWh") {
            start = mongoResult["startCycle"] / 10;
            end = mongoResult["endCycle"] / 10;
            calculatedSoh = mongoResult["bAvgSoh"];
          } else {
            start = mongoResult["startCycle"];
            end = mongoResult["endCycle"];
            calculatedSoh = mongoResult["bAvgSoh"];
          }

          matchingPairs.push({
            "Vehicle Reg No": sqlResult["VehicleRegNo"],
            "VIN ID": sqlResult["VIN"].slice(3),
            "KIT ID": sqlResult["KitId"],
            "Fleet Name": sqlResult["fleetName"],
            "Battery Serial Number": sqlResult["batterySrNo"],
            "Battery Type": mongoResult["batteryType"],
            "Min SOH": mongoResult["bMinSoh"],
            "Max SOH": mongoResult["bMaxSoh"],
            "Avg SOH": mongoResult["bAvgSoh"],
            "End SOH": mongoResult["bEndAvg"],
            "Min Cell Voltage": mongoResult["cMinVolt"],
            "Max Cell Voltage": mongoResult["cMaxVolt"],
            "Avg(Min) Cell Voltage": parseFloat(
              mongoResult["cAvgMinVolt"].toFixed(2)
            ),
            "Avg(Max) Cell Voltage": parseFloat(
              mongoResult["cAvgMaxVolt"].toFixed(2)
            ),
            "Max Delta": mongoResult["cMaxDelta"],
            "Min Battery Temp": mongoResult["bMinTemp"],
            "Max Battery Temp": mongoResult["bMaxTemp"],
            "Avg(Min) Battery Temp": parseFloat(
              mongoResult["bAvgMinTemp"].toFixed(2)
            ),
            "Avg(Max) Battery Temp": parseFloat(
              mongoResult["bAvgMaxTemp"].toFixed(2)
            ),
            "Max Delta Battery Temp": mongoResult["cMaxDelta"],
            "Peak Battery Power Used": mongoResult["peakBattery"],
            "Start Charge Cycle": start,
            "End Charge Cycle": end,
            "Control Software": mongoResult["conSoftVer"],
            "Display Software": mongoResult["disSoftVer"],
            "Monthly Battery SOH(%) Calculated": parseFloat(
              calculatedSoh.toFixed(2)
            ),
            "Start Odometer": mongoResult["startOdo"],
            "End Odometer": mongoResult["endOdo"],
          });
        }
      }
    }

    // 'matchingPairs' array now contains the desired results
    console.log(matchingPairs.length);

    return res.json({
      status: true,
      code: 200,
      values: matchingPairs,
    });
  } catch (error) {
    console.log(error, "err");
    return res.json({
      status: false,
      code: 500,
      values: "Internal Server Error",
    });
  }
};

const fleetWiseBatteryHealthCardCustom = async (req, res) => {
  try {
    await connection(url);

    Client.belongsToMany(Vehicle, {
      through: ClientVehicle,
      foreignKey: "cid",
    });
    Vehicle.belongsToMany(Client, {
      through: ClientVehicle,
      foreignKey: "vid",
    });

    await sequelize.sync();

    const { fleet, yearMonth } = req.body;
    const today = moment(new Date()).format("YYYY-MM-DD");

    let vehiclesList;

    console.log("a");

    const sqlResults = await Vehicle.findAll({
      attributes: ["VIN", "VehicleRegNo", "Kit_ID", "batterySrNo"],
      where: {
        deleteVehicleStatus: 0,
        [Op.or]: [
          { VIN: { [Op.like]: "mq/MD9%" } },
          { VIN: { [Op.like]: "mq/P6R%" } },
        ],
      },
      nest: true,
      include: [
        {
          model: Client,
          attributes: ["clientCode"],
          where: {
            clientCode: {
              [Op.like]: `%${fleet}%`,
            },
          },
          through: { attributes: [] },
        },
      ],
    });

    if (!sqlResults.length)
      return res.json({
        status: false,
        error: "No vehicles found",
      });

    const lastDate = getLastDateOfMonth(yearMonth);

    const mongoResults = await VehicleDailyData.aggregate(
      [
        {
          $match: {
            x11: { $gt: 0 },
            x11: { $ne: "NA" },
            x53: { $gt: 70 },
            x101: { $gt: 0 },
            date: { $lte: lastDate },
          },
        },
        {
          $sort: { date: -1 },
        },
        {
          $group: {
            _id: "$topic",
            date: { $first: "$date" },
            batteryType: { $first: "$x96" },
            vehicleRegNumber: { $first: "$x1" },
            kidId: { $first: "$x4" },
            bMinSoh: { $first: "$x92" },
            bMaxSoh: { $first: "$x93" },
            bAvgSoh: { $first: "$x53" },
            bEndAvg: { $first: "$x53" }, //x94
            cMinVolt: { $first: "$x28" },
            cMaxVolt: { $first: "$x27" },
            cAvgMinVolt: { $avg: "$x28" },
            cAvgMaxVolt: { $avg: "$x27" },
            cMaxDelta: { $first: "$x29" },
            bMinTemp: { $first: "$x31" },
            bMaxTemp: { $first: "$x30" },
            bAvgMinTemp: { $first: "$x31" },
            bAvgMaxTemp: { $first: "$x30" },
            bMaxDeltaTemp: { $first: "$x32" },
            peakBattery: { $first: "$x17" },
            startCycle: { $first: "$x100" },
            endCycle: { $first: "$x101" },
            conSoftVer: { $first: "$x85" },
            disSoftVer: { $first: "$x86" },
            startOdo: { $first: "$x10" },
            endOdo: { $first: "$x11" },
          },
        },
      ],
      { allowDiskUse: true }
    );

    console.log(mongoResults.length);

    const matchingPairs = [];

    for (const sqlResult of sqlResults) {
      for (const mongoResult of mongoResults) {
        if (
          sqlResult["VIN"] === mongoResult["_id"] &&
          String(mongoResult["_id"]) === String(sqlResult["VIN"])
        ) {
          const dateObject = new Date(mongoResult["date"]);
          // console.log(dateObject);
          const monthName = dateObject.toLocaleString("en-US", {
            month: "long",
          });
          // console.log(monthName);
          let calculatedSoh = 0;
          let start = 0;
          let end = 0;

          if (mongoResult["batteryType"] === "Prana 11.a 216 Ah single pack") {
            start = mongoResult["startCycle"] / 2;
            end = mongoResult["endCycle"] / 2;
            const u = (mongoResult["endCycle"] / 4) * 0.01;
            calculatedSoh = 0.021711 * u * u - 1.171193 * u + 99.463824;
          } else if (mongoResult["batteryType"] === "Exponent pack - 8kWh") {
            start = mongoResult["startCycle"] / 10;
            end = mongoResult["endCycle"] / 10;
            const u = (end / 2) * 0.01;
            calculatedSoh = 0.021711 * u * u - 1.171193 * u + 99.463824;
            // calculatedSoh = mongoResult["bAvgSoh"];
          } else {
            start = mongoResult["startCycle"];
            end = mongoResult["endCycle"];
            calculatedSoh = mongoResult["bAvgSoh"];
          }

          matchingPairs.push({
            "Vehicle Reg No": sqlResult["VehicleRegNo"],
            "VIN ID": sqlResult["VIN"].slice(3),
            "Battery Type": mongoResult["batteryType"],
            "Monthly Battery SOH(%) Calculated": parseFloat(
              calculatedSoh.toFixed(2)
            ),
            "End Charge Cycle": end,
            "End Odometer": mongoResult["endOdo"],
            Month: monthName,
          });
        }
      }
    }

    // 'matchingPairs' array now contains the desired results
    // console.log(matchingPairs);

    // 'matchingPairs' array now contains the desired results
    console.log(matchingPairs.length);

    return res.json({
      status: true,
      code: 200,
      values: matchingPairs,
    });
  } catch (error) {
    console.log(error, "err");
    return res.json({
      status: false,
      code: 500,
      values: "Internal Server Error",
    });
  }
};

const MonthWiseBatteryHealthCardBatteryGraph = async (req, res) => {
  try {
    await connection(url);

    const { batteryType, yearMonth } = req.body;

    const firstDate = getFirstDateOfMonth(yearMonth);
    const lastDate = getLastDateOfMonth(yearMonth);

    const mongoResults = await VehicleDailyData.aggregate(
      [
        {
          $match: {
            x11: { $gt: 0 },
            x11: { $ne: "NA" },
            x53: { $gt: 0 },
            x101: { $gt: 0 },
            date: { $lte: lastDate, $gte: firstDate },
            x96: { $regex: new RegExp(batteryType, "i") },
          },
        },
        {
          $sort: { date: -1 },
        },
        {
          $group: {
            _id: "$topic",
            date: { $first: "$date" },
            batteryType: { $first: "$x96" },
            bAvgSoh: { $first: "$x53" },
            endOdo: { $first: "$x11" },
            endChargeCycle: { $first: "$x101" },
            // batteryType: { $first: "$x96" },
          },
        },
      ],
      { allowDiskUse: true }
    );

    return res.json({
      status: true,
      code: 200,
      values: mongoResults,
    });
  } catch (error) {
    console.log(error, "err");
    return res.json({
      status: false,
      code: 500,
      values: "Internal Server Error",
    });
  }
};

const MonthWiseBatteryHealthCardVinGraph = async (req, res) => {
  try {
    await connection(url);

    const { vin, startDate, endDate } = req.body;

    let VIN = "";

    if (vin.startsWith("mq/")) {
      VIN = vin;
    } else {
      VIN = "mq/" + vin;
    }

    let mongoResults = await VehicleDailyData.aggregate(
      [
        {
          $match: {
            topic: { $eq: VIN },
            x11: { $gt: 0 },
            x11: { $ne: "NA" },
            x53: { $gt: 0 },
            x101: { $gt: 0 },
            date: { $lte: endDate, $gte: startDate },
          },
        },
        {
          $group: {
            _id: "$date",
            date: { $first: "$date" },
            batteryType: { $first: "$x96" },
            bAvgSoh: { $first: "$x53" },
            endOdo: { $first: "$x11" },
            endChargeCycle: { $first: "$x101" },
          },
        },
        {
          $sort: { date: 1 },
        },
      ],
      { allowDiskUse: true }
    );

    mongoResults = mongoResults.map((item) => ({
      ...item,
      endChargeCycle:
        item.batteryType === "Prana 11.a 216 Ah single pack"
          ? Number(item.endChargeCycle) / 2
          : item.batteryType === "Exponent pack - 8kWh"
          ? Number(item.endChargeCycle) / 10
          : item.endChargeCycle,
    }));

    return res.json({
      status: true,
      code: 200,
      values: mongoResults,
    });
  } catch (error) {
    console.log(error, "err");
    return res.json({
      status: false,
      code: 500,
      values: "Internal Server Error",
    });
  }
};

const fleetWiseBatteryHealthCardCustomUpdated = async (req, res) => {
  try {
    const { yearMonth, fleet } = req.body;

    let year = parseInt(yearMonth.split("-")[0]);

    let month = parseInt(yearMonth.split("-")[1]);

    await connection(url);

    Client.belongsToMany(Vehicle, {
      through: ClientVehicle,
      foreignKey: "cid",
    });
    Vehicle.belongsToMany(Client, {
      through: ClientVehicle,
      foreignKey: "vid",
    });

    await sequelize.sync();

    const sqlResults = await Vehicle.findAll({
      attributes: ["VIN", "VehicleRegNo", "Kit_ID", "batterySrNo"],
      where: {
        deleteVehicleStatus: 0,
        [Op.or]: [
          { VIN: { [Op.like]: "mq/MD9%" } },
          { VIN: { [Op.like]: "mq/P6R%" } },
        ],
      },
      nest: true,
      include: [
        {
          model: Client,
          attributes: [[sequelize.literal("TRIM(`clientCode`)"), "clientCode"]],
          through: {
            attributes: [],
          },
          where: {
            clientCode: {
              [Op.like]: `${fleet.trim()}`,
            },
          },
        },
      ],
    });

    const mongoResults = await MonthlyBatteryHealthCardReport.aggregate([
      {
        $match: {
          year: { $lte: year },
          month: { $lte: month },
        },
      },
      {
        $sort: {
          year: -1,
          month: -1,
        },
      },
      {
        $lookup: {
          from: "vehicleDailyData",
          let: { localValue: { $concat: ["mq/", "$vin"] } },
          pipeline: [
            {
              $match: {
                $expr: {
                  $eq: ["$topic", "$$localValue"],
                },
                x11: {
                  $gt: 0,
                },
                $and: [{ x96: { $ne: null } }, { x96: { $ne: "NA" } }],
              },
            },

            {
              $sort: {
                x11: -1,
              },
            },
            {
              $limit: 1,
            },
            // Add more pipeline stages if needed
          ],
          as: "joinedData",
        },
      },
      {
        $project: {
          _id: 0,
          vin: 1,
          "joinedData.x96": 1, // Include specific fields from the joined collection
          calculated_soh: 1,
          end_battery_pack_cycle: 1,
          end_odometer: 1,
          year: 1,
          month: 1,

          // Add more fields as needed
        },
      },
      {
        $group: {
          _id: "$vin",
          battery_type: { $first: "$joinedData.x96" },
          calculated_soh: { $first: "$calculated_soh" },
          end_battery_pack_cycle: { $first: "$end_battery_pack_cycle" },
          end_odometer: { $first: "$end_odometer" },
          year: { $first: "$year" },
          month: { $first: "$month" },
        },
      },
    ]);

    const matchingPairs = [];

    for (const sqlResult of sqlResults) {
      for (const mongoResult of mongoResults) {
        if (
          sqlResult["VIN"].slice(3) === mongoResult["_id"] &&
          String(mongoResult["_id"]) === String(sqlResult["VIN"].slice(3))
        ) {
          let date = new Date(mongoResult["year"], mongoResult["month"] - 1, 1);
          const monthName = date.toLocaleString("en-US", { month: "long" });
          matchingPairs.push({
            "Vehicle Reg No": sqlResult["VehicleRegNo"],
            "VIN ID": sqlResult["VIN"].slice(3),
            "Battery Type": mongoResult["battery_type"][0],
            "Monthly Battery SOH(%) Calculated": mongoResult["calculated_soh"],
            "End Charge Cycle": mongoResult["end_battery_pack_cycle"],
            "End Odometer": mongoResult["end_odometer"],
            Month: monthName,
          });
        }
      }
    }

    return res.json({
      status: true,
      code: 200,
      values: matchingPairs,
    });
  } catch (error) {
    console.log(error, "err");
    return res.json({
      status: false,
      code: 500,
      values: "Internal Server Error",
    });
  }
};

const fleetWiseBatteryHealthCardCustomUpdatedNewOne = async (req, res) => {
  try {
    const { yearMonth, fleet } = req.body;

    let year = parseInt(yearMonth.split("-")[0]);

    let month = parseInt(yearMonth.split("-")[1]);

    await connection(url);

    Client.belongsToMany(Vehicle, {
      through: ClientVehicle,
      foreignKey: "cid",
    });
    Vehicle.belongsToMany(Client, {
      through: ClientVehicle,
      foreignKey: "vid",
    });

    await sequelize.sync();

    const sqlResults = await Vehicle.findAll({
      attributes: ["VIN", "VehicleRegNo", "Kit_ID", "batterySrNo"],
      where: {
        deleteVehicleStatus: 0,
        [Op.or]: [
          { VIN: { [Op.like]: "mq/MD9%" } },
          { VIN: { [Op.like]: "mq/P6R%" } },
        ],
      },
      nest: true,
      include: [
        {
          model: Client,
          attributes: [[sequelize.literal("TRIM(`clientCode`)"), "clientCode"]],
          through: {
            attributes: [],
          },
          where: {
            clientCode: {
              [Op.like]: `${fleet.trim()}`,
            },
          },
        },
      ],
    });

    const mongoResults = await MonthlyBatteryHealthCardReport.aggregate(
      [
        {
          $match: {
            $or: [
              { year: { $lt: year } },
              {
                $and: [{ year: year }, { month: { $lte: month } }],
              },
            ],
          },
        },
        // {
        //   $sort: {
        //     year: -1,
        //     month: -1,
        //   },
        // },

        {
          $group: {
            _id: "$vin",
            calculated_soh: { $last: "$calculated_soh" },
            avg_soh: { $last: "$end_soh" },
            end_battery_pack_cycle: { $last: "$end_battery_pack_cycle" },
            end_odometer: { $last: "$end_odometer" },
            year: { $last: "$year" },
            month: { $last: "$month" },
          },
        },
      ],
      { allowDiskUse: true }
    );

    const mongoResults2 = await VehicleDailyData.aggregate(
      [
        {
          $match: {
            x11: {
              $gt: 0,
            },
            $and: [{ x96: { $ne: null } }, { x96: { $ne: "NA" } }],
          },
        },

        {
          $sort: {
            x11: -1,
          },
        },
        {
          $group: {
            _id: "$topic",
            batteryType: { $first: "$x96" },
          },
        },
      ],
      { allowDiskUse: true }
    );

    const matchingPairs1 = [];

    for (const sqlResult of sqlResults) {
      for (const mongoResult of mongoResults2) {
        // for(const mongoResult2 of mongoResults2){
        if (
          sqlResult["VIN"] === mongoResult["_id"] &&
          String(mongoResult["_id"]) === String(sqlResult["VIN"])
        ) {
          // let date = new Date(mongoResult['year'], mongoResult['month'] - 1, 1);
          // const monthName = date.toLocaleString("en-US", { month: "long" });
          matchingPairs1.push({
            "Vehicle Reg No": sqlResult["VehicleRegNo"],
            "VIN ID": sqlResult["VIN"].slice(3),
            "Battery Type": mongoResult["batteryType"],

            // "Monthly Battery SOH(%) Calculated": mongoResult["calculated_soh"],
            // "End Charge Cycle": mongoResult["end_battery_pack_cycle"],
            // "End Odometer": mongoResult["end_odometer"],
            // Month: monthName,
          });
        }
        // }
      }
    }

    const matchingPairs = [];

    for (const sqlResult of matchingPairs1) {
      for (const mongoResult of mongoResults) {
        // for(const mongoResult2 of mongoResults2){
        if (
          sqlResult["VIN ID"] === mongoResult["_id"] &&
          String(mongoResult["_id"]) === String(sqlResult["VIN ID"])
        ) {
          let date = new Date(mongoResult["year"], mongoResult["month"] - 1, 1);
          const monthName = date.toLocaleString("en-US", { month: "long" });

          matchingPairs.push({
            "Vehicle Reg No": sqlResult["Vehicle Reg No"],
            "VIN ID": sqlResult["VIN ID"],
            "Battery Type": sqlResult["Battery Type"],
            "Monthly Battery SOH(%) Calculated":
              sqlResult["Battery Type"] === "Prana 11.a 216 Ah single pack"
                ? mongoResult["calculated_soh"]
                : mongoResult["avg_soh"],
            "End Charge Cycle": mongoResult["end_battery_pack_cycle"],
            "End Odometer": mongoResult["end_odometer"],
            Month: monthName,
          });
        }
        // }
      }
    }
    console.log(matchingPairs.length, matchingPairs1.length);
    return res.json({
      status: true,
      code: 200,
      values: matchingPairs,
    });
  } catch (error) {
    console.log(error, "err");
    return res.json({
      status: false,
      code: 500,
      values: "Internal Server Error",
    });
  }
};

const lockedVehicles = async (req, res) => {
  try {
    await sequelize.sync();
    await connection(url);
    let query =
      await sequelize.query(`select distinct veh.VIN as vin,veh.VehicleRegNo,
        veh.Immob_reason,veh.last_updatedAt, 
        GROUP_CONCAT(DISTINCT cl.ClientFullName SEPARATOR ',') as name from Client cl 
        join ClientVehicle cv on cl.cid = cv.cid 
        join Vehicle veh on cv.vid = veh.vid 
        where deleteVehicleStatus=0 and (veh.vin like 'mq/MD9%' or veh.vin like 'mq/P6R%' ) and Immob_status=0 group by veh.vin`);

    const obj = {};
    query[0].map((item) => (obj[item["vin"]] = item));
    let vinsArray = Object.keys(obj);
    let mongoData = await VehicleLockUnlock.aggregate([
      {
        $match: {
          VIN: { $in: vinsArray },
          status: "Lock",
        },
      },
      {
        $group: {
          _id: "$VIN",
          status: {
            $last: "$status",
          },
          userEmail: {
            $last: "$userEmail",
          },
          lastLockedTime: {
            $last: "$requestTimeStamp",
          },
          confirmLockedTime: {
            $last: "$confirmTimeStamp",
          },
        },
      },
    ]);
    const result = [];
    const stateObject = {};
    if (mongoData) {
      mongoData.map((item) => {
        let object = {
          vehicle_reg_number: obj[item._id]["VehicleRegNo"],
          vin: item._id.slice(3),
          Immob_reason: obj[item._id]["Immob_reason"],
          user: item.userEmail,
          requestedLockTime: item.lastLockedTime,
          confirmedLockedTime:
            item.confirmLockedTime == "NULL"
              ? "Pending"
              : item.confirmLockedTime,
          fleet: obj[item._id]["name"],
        };
        let stateCode = stateCodes.find((it) => {
          return it.code === obj[item._id]["VehicleRegNo"].slice(0, 2);
        });
        if (stateCode != undefined) {
          if (stateObject.hasOwnProperty(stateCode.state)) {
            stateObject[stateCode.state].push(object);
          } else {
            stateObject[stateCode.state] = [object];
          }
        }
        result.push(object);
      });
    }
    let stateResult = [
      Object.keys(stateObject),
      Object.values(stateObject).map((i) => i.length),
    ];
    return res.json({
      status: true,
      code: 200,
      data: { result: result, state: stateObject, stateResult: stateResult },
    });
  } catch (error) {
    console.log(error);
    return res.json({
      status: false,
      code: 500,
      error: error,
    });
  }
};

const vehicleSerialSegmentation = async (req, res) => {
  try {
    await sequelize.sync();
    Vehicle.hasOne(VinSerialNum, {
      foreignKey: "vehicleId",
      sourceKey: "vid",
    });

    VinSerialNum.belongsTo(Vehicle, {
      foreignKey: "vehicleId",
      targetKey: "vid",
    });
    Client.belongsToMany(Vehicle, {
      through: ClientVehicle,
      foreignKey: "cid",
    });
    Vehicle.belongsToMany(Client, {
      through: ClientVehicle,
      foreignKey: "vid",
    });

    await connection(url);

    let result = {
      total_vehicles: null,
      yesterdayvehicles: null,
      top_three_distance: null,
      top_three_odo: null,
      state_wise_vehicles: null,
      rto_jurisdictions: null,
      distance_chart: null,
      top_three_distance_daily: null,
      // vehicleTypesList:null
    };

    const date = new Date();
    let yesterday = moment(
      new Date(date.getFullYear(), date.getMonth(), date.getDate() - 1)
    ).format("YYYY-MM-DD");
    const day_before_yesterday = moment(
      new Date(date.getFullYear(), date.getMonth(), date.getDate() - 2)
    ).format("YYYY-MM-DD");
    const day_2before_yesterday = moment(
      new Date(date.getFullYear(), date.getMonth(), date.getDate() - 3)
    ).format("YYYY-MM-DD");
    const thirtyDaysAgo = moment()
      .tz("Asia/Kolkata")
      .subtract(30, "days")
      .format("YYYY-MM-DD");

    const { segment } = req.body;
    const columnKey = Object.keys(segment)[0];

    let filters;
    if (Object.values(segment).some((item) => item === "Show All")) {
      filters = {
        where: {
          [columnKey]: {
            [Op.notIn]: [""],
          },
        },
        raw: true,
        order: [["id"]],
      };
    } else if (
      Object.values(segment).some((item) => item === "Captive & DCO/MLO")
    ) {
      filters = {
        where: {
          [columnKey]: {
            [Op.in]: ["Captive", "DCO/MLO"],
          },
        },
        raw: true,
        order: [["id"]],
      };
    } else {
      filters = {
        where: segment,
        raw: true,
        order: [["id"]],
      };
    }

    // console.log('log1')

    const computeSegmentation = async (vinsList) => {
      // console.log(vinsList.length,'vinsList')

      let vehiclesList,
        yesterdayvehicles,
        totalDistances,
        top_three_distance,
        top_three_distance_daily,
        top_three_odo,
        state_wise_vehicles,
        rto_jurisdictions;
      // vehicleTypesList;

      // console.log('log4')

      // total vehicles
      vehiclesList = await Vehicle.findAll({
        attributes: ["VIN", "VehicleRegNo", "lastDataSentAt"],
        where: {
          deleteVehicleStatus: 0,
          VIN: {
            [Op.in]: vinsList.map((vin) => vin.vin),
          },
          [Op.or]: [
            { VIN: { [Op.like]: "mq/MD9%" } },
            { VIN: { [Op.like]: "mq/P6R%" } },
          ],
        },
        nest: true,
        include: [
          {
            model: Client,
            attributes: ["clientCode"],
            through: { attributes: [] },
          },
        ],
      });

      let allVehiclesOdo = await VehicleDailyData.aggregate([
        {
          $match: {
            topic: {
              $in: vinsList.map((vin) => vin.vin),
            },
            x78: "Running",
            date: {
              $lte: yesterday,
            },
          },
        },
        {
          $group: {
            _id: "$topic",
            end_odo: { $last: "$x11" },
          },
        },
      ]);
      let vehicleTableVins = {};
      vehiclesList = vehiclesList.map((item) => {
        let foundVehicle = vinsList.find(
          (vehicle) => vehicle.vin === item.dataValues.VIN
        );
        vehicleTableVins[item.dataValues.VIN] = item.dataValues;
        return {
          vin: item.dataValues.VIN.slice(3),
          vehicle_reg_number: item.dataValues.VehicleRegNo,
          [columnKey]: vinsList.find((vin) => vin.vin === item.dataValues.VIN)[
            columnKey
          ],
          odometer:
            allVehiclesOdo.find(
              (vehicle) => vehicle._id === item.dataValues.VIN
            ) !== undefined
              ? allVehiclesOdo.find(
                  (vehicle) => vehicle._id === item.dataValues.VIN
                ).end_odo
              : "No data",
          customer:
            foundVehicle !== undefined ? foundVehicle.customer : "No data",

          fleets: item["Clients"]
            .map((client) => client.dataValues.clientCode)
            .join(","),
          lastPinged: item.dataValues.lastDataSentAt,
        };
      });

      // vehicleTypesList=vinsList.reduce((acc,cur)=>{
      //   if(vehicleTableVins.hasOwnProperty(cur.vin)){
      //     let object={
      //       vin:cur.vin.slice(3),
      //       vehicleRegNo:vehicleTableVins[cur.vin]['VehicleRegNo'],
      //       variant:cur.variant,
      //       customer:cur.customer.trim(),
      //       application:cur.application,
      //       Model:cur.type
      //     }
      //   if(acc.hasOwnProperty(cur.variant)){
      //     acc[cur.variant].push(object)
      //   }else{
      //     acc[cur.variant]=[object]
      //   }
      //   return acc;
      // }else{
      //   return acc;
      // }
      // },{})
      // result.vehicleTypesList=vehicleTypesList
      // Object.keys(vehicleTypesList).map(item=>console.log(item,vehicleTypesList[item].length))
      // console.log(vehiclesList.length,'vehiclesList')

      // console.log('log6')

      result.total_vehicles = vehiclesList;

      //yesterday driven vehicles

      // console.log(yesterday);

      yesterdayvehicles = await VehicleDailyData.aggregate([
        {
          $match: {
            date: yesterday,
            $or: [
              { topic: { $regex: /^mq\/MD9/ } },
              { topic: { $regex: /^mq\/P6R/ } },
            ],
            // [mongoKey]: {
            //   $regex: mongoParameter,
            // },
            topic: {
              $in: vinsList.map((vin) => vin.vin),
            },
            x12: {
              $gt: 0,
              $lte: 500,
            },
            x78: "Running",
          },
        },
        {
          $group: {
            _id: "$topic",
            vehicle_reg_number: { $last: "$x1" },
            date: { $last: "$date" },
            distance: { $last: "$x12" },
          },
        },
      ]);

      // console.log(vehiclesList[0]);

      // console.log('log7')

      yesterdayvehicles = yesterdayvehicles.map((item) => {
        let foundVehicle = vinsList.find((vehicle) => vehicle.vin === item._id);
        return {
          vin: item._id.slice(3),
          reg_no: item.vehicle_reg_number,
          distance: item.distance,
          customer:
            foundVehicle !== undefined ? foundVehicle.customer : "No data",
        };
      });

      result.yesterdayvehicles = yesterdayvehicles;

      totalDistances = await VehicleDailyData.aggregate([
        {
          $match: {
            date: {
              $in: [day_2before_yesterday, day_before_yesterday, yesterday],
            },
            $or: [
              { topic: { $regex: /^mq\/MD9/ } },
              { topic: { $regex: /^mq\/P6R/ } },
            ],
            topic: {
              $in: vinsList.map((vin) => vin.vin),
            },
            // [mongoKey]: {
            //   $regex: mongoParameter,
            // },
            x12: {
              $gt: 1,
              $lte: 500,
            },
            x78: "Running",
          },
        },
        {
          $sort: {
            date: -1,
          },
        },
        {
          $group: {
            _id: "$date",
            totalDistance: { $sum: "$x12" },
            avgDistance: { $avg: "$x12" },
          },
        },
      ]);

      totalDistances.sort((a, b) => moment(b._id) - moment(a._id));

      // console.log(totalDistances);

      //total distance yesterday

      // TotalDistance1 =
      //   totalDistances.length === 3 ? totalDistances[0].totalDistance : 0;

      // result.TotalDistance1 = { distance: TotalDistance1, date: yesterday };

      //total distance day before yesterday

      // TotalDistance2 =
      //   totalDistances.length === 3 ? totalDistances[1].totalDistance : 0;

      // result.TotalDistance2 = {
      //   distance: TotalDistance2,
      //   date: day_before_yesterday,
      // };

      // //total distance 2 days before yesterday

      // TotalDistance3 =
      //   totalDistances.length === 3 ? totalDistances[2].totalDistance : 0;

      // result.TotalDistance3 = {
      //   distance: TotalDistance3,
      //   date: day_2before_yesterday,
      // };

      // console.log(yesterday, thirtyDaysAgo);
      //top three distance

      let top_three_distance_query = await VehicleDailyData.aggregate([
        {
          $match: {
            date: { $lte: yesterday, $gte: thirtyDaysAgo },
            $or: [
              { topic: { $regex: /^mq\/MD9/ } },
              { topic: { $regex: /^mq\/P6R/ } },
            ],
            topic: {
              $in: vinsList.map((vin) => vin.vin),
            },
            x12: {
              $gt: 0,
              $lte: 500,
            },
            x78: "Running",
          },
        },
        {
          $group: {
            _id: "$topic",
            topic: { $last: "$topic" },
            x1: { $last: "$x1" },
            x12: { $sum: "$x12" },
            x11: { $last: "$x11" },
            distanceDaily: { $max: "$x12" },
            // max_distance_driven_date: {
            //   $first: {
            //     $cond: {
            //       if: { $eq: ["$x12", { $max: "$x12" }] },
            //       then: "$date", // Assuming "date" is the field representing the date when distance was recorded
            //       else: null,
            //     },
            //   },
            // },
          },
        },
        {
          $sort: {
            x12: -1,
          },
        },
        {
          $limit: 5,
        },
      ]);

      let top_three_distance_daily_query = await VehicleDailyData.aggregate([
        {
          $match: {
            date: { $lte: yesterday, $gte: thirtyDaysAgo },
            $or: [
              { topic: { $regex: /^mq\/MD9/ } },
              { topic: { $regex: /^mq\/P6R/ } },
            ],
            topic: {
              $in: vinsList.map((vin) => vin.vin),
            },
            x12: {
              $gt: 0,
              $lte: 500,
            },
            x78: "Running",
          },
        },

        {
          $group: {
            _id: "$_id",
            topic: { $last: "$topic" },
            x1: { $last: "$x1" },
            x11: { $last: "$x11" },
            distanceDaily: { $max: "$x12" },
            max_distance_driven_date: {
              $first: {
                $cond: {
                  if: {
                    $eq: ["$x12", { $max: "$x12" }],
                  },
                  then: "$date", // Assuming "date" is the field representing the date when distance was recorded
                  else: null,
                },
              },
            },
          },
        },
        {
          $sort: {
            distanceDaily: -1,
          },
        },
        {
          $group: {
            _id: "$topic",
            topic: { $first: "$topic" },
            x1: { $first: "$x1" },
            x11: { $first: "$x11" },
            distanceDaily: { $first: "$distanceDaily" },
            max_distance_driven_date: { $first: "$max_distance_driven_date" },
          },
        },
        {
          $sort: {
            distanceDaily: -1,
          },
        },
        {
          $group: {
            _id: "$topic",
            topic: { $first: "$topic" },
            x1: { $first: "$x1" },
            x11: { $first: "$x11" },
            distanceDaily: { $first: "$distanceDaily" },
            max_distance_driven_date: { $first: "$max_distance_driven_date" },
          },
        },
        {
          $sort: {
            distanceDaily: -1,
          },
        },
        {
          $limit: 5,
        },
      ]);

      // console.log('log9')

      top_three_distance = top_three_distance_query.map((item) => {
        let foundVehicle = vinsList.find(
          (vehicle) => vehicle.vin === item.topic
        );
        return {
          vin: item.topic.slice(3),
          vehicle_reg_number: item.x1,
          customer:
            foundVehicle !== undefined ? foundVehicle.customer : "No data",
          dist: Number(item.x12).toFixed(2),
          date: yesterday,
          odo: item.x11,
        };
      });

      result.top_three_distance = top_three_distance;

      top_three_distance_daily = top_three_distance_daily_query.map((item) => {
        let foundVehicle = vinsList.find(
          (vehicle) => vehicle.vin === item.topic
        );
        return {
          vin: item.topic.slice(3),
          vehicle_reg_number: item.x1,
          customer:
            foundVehicle !== undefined ? foundVehicle.customer : "No data",
          dist: Number(item.distanceDaily).toFixed(2),
          date: item.max_distance_driven_date,
          odo: item.x11,
        };
      });

      result.top_three_distance_daily = top_three_distance_daily;

      //top three odo

      top_three_odo = await VehicleDailyData.aggregate([
        {
          $match: {
            date: { $lte: yesterday },
            $or: [
              { topic: { $regex: /^mq\/MD9/ } },
              { topic: { $regex: /^mq\/P6R/ } },
            ],
            topic: {
              $in: vinsList.map((vin) => vin.vin),
            },
            // [mongoKey]: {
            //   $regex: mongoParameter,
            // },
            x12: {
              $gt: 0,
              $lte: 500,
            },
            x78: "Running",
          },
        },
        {
          $group: {
            _id: "$topic",
            topic: { $last: "$topic" },
            x1: { $last: "$x1" },
            x11: { $max: "$x11" },
            x12: { $last: "$x12" },
          },
        },

        {
          $sort: {
            x11: -1,
          },
        },
        {
          $limit: 5,
        },
      ]);

      // console.log('log10')

      top_three_odo = top_three_odo.map((item) => {
        let foundVehicle = vinsList.find(
          (vehicle) => vehicle.vin === item.topic
        );
        return {
          vin: item.topic.slice(3),
          vehicle_reg_number: item.x1,
          customer:
            foundVehicle !== undefined ? foundVehicle.customer : "No data",
          dist: Number(item.x12).toFixed(2),
          date: yesterday,
          odo: item.x11,
        };
      });

      result.top_three_odo = top_three_odo;

      state_wise_vehicles = vehiclesList.reduce((acc, cum) => {
        let stateCode = stateCodes.find(
          (item) => item.code === cum.vehicle_reg_number.slice(0, 2)
        );

        if (stateCode !== undefined) {
          if (acc.hasOwnProperty(stateCode.state)) {
            return {
              ...acc,
              [stateCode.state]: [...acc[stateCode.state], cum],
            };
          } else {
            return { ...acc, [stateCode.state]: [cum] };
          }
        } else return acc;
      }, {});

      state_wise_vehicles = Object.entries(state_wise_vehicles).map(
        ([key, value]) => ({ state: key, vehicles: value.length })
      );

      state_wise_vehicles = state_wise_vehicles.sort((a, b) => {
        if (a.vehicles < b.vehicles) return 1;
        if (a.vehicles > b.vehicles) return -1;
        return 0;
      });

      result.state_wise_vehicles = state_wise_vehicles;

      rto_jurisdictions = vehiclesList.reduce((acc, cum) => {
        if (
          cum.vehicle_reg_number.startsWith("MD9") ||
          cum.vehicle_reg_number.startsWith("P6R")
        )
          return acc;
        let rto = cum.vehicle_reg_number.slice(0, 4);
        if (acc.hasOwnProperty(rto)) {
          return {
            ...acc,
            [rto]: [...acc[rto], cum],
          };
        } else {
          return { ...acc, [rto]: [cum] };
        }
      }, {});

      rto_jurisdictions = Object.entries(rto_jurisdictions).map(
        ([key, value]) => ({ rto_jurisdiction: key, vehicles: value.length })
      );

      rto_jurisdictions.sort((a, b) => {
        if (a.vehicles < b.vehicles) return 1;
        if (a.vehicles > b.vehicles) return -1;
        return 0;
      });

      result.rto_jurisdictions = rto_jurisdictions;

      result.distance_chart = totalDistances.map((item) => ({
        date: item._id,
        distance: item.totalDistance,
        avgDistance: Number(item.avgDistance.toFixed(2)),
      }));
    };

    // console.log('log2')
    const data = await VinSerialNum.findAll(filters);
    // console.log(data,'data')
    // console.log('log3')

    await computeSegmentation(
      data.map((item) => ({
        vin: "mq/" + item.VIN,
        [Object.keys(segment)[0]]: item[Object.keys(segment)[0]],
        customer: item.customer_name,
        // type:item.type,
        // variant:item.variant
      }))
    );
    // console.log('log4')

    return res.json({ status: true, data: result });
  } catch (error) {
    console.log(error);
    return res.json({
      status: false,
      code: 500,
      data: "Internal Server Error",
    });
  }
};

const getVehicleTypes = async (req, res) => {
  try {
    const { segment } = req.body;
    await sequelize.sync();
    Vehicle.hasOne(VinSerialNum, {
      foreignKey: "vehicleId",
      sourceKey: "vid",
    });

    VinSerialNum.belongsTo(Vehicle, {
      foreignKey: "vehicleId",
      targetKey: "vid",
    });
    Client.belongsToMany(Vehicle, {
      through: ClientVehicle,
      foreignKey: "cid",
    });
    Vehicle.belongsToMany(Client, {
      through: ClientVehicle,
      foreignKey: "vid",
    });

    //  const query=await sequelize.query(`select distinct veh.VIN as vin,veh.VehicleRegNo,veh.model,veh.SIMservicePrName,veh.network_type,
    //  GROUP_CONCAT(DISTINCT cl.ClientFullName SEPARATOR ',') as name,vs.vinserialnum,vs.variant,vs.application from Client cl
    //  join ClientVehicle cv on cl.cid = cv.cid
    //  join Vehicle veh on cv.vid = veh.vid
    //  left join VinSerialNum vs on vs.vehicleId=veh.vid
    //  where deleteVehicleStatus=0 and
    //  (veh.vin like 'mq/MD9%' or veh.vin like 'mq/P6R%' ) and vs.application='${application}' group by veh.vin`);

    let filters;

    let column, value;
    column = Object.keys(segment)[0];
    value = segment[column];
    if (value != "Show All") {
      console.log(column, value, "col-val");
      filters = {
        attributes: [
          "VIN",
          "VehicleRegNo",
          "model",
          "SIMservicePrName",
          "network_type",
          [
            sequelize.literal(
              'GROUP_CONCAT(DISTINCT Clients.ClientFullName SEPARATOR ",")'
            ),
            "name",
          ],
          [sequelize.literal("`VinSerialNum`.`vinserialnum`"), "vinserialnum"],
          [sequelize.literal("`VinSerialNum`.`variant`"), "variant"],
          [sequelize.literal("`VinSerialNum`.`application`"), "application"],
          [sequelize.literal("`VinSerialNum`.`type`"), "type"],
          [
            sequelize.literal("`VinSerialNum`.`customer_category`"),
            "customer_category",
          ],
          [sequelize.literal("`VinSerialNum`.`finance`"), "finance"],
          [sequelize.literal("`VinSerialNum`.`finance`"), "finance"],
          [
            sequelize.literal("`VinSerialNum`.`financier_name`"),
            "financier_name",
          ],
        ],
        include: [
          {
            model: Client,
            as: "Clients",
            through: {
              model: ClientVehicle,
              attributes: [],
            },
            attributes: [],
            required: true,
          },
          {
            model: VinSerialNum,
            as: "VinSerialNum",
            attributes: [],
            required: false,
          },
        ],
        where: sequelize.and(
          { deleteVehicleStatus: 0 },
          sequelize.where(sequelize.col(`VinSerialNum.${column}`), value),
          sequelize.or(
            { vin: { [Sequelize.Op.like]: "mq/MD9%" } },
            { vin: { [Sequelize.Op.like]: "mq/P6R%" } }
          )
        ),
        group: ["VIN"],
        raw: true,
      };
    } else {
      console.log(value, "vallllll");
      filters = {
        attributes: [
          "VIN",
          "VehicleRegNo",
          "model",
          "SIMservicePrName",
          "network_type",
          [
            sequelize.literal(
              'GROUP_CONCAT(DISTINCT Clients.ClientFullName SEPARATOR ",")'
            ),
            "name",
          ],
          [sequelize.literal("`VinSerialNum`.`vinserialnum`"), "vinserialnum"],
          [sequelize.literal("`VinSerialNum`.`variant`"), "variant"],
          [sequelize.literal("`VinSerialNum`.`application`"), "application"],
          [sequelize.literal("`VinSerialNum`.`type`"), "type"],
          [
            sequelize.literal("`VinSerialNum`.`customer_category`"),
            "customer_category",
          ],
          [sequelize.literal("`VinSerialNum`.`finance`"), "finance"],
          [sequelize.literal("`VinSerialNum`.`finance`"), "finance"],
          [
            sequelize.literal("`VinSerialNum`.`financier_name`"),
            "financier_name",
          ],
        ],
        include: [
          {
            model: Client,
            as: "Clients",
            through: {
              model: ClientVehicle,
              attributes: [],
            },
            attributes: [],
            required: true,
          },
          {
            model: VinSerialNum,
            as: "VinSerialNum",
            attributes: [],
            required: false,
          },
        ],
        where: sequelize.and(
          { deleteVehicleStatus: 0 },
          // sequelize.and(
          //   sequelize.where(sequelize.col(`VinSerialNum.${column}`), {
          //     [Op.not]: null
          //   }),
          sequelize.where(sequelize.col(`VinSerialNum.${column}`), {
            [Op.not]: "",
          }),
          // ),
          sequelize.or(
            { vin: { [Sequelize.Op.like]: "mq/MD9%" } },
            { vin: { [Sequelize.Op.like]: "mq/P6R%" } }
          )
        ),
        group: ["VIN"],
        raw: true,
      };
    }

    const queryResult = await Vehicle.findAll(filters);
    console.log(queryResult.length);
    //  console.log(queryResult)
    const data = queryResult.reduce((acc, cur) => {
      if (acc.hasOwnProperty(cur.variant)) {
        acc[cur.variant].push(cur);
      } else {
        acc[cur.variant] = [cur];
      }
      return acc;
    }, {});
    return res.json({
      status: true,
      code: 200,
      data: data,
    });
  } catch (error) {
    console.log(error, "err");
    return res.json({
      status: false,
      code: 500,
      error: error,
    });
  }
};

const getVinSerialSelectValues = async (req, res) => {
  try {
    await sequelize.sync();
    Vehicle.hasOne(VinSerialNum, {
      foreignKey: "vehicleId",
      sourceKey: "vid",
    });

    VinSerialNum.belongsTo(Vehicle, {
      foreignKey: "vehicleId",
      targetKey: "vid",
    });

    await connection(url);

    const { type } = req.body;

    const filters = {
      where: {
        [type]: {
          [Op.notIn]: [""],
        },
      },
      attributes: [type],
      raw: true,
      order: [["id"]],
      group: [type],
    };

    const data = await VinSerialNum.findAll(filters);
    let result = [
      ...data.map((item) => ({
        label: Object.values(item)[0],
        value: Object.values(item)[0],
      })),
      { label: "Show All", value: "Show All" },
    ];
    if (type === "customer_category")
      result.push({ label: "Captive & DCO/MLO", value: "Captive & DCO/MLO" });
    return res.json({
      status: true,
      data: result,
    });
  } catch (error) {
    console.log(error);
    return res.json({
      status: false,
      code: 500,
      data: "Internal Server Error",
    });
  }
};

const vinWiseBHC = async (req, res) => {
  try {
    await connection(url);

    const { vin, startDate, endDate } = req.body;

    console.log(req.body);

    let VIN = "";

    if (vin.startsWith("mq/")) {
      VIN = vin;
    } else {
      VIN = "mq/" + vin;
    }

    const mongoResults = await VehicleDailyData.aggregate(
      [
        {
          $match: {
            topic: { $eq: VIN },
            x78: "Running",
            date: { $lte: endDate, $gte: startDate },
          },
        },
        {
          $group: {
            _id: "$date",
            topic: { $first: "$topic" },
            reg_no: { $first: "$x1" },
            distance: { $first: "$x12" },
            batteryType: { $first: "$x96" },
            efficiency: { $first: "$x35" },

            regen: { $first: "$x34" },

            bMinSoh: { $first: "$x92" },
            bMaxSoh: { $first: "$x93" },
            bAvgSoh: { $first: "$x53" },
            cMinVolt: { $first: "$x28" },
            cMaxVolt: { $first: "$x27" },
            // cAvgMinVolt: { $avg: "$x28" },
            // cAvgMaxVolt: { $avg: "$x27" },
            cMaxDelta: { $first: "$x29" },
            bMinTemp: { $first: "$x31" },
            bMaxTemp: { $first: "$x30" },
            // bAvgMinTemp: { $avg: "$x31" },
            // bAvgMaxTemp: { $avg: "$x30" },
            bMaxDeltaTemp: { $first: "$x32" },
            peakBattery: { $first: "$x17" },
            startCycle: { $first: "$x100" },
            endCycle: { $first: "$x101" },
            conSoftVer: { $first: "$x85" },
            disSoftVer: { $first: "$x86" },
            startOdo: { $first: "$x10" },
            endOdo: { $first: "$x11" },
            batteryType: { $first: "$x96" },
            cumulativeAhRise: { $first: "$x90" },
            cumulativeAhDrop: { $first: "$x91" },
            cumulative_percentage_battery_charged: { $first: "$x88" },
            cumulative_percentage_battery_discharged: { $first: "$x89" },
            startSoc:{$first:"$x54"},
            endSoc:{$first:"$x55"}
          },
        },
        {
          $sort: { _id: -1 },
        },
      ],
      { allowDiskUse: true }
    );

    const result = mongoResults.map((bhc) => {
      // console.log(bhc)
      let btype = bhc.batteryType;
      let start = 0;
      let end = 0;
      let u = 0;
      let calculated_soh = 0;
      if (btype === "Prana 11.a 216 Ah single pack") {
        start = bhc["startCycle"] / 2;
        end = bhc["endCycle"] / 2;
        u = (bhc["endCycle"] / 4) * 0.01;
        calculated_soh = 0.021711 * u * u - 1.171193 * u + 99.463824;
      } else if (btype == "Exponent pack - 8kWh") {
        start = bhc["startCycle"] / 10;
        end = bhc["endCycle"] / 10;
        calculated_soh = bhc["bAvgSoh"];
      } else {
        start = bhc["startCycle"];
        end = bhc["endCycle"];
        calculated_soh = bhc["bAvgSoh"];
      }

      return {
        vin: bhc.topic.slice(3),
        reg_no: bhc.reg_no,
        date: bhc._id,
        distance: bhc.distance,
        efficiency: bhc.efficiency,
        regen: bhc.regen,
        start_odo: bhc.startOdo,
        end_odo: bhc.endOdo,
        startSoc:bhc.startSoc,
        endSoc:bhc.endSoc,
        min_soh: bhc.bMinSoh,
        max_soh: bhc.bMaxSoh,
        avg_soh: bhc.bAvgSoh,
        controller_software_version: bhc.conSoftVer,
        display_software_version: bhc.disSoftVer,
        cumulative_percentage_battery_charged:
          bhc.cumulative_percentage_battery_charged,
        cumulative_percentage_battery_discharged:
          bhc.cumulative_percentage_battery_discharged,
        calculated_soh: calculated_soh,
        min_cell_voltage: bhc.cMinVolt,
        max_cell_voltage: bhc.cMaxVolt,
        max_delta_cell_voltage: bhc.cMaxDelta,
        BMS_LOW_MODULE_TEMP: bhc.bMinTemp,
        BMS_HIGH_MODULE_TEMP: bhc.bMaxTemp,
        max_delta_battery_temp: bhc.bMaxDeltaTemp,
        peak_battery_power_used: bhc.peakBattery,
        start_charge_cycle_count: start,
        end_charge_cycle_count: end,
        battery_type: bhc.batteryType,
        cumulative_Ah_rise: bhc.cumulativeAhRise,
        cumulative_Ah_drop: bhc.cumulativeAhDrop,
        
      };
    });

    return res.json({
      status: true,
      code: 200,
      data: result,
    });
  } catch (error) {
    console.log(error, "err");
    return res.json({
      status: false,
      code: 500,
      values: "Internal Server Error",
    });
  }
};

const applicationSeg = async (req, res) => {
  try {
    await connection(url);
    await sequelize.sync();
    //   where:{
    //     [Sequelize.Op.and]: [
    //         {
    //             application: {
    //                 [Sequelize.Op.ne]: '' // not equal to empty string
    //             }
    //         },
    //         {
    //             application: {
    //                 [Sequelize.Op.ne]: ' ' // not equal to space
    //             }
    //         },
    //         {
    //             application: {
    //                 [Sequelize.Op.ne]: null // not equal to null
    //             }
    //         }
    //     ]
    // },
    // let dataQuery=await VinSerialNum.findAll({
    //   attributes: [
    //     [sequelize.fn('COUNT', sequelize.literal('DISTINCT VIN')), 'vehicleCount'],
    //     [sequelize.fn('TRIM', sequelize.col('application')), 'application']
    //   ],
    //   group: [sequelize.fn('TRIM', sequelize.col('application'))]
    // });
    let mainQuery = await VinSerialNum.findAll({
      where: {
        [Sequelize.Op.and]: [
          {
            application: {
              [Sequelize.Op.ne]: "Dealer Demo Vehicle", // not equal to empty string
            },
          },
          {
            application: {
              [Sequelize.Op.ne]: "Exponent Demo Vehicle", // not equal to empty string
            },
          },
          {
            application: {
              [Sequelize.Op.ne]: "Others", // not equal to empty string
            },
          },
          {
            application: {
              [Sequelize.Op.ne]: "", // not equal to empty string
            },
          },
          {
            application: {
              [Sequelize.Op.ne]: " ", // not equal to space
            },
          },
          {
            application: {
              [Sequelize.Op.ne]: null, // not equal to null
            },
          },
        ],
      },
      attributes: [
        "VIN",
        "vinserialnum",
        ["type", "model"],
        "customer_category",
        "Manufactured_Date",
        "application",
      ],
    });
    let vins = mainQuery.map((item) => "mq/" + item.VIN);
    let VehicleRegQuery = await Vehicle.findAll({
      where: {
        deleteVehicleStatus: 0,
        VIN: {
          [Sequelize.Op.in]: vins,
        },
      },
      attributes: ["VIN", "VehicleRegNo"],
    });
    let VehicleRegObject = VehicleRegQuery.reduce((acc, cur) => {
      acc[cur["VIN"].slice(3)] = cur["VehicleRegNo"];
      return acc;
    }, {});
    let presentDay = moment().format("YYYY-MM-DD");
    let lastThirtythDay = moment().subtract("days", 31).format("YYYY-MM-DD");
    let yesterday = moment().subtract("days", 1).format("YYYY-MM-DD");
    let vehicleDistanceData = await VehicleDailyData.aggregate([
      {
        $match: {
          date: {
            $gte: lastThirtythDay,
            $lte: yesterday,
          },
          topic: {
            $in: vins,
          },
          x12: {
            $gt: 1,
            $lte: 500,
          },
          x11: {
            $gt: 1000,
          },
        },
      },
      {
        $group: {
          _id: "$topic",
          odometer: { $last: "$x11" },

          distance: {
            $avg: "$x12",
          },
        },
      },
      {
        $project: {
          _id: 0,
          vin: "$_id",
          distance: "$distance",
          odometer: "$odometer",
        },
      },
    ]);

    console.log(vehicleDistanceData[0]);
    let vehicleDistanceObject = vehicleDistanceData.reduce((acc, cur) => {
      acc[cur["vin"].slice(3)] = cur["distance"];
      return acc;
    }, {});
    let vehicleOdoObject = vehicleDistanceData.reduce((acc, cur) => {
      acc[cur["vin"].slice(3)] = cur["odometer"];
      return acc;
    }, {});
    let VehicleCountPieChart = {},
      distanceBarChart = {},
      stateWiseCount = {},
      avgOdometer = {};

    mainQuery.map((item) => {
      const application = item["application"];
      if (application !== undefined) {
        const trimmedApplication = application.trim();
        if (VehicleCountPieChart.hasOwnProperty(trimmedApplication)) {
          VehicleCountPieChart[trimmedApplication] = [
            ...VehicleCountPieChart[trimmedApplication],
            item,
          ];
          if (
            distanceBarChart.hasOwnProperty(trimmedApplication) &&
            vehicleDistanceObject.hasOwnProperty(item["VIN"])
          ) {
            distanceBarChart[trimmedApplication].data.push({
              ...item["dataValues"],
              distance: vehicleDistanceObject[item["VIN"]]
                ? Number(vehicleDistanceObject[item["VIN"]].toFixed(2))
                : 0,
            });
          }
          if (
            avgOdometer.hasOwnProperty(trimmedApplication) &&
            vehicleOdoObject.hasOwnProperty(item["VIN"])
          ) {
            avgOdometer[trimmedApplication].data.push({
              ...item["dataValues"],
              odometer: vehicleOdoObject[item["VIN"]]
                ? Number(vehicleOdoObject[item["VIN"]].toFixed(2))
                : 0,
            });
          }
        } else {
          VehicleCountPieChart[trimmedApplication] = [item];
          if (vehicleDistanceObject.hasOwnProperty(item["VIN"])) {
            const dataArr = [
              {
                ...item["dataValues"],
                distance: vehicleDistanceObject[item["VIN"]]
                  ? Number(vehicleDistanceObject[item["VIN"]].toFixed(2))
                  : 0,
              },
            ];
            distanceBarChart[trimmedApplication] = { data: dataArr };
          }
          if (vehicleOdoObject.hasOwnProperty(item["VIN"])) {
            const dataArr = [
              {
                ...item["dataValues"],
                odometer: vehicleOdoObject[item["VIN"]]
                  ? Number(vehicleOdoObject[item["VIN"]].toFixed(2))
                  : 0,
              },
            ];
            avgOdometer[trimmedApplication] = { data: dataArr };
          }
          stateWiseCount[trimmedApplication] = {};
        }
        if (
          VehicleRegObject[item["VIN"]] &&
          stateCodeObject.hasOwnProperty(
            VehicleRegObject[item["VIN"]].slice(0, 2)
          )
        ) {
          if (stateWiseCount.hasOwnProperty(trimmedApplication)) {
            let state =
              stateCodeObject[VehicleRegObject[item["VIN"]].slice(0, 2)];
            if (stateWiseCount[trimmedApplication].hasOwnProperty(state)) {
              stateWiseCount[trimmedApplication][state]++;
            } else {
              stateWiseCount[trimmedApplication][state] = 1;
            }
          }
        }
        //    if (
        //   avgOdometer.hasOwnProperty(trimmedApplication) &&
        //   avgOdometer.hasOwnProperty(item["VIN"])
        // ) {
        //   avgOdometer[trimmedApplication].data.push({
        //     ...item["dataValues"],
        //     odometer: vehicleOdoObject[item["VIN"]]
        //       ? Number(vehicleOdoObject[item["VIN"]].toFixed(2))
        //       : 0,
        //   });
        // } else {
        //   const dataArr = [
        //     {
        //       ...item["dataValues"],
        //       odometer: vehicleOdoObject[item["VIN"]]
        //         ? Number(vehicleOdoObject[item["VIN"]].toFixed(2))
        //         : 0,
        //     },
        //   ];
        //   avgOdometer[trimmedApplication] = { data: dataArr };

        // }
      }
    });
    Object.keys(stateWiseCount).map((k) => {
      stateWiseCount[k] = Object.entries(stateWiseCount[k])
        .sort((a, b) => b[1] - a[1])
        .slice(0, 2)
        .map((i) => {
          return {
            state: i[0],
            vehicles: i[1],
          };
        });
    });
    Object.keys(distanceBarChart).map((key) => {
      let totalCount = distanceBarChart[key]["data"].length;
      let totalDistance = distanceBarChart[key]["data"].reduce((acc, cur) => {
        acc += Number(cur["distance"]);
        return acc;
      }, 0);
      distanceBarChart[key]["totalCount"] = totalCount;
      distanceBarChart[key]["avgDistance"] = Number(totalDistance.toFixed(2));
      distanceBarChart[key]["avgDistancePerApplication"] = Number(
        (totalDistance / totalCount).toFixed(2)
      );
    });
    distanceBarChart = Object.fromEntries(
      Object.entries(distanceBarChart).sort((a, b) => {
        return b[1].avgDistancePerApplication - a[1].avgDistancePerApplication;
      })
    );

    Object.keys(avgOdometer).map((key) => {
      let totalCount = avgOdometer[key]["data"].length;
      let totalDistance = avgOdometer[key]["data"].reduce((acc, cur) => {
        acc += Number(cur["odometer"]);
        return acc;
      }, 0);
      // odometer[key]['totalCount']=totalCount
      // distanceBarChart[key]['avgDistance']=Number(totalDistance.toFixed(2))
      avgOdometer[key]["odometer"] = Number(
        (totalDistance / totalCount).toFixed(2)
      );
    });
    avgOdometer = Object.fromEntries(
      Object.entries(avgOdometer).sort((a, b) => {
        return b[1].odometer - a[1].odometer;
      })
    );
    return res.json({
      status: true,
      code: 200,
      stateWiseCount: stateWiseCount,
      VehicleCountPieChart: VehicleCountPieChart,
      distanceBarChart,
      avgOdometer,
    });
  } catch (error) {
    console.log(error, "err");
    return res.json({
      status: false,
      code: 500,
      error: error,
    });
  }
};

const batteryvindata = async (req, res) => {
  try {
    await connection(url);
    await sequelize.sync();
    let { vins, startDate, endDate, distance } = req.body;
    if (distance == null || distance == undefined || distance == "") {
      distance = 0;
    }
    let vehicleQuery =
      await sequelize.query(`select distinct veh.VIN as vin,veh.VehicleRegNo,veh.model,veh.SIMservicePrName,veh.network_type,
    GROUP_CONCAT(DISTINCT cl.ClientFullName SEPARATOR ',') as name,vs.vinserialnum,vs.variant from Client cl 
    join ClientVehicle cv on cl.cid = cv.cid 
    join Vehicle veh on cv.vid = veh.vid 
    left join VinSerialNum vs on vs.vehicleId=veh.vid 
    where deleteVehicleStatus=0 and 
    (veh.vin like 'mq/MD9%' or veh.vin like 'mq/P6R%' ) group by veh.vin`);
    VehicleTableData = {};
    vehicleQuery[0].map((item) => {
      VehicleTableData[item.vin] = item;
    });

    startDate = moment(startDate).format("YYYY-MM-DD");
    endDate = moment(endDate).format("YYYY-MM-DD");
    const vinsArray = vins.map((item) => {
      if (item.indexOf("mq/") !== -1) {
        return item;
      } else {
        return "mq/" + item;
      }
    });
    let vehicleDailyDataQuery = await VehicleDailyData.aggregate([
      {
        $match: {
          topic: {
            $in: vinsArray,
          },
          date: {
            $gte: startDate,
            $lte: endDate,
          },
          x12: {
            $gte: Number(distance),
          },
        },
      },
      {
        $project: {
          _id: 0,
          vin: { $substr: ["$topic", 3, { $strLenCP: "$topic" }] },
          date: "$date",
          "Reg no": "$x1",
          "Distance driven": "$x12",
          "Start SOC": "$x54",
          "End SOC": "$x55",
          "Average speed": "$x13",
          "Max Speed": "$x14",
          Regen: "$x34",
          Efficiency: "$x35",
          "Energy used": "$x87",
          min_day_soc: "$x108",
          max_day_soc: "$x109",
          "cumulative SOC rise": "$x88",
          "cumulative SOC drop": "$x89",
          "cumulative AH rise": "$x90",
          "cumulative Ah drop": "$x91",
          "max brake pedal": "$x114",
          battery_type: "$x96",
          start_geo: "$x58",
          end_geo: "$x59",
        },
      },
      {
        $sort: {
          vin: 1,
          date: 1,
        },
      },
    ]);

    const data = vehicleDailyDataQuery.map((item) => {
      let object = { ...item };
      object["variant"] = VehicleTableData["mq/" + item["vin"]]["variant"];
      if (Object.keys(item["end_geo"]).length) {
        object["latitude"] = item["end_geo"]["lat"]
          ? item["end_geo"]["lat"].toFixed(2)
          : "NA";
        object["longitude"] = item["end_geo"]["lng"]
          ? item["end_geo"]["lng"].toFixed(2)
          : "NA";
      } else {
        object["latitude"] = "NA";
        object["longitude"] = "NA";
      }
      // else if(Object.keys(item['start_geo']).length){
      //   object['lat']=item['start_geo']['lat']?item['start_geo']['lat'].toFixed(2):"NA"
      //   object['lng']=item['start_geo']['lng']?item['start_geo']['lng'].toFixed(2):"NA"
      // }
      delete object.start_geo;
      delete object.end_geo;

      return object;
    });

    // let vehicleDailyDataQuery = await VehicleDailyData.aggregate([
    //   {
    //     $match: {
    //       date: {
    //         $gte: "2024-01-01",
    //         $lte: "2024-01-30",
    //       },
    //       topic:{
    //         $in:vinsArray
    //       }
    //     },
    //   },
    //   {
    //     $project: {
    //       _id:0,
    //       topic: "$topic",
    //       date: "$date",
    //       "Reg no": "$x1",
    //       "Distance driven": "$x12",
    //       "Start SOC": "$x54",
    //       "End SOC": "$x55",
    //       "Average speed": "$x13",
    //       "Max Speed": "$x14",
    //       Regen: "$x34",
    //       Efficiency: "$x35",
    //       "Energy used": "$x87",
    //       min_day_soc: "$x108",
    //       max_day_soc: "$x109",
    //       "cumulative SOC rise": "$x88",
    //       "cumulative SOC drop": "$x89",
    //       "cumulative AH rise": "$x90",
    //       "cumulative Ah drop": "$x91",
    //       "max brake pedal": "$x114",
    //       battery_type: "$x96",
    //     },
    //   },
    //   {
    //     $lookup: {
    //       from: "drive-score",
    //       let: {
    //         localValue: {
    //           $substr: [
    //             "$topic",
    //             3,
    //             { $subtract: [{ $strLenCP: "$topic" }, 3] },
    //           ],
    //         },
    //         date: "$date",
    //       },
    //       pipeline: [
    //         {
    //           $match: {
    //             $expr: {
    //               $and: [
    //                 { $eq: ["$vin", "$$localValue"] },
    //                 { $eq: ["$Date", "$$date"] }, // Compare date field with original topic
    //               ],
    //             },
    //           },
    //         },
    //         {$project:{
    //           _id:0,
    //           drive_score:'$drive_score',
    //           percentage_agressive_acceleration:'$percentage_agressive_acceleration',
    //           percentage_agressive_braking:'$percentage_agressive_braking',
    //           percentage_agressive_turning:'$percentage_agressive_turning',

    //         }}
    //       ],
    //       as: "joinedData",
    //     },
    //   }
    // ]);
    return res.json({
      status: true,
      code: 200,
      data: data,
      // VehicleTableData:VehicleTableData
    });
  } catch (error) {
    console.log(error);
    return res.json({
      status: false,
      code: 500,
      error: error,
    });
  }
};

const fleetSegmentationServiceLogs = async (req, res) => {
  try {
    await connection(url);

    Client.belongsToMany(Vehicle, {
      through: ClientVehicle,

      foreignKey: "cid",
    });

    Vehicle.belongsToMany(Client, {
      through: ClientVehicle,

      foreignKey: "vid",
    });

    await sequelize.sync();

    const { fleet, yearMonth } = req.body;

    let vehiclesList;

    let dmyYearMonth = yearMonth.split("-").reverse().join("-");

    // Fetch all VINs that meet the criteria

    vehiclesList = await Vehicle.findAll({
      attributes: [
        ["VIN", "vin"],

        ["VehicleRegNo", "vehicle_reg_number"],

        "model",

        "SIMservicePrName",

        "network_type",
      ],

      where: {
        deleteVehicleStatus: 0,

        [Op.or]: [
          { VIN: { [Op.like]: "mq/MD9%" } },

          { VIN: { [Op.like]: "mq/P6R%" } },
        ],
      },

      include: [
        {
          model: Client,

          attributes: [[sequelize.literal("TRIM(`clientCode`)"), "clientCode"]],

          through: {
            attributes: [],
          },

          where: {
            clientCode: {
              [Op.like]: `${fleet.trim()}`,
            },
          },
        },
      ],
    });

    if (!vehiclesList.length)
      return res.json({
        status: false,

        error: "No vehicles found",
      });

    // Extract VINs from the fetched vehicles

    const vins = vehiclesList.map((vehicle) => vehicle.dataValues.vin.slice(3));

    console.log(vins);

    const [year, month] = yearMonth.split("-");
    const startDate = new Date(year, month - 1, 1);
    const endDate = new Date(year, month, 0);

    // const formattedStartDate = startDate.toISOString().substr(0, 10); // YYYY-MM-DD format
    const formattedEndDate = endDate.toISOString().substring(0, 10); // YYYY-MM-DD format

    // Execute aggregate queries for all VINs concurrently

    let [vDDForVins, vssForVins, jobCardVins] = await Promise.all([
      VehicleDailyData.aggregate([
        {
          $match: {
            topic: { $in: vins.map((vin) => `mq/${vin}`) },

            x12: { $gt: 0, $lte: 500 },
            date: {
              $lte: formattedEndDate,
            },

            // date: { $regex: new RegExp('^' + yearMonth) }
          },
        },

        { $group: { _id: "$topic", odo: { $last: "$x11" } } },
      ]),

      VehicleSaleStatement.aggregate([
        { $match: { chassis_no: { $in: vins } } },
        {
          $group: {
            _id: "$chassis_no",
            document_date: { $last: "$document_date" },
            chassis_no: { $last: "$chassis_no" },
          },
        },
      ]),

      AplJobCards.aggregate([
        {
          $match: {
            vin: { $in: vins },

            repair_order_date: { $regex: new RegExp(dmyYearMonth + "$") },
          },
        },
      ]),
    ]);

    console.log(vDDForVins);

    // Map the aggregate results to VINs for easy lookup

    const vDDMap = vDDForVins.reduce((acc, cur) => {
      acc[cur._id.split("/")[1]] = cur.odo;

      return acc;
    }, {});

    const vssMap = vssForVins.reduce((acc, cur) => {
      acc[cur.chassis_no] = cur.document_date;

      return acc;
    }, {});

    const jobCardMap = jobCardVins.reduce((acc, cur) => {
      if (!acc[cur.vin]) acc[cur.vin] = [];

      acc[cur.vin].push(cur);

      return acc;
    }, {});

    let result = [];

    // Process individual VIN data

    for (let item of vehiclesList) {
      if (!vDDMap[item.dataValues.vin.slice(3)]) continue;

      let curObject = {
        vin: item.dataValues.vin.slice(3),

        reg_number: item.dataValues.vehicle_reg_number,

        odo: vDDMap[item.dataValues.vin.slice(3)] || 0,

        sold_date: vssMap[item.dataValues.vin.slice(3)] || "No date",

        "First Free Service done": "NO",

        "Second Free Service done": "NO",

        "Third Free Service done": "NO",

        "Fourth Free Service done": "NO",
      };

      // Check if job cards exist for the VIN and update curObject accordingly

      const jobCards = jobCardMap[item.dataValues.vin.slice(3)] || [];

      jobCards.forEach((jobCard) => {
        if (jobCard.repair_type === "First Free Service") {
          curObject["First Free Service done"] = "YES";
        } else if (jobCard.repair_type === "Second Free Service") {
          curObject["Second Free Service done"] = "YES";
        } else if (jobCard.repair_type === "Third Free Service") {
          curObject["Third Free Service done"] = "YES";
        } else if (jobCard.repair_type === "Fourth Free Service") {
          curObject["Fourth Free Service done"] = "YES";
        }
      });

      result.push(curObject);
    }

    return res.json({
      status: true,

      code: 200,

      values: result,
    });
  } catch (error) {
    console.log(error, "err");

    return res.json({
      status: false,

      code: 500,

      values: "Internal Server Error",
    });
  }
};


const vehicleDetailService=async(req,res)=>{
  try {
    await connection(url);
    await sequelize.sync();
    const {fleet}=req.body;
    let vehiclesQuery= await sequelize.query(`select distinct veh.VIN as vin,
    veh.VehicleRegNo,
    GROUP_CONCAT(DISTINCT cl.ClientFullName SEPARATOR ',') as name from Client cl 
    join ClientVehicle cv on cl.cid = cv.cid 
    join Vehicle veh on cv.vid = veh.vid 
    where cl.ClientFullName='${fleet}' and deleteVehicleStatus=0 and 
    (veh.vin like 'mq/MD9%' or veh.vin like 'mq/P6R%' ) group by veh.vin`);
    let vehicleObjectArray={}
    const vinsList=vehiclesQuery[0].map(i=>{
      vehicleObjectArray[i.vin]={VehicleRegNo:i['VehicleRegNo'],VIN:i.vin.slice(3)}
      return i.vin
    })
    console.log(vinsList.length)
    const vinsListStr=vinsList.map(i=>i.slice(3))
    const todayDate=moment().format("YYYY-MM-DD")
    const lastfifteenthDate=moment().subtract(15,'days').format("YYYY-MM-DD")
    let DistanceQuery=await VehicleDailyData.aggregate([
      {
        $match:{
          topic:{
            $in:vinsList
          },
          x78:'Running'
        }
      },
      {
        $facet:{
          vehicleDistance:[
            {
              $match:{
                date:{
                  $gte:lastfifteenthDate,
                  $lte:todayDate
                },
                x12:{$gte:0}
              }
            },
            {
              $group:{
                _id:'$topic',
                distance:{
                  $sum:'$x12'
                },
                date:{$last:'$date'}
              }
            }
          ],
          lastPingedDate:[
            {$match:{
              date:{$gte:"2021-01-01",$lte:todayDate}
            }},
            {
              $group:{
                _id:'$topic',
                lastPingedDate:{
                  $last:'$date'
                },
                lastOdo:{
                  $last:'$x11'
                },
                lastLocation:{
                  $last:"$x59"
                }
              }
            }
          ]
        }
      }
    ])
    let vehicleDistance=DistanceQuery[0]['vehicleDistance']
    let lastPingedDate=DistanceQuery[0]['lastPingedDate']
    vehicleDistance.map(i=>vehicleObjectArray[i._id]={...vehicleObjectArray[i._id],...i})
    lastPingedDate.map(i=>{
      vehicleObjectArray[i._id]={...vehicleObjectArray[i._id],...i}
    })
    let vehicleDailyDataQuery=await AplJobCards.aggregate([
      {
        $match: {
          vin: {
            $in: vinsListStr
          },
          // part_description: {
          //   $in: [
          //     "Paid Service AMC",
          //     "Paid Service Non AMC"
          //   ]
          // }
          $expr: {
            $cond: {
              if: { $eq: ["$repair_type", "Paid"] },
              then: {
                $in: [
                  "$part_description",
                  [
                    "Paid Service AMC",
                    "Paid Service Non AMC"
                  ]
                ]
              },
              else: true
            }
          }
        }
      },
      // for paid service
      // {
      //   $group: {
      //     _id: "$repair_order_no",
      //     vin: { $first: "$vin" },
      //     repair_order_date: {
      //       $first: "$repair_order_date"
      //     },
      //     repair_type: { $first: "$repair_type" },
      //     part_description: {
      //       $first: "$part_description"
      //     }
      //   }
      // },
    
      // forother services
    
      {
        $project: {
          _id: 0,
          repair_order_date: 1,
          repair_order_no: 1,
          repair_type: 1,
          vin: 1,
          part_description: 1
        }
      },
      {
        $group: {
          _id: {
            vin: "$vin",
            repair_type: "$repair_type",
            repair_order_no: "$repair_order_no"
          },
          repair_order_date: {
            $first: "$repair_order_date"
          },
          vin: { $first: "$vin" },
          repair_type: { $first: "$repair_type" },
          repair_order_no: {
            $first: "$repair_order_no"
          },
          part_description: {
            $first: "$part_description"
          }
        }
      },
      {
        $group: {
          _id: "$vin",
          "Pre Sales Repair Order": {
            $sum: {
              $cond: [
                {
                  $eq: [
                    "$repair_type",
                    "Pre Sales Repair Order"
                  ]
                },
                1,
                0
              ]
            }
          },
          "First Free Service": {
            $max: {
              $cond: [
                {
                  $eq: [
                    "$repair_type",
                    "First Free Service"
                  ]
                },
                "$repair_order_date",
                ""
              ]
            }
          },
          "Second Free Service": {
            $max: {
              $cond: [
                {
                  $eq: [
                    "$repair_type",
                    "Second Free Service"
                  ]
                },
                "$repair_order_date",
                ""
              ]
            }
          },
          "Fourth Free Service": {
            $max: {
              $cond: [
                {
                  $eq: [
                    "$repair_type",
                    "Fourth Free Service"
                  ]
                },
                "$repair_order_date",
                ""
              ]
            }
          },
          Expense: {
            $sum: {
              $cond: [
                { $eq: ["$repair_type", "Expense"] },
                1,
                0
              ]
            }
          },
          PDI: {
            $sum: {
              $cond: [
                { $eq: ["$repair_type", "PDI"] },
                1,
                0
              ]
            }
          },
          "Third Free Service": {
            $max: {
              $cond: [
                {
                  $eq: [
                    "$repair_type",
                    "Third Free Service"
                  ]
                },
                "$repair_order_date",
                ""
              ]
            }
          },
          "Accidental Paid": {
            $sum: {
              $cond: [
                {
                  $eq: [
                    "$repair_type",
                    "Accidental Paid"
                  ]
                },
                1,
                0
              ]
            }
          },
          "Running Repair": {
            $sum: {
              $cond: [
                {
                  $eq: [
                    "$repair_type",
                    "Running Repair"
                  ]
                },
                1,
                0
              ]
            }
          },
          Paid: {
            $sum: {
              $cond: [
                { $eq: ["$repair_type", "Paid"] },
                1,
                0
              ]
            }
          },
          "Accidental Insurance": {
            $sum: {
              $cond: [
                {
                  $eq: [
                    "$repair_type",
                    "Accidental Insurance"
                  ]
                },
                1,
                0
              ]
            }
          },
          Warranty: {
            $sum: {
              $cond: [
                { $eq: ["$repair_type", "Warranty"] },
                1,
                0
              ]
            }
          },
          paid_amc: {
            $sum: {
              $cond: [
                {
                  $eq: [
                    "$part_description",
                    "Paid Service AMC"
                  ]
                },
                1,
                0
              ]
            }
          },
          paid_non_amc: {
            $sum: {
              $cond: [
                {
                  $eq: [
                    "$part_description",
                    "Paid Service Non AMC"
                  ]
                },
                1,
                0
              ]
            }
          },
          paid_amc_dates: {
            $push: {
              $cond: [
                {
                  $eq: [
                    "$part_description",
                    "Paid Service AMC"
                  ]
                },
                "$repair_order_date",
                null
              ]
            }
          },
          paid_non_amc_dates: {
            $push: {
              $cond: [
                {
                  $eq: [
                    "$part_description",
                    "Paid Service Non AMC"
                  ]
                },
                "$repair_order_date",
                null
              ]
            }
          }
        }
      },
      {
        $project: {
          _id: 0,
          VIN: "$_id",
          "First Free Service": 1,
          "Second Free Service": 1,
          "Third Free Service": 1,
          "Fourth Free Service": 1,
          "Pre Sales Repair Order": 1,
    
          Expense: 1,
          PDI: 1,
    
          "Accidental Paid": 1,
          "Running Repair": 1,
          Paid: 1,
          "Accidental Insurance": 1,
          Warranty: 1,
          paid_amc: 1,
          paid_non_amc: 1,
          paid_amc_dates: {
            $filter: {
              input: "$paid_amc_dates",
              as: "date",
              cond: { $ne: ["$$date", null] }
            }
          },
          paid_non_amc_dates: {
            $filter: {
              input: "$paid_non_amc_dates",
              as: "date",
              cond: { $ne: ["$$date", null] }
            }
          }
        }
      },
      {
        $addFields: {
          paid_amc_dates: {
            $reduce: {
              input: "$paid_amc_dates",
              initialValue: "",
              in: {
                $cond: {
                  if: { $eq: ["$$value", ""] },
                  then: "$$this",
                  else: {
                    $concat: [
                      "$$value",
                      ", ",
                      "$$this"
                    ]
                  }
                }
              }
            }
          },
          paid_non_amc_dates: {
            $reduce: {
              input: "$paid_non_amc_dates",
              initialValue: "",
              in: {
                $cond: {
                  if: { $eq: ["$$value", ""] },
                  then: "$$this",
                  else: {
                    $concat: [
                      "$$value",
                      ", ",
                      "$$this"
                    ]
                  }
                }
              }
            }
          }
        }
      }
    ])
    console.log(vehicleDailyDataQuery.length)
    vehicleDailyDataQuery.map(i=>{
      // console.log(vehicleObjectArray['mq/'+i['VIN']]["lastLocation"],'location')
      vehicleObjectArray['mq/'+i['VIN']]=
    {
      "VIN":vehicleObjectArray['mq/'+i['VIN']]['VIN'],
      "VehicleRegNo":vehicleObjectArray['mq/'+i['VIN']]["VehicleRegNo"],
      "Distance(Last 15 days cummulative)":vehicleObjectArray['mq/'+i['VIN']]['distance']?vehicleObjectArray['mq/'+i['VIN']]['distance'].toFixed(2):0,
      "Latest location":vehicleObjectArray['mq/'+i['VIN']]["lastLocation"]  && vehicleObjectArray['mq/'+i['VIN']]["lastLocation"]!=="NA" ?vehicleObjectArray['mq/'+i['VIN']]["lastLocation"]["lat"]
      +","+vehicleObjectArray['mq/'+i['VIN']]["lastLocation"]['lng']:"",
      "Last pinged date":vehicleObjectArray['mq/'+i['VIN']]['lastPingedDate'],
      "Latest Odo":vehicleObjectArray['mq/'+i['VIN']]['lastOdo'],
      "Pre Sales Repair Order":i["Pre Sales Repair Order"],
      "Free Service 1":i["First Free Service"],
      "Free Service 2":i["Second Free Service"],
      "Free Service 3":i["Third Free Service"],
      "Free Service 4":i["Fourth Free Service"],
      "Paid AMC":i["paid_amc"],
      "Paid AMC Dates":i["paid_amc_dates"],
      "Paid Non AMC":i["paid_non_amc"],
      "Paid Non AMC Dates":i["paid_non_amc_dates"],
      "Pre Sales Repair Order":i["Pre Sales Repair Order"],
      "Expense":i["Expense"],
      "PDI":i["PDI"],
      "Accidental Paid":i['Accidental Paid'],
      "Running Repair":i['Running Repair'],
      "Accidental Insurance":i["Accidental Insurance"],
      "Warranty":i["Warranty"]
    }})

   let result=Object.values(vehicleObjectArray).map(i=>{
    if(i.hasOwnProperty("Pre Sales Repair Order")){
      return i
    }else{
      return {
        "VIN": i["VIN"],
        "VehicleRegNo": i["VehicleRegNo"],
        "Distance(Last 15 days cummulative)": i["distance"]?i["distance"].toFixed(2):0,
        "Latest location": i["lastLocation"]  && i["lastLocation"]!=="NA" ?
        i["lastLocation"]["lat"]
        +","+i["lastLocation"]['lng']:"",
        "Last pinged date": i["lastPingedDate"]?i["lastPingedDate"]:"NA",
        "Latest Odo": i["lastOdo"]?i["lastOdo"]:"NA",
        "Pre Sales Repair Order": "NA",
        "Free Service 1": "NA",
        "Free Service 2": "NA",
        "Free Service 3": "NA",
        "Free Service 4": "NA",
        "Paid AMC": "NA",
        "Paid AMC Dates": "NA",
        "Paid Non AMC": "NA",
        "Paid Non AMC Dates": "NA",
        "Expense": "NA",
        "PDI": "NA",
        "Accidental Paid": "NA",
        "Running Repair": "NA",
        "Accidental Insurance": "NA",
        "Warranty": "NA"
      }
    }
   })
   console.log(result.length);
    return res.json({
      status:true,
      code:200,
      data:result
    })
  } catch (error) {
    console.log(error);
    return res.json({
      status:false,
      code:500,
      error:error
    })
  }
  }

  const addFleetAnomalies = async (req, res) => {
    try {
      const { monthYear, vins } = req.body;
      console.log(req.body)
      const existingData = await FleetAnomalies.findOne({
        where: { monthYear },
        raw: true,
      });
  
      if (existingData) {
        let vinsArray = vins.split(",");
        console.log(vinsArray)
        let existingVins = existingData.vins.split(",");
  
        for (let vin of vinsArray) {
          if (existingVins.includes(vin)) {
            return res.json({
              status: false,
              error: `${vin.slice(3)} already exists!`,
            });
          }
          existingVins.push(vin);
        }
  
        console.log(existingVins)
  
        await FleetAnomalies.update(
          {
            monthYear,
            vins: existingVins.join(','),
            lastUpdated: getCurrentTime(),
          },
          { where: {monthYear} }
        );
  
        return res.json({
          status: true,
          message: "VINs added successfully",
        });
      } else {
        await FleetAnomalies.create({
          monthYear,
          vins,
          lastUpdated: getCurrentTime(),
        });
        return res.json({
          status: true,
          message: "VINs added successfully",
        });
      }
    } catch (error) {
      console.log(error);
      return res.json({
        status: false,
        error: "Internal Server Error",
      });
    }
  };
  
  const getFleetAnomalies = async (req, res) => {
    try {
      const data = await FleetAnomalies.findAll({ raw: true });
  
      return res.json({
        status: true,
        data: data,
      });
    } catch (error) {
      console.log(error);
      return res.json({
        status: false,
        error: "Internal Server Error",
      });
    }
  };

  const getVehicleFaultCodes = async (req, res)=>{
    try {
      const {vins, dates} = req.body;
      let data;
     

      if(vins && dates){
        let {startDate, endDate} = dates;
        data = await VehicleDailyData.aggregate([
          {
            $match: {
              topic: {
                $in: vins.map(v=>`mq/${v}`) // Array of VINs to match
              },
              date: {
                $gte: startDate, // Start date for the range
                $lte: endDate // End date for the range
              }
            }
          },
          {
            $lookup: {
              from: "vehicle_fault_codes",
              let: {
                vin: { $substr: ["$topic", 3, -1] },
                date: "$date"
              },
              pipeline: [
                {
                  $match: {
                    $expr: {
                      $and: [
                        { $eq: ["$VIN", "$$vin"] },
                        { $eq: ["$Date", "$$date"] }
                      ]
                    }
                  }
                }
              ],
              as: "vehicleFaultCodes"
            }
          },
          {
            $unwind: {
              path: "$vehicleFaultCodes"
            }
          },
          {
            $project: {
              _id: 0,
              VIN: "$vehicleFaultCodes.VIN",
              Date: "$vehicleFaultCodes.Date",
              distance: "$x12",
              start_odo: "$x10",
              end_odo: "$x11",
              battery_type: "$x96",
              efficiency: "$x35",
        
              CFC1_BGND_OR_FAULT:
                "$vehicleFaultCodes.CFC1_BGND_OR_FAULT",
              CFC1_BMS_FAULT:
                "$vehicleFaultCodes.CFC1_BMS_FAULT",
              CFC1_CHARGER_CONNECTED:
                "$vehicleFaultCodes.CFC1_CHARGER_CONNECTED",
              CFC1_CONTACTOR_STATE_INV:
                "$vehicleFaultCodes.CFC1_CONTACTOR_STATE_INV",
              CFC1_DCDC_FAULT:
                "$vehicleFaultCodes.CFC1_DCDC_FAULT",
              CFC1_FAULT_CODE_2:
                "$vehicleFaultCodes.CFC1_FAULT_CODE_2",
              CFC1_HARDWARE_FAULT:
                "$vehicleFaultCodes.CFC1_HARDWARE_FAULT",
              CFC1_IM_OVER_TEMP_FAULT:
                "$vehicleFaultCodes.CFC1_IM_OVER_TEMP_FAULT",
              CFC1_OVERRUN_FAULT:
                "$vehicleFaultCodes.CFC1_OVERRUN_FAULT",
              CFC1_OVER_CURRENT_FAULT:
                "$vehicleFaultCodes.CFC1_OVER_CURRENT_FAULT",
              CFC1_OVER_CURRENT_NEG_FAULT:
                "$vehicleFaultCodes.CFC1_OVER_CURRENT_NEG_FAULT",
              CFC1_OVER_VOLTAGE_FAULT:
                "$vehicleFaultCodes.CFC1_OVER_VOLTAGE_FAULT",
              CFC1_OVER_VOLTAGE_FAULT1:
                "$vehicleFaultCodes.CFC1_OVER_VOLTAGE_FAULT1",
              CFC1_PHASE_CURR_FAULT:
                "$vehicleFaultCodes.CFC1_PHASE_CURR_FAULT",
              CFC1_PRECHARGE_FAULT:
                "$vehicleFaultCodes.CFC1_PRECHARGE_FAULT",
              CFC1_UNDER_VOLTAGE_FAULT:
                "$vehicleFaultCodes.CFC1_UNDER_VOLTAGE_FAULT",
              CFC2_0x0800:
                "$vehicleFaultCodes.CFC2_0x0800",
              CFC2_0x1000:
                "$vehicleFaultCodes.CFC2_0x1000",
              CFC2_0x2000:
                "$vehicleFaultCodes.CFC2_0x2000",
              CFC2_0x4000:
                "$vehicleFaultCodes.CFC2_0x4000",
              CFC2_0x8000:
                "$vehicleFaultCodes.CFC2_0x8000",
              CFC2_BATTERY_PACK_WARNING:
                "$vehicleFaultCodes.CFC2_BATTERY_PACK_WARNING",
              CFC2_CALIBRATION_FAULT:
                "$vehicleFaultCodes.CFC2_CALIBRATION_FAULT",
              CFC2_DC_BUS_FAULT:
                "$vehicleFaultCodes.CFC2_DC_BUS_FAULT",
              CFC2_INPUT_VOLTAGE_FAULT:
                "$vehicleFaultCodes.CFC2_INPUT_VOLTAGE_FAULT",
              CFC2_OVER_LOAD_FAULT:
                "$vehicleFaultCodes.CFC2_OVER_LOAD_FAULT",
              CFC2_OVER_SPEED_FAULT:
                "$vehicleFaultCodes.CFC2_OVER_SPEED_FAULT",
              CFC2_PPR_CONF_FAULT:
                "$vehicleFaultCodes.CFC2_PPR_CONF_FAULT",
              CFC2_RNFB_FAULT:
                "$vehicleFaultCodes.CFC2_RNFB_FAULT",
              CFC2_SPEED_PHASE_FAULT:
                "$vehicleFaultCodes.CFC2_SPEED_PHASE_FAULT",
              CFC2_THROTTLE_FAULT:
                "$vehicleFaultCodes.CFC2_THROTTLE_FAULT",
              CFC2_VEHICLE_DISABLE:
                "$vehicleFaultCodes.CFC2_VEHICLE_DISABLE",
              VFC_0x0800: "$vehicleFaultCodes.VFC_0x0800",
              VFC_0x1000: "$vehicleFaultCodes.VFC_0x1000",
              VFC_0x2000: "$vehicleFaultCodes.VFC_0x2000",
              VFC_0x4000: "$vehicleFaultCodes.VFC_0x4000",
              VFC_0x8000: "$vehicleFaultCodes.VFC_0x8000",
              VFC_48V_TOPUP_STATUS:
                "$vehicleFaultCodes.VFC_48V_TOPUP_STATUS",
              VFC_BATTERY_12V_CHECK_HEALTH:
                "$vehicleFaultCodes.VFC_BATTERY_12V_CHECK_HEALTH",
              VFC_CALIB_FAULT:
                "$vehicleFaultCodes.VFC_CALIB_FAULT",
              VFC_CAN_RX_FAULT:
                "$vehicleFaultCodes.VFC_CAN_RX_FAULT",
              VFC_DISP_IMG_MISMATCH:
                "$vehicleFaultCodes.VFC_DISP_IMG_MISMATCH",
              VFC_FLASH_INIT_FAULT:
                "$vehicleFaultCodes.VFC_FLASH_INIT_FAULT",
              VFC_FLASH_READ_FAULT:
                "$vehicleFaultCodes.VFC_FLASH_READ_FAULT",
              VFC_GPRS_ATTACH_FAULT:
                "$vehicleFaultCodes.VFC_GPRS_ATTACH_FAULT",
              VFC_GPRS_NETWORK_FAULT:
                "$vehicleFaultCodes.VFC_GPRS_NETWORK_FAULT",
              VFC_GPS_RX_FAULT:
                "$vehicleFaultCodes.VFC_GPS_RX_FAULT",
              VFC_GSM_MODULE_LOWER_THRESHOLD:
                "$vehicleFaultCodes.VFC_GSM_MODULE_LOWER_THRESHOLD",
              VFC_GSM_RSP_FAULT:
                "$vehicleFaultCodes.VFC_GSM_RSP_FAULT",
              VFC_GSM_RX_FAULT:
                "$vehicleFaultCodes.VFC_GSM_RX_FAULT",
              VFC_GSM_SIGNAL_FAULT:
                "$vehicleFaultCodes.VFC_GSM_SIGNAL_FAULT",
              VFC_NETWORK_CONFIG_MISMATCH:
                "$vehicleFaultCodes.VFC_NETWORK_CONFIG_MISMATCH",
              VFC_RTC_FAULT:
                "$vehicleFaultCodes.VFC_RTC_FAULT",
              VFC_RTC_PREFETCH_FAILED:
                "$vehicleFaultCodes.VFC_RTC_PREFETCH_FAILED",
              VFC_SERVER_ACTIVE_FAULT:
                "$vehicleFaultCodes.VFC_SERVER_ACTIVE_FAULT",
              VFC_SERVER_DETACTH_FAULT:
                "$vehicleFaultCodes.VFC_SERVER_DETACTH_FAULT",
              VFC_SIM_DETECTION_FAULT:
                "$vehicleFaultCodes.VFC_SIM_DETECTION_FAULT",
              VFC_VDM_BMS_CAN_RX_FAULT:
                "$vehicleFaultCodes.VFC_VDM_BMS_CAN_RX_FAULT",
              VFC_VDM_BRAKE_OIL_LOW:
                "$vehicleFaultCodes.VFC_VDM_BRAKE_OIL_LOW",
              VFC_VDM_CHARGE_DETECT_STATUS:
                "$vehicleFaultCodes.VFC_VDM_CHARGE_DETECT_STATUS",
              VFC_VDM_SHUTDOWN_12V_LOW:
                "$vehicleFaultCodes.VFC_VDM_SHUTDOWN_12V_LOW",
              VFC_VDM_SHUTDOWN_GSM_RX:
                "$vehicleFaultCodes.VFC_VDM_SHUTDOWN_GSM_RX",
              VFC_VEHICLE_DISABLE_CMD:
                "$vehicleFaultCodes.VFC_VEHICLE_DISABLE_CMD",
              VFC_WAKE_OR_ALIVE_STATUS:
                "$vehicleFaultCodes.VFC_WAKE_OR_ALIVE_STATUS",
              created_date:
                "$vehicleFaultCodes.created_date"
            }
          }
        ])
      }
     

      if(!data.length) return res.json({
        status: false,
        error: "No Data"
      })

      return res.json({
        status: true,
        data
      })


    } catch (error) {
      console.log(error);
      return res.json({
        status: false,
        error: "Internal Server Error"
      })
    }
  }



  const getvehicleproductionInfo=async(req,res)=>{
    try {
      await sequelize.sync();
      let query1=await sequelize.query(`WITH RankedRecords AS (
SELECT
        *,
        ROW_NUMBER() OVER (PARTITION BY vin ORDER BY date DESC
        ) AS rn
    FROM
        vehicle_produced_status
        )
        SELECT
     vin,vehicleRegNo, date, produced_status, model, vehicle_type,year,month
FROM
    RankedRecords
WHERE
    rn = 1
    AND produced_status = 101`);
    let query2=await sequelize.query(`WITH RankedRecords AS (
SELECT
        *,
        ROW_NUMBER() OVER (PARTITION BY vin ORDER BY date DESC
        ) AS rn
    FROM
        vehicle_produced_status
        )
        SELECT
     vin,vehicleRegNo, date, produced_status, model, vehicle_type,year,month
FROM
    RankedRecords
WHERE
    rn = 1
    AND produced_status = 102`);


    let query3=await sequelize.query(`
      select  vin,vehicleRegNo, date, produced_status, model, vehicle_type,year,month
FROM vehicle_produced_status
      `)

    const totalData=[]
    query1[0].map(item=>totalData.push(item))
    query2[0].map(item=>totalData.push(item))

    return res.json({
      status:true,
      data:{
        "101Status":query1[0],
        "102Status":query2[0],
        // totalData:totalData
        totalData:query3[0]
      }
    })
    } catch (error) {
      console.log(error,'err')
      return res.json({
        status:false,
        code:500,
        data:"Internal Server error"
      })
    }
  }

  const getvehicleproductionInfoOverview=async(req,res)=>{
    try {
      console.log(req.body,"request body")
    let {startDate,endDate}=req.body;
    startDate=moment(startDate).format('YYYY-MM-DD');
    endDate=moment(endDate).format('YYYY-MM-DD');
    console.log(startDate,endDate,'dates')
    await sequelize.sync();
    let query1=await sequelize.query(`WITH RankedRecords AS (
SELECT
        *,
        ROW_NUMBER() OVER (PARTITION BY vin ORDER BY datetime DESC
        ) AS rn
    FROM
        vehicle_produced_status
        WHERE
        date BETWEEN '${startDate}' AND  '${endDate}' 
        )
        SELECT
     vin,vehicleRegNo, date, produced_status, model, vehicle_type,year,month
FROM
    RankedRecords
WHERE
    rn = 1
    AND produced_status = 101`);
    let query2=await sequelize.query(`WITH RankedRecords AS (
SELECT
        *,
        ROW_NUMBER() OVER (PARTITION BY vin ORDER BY datetime DESC
        ) AS rn
    FROM
        vehicle_produced_status
        WHERE
        date BETWEEN '${startDate}' AND  '${endDate}' 
        )
        SELECT
     vin,vehicleRegNo, date, produced_status, model, vehicle_type,year,month
FROM
    RankedRecords
WHERE
    rn = 1
    AND produced_status = 102`);
    let query3=await sequelize.query(`SELECT
     vin,vehicleRegNo, date, produced_status, model, vehicle_type,year,month from vehicle_produced_status WHERE
        date BETWEEN '${startDate}' AND  '${endDate}'`)
//     let query=await sequelize.query(`WITH RankedData AS (
//     SELECT
//         *,
//         ROW_NUMBER() OVER (PARTITION BY vin ORDER BY date DESC, produced_status DESC) AS initial_rn
//     FROM
//         vehicle_produced_status  
//     WHERE
//         date BETWEEN '${startDate}' AND '${endDate}'
// ),
// AlternatingStatus AS (
//     SELECT
//         *,
//         CASE
//             WHEN MOD(initial_rn, 2) = 1 THEN 101
//             ELSE 102
//         END AS alternating_status
//     FROM
//         RankedData
// )
// SELECT
//     *,
//     ROW_NUMBER() OVER (PARTITION BY vin ORDER BY date DESC, alternating_status DESC) AS rn
// FROM
//     AlternatingStatus 
// ORDER BY
//     vin, rn;
// `)
//format1 starts

    const totalData=[]
    query1[0].map(item=>totalData.push(item))
    query2[0].map(item=>totalData.push(item))

    console.log(query1[0].length,query2[0].length,query3[0].length)
    let data={
        "101Status":query1[0],
        "102Status":query2[0],
        totalData:totalData,
        fullData:query3[0]
      }
    //format 1 ends

    //format2 starts
    // const totalData=[],data1=[],data2=[],fullData=[]
    // query[0].map(item=>{
    //   if(item.rn==1 && item.produced_status==101){
    //     data1.push({
    //       vin:item.vin,
    //       vehicleRegNo:item.vehicleRegNo, 
    //       date:item.date, 
    //       produced_status:item.produced_status,
    //       model:item.model, 
    //       vehicle_type:item.vehicle_type,
    //       year:item.year,
    //       month:item.month
    //     })
    //   }else if(item.rn==1 && item.produced_status==102){
    //     data2.push({
    //       vin:item.vin,
    //       vehicleRegNo:item.vehicleRegNo, 
    //       date:item.date, 
    //       produced_status:item.produced_status,
    //       model:item.model, 
    //       vehicle_type:item.vehicle_type,
    //       year:item.year,
    //       month:item.month
    //     })
    //   }
    //   if(item.rn==1){
    //   totalData.push({
    //     vin:item.vin,
    //     vehicleRegNo:item.vehicleRegNo, 
    //     date:item.date, 
    //     produced_status:item.produced_status,
    //     model:item.model, 
    //     vehicle_type:item.vehicle_type,
    //     year:item.year,
    //     month:item.month
    //   })}

    //   fullData.push({
    //     vin:item.vin,
    //     vehicleRegNo:item.vehicleRegNo, 
    //     date:item.date, 
    //     produced_status:item.produced_status,
    //     model:item.model, 
    //     vehicle_type:item.vehicle_type,
    //     year:item.year,
    //     month:item.month
    //   })
    // })
    // let data={
    //     "101Status":data1,
    //     "102Status":data2,
    //     totalData:totalData,
    //     fullData:fullData
    //   }

    //   console.log(data1.length,data2.length,totalData.length,fullData.length)
    //format2 ends
    return res.json({
      status:true,
      data:data
    })
    } catch (error) {
      console.log(error,'err')
      return res.json({
        status:false,
        code:500,
        data:"Internal Server error"
      })
    }
  }

  const getFleetWiseDriveLogs = async (req, res)=>{
    try {
      
      const {fleet, startDate, endDate}= req.body;
      let vehiclesList,result;

      await connection(url);

      Client.belongsToMany(Vehicle, {
        through: ClientVehicle,
        foreignKey: "cid",
      });
      Vehicle.belongsToMany(Client, {
        through: ClientVehicle,
        foreignKey: "vid",
      });

      vehiclesList = await Vehicle.findAll({
        attributes: [
          ["VIN", "vin"],
          ["VehicleRegNo", "vehicle_reg_number"],
          "model",
          "SIMservicePrName",
          "network_type",
        ],
        where: {
          deleteVehicleStatus: 0,
          [Op.or]: [
            { VIN: { [Op.like]: "mq/MD9%" } },
            { VIN: { [Op.like]: "mq/P6R%" } },
          ],
        },
        nest: true,
        include: [
          {
            model: Client,
            attributes: [[sequelize.literal("TRIM(`clientCode`)"), "clientCode"]],
            through: {
              attributes: [],
            },
            where: {
              clientCode: {
                [Op.like]: `${fleet.trim()}`,
              },
            },
          },
        ],
      });
  
      if (!vehiclesList.length)
        return res.json({
          status: false,
          error: "No data",
        });

      let rawVINs = vehiclesList.map(v=>v.dataValues.vin);
  
      vehiclesList = vehiclesList.map((item) => ({
        vin: item.dataValues.vin.slice(3),
        vehicle_reg_number: item.dataValues.vehicle_reg_number,
        fleets: item["Clients"]
          .map((client) => client.dataValues.clientCode)
          .join(","),
        model: item.dataValues.model,
        SIMservicePrName: item.dataValues.SIMservicePrName,
        network_type: item.dataValues.network_type,
      }));

      const mongoData = await VehicleDailyData.aggregate( [
        {
          $match: {
            topic: {
              $in: rawVINs
            },
            date: {
              $gte: startDate,
              $lte: endDate
            }
          }
        },
        {
          $project: {
            _id: 0,
            topic: 1,
            date: 1,
            x78: 1,
            x12: 1
          }
        }
      ]);

      result = mongoData.reduce((acc,cur)=>{
        if(acc[cur.topic])
          acc[cur.topic].push(cur);
        else
          acc[cur.topic] = [cur];
      
        return acc;
      },{});

      let finalResult = Object.keys(result).map(vin=>{
        let returnData = {vin: vin.slice(3)};

        result[vin].forEach(d=>{
          returnData[d?.date] = d?.x78 === 'NoData' ? 'NA' : d?.x12
        });

        return returnData;

      });

      return res.json({
        status: true,
        data: finalResult
      })


    } catch (error) {
      console.log(error);
      return res.json({
        status:false,
        code:500,
        data:"Internal Server error"
      })
    }
  }

module.exports = {
  getAllVehicles,
  vehicleUsage,
  vehicleDateRangeUsage,
  vehicleChartData,
  anamolyData,
  fleetSegmentation,
  lastLocationData,
  monthlyBatteryHealthCard,
  vehicleServiceData,
  notPingedVehicles,
  notPingedVehiclesFleet,
  vehicleMoreInfo,
  vehicleLocator,
  customLocationDetails,
  dummy,
  fleetSegmentationMonthWise,
  vehicleSerial,
  fleetWiseBatteryHealthCard,
  fleetWiseBatteryHealthCardCustom,
  MonthWiseBatteryHealthCardBatteryGraph,
  MonthWiseBatteryHealthCardVinGraph,
  fleetWiseBatteryHealthCardCustomUpdated,
  lockedVehicles,
  fleetWiseBatteryHealthCardCustomUpdatedNewOne,
  vehicleSerialSegmentation,
  getVinSerialSelectValues,
  vinWiseBHC,
  applicationSeg,
  batteryvindata,
  getVehicleTypes,
  fleetSegmentationConfiguration,
  fleetSegmentationDriveScore,
  avgDriveScoreData,
  fleetSegmentationServiceLogs,
  fleetWisePdfData,
  vehicleDetailService,
  addFleetAnomalies,
  getFleetAnomalies,
  getVehicleFaultCodes,
  getvehicleproductionInfo,
  getvehicleproductionInfoOverview,
  getFleetWiseDriveLogs
};
