const sequelize = require("../../utils/sqldb");
const Vehicle = require("../../models/vehicle");
const { Sequelize, literal } = require("sequelize");
const moment = require("moment-timezone");
const fs = require("fs");
const csvParser = require("csv-parser");
const VehicleProductionStatus = require("../../models/vehicleProductionStatus");
const momentz=require("moment-timezone")

const insertVehicleProducedStatusMapper = {
  VIN: "vin",
  "Posting Date": "date",
  "Movement type": "produced_status",
  "Material Description": "vehicle_type",
  Order: "order_no",
  "Amt.in Loc.Cur. (WAERS)": "amount_loc",
  year: "year",
  month: "month",
  datetime: "datetime",
  date: "date",
};

const monthyear = (date) => {
  try {
    let arr = date.split("-");
    return {
      year: Number(arr[2]),
      month: Number(arr[1]),
      date: moment(date, "DD-MM-YYYY").format("YYYY-MM-DD"),
      datetime: moment(date, "DD-MM-YYYY").format("YYYY-MM-DD") + " 00:00:00",
    };
  } catch (error) {
    console.error("Error in monthyear function:", error.message, "Date:", date);
    throw error;
  }
};

const vehicleModels = {
  A: "ADI",
  B: "BHAI",
  N: "neEv",
  T: "TEZ",
  R: "RAHI",
};

const InsertVehicleProducedStatus1 = async (req, res) => {
  try {
    if (!req.file) {
      return res
        .status(400)
        .json({ status: false, code: 400, error: "No file uploaded" });
    }
    const stripBomStream = (await import("strip-bom-stream")).default;
    let fileRows = [];
    const uniqueRows = new Set();
    await sequelize.sync();
    fs.createReadStream(req.file.path)
      .pipe(stripBomStream())
      .pipe(csvParser())
      .on("data", (data) => {
        const rowKey = JSON.stringify(data);
        // Only add the row if it hasn't been seen before
        if (!uniqueRows.has(rowKey)) {
          uniqueRows.add(rowKey);
          fileRows.push({ ...data, ...monthyear(data["Posting Date"]) });
        }
      })
      .on("end", async () => {
        let vsqlReg = {},
          vinObject = {},
          AnamolyData = [];
        let vsqlData = await Vehicle.findAll({
          where: { deletevehicleStatus: 0, Immob_status: 1 },
          raw: true,
          nest: true,
          attributes: ["VIN", "VehicleRegNo"],
        });
        vsqlData.map((i) => (vsqlReg[i["VIN"].slice(3)] = i.VehicleRegNo));
        let bulkInsertArray = [];
        for (let i of fileRows) {
          const mappedData = Object.keys(
            insertVehicleProducedStatusMapper
          ).reduce((acc, key) => {
            const newKey = insertVehicleProducedStatusMapper[key];
            acc[newKey] = i[key];
            return acc;
          }, {});
          if (i["VIN"].startsWith("P6R")) {
            mappedData["model"] = vehicleModels[i["VIN"][4]];
          } else {
            mappedData["model"] = "neEv";
          }
          mappedData["VehicleRegNo"] = vsqlReg[mappedData["vin"]];
          let entryInDb = await VehicleProductionStatus.findOne({
            where: { vin: mappedData["vin"] },
            order: [["datetime", "DESC"]],
            raw: true,
          });
          let vin = mappedData["vin"];
          if (!entryInDb) {
            // vinObject[vin]=[mappedData];
            // bulkInsertArray.push(mappedData);
            console.log("Not Found new Entry");
          } else if (entryInDb) {
            if (mappedData["produced_status"] != entryInDb.produced_status) {
              mappedData["datetime"] = moment(mappedData["datetime"])
                .startOf("day")
                .format("YYYY-MM-DD HH:mm:ss");
            } else {
              mappedData["datetime"] = moment(mappedData["datetime"])
                .endOf("day")
                .format("YYYY-MM-DD HH:mm:ss");
            }
          }
          bulkInsertArray.push(mappedData);
          await VehicleProductionStatus.upsert(
            {
              vin: mappedData["vin"],
              model: mappedData["model"],
              vehicle_type: mappedData["vehicle_type"],
              amount_loc: mappedData["amount_loc"],
              VehicleRegNo: mappedData["VehicleRegNo"],
              year: mappedData["year"],
              month: mappedData["month"],
              datetime: mappedData["datetime"],
              produced_status: mappedData["produced_status"],
              date: mappedData["date"],
              order_no: mappedData["order_no"],
            },
            {
              updateOnDuplicate: [
                "model",
                "vehicle_type",
                "amount_loc",
                "VehicleRegNo",
                "year",
                "month",
                "datetime",
              ],
            }
          );
        }
        // await VehicleProductionStatus.bulkCreate(bulkInsertArray,
        //     {
        //         updateOnDuplicate:['model', 'vehicle_type', 'amount_loc', 'VehicleRegNo', 'year', 'month', 'datetime']
        //     }
        // );
        await fs.promises.unlink(req.file.path);
        return res.json({ status: true, data: bulkInsertArray });
      });
    // return res.status(200).json("Hellp");
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error" });
  }
};

const InsertVehicleProducedStatus2 = async (req, res) => {
  try {
    if (!req.file) {
      return res
        .status(400)
        .json({ status: false, code: 400, error: "No file uploaded" });
    }

    const stripBomStream = (await import("strip-bom-stream")).default;
    let fileRows = [];
    const uniqueRows = new Set();
    await sequelize.sync();

    fs.createReadStream(req.file.path)
      .pipe(stripBomStream())
      .pipe(csvParser())
      .on("data", (data) => {
        data.produced_status = data["Movement type"];

        const rowKey = JSON.stringify(data);
        if (!uniqueRows.has(rowKey)) {
          uniqueRows.add(rowKey);
          fileRows.push({ ...data, ...monthyear(data["Posting Date"]) });
        }
      })
      .on("end", async () => {
        let vsqlReg = {};
        let productionStatusMap = {};
        let bulkInsertArray = [];

        let vsqlData = await Vehicle.findAll({
          where: { deletevehicleStatus: 0, Immob_status: 1 },
          raw: true,
          nest: true,
          attributes: ["VIN", "VehicleRegNo"],
        });

        vsqlData.forEach((i) => {
          vsqlReg[i["VIN"].slice(3)] = i.VehicleRegNo;
        });

        let allProductionStatuses = await sequelize.query(
          `
          SELECT * FROM (
            SELECT vp.* FROM vehicle_produced_status vp
            JOIN (
              SELECT MAX(datetime) AS datetime, vin FROM vehicle_produced_status
              GROUP BY vin
            ) AS vh
            ON vh.vin = vp.vin AND vp.datetime = vh.datetime
          ) q;
          `,
          { type: sequelize.QueryTypes.SELECT }
        );

        allProductionStatuses.forEach((record) => {
          productionStatusMap[record.vin] = record;
        });

        fileRows.sort((a, b) => {
          if (a.VIN < b.VIN) return -1;
          if (a.VIN > b.VIN) return 1;
          return new Date(a.date) - new Date(b.date);
        });

        let fileDataGroupedByVin = fileRows.reduce((acc, row) => {
          let vin = row.VIN;
          if (!acc[vin]) acc[vin] = [];
          acc[vin].push(row);
          return acc;
        }, {});

        Object.keys(fileDataGroupedByVin).forEach((vin) => {
          let dbRecord = productionStatusMap[vin] || {
            produced_status: null,
            datetime: null,
          };
          let csvRecords = fileDataGroupedByVin[vin];

          let combinedRecords = [...csvRecords];

          combinedRecords.sort((a, b) => new Date(a.date) - new Date(b.date));

          let alternatingRecords = [];
          let currentStatus = dbRecord.produced_status === 101 ? 102 : 101;
          let currentDateTime = dbRecord.datetime
            ? new Date(dbRecord.datetime)
            : new Date("2024-01-01T00:00:00");

          let bool = false;
          combinedRecords.forEach((record, index) => {
            let recordDate = new Date(record.date);
            let startOfDay = new Date(recordDate.setHours(0, 0, 0, 0));
            let endOfDay = new Date(recordDate.setHours(23, 59, 59, 999));

            if (index === 0) {
              if (dbRecord.datetime) {
                if (dbRecord["produced_status"] === record["produced_status"]) {
                  currentDateTime = endOfDay;
                } else {
                  currentDateTime = startOfDay;
                }
              } else {
                currentDateTime = startOfDay;
              }
            } else {
              let prevRecord = combinedRecords[index - 1];
              if (record["date"] === prevRecord["date"]) {
                if (
                  record["produced_status"] !== prevRecord["produced_status"]
                ) {
                  if (bool) {
                    bool = false;
                    currentDateTime = startOfDay;
                  } else {
                    currentDateTime = endOfDay;
                  }
                } else {
                  currentDateTime = startOfDay;
                }
              } else {
                if (
                  record["produced_status"] === prevRecord["produced_status"]
                ) {
                  bool = true;
                  currentDateTime = endOfDay;
                } else {
                  currentDateTime = startOfDay;
                }
              }
            }

            record.datetime = moment(currentDateTime).format(
              "YYYY-MM-DD HH:mm:ss"
            );

            let mappedData = Object.keys(
              insertVehicleProducedStatusMapper
            ).reduce((acc, key) => {
              const newKey = insertVehicleProducedStatusMapper[key];
              acc[newKey] = record[key];
              return acc;
            }, {});

            mappedData["model"] = record["VIN"].startsWith("P6R")
              ? vehicleModels[record["VIN"][4]]
              : "neEv";
            mappedData["VehicleRegNo"] = vsqlReg[mappedData["vin"]];

            alternatingRecords.push(mappedData);

            // Alternate the status for the next record
            currentStatus = record.produced_status;
          });

          bulkInsertArray.push(...alternatingRecords);
        });

        await VehicleProductionStatus.bulkCreate(bulkInsertArray, {
          updateOnDuplicate: [
            "model",
            "vehicle_type",
            "amount_loc",
            "VehicleRegNo",
            "year",
            "month",
            "datetime",
            "produced_status",
          ],
        });

        await fs.promises.unlink(req.file.path);
        return res.json({ status: true, data: bulkInsertArray });
      });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error" });
  }
};

async function fileExists(filePath) {
  try {
    await fs.promises.access(filePath);
    return true;
  } catch {
    return false;
  }
}
const InsertVehicleProducedStatusNew = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ status: false, code: 400, error: "No file uploaded" });
    }

    const stripBomStream = (await import("strip-bom-stream")).default;
    let fileRows = [];
    const uniqueRows = new Set();
    await sequelize.sync();
    let errorOccurred = false;
    let responseSent = false;

    const sendResponse = (res, statusCode, message, filePath, status) => {
      if (responseSent) return;
      responseSent = true;
      if (filePath && fileExists(filePath)) {
        fs.promises.unlink(filePath).catch((err) => console.error("Error deleting file:", err.message));
      }
      res.status(statusCode).json({ status: status, data: message });
    };

    fs.createReadStream(req.file.path)
      .pipe(stripBomStream())
      .pipe(csvParser())
      .on("data", async (data) => {
        if (errorOccurred) {
          return;
        }

        try {
          data.produced_status = data['Movement type'];
          const rowKey = JSON.stringify(data);
          if (!uniqueRows.has(rowKey)) {
            uniqueRows.add(rowKey);
            fileRows.push({ ...data, ...monthyear(data["Posting Date"]) });
          }
        } catch (error) {
          errorOccurred = true;
          sendResponse(res, 400, "Invalid csv file", req.file.path, false);
          console.error("Data processing error:", error.message, "Data:", data);
        }
      })
      .on("end", async () => {
        if (errorOccurred || responseSent) {
          return;
        }

        try {
          let vsqlReg = {};
          let productionStatusMap = {};
          let bulkInsertArray = [];

          let vsqlData = await Vehicle.findAll({
            where: { deletevehicleStatus: 0, Immob_status: 1 },
            raw: true,
            nest: true,
            attributes: ["VIN", "VehicleRegNo"],
          });

          vsqlData.forEach((i) => {
            vsqlReg[i["VIN"].slice(3)] = i.VehicleRegNo;
          });

          let allProductionStatuses = await sequelize.query(
            `
            SELECT * FROM (
              SELECT vp.* FROM vehicle_produced_status vp
              JOIN (
                SELECT MAX(datetime) AS datetime, vin FROM vehicle_produced_status
                GROUP BY vin
              ) AS vh
              ON vh.vin = vp.vin AND vp.datetime = vh.datetime
            ) q;
            `,
            { type: sequelize.QueryTypes.SELECT }
          );

          allProductionStatuses.forEach((record) => {
            productionStatusMap[record.vin] = record;
          });

          fileRows.sort((a, b) => {
            if (a.VIN < b.VIN) return -1;
            if (a.VIN > b.VIN) return 1;
            return new Date(a.date) - new Date(b.date);
          });

          let fileDataGroupedByVin = fileRows.reduce((acc, row) => {
            let vin = row.VIN;
            if (!acc[vin]) acc[vin] = [];
            acc[vin].push(row);
            return acc;
          }, {});

          Object.keys(fileDataGroupedByVin).forEach((vin) => {
            let dbRecord = productionStatusMap[vin] || { produced_status: null, datetime: null };
            let csvRecords = fileDataGroupedByVin[vin];

            let combinedRecords = [...csvRecords];
            combinedRecords.sort((a, b) => new Date(a.date) - new Date(b.date));

            let alternatingRecords = [];
            let currentStatus = dbRecord.produced_status === 101 ? 102 : 101;
            let currentDateTime = dbRecord.datetime ? new Date(dbRecord.datetime) : new Date('2024-01-01T00:00:00');
            let dateFlag = {};
            let lastEndOfDayStatus = dbRecord.produced_status;

            combinedRecords.forEach((record, index) => {
              let recordDate = new Date(record.date);
              let dateString = recordDate.toISOString().split('T')[0];
              let startOfDay = moment.tz(`${dateString} 00:00:00`, "Asia/Kolkata").toDate();
              let endOfDay = moment.tz(`${dateString} 23:59:59`, "Asia/Kolkata").toDate();

              if (!dateFlag[dateString]) {
                dateFlag[dateString] = { startAssigned: false, endAssigned: false };
              }

              if (index === 0) {
                if (dbRecord.datetime) {
                  let dbProducedStatus = parseInt(dbRecord.produced_status.toString().trim(), 10);
                  let recordProducedStatus = parseInt(record.produced_status.toString().trim(), 10);

                  if (dbProducedStatus === recordProducedStatus) {
                    currentDateTime = endOfDay;
                    dateFlag[dateString].endAssigned = true;
                    lastEndOfDayStatus = record.produced_status;
                  } else {
                    currentDateTime = startOfDay;
                    dateFlag[dateString].startAssigned = true;
                  }
                } else {
                  currentDateTime = startOfDay;
                  dateFlag[dateString].startAssigned = true;
                }
              } else {
                let prevDateString = new Date(combinedRecords[index - 1].date).toISOString().split('T')[0];
                if (dateString !== prevDateString) {
                  if (dateFlag[prevDateString] && dateFlag[prevDateString].startAssigned && dateFlag[prevDateString].endAssigned) {
                    currentStatus = lastEndOfDayStatus;
                  }
                }

                if (record.produced_status != currentStatus) {
                  if (!dateFlag[dateString].startAssigned) {
                    currentDateTime = startOfDay;
                    dateFlag[dateString].startAssigned = true;
                  } else {
                    currentDateTime = endOfDay;
                    dateFlag[dateString].endAssigned = true;
                    lastEndOfDayStatus = record.produced_status;
                  }
                } else {
                  if (!dateFlag[dateString].endAssigned) {
                    currentDateTime = endOfDay;
                    dateFlag[dateString].endAssigned = true;
                    lastEndOfDayStatus = record.produced_status;
                  } else {
                    currentDateTime = startOfDay;
                    dateFlag[dateString].startAssigned = true;
                  }
                }
              }
              //for server
              record.datetime =momentz.tz(currentDateTime, "Asia/Kolkata").utc().format("YYYY-MM-DD HH:mm:ss");
              //for local
              // record.datetime = moment.tz(currentDateTime, "Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
              // moment.tz(currentDateTime, 'YYYY-MM-DD HH:mm:ss', 'Asia/Kolkata')
              // console.log("Final datetime for record:", record.datetime); // Debugging log

              let mappedData = Object.keys(insertVehicleProducedStatusMapper).reduce((acc, key) => {
                const newKey = insertVehicleProducedStatusMapper[key];
                acc[newKey] = record[key];
                return acc;
              }, {});

              mappedData["model"] = record["VIN"].startsWith("P6R") ? vehicleModels[record["VIN"][4]] : "neEv";
              mappedData["VehicleRegNo"] = vsqlReg[mappedData["vin"]];

              alternatingRecords.push(mappedData);

              currentStatus = record.produced_status;
            });

            bulkInsertArray.push(...alternatingRecords);
          });

          await VehicleProductionStatus.bulkCreate(bulkInsertArray, {
            updateOnDuplicate: ['model', 'vehicle_type', 'amount_loc', 'VehicleRegNo', 'year', 'month', 'datetime', 'produced_status'],
          });

          sendResponse(res, 200, { status: true, data: bulkInsertArray }, req.file.path, true);

        } catch (error) {
          console.error("Error processing file:", error.message);
          sendResponse(res, 500, "Server error", req.file.path, false);
        }
      });
  } catch (error) {
    console.error(error);
    if (req.file && req.file.path) {
      await fs.promises.unlink(req.file.path);
    }
    res.status(500).json({ status: false, message: "Server error" });
  }
};


const InsertVehicleProducedStatus = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ status: false, code: 400, error: "No file uploaded" });
    }

    const stripBomStream = (await import("strip-bom-stream")).default;
    let fileRows = [];
    const uniqueRows = new Set();
    await sequelize.sync();
    let errorOccurred = false;
    let responseSent = false;

    const sendResponse = (res, statusCode, message, filePath, status) => {
      if (responseSent) return;
      responseSent = true;
      if (filePath && fileExists(filePath)) {
        fs.promises.unlink(filePath).catch((err) => console.error("Error deleting file:", err.message));
      }
      res.status(statusCode).json({ status: status, data: message });
    };

    fs.createReadStream(req.file.path)
      .pipe(stripBomStream())
      .pipe(csvParser())
      .on("data", async (data) => {
        if (errorOccurred) {
          return;
        }

        try {
          data.produced_status = data['Movement type'];
          const rowKey = JSON.stringify(data);
          if (!uniqueRows.has(rowKey)) {
            uniqueRows.add(rowKey);
            fileRows.push({ ...data, ...monthyear(data["Posting Date"]) });
          }
        } catch (error) {
          errorOccurred = true;
          sendResponse(res, 400, "Invalid csv file", req.file.path, false);
          console.error("Data processing error:", error.message, "Data:", data);
        }
      })
      .on("end", async () => {
        if (errorOccurred || responseSent) {
          return;
        }

        try {
          let vsqlReg = {};
          let productionStatusMap = {};
          let bulkInsertArray = [];
          let anamolyData=[];

          let vsqlData = await Vehicle.findAll({
            where: { deletevehicleStatus: 0, Immob_status: 1 },
            raw: true,
            nest: true,
            attributes: ["VIN", "VehicleRegNo"],
          });

          vsqlData.forEach((i) => {
            vsqlReg[i["VIN"].slice(3)] = i.VehicleRegNo;
          });

          let allProductionStatuses = await sequelize.query(
            `
            SELECT * FROM (
              SELECT vp.* FROM vehicle_produced_status vp
              JOIN (
                SELECT MAX(datetime) AS datetime, vin FROM vehicle_produced_status
                GROUP BY vin
              ) AS vh
              ON vh.vin = vp.vin AND vp.datetime = vh.datetime
            ) q;
            `,
            { type: sequelize.QueryTypes.SELECT }
          );

          allProductionStatuses.forEach((record) => {
            productionStatusMap[record.vin] = record;
          });

          fileRows.sort((a, b) => {
            if (a.VIN < b.VIN) return -1;
            if (a.VIN > b.VIN) return 1;
            return new Date(a.date) - new Date(b.date);
          });

          let fileDataGroupedByVin = fileRows.reduce((acc, row) => {
            let vin = row.VIN;
            if (!acc[vin]) acc[vin] = [];
            acc[vin].push(row);
            return acc;
          }, {});

          // Fetch existing records to avoid duplicates
          let existingRecords = await VehicleProductionStatus.findAll({
            where: {
              vin: Object.keys(fileDataGroupedByVin),
              // datetime: {
              //   [Sequelize.Op.between]: [
              //     moment().startOf('day').toDate(),
              //     moment().endOf('day').toDate()
              //   ]
              // }
            },
            attributes: ['vin', 'produced_status', 'date', 'datetime']
          });

          let existingRecordsMap = existingRecords.reduce((map, record) => {
            let key = `${record.vin}-${record.produced_status}-${record.date}`;
            map[key] = true;
            return map;
          }, {});

          // console.log(existingRecordsMap,'existingRecordsMap')

          Object.keys(fileDataGroupedByVin).forEach((vin) => {
            let dbRecord = productionStatusMap[vin] || { produced_status: null, datetime: null };
            let csvRecords = fileDataGroupedByVin[vin];

            let combinedRecords = [...csvRecords];
            combinedRecords.sort((a, b) => new Date(a.date) - new Date(b.date));

            let alternatingRecords = [];
            let currentStatus = dbRecord.produced_status === 101 ? 102 : 101;
            let currentDateTime = dbRecord.datetime ? new Date(dbRecord.datetime) : new Date('2024-01-01T00:00:00');
            let dateFlag = {};
            let lastEndOfDayStatus = dbRecord.produced_status;

            combinedRecords.forEach((record, index) => {
              let recordDate = new Date(record.date);
              let dateString = recordDate.toISOString().split('T')[0];
              let startOfDay = moment.tz(`${dateString} 00:00:00`, "Asia/Kolkata").toDate();
              let endOfDay = moment.tz(`${dateString} 23:59:59`, "Asia/Kolkata").toDate();

              if (!dateFlag[dateString]) {
                dateFlag[dateString] = { startAssigned: false, endAssigned: false };
              }

              if (index === 0) {
                if (dbRecord.datetime) {
                  let dbProducedStatus = parseInt(dbRecord.produced_status.toString().trim(), 10);
                  let recordProducedStatus = parseInt(record.produced_status.toString().trim(), 10);

                  if (dbProducedStatus === recordProducedStatus) {
                    currentDateTime = endOfDay;
                    dateFlag[dateString].endAssigned = true;
                    lastEndOfDayStatus = record.produced_status;
                  } else {
                    if(moment(dbRecord.datetime).format('HH:mm:ss') === '00:00:00'){
                      console.log(dbRecord.datetime,'datetime index 0  same index bt change assign end of day')
                      currentDateTime = endOfDay;
                      dateFlag[dateString].endAssigned = true;
                      lastEndOfDayStatus = record.produced_status;
                    }else{
                      console.log(dbRecord.datetime,'datetime index 0  same index bt change assign start of day')
                    currentDateTime = startOfDay;
                    dateFlag[dateString].startAssigned = true;
                    }
                  }
                } else {
                  currentDateTime = startOfDay;
                  dateFlag[dateString].startAssigned = true;
                }
              } else {
                let prevDateString = new Date(combinedRecords[index - 1].date).toISOString().split('T')[0];
                if (dateString !== prevDateString) {
                  if (dateFlag[prevDateString] && dateFlag[prevDateString].startAssigned && dateFlag[prevDateString].endAssigned) {
                    currentStatus = lastEndOfDayStatus;
                  }
                }

                if (record.produced_status != currentStatus) {
                  if (!dateFlag[dateString].startAssigned) {
                    currentDateTime = startOfDay;
                    dateFlag[dateString].startAssigned = true;
                  } else {
                    currentDateTime = endOfDay;
                    dateFlag[dateString].endAssigned = true;
                    lastEndOfDayStatus = record.produced_status;
                  }
                } else {
                  if (!dateFlag[dateString].endAssigned) {
                    currentDateTime = endOfDay;
                    dateFlag[dateString].endAssigned = true;
                    lastEndOfDayStatus = record.produced_status;
                  } else {
                    currentDateTime = startOfDay;
                    dateFlag[dateString].startAssigned = true;
                  }
                }
              }

               //for server
               record.datetime =momentz.tz(currentDateTime, "Asia/Kolkata").utc().format("YYYY-MM-DD HH:mm:ss");
               //for local
              //  record.datetime = moment.tz(currentDateTime, "Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
              let mappedData = Object.keys(insertVehicleProducedStatusMapper).reduce((acc, key) => {
                const newKey = insertVehicleProducedStatusMapper[key];
                acc[newKey] = record[key];
                return acc;
              }, {});
              mappedData["model"] = record["VIN"].startsWith("P6R") ? vehicleModels[record["VIN"][4]] : "neEv";
              mappedData["VehicleRegNo"] = vsqlReg[mappedData["vin"]];
              let recordKey = `${record.VIN}-${record.produced_status}-${record.date}`;
              // console.log(recordKey,'recordKey')
              if (!existingRecordsMap[recordKey]) {
                alternatingRecords.push(mappedData);
                existingRecordsMap[recordKey] = true;
              }else{
                anamolyData.push(mappedData);
                // console.log(recordKey,'already exiting')
              }
              currentStatus = record.produced_status;
            });
            bulkInsertArray.push(...alternatingRecords);
          });

          await VehicleProductionStatus.bulkCreate(bulkInsertArray, {
            updateOnDuplicate: ['model', 'vehicle_type', 'amount_loc', 'VehicleRegNo', 'year', 'month', 'datetime', 'produced_status'],
          });

          sendResponse(res, 200, { data: bulkInsertArray ,anamolyData:anamolyData}, req.file.path, true);

        } catch (error) {
          console.error("Error processing file:", error.message);
          sendResponse(res, 500, "Server error", req.file.path, false);
        }
      });
  } catch (error) {
    console.error(error);
    if (req.file && req.file.path) {
      await fs.promises.unlink(req.file.path);
    }
    res.status(500).json({ status: false, message: "Server error" });
  }
};

module.exports = { InsertVehicleProducedStatus };
