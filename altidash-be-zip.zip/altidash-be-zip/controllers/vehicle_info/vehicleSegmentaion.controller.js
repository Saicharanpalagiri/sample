const mongoose = require("mongoose");
const { response } = require("express");
const Vehicle = require("../../models/vehicle");
const sequelize = require("../../utils/sqldb");
const VehicleDailyData = require("../../models/vehicleDailyData");
const moment = require("moment");
const { Op } = require("sequelize");
const Client = require("../../models/client");
const ClientVehicle = require("../../models/client-vehicle");
const VehicleSaleStatement = require("../../models/VehicleSaleStatement");

connection = (url) => {
  mongoose.connect(url, { useNewUrlParser: true });
};

const url =
  "mongodb+srv://alti-admin-prod:APL2023ADMIN@mqtt-production.iqeii.mongodb.net/mqttDatabase_aplmq";

const vehicleSegmentation = async (req, res) => {
  let result = {
    total_vehicles: null,
    yesterdayvehicles: null,
    TotalDistance1: null,
    TotalDistance2: null,
    TotalDistance3: null,
    top_three_distance: null,
    top_three_odo: null,
  };
  const date = new Date();
  let yesterday = moment(
    new Date(date.getFullYear(), date.getMonth(), date.getDate() - 1)
  ).format("YYYY-MM-DD");
  const day_before_yesterday = moment(
    new Date(date.getFullYear(), date.getMonth(), date.getDate() - 2)
  ).format("YYYY-MM-DD");
  const day_2before_yesterday = moment(
    new Date(date.getFullYear(), date.getMonth(), date.getDate() - 3)
  ).format("YYYY-MM-DD");

  let modifyItem = {
    vin: "VIN",
    vehicle_reg_number: "VehicleRegNo",
  };

  let sequelizeRegex = {
    starts_with: function (str, item) {
      return item === "VIN" && !str.includes("mq/")
        ? `mq/${str.toUpperCase()}%`
        : `${str.toUpperCase()}%`;
    },
    ends_with: function (str) {
      return `%${str.toUpperCase()}`;
    },
    contains: function (str) {
      return `%${str.toUpperCase()}%`;
    },
  };

  let mongoRegex = {
    starts_with: function (str, item) {
      return item === "VIN" && !str.includes("mq/")
        ? new RegExp(`^mq/${str.toUpperCase()}`)
        : new RegExp(`^${str.toUpperCase()}`);
    },
    ends_with: function (str) {
      return new RegExp(`${str.toUpperCase()}$`);
    },
    contains: function (str) {
      return new RegExp(`.*${str.toUpperCase()}.*`);
    },
  };

  await connection(url);

  const computeSegmentation = async (item, parameter, method) => {
    let vehiclesList,
      yesterdayvehicles,
      totalDistances,
      TotalDistance1,
      TotalDistance2,
      TotalDistance3,
      top_three_distance,
      top_three_odo;

    let sequelizeParameter = sequelizeRegex[method](parameter, item);
    let mongoParameter = mongoRegex[method](parameter, item);

    let mongoKey = item === "VIN" ? "topic" : "VehicleRegNo" && "x1";

    // total vehicles
    vehiclesList = await Vehicle.findAll({
      attributes: ["VIN", "VehicleRegNo", "lastDataSentAt"],
      where: {
        deleteVehicleStatus: 0,
        [Op.or]: [
          { VIN: { [Op.like]: "mq/MD9%" } },
          { VIN: { [Op.like]: "mq/P6R%" } },
        ],
        [item]: {
          [Op.like]: sequelizeParameter,
        },
      },
      nest: true,
      include: [
        {
          model: Client,
          attributes: ["clientCode"],
          through: { attributes: [] },
        },
      ],
    });

    vehiclesList = vehiclesList.map((item) => ({
      vin: item.dataValues.VIN.slice(3),
      reg_no: item.dataValues.VehicleRegNo,
      lastPinged: item.dataValues.lastDataSentAt,
      fleets: item["Clients"]
        .map((client) => client.dataValues.clientCode)
        .join(","),
    }));

    result.total_vehicles = vehiclesList;

    //yesterday driven vehicles

    yesterdayvehicles = await VehicleDailyData.aggregate([
      {
        $match: {
          date: yesterday,
          $or: [
            { topic: { $regex: /^mq\/MD9/ } },
            { topic: { $regex: /^mq\/P6R/ } },
          ],
          [mongoKey]: {
            $regex: mongoParameter,
          },
          x12: {
            $gt: 0,
            $lte: 500,
          },
          x13: {
            $lt: 70,
          },
          x14: {
            $lt: 70,
          },
        },
      },
      {
        $group: {
          _id: "$topic",
          vehicle_reg_number: { $last: "$x1" },
          date: { $last: "$date" },
        },
      },
    ]);
    yesterdayvehicles = yesterdayvehicles.map((item) => ({
      vin: item._id.slice(3),
      reg_no: item.vehicle_reg_number,
      Fleets:
        vehiclesList.find((vehicle) => vehicle.VIN === item._id) !== undefined
          ? vehiclesList.find((vehicle) => vehicle.VIN === item._id).Clients
          : "No data",
    }));

    result.yesterdayvehicles = yesterdayvehicles;

    totalDistances = await VehicleDailyData.aggregate([
      {
        $match: {
          date: {
            $in: [day_2before_yesterday, day_before_yesterday, yesterday],
          },
          $or: [
            { topic: { $regex: /^mq\/MD9/ } },
            { topic: { $regex: /^mq\/P6R/ } },
          ],
          [mongoKey]: {
            $regex: mongoParameter,
          },
          x12: {
            $gt: 0,
            $lte: 500,
          },
          x13: {
            $lt: 70,
          },
          x14: {
            $lt: 70,
          },
        },
      },
      {
        $group: {
          _id: "$date",
          totalDistance: { $sum: "$x12" },
        },
      },
    ]);

    //total distance yesterday

    TotalDistance1 =
      totalDistances.length === 3 ? totalDistances[2].totalDistance : 0;

    result.TotalDistance1 = TotalDistance1;

    //total distance day before yesterday

    TotalDistance2 =
      totalDistances.length === 3 ? totalDistances[1].totalDistance : 0;

    result.TotalDistance2 = TotalDistance2;

    //total distance 2 days before yesterday

    TotalDistance3 =
      totalDistances.length === 3 ? totalDistances[0].totalDistance : 0;

    result.TotalDistance3 = TotalDistance3;

    //top three distance

    top_three_distance = await VehicleDailyData.aggregate([
      {
        $match: {
          date: yesterday,
          $or: [
            { topic: { $regex: /^mq\/MD9/ } },
            { topic: { $regex: /^mq\/P6R/ } },
          ],
          [mongoKey]: {
            $regex: mongoParameter,
          },
          x12: {
            $gt: 0,
            $lte: 500,
          },
          x13: {
            $lt: 70,
          },
          x14: {
            $lt: 70,
          },
        },
      },
      {
        $sort: {
          x12: -1,
        },
      },
      {
        $limit: 3,
      },
    ]);
    top_three_distance = top_three_distance.map((item) => ({
      vin: item.topic.slice(3),
      reg_no: item.x1,
      name:
        vehiclesList.find((vehicle) => vehicle.VIN === item.topic) !== undefined
          ? vehiclesList.find((vehicle) => vehicle.VIN === item.topic).Clients
          : "No data",
      dist: Number(item.x12).toFixed(2),
      date: yesterday,
      odo: item.x11,
    }));

    result.top_three_distance = top_three_distance;

    //top three odo

    top_three_odo = await VehicleDailyData.aggregate([
      {
        $match: {
          date: yesterday,
          $or: [
            { topic: { $regex: /^mq\/MD9/ } },
            { topic: { $regex: /^mq\/P6R/ } },
          ],
          [mongoKey]: {
            $regex: mongoParameter,
          },
          x12: {
            $gt: 0,
            $lte: 500,
          },
          x13: {
            $lt: 70,
          },
          x14: {
            $lt: 70,
          },
        },
      },
      {
        $sort: {
          x11: -1,
        },
      },
      {
        $limit: 3,
      },
    ]);
    top_three_odo = top_three_odo.map((item) => ({
      vin: item.topic.slice(3),
      reg_no: item.x1,
      name:
        vehiclesList.find((vehicle) => vehicle.VIN === item.topic) !== undefined
          ? vehiclesList.find((vehicle) => vehicle.VIN === item.topic).Clients
          : "No data",
      dist: Number(item.x12).toFixed(2),
      date: yesterday,
      odo: item.x11,
    }));

    result.top_three_odo = top_three_odo;
  };
  Client.belongsToMany(Vehicle, { through: ClientVehicle, foreignKey: "cid" });
  Vehicle.belongsToMany(Client, { through: ClientVehicle, foreignKey: "vid" });
  try {
    await sequelize.sync();

    const { item, method, parameter } = req.body;

    await computeSegmentation(modifyItem[item], parameter, method);
    return res.json({ status: true, ...result });
  } catch (error) {
    console.log(error, "err");
    return res.json({
      status: false,
      code: 500,
      values: "Internal Server Error",
    });
  }
};

const soldDateSegmentation = async (req, res) => {
  let result = null;
  let vehiclesList;

  Client.belongsToMany(Vehicle, { through: ClientVehicle, foreignKey: "cid" });
  Vehicle.belongsToMany(Client, { through: ClientVehicle, foreignKey: "vid" });

  await connection(url);

  try {
    await sequelize.sync();

    const { startDate, endDate } = req.body;

    let segmentResult = await VehicleSaleStatement.aggregate([
      {
        $match: {
          document_date: {
            $gte: startDate,
            $lte: endDate,
          },
        },
      },
      {
        $lookup: {
          from: "vehicleDailyData",
          let: { localValue: { $concat: ["mq/", "$chassis_no"] } },
          pipeline: [
            {
              $match: {
                $expr: {
                  $eq: ["$topic", "$$localValue"],
                },
                x11: {
                  $gt: 0,
                },
                // x78: "Running"
                // x12: { $gt: 0 }
              },
            },

            {
              $sort: {
                x11: -1,
              },
            },
            {
              $limit: 1,
            },
            // Add more pipeline stages if needed
          ],
          as: "joinedData",
        },
      },
      {
        $project: {
          _id: 0,
          document_date: 1,
          "joinedData.topic": 1, // Include specific fields from the joined collection
          chassis_no: 1,
          "joinedData.x11": 1,
          "joinedData.date": 1,

          // Add more fields as needed
        },
      },
      {
        $group: {
          _id: "$chassis_no",
          document_date: { $first: "$document_date" },
          end_odo: { $first: "$joinedData.x11" },
          date: { $first: "$joinedData.date" },
        },
      },
    ]);

    if (!segmentResult.length) {
      return res.status(200).json({
        status: false,
        data: [],
      });
    }

    vehiclesList = await Vehicle.findAll({
      attributes: ["VIN", "VehicleRegNo"],
      where: {
        deleteVehicleStatus: 0,
        [Op.or]: [
          { VIN: { [Op.like]: "mq/MD9%" } },
          { VIN: { [Op.like]: "mq/P6R%" } },
        ],
        VIN: {
          [Op.in]: segmentResult.map((item) => "mq/" + item._id),
        },
      },
      nest: true,
      include: [
        {
          model: Client,
          attributes: ["clientCode"],
          through: { attributes: [] },
        },
      ],
    });

    result = vehiclesList.map((item) => ({
      vin: item.dataValues.VIN.slice(3),
      reg_no: item.dataValues.VehicleRegNo,
      fleets: item["Clients"]
        .map((client) => client.dataValues.clientCode)
        .join(","),
      sold_date:
        segmentResult.find((item1) => "mq/" + item1._id === item.VIN) !==
        undefined
          ? segmentResult.find((item1) => "mq/" + item1._id === item.VIN)
              .document_date
          : "No date",
      end_odo:
        segmentResult.find((item1) => "mq/" + item1._id === item.VIN) !==
          undefined &&
        segmentResult.find((item1) => "mq/" + item1._id === item.VIN).end_odo
          .length
          ? segmentResult.find((item1) => "mq/" + item1._id === item.VIN)
              .end_odo[0]
          : "No data",
      last_pinged:
        segmentResult.find((item1) => "mq/" + item1._id === item.VIN) !==
          undefined &&
        segmentResult.find((item1) => "mq/" + item1._id === item.VIN).date
          .length
          ? segmentResult.find((item1) => "mq/" + item1._id === item.VIN)
              .date[0]
          : "No data",
    }));

    return res.json({ status: true, result });
  } catch (error) {
    console.log(error, "err");
    return res.json({
      status: false,
      code: 500,
      values: "Internal Server Error",
    });
  }
};

const odoRangeSegmentation = async (req, res) => {
  let result = null;
  let vehiclesList;
  const date = new Date();
  let yesterday = moment(
    new Date(date.getFullYear(), date.getMonth(), date.getDate() - 1)
  ).format("YYYY-MM-DD");

  Client.belongsToMany(Vehicle, { through: ClientVehicle, foreignKey: "cid" });
  Vehicle.belongsToMany(Client, { through: ClientVehicle, foreignKey: "vid" });

  await connection(url);

  try {
    await sequelize.sync();

    const { startOdo, endOdo } = req.body;

    let segmentResult = await VehicleDailyData.aggregate([
      {
        $match: {
          x11: {
            $gte: 0,
          },
        },
      },
      {
        $sort: {
          date: -1, // Sort by date in descending order to get the latest dates first
        },
      },
      {
        $group: {
          _id: "$topic",
          end_odo: { $first: "$x11" },
          last_driven: { $first: "$date" },
        },
      },
      {
        $match: {
          end_odo: {
            $gte: startOdo,
            $lte: endOdo,
          },
        },
      },
    ]);

    if (!segmentResult.length) {
      return res.status(200).json({
        status: false,
        data: [],
      });
    }

    vehiclesList = await Vehicle.findAll({
      attributes: ["VIN", "VehicleRegNo"],
      where: {
        deleteVehicleStatus: 0,
        [Op.or]: [
          { VIN: { [Op.like]: "mq/MD9%" } },
          { VIN: { [Op.like]: "mq/P6R%" } },
        ],
        VIN: {
          [Op.in]: segmentResult.map((item) => item._id),
        },
      },
      nest: true,
      include: [
        {
          model: Client,
          attributes: ["clientCode"],
          through: { attributes: [] },
        },
      ],
    });

    result = vehiclesList.map((item) => ({
      vin: item.dataValues.VIN.slice(3),
      reg_no: item.dataValues.VehicleRegNo,
      fleets: item["Clients"]
        .map((client) => client.dataValues.clientCode)
        .join(","),

      end_odo:
        segmentResult.find((item1) => item1._id === item.VIN) !== undefined
          ? segmentResult.find((item1) => item1._id === item.VIN).end_odo
          : "No data",
      last_pinged:
        segmentResult.find((item1) => item1._id === item.VIN) !== undefined
          ? segmentResult.find((item1) => item1._id === item.VIN).last_driven
          : "No data",
    }));

    return res.json({ status: true, result });
  } catch (error) {
    console.log(error, "err");
    return res.json({
      status: false,
      code: 500,
      values: "Internal Server Error",
    });
  }
};

module.exports = {
  vehicleSegmentation,
  soldDateSegmentation,
  odoRangeSegmentation,
};
