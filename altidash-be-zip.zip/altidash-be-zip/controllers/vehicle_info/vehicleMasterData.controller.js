const httpStatus = require("http-status");
const AplJobCards = require("../../models/AplJobCards");
const Vehicle = require("../../models/vehicle");
const ClientVehicle = require("../../models/client-vehicle");
// const ApiError = require('../utils/ApiError');
const moment = require("moment");
const mongoose = require("mongoose");
const sequelize = require("../../utils/sqldb");
const Client = require("../../models/client");
const vehicleMasterData=require("../../models/VehicleMasterData");
const vehicleJobCard = require("../../models/vehicleJobCard");
const VehicleMasterData = require("../../models/VehicleMasterData");

connection = (url) => {
    mongoose.connect(url, { useNewUrlParser: true });
  };
const url ="mongodb+srv://alti-admin-prod:APL2023ADMIN@mqtt-production.iqeii.mongodb.net/mqttDatabase_aplmq";

    const vehicleTable = async (req, res) => {
        try {
          await connection(url);
          let data = await VehicleMasterData.aggregate([
            {$sort:{
                created_at:-1
            }},
            {
            $project:{
                _id:0
            },
          }])
          return res.json(data);
        } catch (error) {
          console.log(error);
          return res.json(error);
        }
};

module.exports = {vehicleTable};


