const VehicleSaleStatment = require("../../models/VehicleSaleStatement");
const Client = require("../../models/client");
const ClientVehicle = require("../../models/client-vehicle");
const dealerDetails = require("../../models/dealerDetails");
const Vehicle = require("../../models/vehicle");
const VehicleDailyData = require("../../models/vehicleDailyData");
const sequelize = require("../../utils/sqldb");
const VehicleFaultCodes =require("../../models/vehicleFaultCodes");
const moment=require('moment')

connection = (url) => {
  mongoose.connect(url, { useNewUrlParser: true });
};

const url =
  "mongodb+srv://alti-admin-prod:APL2023ADMIN@mqtt-production.iqeii.mongodb.net/mqttDatabase_aplmq";

const showVins = async (req, res) => {
  try {
    await sequelize.sync();
    const data =
      await sequelize.query(`select distinct v.VIN as vin,v.VehicleRegNo,vs.vinserialnum as VINSERIAL,v.model,v.SIMservicePrName,v.network_type,v.vehicleColor
      from Vehicle v 
      left join VinSerialNum vs on vs.vehicleId=v.vid
      where v.deleteVehicleStatus=0 and 
      (v.vin like 'mq/MD9%' or v.vin like 'mq/P6R%' ) group by v.vin`);
    const dealerVinsList = [];
    VehicleTableData = {};
    let dat = data[0];
    // dat=dat.sort((a,b)=>(a.VINSERIAL,b.VIN))
    dat.map((item) => {
      dealerVinsList.push({
        label: 
          item.vin.slice(3) + " | " + item.VehicleRegNo
          ,
        value: item.vin.slice(3),
      });
    });
    return res.json(dealerVinsList);
  } catch (error) {
    return res.json({ status: false, code: 500, data: error });
  }
};
const showVehicleVinInfo = async (req, res) => {
  try {
    Client.belongsToMany(Vehicle, {
      through: ClientVehicle,
      foreignKey: "cid",
    });
    Vehicle.belongsToMany(Client, {
      through: ClientVehicle,
      foreignKey: "vid",
    });

    await connection(url);

    let {vin} = req.params;
    let dVin;

    if (!vin.startsWith("mq/")) {
      vin = "mq/" + vin;
      dVin = req.body.vin;
    } else {
      dVin = vin.slice(3);
    }

    const fleetVehicle = await Vehicle.findOne({
      where: {
        VIN: vin,
      },
      nest: true,
      include: [
        {
          model: Client,
          attributes: ["clientCode"],
          through: { attributes: [] },
        },
      ],
    });

    const vehicleDailyData = await VehicleDailyData.find({
      $and: [
        { topic: fleetVehicle.VIN },
        { x78: "Running" },
        { x11: { $ne: 0 } },
      ],
    })
      .sort({ date: -1 })
      .limit(1)
      .select({
        x11: 1,
        x12: 1,
        topic: 1,
        date: 1,
        x96: 1,
        x78: 1,
        x101: 1,
        x85: 1,
        x86: 1,
      });

    console.log(dVin);

    const vehicleSaleStatement = await VehicleSaleStatment.findOne({
      chassis_no: dVin,
    });
    let dealer;

    if (vehicleSaleStatement) {
      dealer = await dealerDetails.findOne({
        dealer_code: vehicleSaleStatement.dealer_code,
      });
    }
    let result;
    if (fleetVehicle) {
      result = {
        Vin: fleetVehicle.VIN.slice(3),
        "Kit id": fleetVehicle.Kit_ID,
        "Vehicle reg number": fleetVehicle.VehicleRegNo,
        "Chassis number": fleetVehicle.chassisSrNo,
        "Vehicle display name": fleetVehicle.vDisplayName,
        "Display software version":
          vehicleDailyData && vehicleDailyData.length > 0
            ? vehicleDailyData[0].x86
            : null,
        "Controller software version":
          vehicleDailyData && vehicleDailyData.length > 0
            ? vehicleDailyData[0].x85
            : null,
        Fleet: fleetVehicle["Clients"]
          .map((client) => client.dataValues.clientCode)
          .join(","),
        "Sim service provider name": fleetVehicle.SIMservicePrName,
        "Network type": fleetVehicle.network_type,
        "IMEI number": fleetVehicle.imei_number,
        "Sim serial number": fleetVehicle.SIMsrNo,
        City:
          vehicleSaleStatement && vehicleSaleStatement.city
            ? vehicleSaleStatement.city
            : null,
        "Sold date":
          vehicleSaleStatement && vehicleSaleStatement.document_date
            ? vehicleSaleStatement.document_date
            : null,
        Customer:
          vehicleSaleStatement && vehicleSaleStatement.customer
            ? vehicleSaleStatement.customer
            : null,
        "Dealer name": dealer && dealer.dealer_name ? dealer.dealer_name : null,
        "Vehicle color":
          vehicleSaleStatement && vehicleSaleStatement.color
            ? vehicleSaleStatement.color
            : fleetVehicle.vehicleColor,
        "Battery capacity": fleetVehicle.batteryCapacity,
        Model: fleetVehicle.model,
        "Display hardware version": "Coming Soon",
        Odo:
          vehicleDailyData && vehicleDailyData.length > 0
            ? vehicleDailyData[0].x11
            : null,
        LastPingedDate:
          vehicleDailyData && vehicleDailyData.length > 0
            ? vehicleDailyData[0].date
            : null,
        "End charge cycle count":
          vehicleDailyData && vehicleDailyData.length > 0
            ? vehicleDailyData[0].x101
            : null,
        "Vehicle status":
          vehicleDailyData && vehicleDailyData.length > 0
            ? vehicleDailyData[0].x78
            : "None",
        "Manufacturing date":
          fleetVehicle.mfgyear && fleetVehicle.mfgmonth
            ? new Date(
                fleetVehicle.mfgyear,
                fleetVehicle.mfgmonth - 1,
                1
              ).toLocaleString("en-US", { month: "long" }) +
              " " +
              fleetVehicle.mfgyear
            : "No data",
      };
    }

    return res.json(result);
  } catch (error) {
    console.log(error, "err");
    return res.json({
      status: false,
      code: 500,
      values: "Internal Server Error",
    });
  }
};
const getCurrentDateTime = () => {
    const now = moment.tz("Asia/Kolkata");
  
    // Format the date and time in 'YYYY-MM-DD HH:mm:ss' format
    const formattedDateTime = now.format("YYYY-MM-DD HH:mm:ss");
  
    return formattedDateTime;
  };
  
  const getCurrentDate = () => {
    const now = moment.tz("Asia/Kolkata");
  
    // Format the date and time in 'YYYY-MM-DD HH:mm:ss' format
    const formattedDate = now.format("YYYY-MM-DD");
  
    return formattedDate;
  };


const vehicleFaultCodesDump = async (req, res) => {
  try {
    // let url = req.mongoUrl;
    await connection(url);

    const getVINDate = (filename)=>{

      return {
        VIN: filename.slice(0,17),
        Date: filename.slice(18,28)
      }
    }

    if(req.body.data === undefined || req.body.data.length === 0){
      return res.json({
        status: false,
        code: 400,
        message: "Invalid parameters"
      })
    }

    const dataToDump = req.body.data.map(item=>({
      ...getVINDate(item.Filename),
      ...item,
      created_date: getCurrentDate(),
      created_datetime: getCurrentDateTime(),
    }))

    // await VehicleFaultCodes.insertMany(dataToDump);

    const bulkOps = dataToDump.map(doc => ({
      updateOne: {
        filter: { VIN: doc.VIN, Date: doc.Date },
        update: doc,
        upsert: true  // Create a new document if no match found
      }
    }));

    await VehicleFaultCodes.bulkWrite(bulkOps)


    return res.json({
      code: 201,
      status: true,
      message: "Data dumped successfully"
    })
  } catch (error) {
    console.log(error);
    return res.json({
      status: false,
      code: 502,
      message: "Internal Server Error",
    }) 
  }
};
module.exports = {showVins,showVehicleVinInfo,vehicleFaultCodesDump};
