const mongoose = require("mongoose");
const { response } = require("express");
const driveScore = require("../../models/driveScore");
const Vehicle = require("../../models/vehicle");
const sequelize = require("../../utils/sqldb");
const { Op } = require("sequelize");

connection = (url) => {
  mongoose.connect(url, { useNewUrlParser: true });
};

const url =
  "mongodb+srv://alti-admin-prod:APL2023ADMIN@mqtt-production.iqeii.mongodb.net/mqttDatabase_aplmq";

const driveScoreService = async (req, res) => {
  try {
    await connection(url);
    let { vin, date } = req.body;
    const result = await driveScore
      .find({ vin: vin, Date: date })
      .select("-_id -range -city -city_rank");
    return res.json({
      status: true,
      code: 200,
      data: result,
    });
  } catch (error) {
    console.log(error, "err");
    return res.json({
      status: false,
      code: 500,
      values: "Internal Server Error",
    });
  }
};


const driveScoreAll = async (req, res) => {
  try {
    let date = req.body.date;
    await connection(url);

    const fleetVehicls = await sequelize.query(`select GROUP_CONCAT(DISTINCT cl.ClientFullName SEPARATOR ',') as fleetName,cv.vid,veh.VIN as vin, veh.VehicleRegNo, veh.model from Client cl 
    join ClientVehicle cv on cl.cid = cv.cid 
    join Vehicle veh on cv.vid = veh.vid where veh.deleteVehicleStatus=0 group by vin`);

    const modifiedFleetVehicles = fleetVehicls[0].map(vehicle => ({
      vin: vehicle.vin.substring(3), // Extract substring excluding "mq/"
      vid: vehicle.vid,
      VehicleRegNo: vehicle.VehicleRegNo,
      model: vehicle.model,
      fleetName: vehicle.fleetName
    }));

    const alldriveScore = await driveScore
      .find({ Date: date })
      .select({ _id: 0, vin: 1, drive_score: 1 });

    let avgDriveScoreVehicle = []
      for (const vehicle of modifiedFleetVehicles) {
        const foundTopScore = alldriveScore.find(score => score.vin === vehicle.vin);
        if (foundTopScore) {
          avgDriveScoreVehicle.push({
            vin: vehicle.vin,
            fleetName: vehicle.fleetName,
            driveScore: foundTopScore.drive_score
          });
        }
      }

      let resobj={};
        for(let i=0;i<avgDriveScoreVehicle.length;i++){
          let fleetArray=avgDriveScoreVehicle[i].fleetName.split(',');
          for(let j=0;j<fleetArray.length;j++){
            if(resobj.hasOwnProperty(fleetArray[j].trim())){
              resobj[fleetArray[j].trim()]={...resobj[fleetArray[j].trim()],vehicle_count:resobj[fleetArray[j].trim()]['vehicle_count']+1,
              score:resobj[fleetArray[j].trim()]['score']+avgDriveScoreVehicle[i]['driveScore']}
            }
            else{
              resobj[fleetArray[j].trim()]={vehicle_count:1,score:avgDriveScoreVehicle[i]['driveScore'],fleet_type:fleetArray[j]}
            }
          }      
        }

        let resultObject=[]
        Object.keys(resobj).forEach(key => {
         
          if(resobj[key]['fleet_type']!==4 ){
            if(resobj[key]['vehicle_count']>5){
              resultObject.push({avg_drive_score:(resobj[key]['score']/resobj[key]['vehicle_count']).toFixed(2),name:key,vehicle_count:resobj[key]['vehicle_count']})
            }
          }
        });

        resultObject.sort((a,b)=>(Number(b.avg_drive_score)-Number(a.avg_drive_score)))
        resultObject=resultObject.slice(0,15)

    let topdriveScore = await driveScore
      .find({ Date: date })
      .sort({ drive_score: -1 })
      .limit(10)
      .select({ _id: 0, vin: 1, drive_score: 1, percentage_agressive_acceleration: 1, percentage_agressive_turning: 1, eEfficiency: 1, percentage_agressive_braking:1 });

      
      let leastdriveScore = await driveScore
      .find({ Date: date })
      .sort({ drive_score: 1 })
      .limit(10)
      .select({ _id: 0, vin: 1, drive_score: 1, percentage_agressive_acceleration: 1, percentage_agressive_turning: 1, eEfficiency: 1, percentage_agressive_braking:1 });

      
      const avgCityDriveScore = await driveScore.aggregate([
        {
          $match: {
            Date: date,
            city: { $ne: "" },
            city: { $not: /\\N/ },
            city:{ $ne: "NA"}
          },
        },
        {
          $group: {
            _id: "$city",
            drive_score: { $avg: "$drive_score" },
            count: { $addToSet: "$vin" },
          },
        },
        {
          $project: {
            _id: 0,
            city: "$_id",
            drive_score: { $round: ["$drive_score", 2] },
            count: { $size: "$count" },
          },
        },
        {
          $match: {
            count: { $gt: 5 },
          },
        },
        {
          $sort: {
            drive_score: -1,
          },
        },
        {
          $limit: 20,
        },
      ]);
    

      let matchingTopdriveScore = [];
      let matchingLeastdriveScore = [];
      

      for (const vehicle of modifiedFleetVehicles) {
      let foundTopScore = topdriveScore.find(score => score.vin === vehicle.vin);
        if (foundTopScore) {
          matchingTopdriveScore.push({
            vin: vehicle.vin,
            vehicle_reg_number: vehicle.VehicleRegNo,
            name: vehicle.fleetName,
            model: vehicle.model,
            driveScore: foundTopScore.drive_score
          });
        }
        matchingTopdriveScore=matchingTopdriveScore.sort((a,b)=>(b.driveScore-a.driveScore))


        let foundLeastScore = leastdriveScore.find(score => score.vin === vehicle.vin);
        if (foundLeastScore) {
          matchingLeastdriveScore.push({
            vin: vehicle.vin,
            vehicle_reg_number: vehicle.VehicleRegNo,
            name: vehicle.fleetName,
            model: vehicle.model,
            driveScore: foundLeastScore.drive_score
          });
        }
      }
      matchingLeastdriveScore=matchingLeastdriveScore.sort((a,b)=>(a.driveScore-b.driveScore))



      let topAcceleration = 0;
      let topTurning = 0;
      let topEfficiency = 0;
      let topBreaking = 0;
      topdriveScore.forEach((score) => {
        topAcceleration += score.percentage_agressive_acceleration;
        topTurning += score.percentage_agressive_turning;
        topEfficiency += isNaN(score.eEfficiency) ? 0 : score.eEfficiency;
        topBreaking += score.percentage_agressive_braking
      });

      // console.log(topEfficiency);

      const aggressiveTopAcceleration = (topAcceleration / topdriveScore.length).toFixed(2);
      const aggressiveTopTurning = (topTurning/ topdriveScore.length).toFixed(2);
      const aggressiveTopEfficiency = (topEfficiency / topdriveScore.length).toFixed(2);
      const aggressiveTopBraking = (topBreaking / topdriveScore.length).toFixed(2);

      let leastAcceleration = 0;
      let leastTurning  = 0;
      let leastEfficiency = 0;
      let leastBreaking = 0;
      leastdriveScore.forEach((score) => {
        leastAcceleration += score.percentage_agressive_acceleration;
        leastTurning += score.percentage_agressive_turning;
        leastEfficiency += isNaN(score.eEfficiency) ? 0 : score.eEfficiency
        leastBreaking += score.percentage_agressive_braking
      });

      const aggressiveLeastAcceleration = (leastAcceleration / leastdriveScore.length).toFixed(2);
      const aggressiveLeastTurning = (leastTurning / leastdriveScore.length).toFixed(2);
      const aggressiveLeastEfficiency = (leastEfficiency / leastdriveScore.length).toFixed(2);
      const aggressiveLeastBraking = (leastBreaking / leastdriveScore.length).toFixed(2);


      
    return res.json({
      status: true,
      code: 200,
      values: {
        topdriveScore: matchingTopdriveScore, //Array of Objects
        leastdriveScore: matchingLeastdriveScore, //Array of Objects
        avgCityDriveScore: avgCityDriveScore, //Array of Objects
        avgFleetDriveScore: resultObject, //Array of Objects
        aggressiveTopAcceleration: aggressiveTopAcceleration,  
        aggressiveLeastAcceleration: aggressiveLeastAcceleration,
        aggressiveTopTurning: aggressiveTopTurning,
        aggressiveLeastTurning: aggressiveLeastTurning,
        aggressiveTopEfficiency: aggressiveTopEfficiency,
        aggressiveLeastEfficiency: aggressiveLeastEfficiency,
        aggressiveTopBraking: aggressiveTopBraking,
        aggressiveLeastBraking: aggressiveLeastBraking,
        
      },
    });

    // return res.json(resultObject)

  } catch (error) {
    console.log(error, "err");
    return res.json({
      status: false,
      code: 500,
      values: "Internal Server Error",
    });
  }
};


const driveScoreOnDate = async(req, res) => {
  try {
    const {vin, date } = req.body;
    await connection(url);
    const fleetVehicls = await sequelize.query(`select GROUP_CONCAT(DISTINCT cl.ClientFullName SEPARATOR ',') as fleetName,cv.vid,veh.VIN as vin, veh.VehicleRegNo, veh.model from Client cl 
    join ClientVehicle cv on cl.cid = cv.cid 
    join Vehicle veh on cv.vid = veh.vid where veh.deleteVehicleStatus=0 and veh.VIN="mq/${vin}" group by vin`);

    const modifiedFleetVehicles = fleetVehicls[0].map(vehicle => ({
      vin: vehicle.vin.substring(3), // Extract substring excluding "mq/"
      vid: vehicle.vid,
      VehicleRegNo: vehicle.VehicleRegNo,
      model: vehicle.model,
      fleetName: vehicle.fleetName
    }));


    let driveScoreData = "";
    if(date === ""){
      driveScoreData = await driveScore
      .find({ vin: vin })
      .sort({ Date: -1 })
      .limit(1)
      .select({ _id: 0, vin: 1, Date:1, drive_score: 1, percentage_agressive_acceleration: 1, percentage_agressive_turning: 1, eEfficiency: 1, percentage_agressive_braking:1, city: 1, normalised_throttle_position:1, brake_pedal_percentage:1 })
    }
    else{
      driveScoreData = await driveScore
      .find({ vin: vin, Date: date })
      .select({ _id: 0, vin: 1, Date:1, drive_score: 1, percentage_agressive_acceleration: 1, percentage_agressive_turning: 1, eEfficiency: 1, percentage_agressive_braking:1, city: 1, normalised_throttle_position:1, brake_pedal_percentage:1 })
    }

    let matchingdriveScore = []

    for (const vehicle of modifiedFleetVehicles) {
      const foundScore = driveScoreData.find(score => score.vin === vehicle.vin);
      if (foundScore) {
        matchingdriveScore.push({
          date: foundScore.Date,
          vin: vehicle.vin,
          VehicleRegNo: vehicle.VehicleRegNo,
          drive_score: foundScore.drive_score,
          percentage_agressive_acceleration: foundScore.percentage_agressive_acceleration,
          percentage_agressive_turning: foundScore.percentage_agressive_turning,
          eEfficiency: foundScore.eEfficiency,
          percentage_agressive_braking: foundScore.percentage_agressive_braking,
          city: foundScore.city,
          normalised_throttle_position: foundScore.normalised_throttle_position,
          brake_pedal_percentage: foundScore.brake_pedal_percentage,
          model: vehicle.model,
          name: vehicle.fleetName,
        });
      }
    }


    // -----------------------------------------------

    const driveScore30DaysData = await driveScore
      .find({ vin: vin })
      .sort({ Date: -1 })
      .limit(30)
      .select({ _id: 0, vin: 1, Date:1, drive_score: 1, percentage_agressive_acceleration: 1, percentage_agressive_turning: 1, eEfficiency: 1, percentage_agressive_braking:1, city: 1, normalised_throttle_position:1, brake_pedal_percentage:1, regen:1 })

      const updatedDriveScore30DaysData = [];
      for(const foundScore of driveScore30DaysData){
        updatedDriveScore30DaysData.push({
          brake_pedal_percentage: (foundScore.brake_pedal_percentage * 100).toFixed(2),
          date: foundScore.Date,
          drive_score: foundScore.drive_score,
          eEfficiency: foundScore.eEfficiency ? (foundScore.eEfficiency).toFixed(1) : null,
          normalised_throttle_position: (foundScore.normalised_throttle_position * 100).toFixed(2),
          percentage_agressive_acceleration: foundScore.percentage_agressive_acceleration,
          percentage_agressive_braking: foundScore.percentage_agressive_braking,
          percentage_agressive_turning: foundScore.percentage_agressive_turning,
          regen: foundScore.regen,
          vin: foundScore.vin,
        })
      }

    return res.json({CurrentData: matchingdriveScore, thirtyDaysData: updatedDriveScore30DaysData})

  } catch (error) {
    console.log(error, "err");
    return res.json({
      status: false,
      code: 500,
      values: "Internal Server Error",
    });
  }
}

const driveScoreVins = async (req,res) => {
  try {
    await sequelize.sync();
    await connection(url);
    query=(await driveScore.distinct('vin')).map(item=>'mq/'+item)
    const vehicleData=await Vehicle.findAll({attributes:[ [sequelize.fn('SUBSTRING', sequelize.col('VIN'),4), 'vin'],['VehicleRegNo','vehicle_reg_no']],
    where:{
      VIN:{
        [Op.in]:query
      }
    },
    distinct:true,
    raw: true,
  })

  const data=vehicleData.map((item)=>{
    return {
      label: `${item.vin} | ${item.vehicle_reg_no}`,
      value: item.vin,
    }
  })

    return res.json({status:true,data:data});
  } catch (error) {
    console.log(error);
    return res.json({status:false,data:error});
  }
};

module.exports = { driveScoreService, driveScoreAll, driveScoreOnDate ,driveScoreVins};
