const AltidashUser = require("../../models/AltidashUser");
const { getCurrentDate } = require("../../utils/constants");
const sequelize = require("../../utils/sqldb");

const getAllUsers = async (req, res) => {
  try {
    await sequelize.sync();

    const roles = {
      1: "Service",
      2: "Sales",
      3: "CXO",
      4: "Admin",
      5: "AltiDash Import",
      6: "Fleet Segment",
      7: "BHC",
      8: "Drive Safety Score",
      9:"Vehicle Prod Status",
      10:"Alti Engineer"

    };

    let users = await AltidashUser.findAll({
      raw: true,
    });
    if (!users.length)
      return res.json({
        status: false,
        error: "No users",
      });

    users = users.map((user) => {
      let obj = {
        email: user.email,
        roles: user.role_id
          .split(",")
          .map((id) => roles[id])
          .join(","),
        created_at: user.created_at === "0000-00-00" ? "" : user.created_at,
        status: user.status ? "Active" : "Disabled",
      };

      return obj;
    });

    return res.json({
      status: true,
      data: users,
    });
  } catch (error) {
    console.log(error);
    return res.json({
      status: false,
      error: "Internal Server Error",
    });
  }
};

const addUser = async (req, res) => {
  try {
    const { email, roles, status } = req.body;

    if (await AltidashUser.findOne({ where: { email } }))
      return res.json({
        status: false,
        error: "User already exists",
      });

    await AltidashUser.create({
      email,
      role_id: roles,
      created_at: getCurrentDate(),
      status,
    });

    return res.json({
      status: true,
      message: "User created successfully",
    });
  } catch (error) {
    console.log(error);
    return res.json({
      status: false,
      error: "Couldn't create user",
    });
  }
};

const editUser = async (req, res) => {
  try {
    const { email, roles, status } = req.body;
    if (!(await AltidashUser.findOne({ where: { email } })))
      return res.json({
        status: false,
        error: "User not found",
      });

    await AltidashUser.update(
      { email, role_id: roles, status },
      { where: { email } }
    );

    return res.json({
      status: true,
      message: "User updated successfully",
    });
  } catch (error) {
    console.log(error);
    return res.json({
      status: false,
      error: "Couldn't update user",
    });
  }
};

const deleteUser = async (req, res) => {
  try {
    const { email } = req.body;
    if (!(await AltidashUser.findOne({ where: { email } })))
      return res.json({
        status: false,
        error: "User not found",
      });

    await AltidashUser.destroy({ where: { email } });

    return res.json({
      status: true,
      message: "User deleted successfully",
    });
  } catch (error) {
    console.log(error);
    return res.json({
      status: false,
      error: "Couldn't delete user",
    });
  }
};

module.exports = {
  getAllUsers,
  addUser,
  editUser,
  deleteUser,
};
