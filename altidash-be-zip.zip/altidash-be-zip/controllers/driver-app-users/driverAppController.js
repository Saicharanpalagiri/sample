const { Op } = require("sequelize");
const User = require("../../models/user");

const getDriverAppUserDetails = async (req, res) => {
  try {
    const { dates } = req.body;
    let usersData;
    if (!dates) {
      usersData = await User.findAll({
        raw: true,
        where: {
          firstAppLogin: {
            [Op.ne]: null,
          },
        },
        attributes: ["email", "mobile", "userName", "firstAppLogin"],
      });
    } else {
      let { startDate, endDate } = dates;
      usersData = await User.findAll({
        raw: true,
        where: {
          firstAppLogin: {
            [Op.between]: [startDate, endDate],
            [Op.ne]: null,
          },
        },
        attributes: ["email", "mobile", "userName", "firstAppLogin"],
      });
    }

    if (!usersData)
      return res.json({
        status: false,
        error: "No users found",
      });
    else {
      return res.json({
        status: true,
        data: usersData,
      });
    }
  } catch (error) {
    console.log(error);
    return res.json({
      status: false,
      error: "Internal server error",
    });
  }
};

module.exports = {
  getDriverAppUserDetails,
};
