const sequelize_aleads = require("../../utils/sqldb_aleads");
const sequelize=require("../../utils/sqldb")
const mongoose = require("mongoose");
const Vehicle = require("../../models/vehicle");
const VehicleDailyData = require("../../models/vehicleDailyData");
const moment= require("moment");
const sequelize_retFin=require("../../utils/sqldb_retFin")

const getDifferenceDateForTatAnalysis = (date1, date2) => {
  let dateObj1 = new Date(date1);
  let dateObj2 = new Date(date2);
  let differenceInMilliseconds = dateObj1 - dateObj2;
  let differenceInDays = differenceInMilliseconds / (1000 * 60 * 60 * 24);
  return differenceInDays;
};

connection = (url) => {
    mongoose.connect(url, { useNewUrlParser: true });
  };
  
  const url =
    "mongodb+srv://alti-admin-prod:APL2023ADMIN@mqtt-production.iqeii.mongodb.net/mqttDatabase_aplmq";


const pdfController = async (req, res) => {
  try {
    await sequelize_aleads.sync();
    await sequelize_retFin.sync();
    const {date}=req.body;
    const todayDate=moment();
        const previousMonthDate = moment().subtract(1, 'months');
        const startOfLastMonth = previousMonthDate.startOf('month').format('YYYY-MM-DD');
        const endOfLastMonth = previousMonthDate.endOf('month').format('YYYY-MM-DD');
        const lastMonthName = previousMonthDate.format('MMMM');
        const lastMonthYear= previousMonthDate.format("YYYY")

        const currentMonthStartDate=moment(date).startOf('month').format('YYYY-MM-DD');
        const currentMonthEndDate=moment(date).endOf('month').format('YYYY-MM-DD');
        const currentMonthName=moment(date).format("MMMM")
        const todayDateDate=moment(date).format('YYYY-MM-DD')
        const last90DaysBeforeDate=moment(date).subtract(90,'days').format('YYYY-MM-DD')
        const currentYear=moment(date).format("YYYY")
        const startDate=moment().subtract(2, 'months').startOf('month').format("YYYY-MM-DD")
        const endDate=currentMonthEndDate
    

        console.log(startDate,endDate,'dates')

    // AltiDash Queries
    // await sequelize.sync();
    // await connection(url);
    // let vehiclesData=await Vehicle.findAll({
    //     attributes:['VIN',"VehicleRegNo"],
    //     where:{deleteVehicleStatus:0},
    //     raw:true
    // });
    // let VehicleDistanceQuery=await VehicleDailyData.aggregate([
    //     {
    //         $match:{
    //         topic:{$in:vehiclesData.map(i=>i.VIN)},
    //         date:{$gte:"2024-07-01",$lte:"2024-07-31"},
    //         x12:{
    //             $gt:0,
    //             $lte:500
    //         }
    //     }},{
    //     $group:{
    //         _id:null,
    //         distance:{$sum:'$x12'}
    //     }}
    // ])

    //altileads DB Queries
    let query = await sequelize_aleads.query(`WITH LeadDifferences AS (
    SELECT 
        customerLeadId,
        DATEDIFF(\`Uploaded Date\`,\`Created Date\`) AS createUploadDiff,
        DATEDIFF(\`Uploaded Date\`,\`First Disposition Date\`) AS uploadFirstCallDiff,
        CASE
            WHEN \`Qualified-Warm Date\` IS NOT NULL THEN DATEDIFF(\`Qualified-Warm Date\`, \`Uploaded Date\`)
            WHEN \`Qualified-Hot Date\` IS NOT NULL THEN DATEDIFF(\`Qualified-Hot Date\`, \`Uploaded Date\`)
            ELSE NULL
        END AS qualifiedDiff,
        CASE
            WHEN \`Qualified-Warm Date\` IS NOT NULL AND \`Test Drive Date\` IS NOT NULL THEN DATEDIFF(\`Test Drive Date\`, \`Qualified-Warm Date\`)
            WHEN \`Qualified-Hot Date\` IS NOT NULL AND \`Test Drive Date\` IS NOT NULL THEN DATEDIFF(\`Test Drive Date\`, \`Qualified-Hot Date\`)
            ELSE NULL
        END AS testDriveDiff,
        CASE
            WHEN \`Qualified-Warm Date\` IS NOT NULL AND \`First Follow-up Date\` IS NOT NULL THEN DATEDIFF(\`First Follow-up Date\`, \`Qualified-Warm Date\`)
            WHEN \`Qualified-Hot Date\` IS NOT NULL AND \`First Follow-up Date\` IS NOT NULL THEN DATEDIFF(\`First Follow-up Date\`, \`Qualified-Hot Date\`)
            ELSE NULL
        END AS qualiFollowDiff,
        CASE
            WHEN \`Test Drive Date\` IS NOT NULL AND \`Booked Date\` IS NOT NULL THEN DATEDIFF(\`Booked Date\`, \`Test Drive Date\`)
            ELSE NULL
        END AS bookingDiff,
        CASE
            WHEN \`Booked Date\` IS NOT NULL AND \`Retailed Date\` IS NOT NULL 
            THEN DATEDIFF(\`Retailed Date\`, \`Booked Date\`)
            ELSE NULL
        END AS bookRetailDiff,
        DATEDIFF(\`Retailed Date\`, \`Uploaded Date\`) AS retailDiff
    FROM 
        CustomerLeads
    WHERE 
        DuplicateStatus = 0
        AND \`Uploaded Date\` >= '2024-07-01'
)
SELECT 
    ROUND(AVG(createUploadDiff),1) AS "Create to Upload",
    ROUND(AVG(uploadFirstCallDiff),1) AS "Upload to First Calling",
    ROUND(AVG(qualifiedDiff),1) AS "Upload to Qualify",
    ROUND(AVG(testDriveDiff),1) AS "Qualify to Test Drive",
    ROUND(AVG(bookingDiff),1) AS "Test Drive to Booking",
    ROUND(AVG(bookRetailDiff),1) AS "Booking to Retail",
    ROUND(AVG(retailDiff),1) AS "Upload to Retail",
    ROUND(AVG(qualiFollowDiff),1) AS "Qualify to First Follow-up"
FROM 
    LeadDifferences`);

    let query1 = await sequelize_aleads.query(`SELECT 
        COUNT(*) as total_qualified,SUM(CASE WHEN \`Lead Status\` IN ('Qualified-Warm', 'Qualified-Hot') THEN 1 ELSE 0 END) 
    AS qualifiedCount,
    SUM(CASE 
            WHEN \`Lead Status\` IN ('Qualified-Warm', 'Qualified-Hot') 
                 AND (\`Lead Follow-up Status\` <> 'Out of Territory' or \`Lead Follow-up Status\` is NULL) THEN 1 
            ELSE 0 
        END) AS qualifiedInTerritoryCount,
        SUM(CASE WHEN \`Test Drive Given?\` = 'YES' THEN 1 ELSE 0 END) AS testDriveDoneCount,
    SUM(CASE WHEN (\`Lead Follow-up Status\` = 'Booked' or \`Lead Follow-up Status\` = 'Retailed') THEN 1 ELSE 0 END) AS bookedCount,
    SUM(CASE WHEN \`Lead Follow-up Status\` = 'Retailed' THEN 1 ELSE 0 END) AS retailedCount
    from CustomerLeads where DuplicateStatus=0  AND \`Created Date\` >= '${last90DaysBeforeDate}'
    AND \`Created Date\` <= '${todayDateDate}' AND
    ('Disposition' !="Dealership Enquiry"  or 'Disposition' is NULL)
   `);

   let query2=await sequelize_aleads.query(`
    SELECT
        Month,
        SUM(BookedCount) AS Booked,
        SUM(RetailedCount) AS Retailed,
        SUM(QualifiedCount) AS Qualified,
        SUM(TestDriveCount) AS TestDriveDone,
        SUM(QualifiedCountInTerritory) AS QualifiedInTerritory
    FROM (
        SELECT
            DATE_FORMAT(STR_TO_DATE(SUBSTR(\`Booked Date\`, 1, 7), '%Y-%m'), '%M') AS Month,
            COUNT(customerLeadId) AS BookedCount,
            0 AS RetailedCount,
            0 AS QualifiedCount,
            0 AS QualifiedCountInTerritory,
            0 AS TestDriveCount
        FROM a_lead.CustomerLeads
        WHERE \`Booked Date\` BETWEEN '${startDate}' AND '${endDate}' AND ( Disposition != "Dealership Enquiry" OR Disposition IS NULL) AND DuplicateStatus = 0
        GROUP BY Month
 
        UNION ALL
 
        SELECT
            DATE_FORMAT(STR_TO_DATE(SUBSTR(\`Retailed Date\`, 1, 7), '%Y-%m'), '%M') AS Month,
            0 AS BookedCount,
            COUNT(customerLeadId) AS RetailedCount,
            0 AS QualifiedCount,
            0 AS TestDriveCount,
            0 AS QualifiedCountInTerritory
        FROM a_lead.CustomerLeads
        WHERE \`Retailed Date\` BETWEEN '${startDate}' AND '${endDate}' AND ( Disposition != "Dealership Enquiry" OR Disposition IS NULL) AND DuplicateStatus = 0 
        GROUP BY Month
 
        UNION ALL
 
        SELECT
            DATE_FORMAT(STR_TO_DATE(SUBSTR(\`Qualified Standard Date\`, 1, 7), '%Y-%m'), '%M') AS Month,
            0 AS BookedCount,
            0 AS RetailedCount,
            COUNT(customerLeadId) AS QualifiedCount,
            0 AS QualifiedCountInTerritory,
            0 AS TestDriveCount
        FROM a_lead.CustomerLeads
        WHERE \`Qualified Standard Date\` BETWEEN '${startDate}' AND '${endDate}' AND ( Disposition != "Dealership Enquiry" OR Disposition IS NULL) AND DuplicateStatus = 0 
        GROUP BY Month
 
        UNION ALL
 
        SELECT
            DATE_FORMAT(STR_TO_DATE(SUBSTR(\`Qualified Standard Date\`, 1, 7), '%Y-%m'), '%M') AS Month,
            0 AS BookedCount,
            0 AS RetailedCount,
            0 AS QualifiedCount,
            COUNT(customerLeadId) AS QualifiedCountInTerritory,
            0 AS TestDriveCount
        FROM a_lead.CustomerLeads
        WHERE \`Qualified Standard Date\` BETWEEN '${startDate}' AND '${endDate}' AND ( Disposition != "Dealership Enquiry" OR Disposition IS NULL) AND DuplicateStatus = 0 AND (\`Lead Follow-up Status\` != "Out of Territory" OR \`Lead Follow-up Status\` IS NULL) 
        GROUP BY Month
 
        UNION ALL
 
        SELECT
            DATE_FORMAT(STR_TO_DATE(SUBSTR(\`Test Drive Date\`, 1, 7), '%Y-%m'), '%M') AS Month,
            0 AS BookedCount,
            0 AS RetailedCount,
            0 AS QualifiedCount,
            0 AS QualifiedCountInTerritory,
            COUNT(customerLeadId) AS TestDriveCount
        FROM a_lead.CustomerLeads
        WHERE \`Test Drive Date\` BETWEEN '${startDate}' AND '${endDate}' AND \`Test Drive Given?\` = "YES" AND ( Disposition != "Dealership Enquiry" OR Disposition IS NULL) AND DuplicateStatus = 0 
        GROUP BY Month
    ) AS Combined
    GROUP BY Month;
  `)
let leadData={
    data: query[0][0],
    funnelData: query1[0][0],
    chartData:query2[0]
}
 
//    console.log(todayDate,startOfLastMonth,endOfLastMonth,lastMonthName,lastMonthYear)

//    //retail Finance App
   let retailCountQuery=await sequelize_retFin.query(`SELECT 
    'Retailed_new' AS Category, 
    SUM(QTY) AS TotalQuantity 
FROM 
    Customer 
WHERE 
    ProjectedMonth = '${currentMonthName}' 
    AND ProjectedYear = ${currentYear} 
    AND status IN ('Cash Retail', 'Other Bank Retail', 'Retail') 
    AND DateOfEnquiry BETWEEN "${currentMonthStartDate}" AND "${currentMonthEndDate}" 
    AND DeletedStatus = 0

UNION ALL

SELECT 
    'Retailed_exisiting' AS Category, 
    SUM(QTY) AS TotalQuantity 
FROM 
    Customer 
WHERE 
    ProjectedMonth = '${currentMonthName}'  
    AND ProjectedYear = ${currentYear}  
    AND status IN ('Cash Retail', 'Other Bank Retail', 'Retail') 
    AND DateOfEnquiry < "${currentMonthStartDate}"
    AND DeletedStatus = 0

UNION ALL

SELECT 
    'logged_new' AS Category, 
    SUM(QTY) AS TotalQuantity 
FROM 
    CustomerStatus 
WHERE 
    ProjectedMonth = '${currentMonthName}' 
    AND ProjectedYear = ${currentYear}  
    AND DateOfEnquiry BETWEEN "${currentMonthStartDate}" AND "${currentMonthEndDate}" 
    AND ViewAccess = 0 
    AND DeletedStatus = 0

UNION ALL

SELECT 
    'logged_other' AS Category, 
    SUM(QTY) AS TotalQuantity 
FROM 
    CustomerStatus 
WHERE 
    ProjectedMonth = '${currentMonthName}' 
    AND ProjectedYear = ${currentYear}  
    AND DateOfEnquiry < "${currentMonthStartDate}"
    AND ViewAccess = 0 
    AND DeletedStatus = 0;
`);


let RetailersQuery=await sequelize_retFin.query(`select count(c.QTY) as count, c.FinancerName from Customer c
join Financer f on f.FinancerName=c.FinancerName
where c.DeletedStatus=0 and c.FinancerName not in ('Cash','Rental') 
and c.status IN ('Cash Retail', 'Other Bank Retail', 'Retail') 
and f.isBank=0 
group by FinancerName order by count desc limit 3;`)

let BankersQuery=await sequelize_retFin.query(`select count(c.QTY) as count, c.FinancerName from Customer c
join Financer f on f.FinancerName=c.FinancerName
where c.DeletedStatus=0 and c.FinancerName not in ('Cash','Rental') 
and c.status IN ('Cash Retail', 'Other Bank Retail', 'Retail') 
and f.isBank=1
group by FinancerName order by count desc limit 3;`)

let PostponedQuery=`select sum(QTY) as count from CustomerStatus where
 DateOfEnquiry < '${currentMonthStartDate}' and ProjectedMonth='${currentMonthName}'
and deletedStatus=0 and viewAccess=0`


let totalPostponed=await sequelize_retFin.query(PostponedQuery)

let retailData={
    retailCountQuery:retailCountQuery[0],
    retailersQuery:RetailersQuery[0],
    query2:query2[0],
    bankersQuery:BankersQuery[0],
    totalPostponed:totalPostponed[0]
}


    return res.json({
      status: true,
      code: 200,
      leadData:leadData,
      retailData:retailData
    });
  } catch (error) {
    console.log(error);
    return res.json({
      status: false,
      code: 500,
      message: "Internal Server Error",
    });
  }
};

module.exports = { pdfController };
