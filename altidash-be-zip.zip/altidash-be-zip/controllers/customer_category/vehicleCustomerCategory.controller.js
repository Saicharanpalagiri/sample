const moment = require("moment");
const mongoose = require("mongoose");
const { response } = require("express");
const VehicleDailyData = require("../../models/vehicleDailyData");
const Vehicle = require("../../models/vehicle");
const { Op } = require("sequelize");
connection = (url) => {
  mongoose.connect(url, { useNewUrlParser: true });
};

const url =
  "mongodb+srv://alti-admin-prod:APL2023ADMIN@mqtt-production.iqeii.mongodb.net/mqttDatabase_aplmq";

const getCustomerCategoryData = async (req, res) => {
  try {
    let { startDate, endDate } = req.body.dates;
    const { distance, category } = req.body;
    let vinsList;
    let categories = ["B2B", "Captive", "DCO/MLO"];

    if (category === "all")
      vinsList = await Vehicle.findAll({
        where: {
          category: {
            [Op.in]: categories,
          },
        },
      });
    else
      vinsList = await Vehicle.findAll({
        where: {
          category: category,
        },
      });

    if (!vinsList.length)
      return res.status(204).json({ status: false, error: "No VINs found" });

    await connection(url);
    let response1 = await VehicleDailyData.aggregate([
      {
        $match: {
          date: {
            $gte: startDate,
            $lte: endDate,
          },
          x12: {
            $gt: distance,
          },
          topic: {
            $in: vinsList.map((item) => item.dataValues.VIN),
          },
        },
      },
      {$sort:{
        date:1
      }},
      {
        $group: {
          _id: {
            date: "$date",
          },

          avgDistance: {
            $avg: "$x12",
          },

          totalVehicles: { $sum: 1 },

          avgSpeed: { $avg: "$x13" },
          avg_efficiency: {$avg: "$x35"},
          //  uniqueVehicles: { $addToSet: '$topic' } // Collect unique vehicle ids in an array
        },
      }
    ]);
    let response2 = await VehicleDailyData.aggregate([
      {
        $match: {
          date: {
            $gte: startDate,
            $lte: endDate,
          },
          x12: {
            $gt: distance,
          },
          topic: {
            $in: vinsList.map((item) => item.dataValues.VIN),
          },
        },
      },
      {
        $group: {
          _id: null,
          avgDistance: {
            $avg: "$x12",
          },
          avgSpeed: { $avg: "$x13" },
          uniqueVehicles: { $addToSet: "$topic" },
          avg_efficiency: {$avg: "$x35"}

        },
      },
    ]);
    response1 = response1.map((item) => ({
      total_vehicles_driven: item.totalVehicles,
      avg_speed: item.avgSpeed.toFixed(2),
      avg_distance: item.avgDistance.toFixed(2),
      avg_efficiency: item.avg_efficiency.toFixed(2),
      date: item._id["date"],
    }));

    response1=response1.sort((a,b)=>(moment(a.date)-moment(b.date)))

    response2 = {
      avgDistance: response2[0].avgDistance.toFixed(2),
      totalVehicles: response2[0].totalVehicles,
      avgSpeed: response2[0].avgSpeed.toFixed(2),
      avg_efficiency: response2[0].avg_efficiency.toFixed(2),

      total_vehicles_driven: response2[0].uniqueVehicles.length,
      avg_vehicles: response1.reduce(
        (acc, cum) =>
          acc + parseInt(cum.total_vehicles_driven / response1.length),
        0
      ),
    };

    let result = {
      data: response1,
      ...response2,
      vehicles_count: vinsList.length,
    };

    return res.json({ status: true, ...result });
  } catch (error) {
    console.log(error);
    return res.json(error);
  }
};

const getCustomerCategoryAnalysis = async (req, res) => {
  try {
    let { startDate, endDate } = req.body.dates;
    const { distance, category } = req.body;
    let vinsList;
    const categories = ["B2B", "Captive", "DCO/MLO"];

    await connection(url);

    if (category === "all") {
      console.log('start')
      vinsList = await Vehicle.findAll({
        where: {
          category: {
            [Op.in]: categories,
          },
        },
      });
      if (!vinsList.length)
        return res.status(204).json({ status: false, error: "No VINs found" });
      console.log('vins are there')

      const result = {
        histograms: {
          B2B: [],
          Captive: [],
          "DCO/MLO": [],
        },
        lines: {
          B2B: [],
          Captive: [],
          "DCO/MLO": [],
        },
        efficiencyPercentile: {
          B2B: [],
          Captive: [],
          "DCO/MLO": [],
        },
        odometerChart: {
          xvalues: [],
          yvalues: [],
        },
      };

      let odometerChart = await VehicleDailyData.aggregate([
        {
          $match: {
            topic: {
              $in: vinsList.map((item) => item.dataValues.VIN),
            },
            date: {
              $gte: startDate,
              $lte: endDate,
            },
            x12: {
              $gt: distance,
              $lte: 500,
            },
          },
        },
        {
          $group: {
            _id: {
              topic: "$topic",
            },
            max_date: { $max: "$date" },
            x11: { $last: "$x11" },
          },
        },
        {
          /**
           * _id: The id of the group.
           * fieldN: The first field name.
           */
          $group: {
            _id: "$_id.topic",
            "0-500": { $sum: { $cond: [{ $lte: ["$x11", 500] }, 1, 0] } },
            "500-1000": {
              $sum: {
                $cond: [
                  { $and: [{ $gt: ["$x11", 500] }, { $lte: ["$x11", 1000] }] },
                  1,
                  0,
                ],
              },
            },
            "1000-5000": {
              $sum: {
                $cond: [
                  { $and: [{ $gt: ["$x11", 1000] }, { $lte: ["$x11", 5000] }] },
                  1,
                  0,
                ],
              },
            },
            "5000-10000": {
              $sum: {
                $cond: [
                  {
                    $and: [{ $gt: ["$x11", 5000] }, { $lte: ["$x11", 10000] }],
                  },
                  1,
                  0,
                ],
              },
            },
            "10000-20000": {
              $sum: {
                $cond: [
                  {
                    $and: [{ $gt: ["$x11", 10000] }, { $lte: ["$x11", 20000] }],
                  },
                  1,
                  0,
                ],
              },
            },
            "20000-30000": {
              $sum: {
                $cond: [
                  {
                    $and: [{ $gt: ["$x11", 20000] }, { $lte: ["$x11", 30000] }],
                  },
                  1,
                  0,
                ],
              },
            },
            "30000-40000": {
              $sum: {
                $cond: [
                  {
                    $and: [{ $gt: ["$x11", 30000] }, { $lte: ["$x11", 40000] }],
                  },
                  1,
                  0,
                ],
              },
            },
            "40000-50000": {
              $sum: {
                $cond: [
                  {
                    $and: [{ $gt: ["$x11", 40000] }, { $lte: ["$x11", 50000] }],
                  },
                  1,
                  0,
                ],
              },
            },
          },
        },
        {
          /**
           * _id: The id of the group.
           * fieldN: The first field name.
           */
          $group: {
            _id: null,
            "0-500": { $sum: "$0-500" },
            "500-1000": { $sum: "$500-1000" },
            "1000-5000": { $sum: "$1000-5000" },
            "5000-10000": { $sum: "$5000-10000" },
            "10000-20000": { $sum: "$10000-20000" },
            "20000-30000": { $sum: "$20000-30000" },
            "30000-40000": { $sum: "$30000-40000" },
            "40000-50000": { $sum: "$40000-50000" },
          },
        },
      ]);

      let odometerXValues = Object.keys(odometerChart[0]).filter(
        (key) => key !== "_id"
      );
      let odometerYValues = Object.entries(odometerChart[0]).reduce(
        (acc, cum) => (cum[0] === "_id" ? acc : [...acc, cum[1]]),
        []
      );

      result.odometerChart.xvalues = odometerXValues;
      result.odometerChart.yvalues = odometerYValues;

      for (let i of categories) {
        
        let vehicleHistogram = await VehicleDailyData.aggregate([
          {
            $match: {
              topic: {
                $in: vinsList.reduce(
                  (acc, cum) =>
                    cum.dataValues.category === i
                      ? [...acc, cum.dataValues.VIN]
                      : acc,
                  []
                ),
              },
              date: {
                $gte: startDate,
                $lte: endDate,
              },
              x12: {
                $gt: distance,
                $lte: 500,
              },
            },
          },
          {
            $project: {
              distancerange: {
                $switch: {
                  branches: [
                    {
                      case: {
                        $and: [{ $gte: ["$x12", 0] }, { $lte: ["$x12", 25] }],
                      },
                      then: 0,
                    },
                    {
                      case: {
                        $and: [{ $gt: ["$x12", 25] }, { $lte: ["$x12", 50] }],
                      },
                      then: 25,
                    },
                    {
                      case: {
                        $and: [{ $gt: ["$x12", 50] }, { $lte: ["$x12", 75] }],
                      },
                      then: 50,
                    },
                    {
                      case: {
                        $and: [{ $gt: ["$x12", 75] }, { $lte: ["$x12", 100] }],
                      },
                      then: 75,
                    },
                    {
                      case: {
                        $and: [{ $gt: ["$x12", 100] }, { $lte: ["$x12", 125] }],
                      },
                      then: 100,
                    },
                    {
                      case: {
                        $and: [{ $gt: ["$x12", 125] }, { $lte: ["$x12", 150] }],
                      },
                      then: 125,
                    },
                    {
                      case: {
                        $and: [{ $gt: ["$x12", 150] }, { $lte: ["$x12", 175] }],
                      },
                      then: 150,
                    },
                    {
                      case: {
                        $and: [{ $gt: ["$x12", 175] }, { $lte: ["$x12", 200] }],
                      },
                      then: 175,
                    },
                    {
                      case: {
                        $and: [{ $gt: ["$x12", 200] }, { $lte: ["$x12", 225] }],
                      },
                      then: 200,
                    },
                    {
                      case: {
                        $and: [{ $gt: ["$x12", 225] }, { $lte: ["$x12", 250] }],
                      },
                      then: 225,
                    },
                    {
                      case: {
                        $and: [{ $gt: ["$x12", 250] }, { $lte: ["$x12", 275] }],
                      },
                      then: 250,
                    },
                    {
                      case: {
                        $and: [{ $gt: ["$x12", 275] }, { $lte: ["$x12", 300] }],
                      },
                      then: 275,
                    },
                    {
                      case: {
                        $and: [{ $gt: ["$x12", 300] }, { $lte: ["$x12", 325] }],
                      },
                      then: 300,
                    },
                    {
                      case: {
                        $and: [{ $gt: ["$x12", 325] }, { $lte: ["$x12", 350] }],
                      },
                      then: 325,
                    },
                    {
                      case: {
                        $and: [{ $gt: ["$x12", 350] }, { $lte: ["$x12", 375] }],
                      },
                      then: 350,
                    },
                    {
                      case: {
                        $and: [{ $gt: ["$x12", 375] }, { $lte: ["$x12", 400] }],
                      },
                      then: 375,
                    },
                    {
                      case: {
                        $and: [{ $gt: ["$x12", 400] }, { $lte: ["$x12", 425] }],
                      },
                      then: 400,
                    },
                    {
                      case: {
                        $and: [{ $gt: ["$x12", 425] }, { $lte: ["$x12", 450] }],
                      },
                      then: 425,
                    },
                    {
                      case: {
                        $and: [{ $gt: ["$x12", 450] }, { $lte: ["$x12", 475] }],
                      },
                      then: 450,
                    },
                    {
                      case: {
                        $and: [{ $gt: ["$x12", 475] }, { $lte: ["$x12", 500] }],
                      },
                      then: 475,
                    },
                    { case: { $gte: ["$x12", 500] }, then: "Unknown" },
                  ],
                },
              },
            },
          },
          {
            $group: {
              _id: "$distancerange",
              vehicle_count: { $sum: 1 },
            },
          },

          {
            /**
             * Provide any number of field/order pairs.
             */
            $sort: {
              _id: 1,
            },
          },
        ]);

        result.histograms[i] = vehicleHistogram.reduce(
          (acc, cum) => [
            ...acc,
            {
              x: parseInt(cum["_id"]) + 12.5,
              y: parseInt(cum["vehicle_count"]),
            },
          ],
          []
        );

        console.log(vehicleHistogram)

        let distancePercentile = await VehicleDailyData.aggregate([
          {
            $match: {
              date: {
                $gte: startDate,
                $lte: endDate,
              },
              x12: {
                $gt: distance,
                $lte: 500,
              },
              topic: {
                $in: vinsList.reduce(
                  (acc, cum) =>
                    cum.dataValues.category === i
                      ? [...acc, cum.dataValues.VIN]
                      : acc,
                  []
                ),
              },
            },
          },
          {
            $sort: {
              x12: 1,
            },
          },
          {
            $group: {
              _id: null,
              value: {
                $push: "$x12",
              },
            },
          },
          {
            $project: {
              _id: 0,
              0: {
                $arrayElemAt: [
                  "$value",
                  {
                    $floor: {
                      $multiply: [
                        0,
                        {
                          $size: "$value",
                        },
                      ],
                    },
                  },
                ],
              },
              30: {
                $arrayElemAt: [
                  "$value",
                  {
                    $floor: {
                      $multiply: [
                        0.3,
                        {
                          $size: "$value",
                        },
                      ],
                    },
                  },
                ],
              },
              50: {
                $arrayElemAt: [
                  "$value",
                  {
                    $floor: {
                      $multiply: [
                        0.5,
                        {
                          $size: "$value",
                        },
                      ],
                    },
                  },
                ],
              },
              70: {
                $arrayElemAt: [
                  "$value",
                  {
                    $floor: {
                      $multiply: [
                        0.7,
                        {
                          $size: "$value",
                        },
                      ],
                    },
                  },
                ],
              },
              100: {
                $arrayElemAt: [
                  "$value",
                  {
                    $floor: {
                      $multiply: [
                        1,
                        {
                          $subtract: [
                            {
                              $size: "$value",
                            },
                            1, // Subtract 1 to ensure the index is within bounds
                          ],
                        },
                      ],
                    },
                  },
                ],
              },
            },
          },
        ]);

        result.lines[i] = Object.entries(distancePercentile[0]).reduce(
          (acc, cum) => [...acc, { x: Number(cum[1]), y: Number(cum[0]) }],
          []
        );

        let efficiencyPercentile = await VehicleDailyData.aggregate([
          {
            $match: {
              date: {
                $gte: startDate,
                $lte: endDate,
              },
              x12: {
                $gt: distance,
                $lte: 500,
              },
              x35: {
                $gte: 60,
                $lte: 200,
              },
              topic: {
                $in: vinsList.reduce(
                  (acc, cum) =>
                    cum.dataValues.category === i
                      ? [...acc, cum.dataValues.VIN]
                      : acc,
                  []
                ),
              },
            },
          },
          {
            $sort: {
              x35: 1,
            },
          },
          {
            $group: {
              _id: null,
              value: {
                $push: "$x35",
              },
            },
          },
          {
            $project: {
              _id: 0,
              0: {
                $arrayElemAt: [
                  "$value",
                  {
                    $floor: {
                      $multiply: [
                        0,
                        {
                          $size: "$value",
                        },
                      ],
                    },
                  },
                ],
              },
              30: {
                $arrayElemAt: [
                  "$value",
                  {
                    $floor: {
                      $multiply: [
                        0.3,
                        {
                          $size: "$value",
                        },
                      ],
                    },
                  },
                ],
              },
              50: {
                $arrayElemAt: [
                  "$value",
                  {
                    $floor: {
                      $multiply: [
                        0.5,
                        {
                          $size: "$value",
                        },
                      ],
                    },
                  },
                ],
              },
              70: {
                $arrayElemAt: [
                  "$value",
                  {
                    $floor: {
                      $multiply: [
                        0.7,
                        {
                          $size: "$value",
                        },
                      ],
                    },
                  },
                ],
              },
              100: {
                $arrayElemAt: [
                  "$value",
                  {
                    $floor: {
                      $multiply: [
                        1,
                        {
                          $subtract: [
                            {
                              $size: "$value",
                            },
                            1, // Subtract 1 to ensure the index is within bounds
                          ],
                        },
                      ],
                    },
                  },
                ],
              },
            },
          },
        ]);

        result.efficiencyPercentile[i] = Object.entries(
          efficiencyPercentile[0]
        ).reduce(
          (acc, cum) => [...acc, { x: Number(cum[1]), y: Number(cum[0]) }],
          []
        );
      }

      console.log(result)

      return res.json({ status: true, ...result });
    } else {
      vinsList = await Vehicle.findAll({
        where: {
          category: category,
        },
      });

      let result = {
        vehiclePercentile: {
          distancePercentile: [],
          efficiencyPercentile: [],
        },
        vehicleHistogram: [],
        odometerChart: {
          xvalues: [],
          yvalues: [],
        },
      };

      if (!vinsList.length)
        return res.status(204).json({ status: false, error: "No VINs found" });

      let distancePercentile = await VehicleDailyData.aggregate([
        {
          $match: {
            date: {
              $gte: startDate,
              $lte: endDate,
            },
            x12: {
              $gt: distance,
              $lte: 500,
            },
            topic: {
              $in: vinsList.map((item) => item.dataValues.VIN),
            },
          },
        },
        {
          $sort: {
            x12: 1,
          },
        },
        {
          $group: {
            _id: null,
            value: {
              $push: "$x12",
            },
          },
        },
        {
          $project: {
            _id: 0,
            0: {
              $arrayElemAt: [
                "$value",
                {
                  $floor: {
                    $multiply: [
                      0,
                      {
                        $size: "$value",
                      },
                    ],
                  },
                },
              ],
            },
            30: {
              $arrayElemAt: [
                "$value",
                {
                  $floor: {
                    $multiply: [
                      0.3,
                      {
                        $size: "$value",
                      },
                    ],
                  },
                },
              ],
            },
            50: {
              $arrayElemAt: [
                "$value",
                {
                  $floor: {
                    $multiply: [
                      0.5,
                      {
                        $size: "$value",
                      },
                    ],
                  },
                },
              ],
            },
            70: {
              $arrayElemAt: [
                "$value",
                {
                  $floor: {
                    $multiply: [
                      0.7,
                      {
                        $size: "$value",
                      },
                    ],
                  },
                },
              ],
            },
            100: {
              $arrayElemAt: [
                "$value",
                {
                  $floor: {
                    $multiply: [
                      1,
                      {
                        $subtract: [
                          {
                            $size: "$value",
                          },
                          1, // Subtract 1 to ensure the index is within bounds
                        ],
                      },
                    ],
                  },
                },
              ],
            },
          },
        },
      ]);

      result.vehiclePercentile.distancePercentile = Object.entries(
        distancePercentile[0]
      ).reduce(
        (acc, cum) => [...acc, { x: Number(cum[1]), y: Number(cum[0]) }],
        []
      );

      let efficiencyPercentile = await VehicleDailyData.aggregate([
        {
          $match: {
            date: {
              $gte: startDate,
              $lte: endDate,
            },
            x12: {
              $gt: distance,
              $lte: 500,
            },
            x35: {
              $gte: 60,
              $lte: 200,
            },
            topic: {
              $in: vinsList.map((item) => item.dataValues.VIN),
            },
          },
        },
        {
          $sort: {
            x35: 1,
          },
        },
        {
          $group: {
            _id: null,
            value: {
              $push: "$x35",
            },
          },
        },
        {
          $project: {
            _id: 0,
            0: {
              $arrayElemAt: [
                "$value",
                {
                  $floor: {
                    $multiply: [
                      0,
                      {
                        $size: "$value",
                      },
                    ],
                  },
                },
              ],
            },
            30: {
              $arrayElemAt: [
                "$value",
                {
                  $floor: {
                    $multiply: [
                      0.3,
                      {
                        $size: "$value",
                      },
                    ],
                  },
                },
              ],
            },
            50: {
              $arrayElemAt: [
                "$value",
                {
                  $floor: {
                    $multiply: [
                      0.5,
                      {
                        $size: "$value",
                      },
                    ],
                  },
                },
              ],
            },
            70: {
              $arrayElemAt: [
                "$value",
                {
                  $floor: {
                    $multiply: [
                      0.7,
                      {
                        $size: "$value",
                      },
                    ],
                  },
                },
              ],
            },
            100: {
              $arrayElemAt: [
                "$value",
                {
                  $floor: {
                    $multiply: [
                      1,
                      {
                        $subtract: [
                          {
                            $size: "$value",
                          },
                          1, // Subtract 1 to ensure the index is within bounds
                        ],
                      },
                    ],
                  },
                },
              ],
            },
          },
        },
      ]);

      result.vehiclePercentile.efficiencyPercentile = Object.entries(
        efficiencyPercentile[0]
      ).reduce(
        (acc, cum) => [...acc, { x: Number(cum[1]), y: Number(cum[0]) }],
        []
      );

      let vehicleHistogram = await VehicleDailyData.aggregate([
        {
          $match: {
            topic: {
              $in: vinsList.map((item) => item.dataValues.VIN),
            },
            date: {
              $gte: startDate,
              $lte: endDate,
            },
            x12: {
              $gt: distance,
              $lte: 500,
            },
          },
        },
        {
          $project: {
            distancerange: {
              $switch: {
                branches: [
                  {
                    case: {
                      $and: [{ $gte: ["$x12", 0] }, { $lte: ["$x12", 25] }],
                    },
                    then: 0,
                  },
                  {
                    case: {
                      $and: [{ $gt: ["$x12", 25] }, { $lte: ["$x12", 50] }],
                    },
                    then: 25,
                  },
                  {
                    case: {
                      $and: [{ $gt: ["$x12", 50] }, { $lte: ["$x12", 75] }],
                    },
                    then: 50,
                  },
                  {
                    case: {
                      $and: [{ $gt: ["$x12", 75] }, { $lte: ["$x12", 100] }],
                    },
                    then: 75,
                  },
                  {
                    case: {
                      $and: [{ $gt: ["$x12", 100] }, { $lte: ["$x12", 125] }],
                    },
                    then: 100,
                  },
                  {
                    case: {
                      $and: [{ $gt: ["$x12", 125] }, { $lte: ["$x12", 150] }],
                    },
                    then: 125,
                  },
                  {
                    case: {
                      $and: [{ $gt: ["$x12", 150] }, { $lte: ["$x12", 175] }],
                    },
                    then: 150,
                  },
                  {
                    case: {
                      $and: [{ $gt: ["$x12", 175] }, { $lte: ["$x12", 200] }],
                    },
                    then: 175,
                  },
                  {
                    case: {
                      $and: [{ $gt: ["$x12", 200] }, { $lte: ["$x12", 225] }],
                    },
                    then: 200,
                  },
                  {
                    case: {
                      $and: [{ $gt: ["$x12", 225] }, { $lte: ["$x12", 250] }],
                    },
                    then: 225,
                  },
                  {
                    case: {
                      $and: [{ $gt: ["$x12", 250] }, { $lte: ["$x12", 275] }],
                    },
                    then: 250,
                  },
                  {
                    case: {
                      $and: [{ $gt: ["$x12", 275] }, { $lte: ["$x12", 300] }],
                    },
                    then: 275,
                  },
                  {
                    case: {
                      $and: [{ $gt: ["$x12", 300] }, { $lte: ["$x12", 325] }],
                    },
                    then: 300,
                  },
                  {
                    case: {
                      $and: [{ $gt: ["$x12", 325] }, { $lte: ["$x12", 350] }],
                    },
                    then: 325,
                  },
                  {
                    case: {
                      $and: [{ $gt: ["$x12", 350] }, { $lte: ["$x12", 375] }],
                    },
                    then: 350,
                  },
                  {
                    case: {
                      $and: [{ $gt: ["$x12", 375] }, { $lte: ["$x12", 400] }],
                    },
                    then: 375,
                  },
                  {
                    case: {
                      $and: [{ $gt: ["$x12", 400] }, { $lte: ["$x12", 425] }],
                    },
                    then: 400,
                  },
                  {
                    case: {
                      $and: [{ $gt: ["$x12", 425] }, { $lte: ["$x12", 450] }],
                    },
                    then: 425,
                  },
                  {
                    case: {
                      $and: [{ $gt: ["$x12", 450] }, { $lte: ["$x12", 475] }],
                    },
                    then: 450,
                  },
                  {
                    case: {
                      $and: [{ $gt: ["$x12", 475] }, { $lte: ["$x12", 500] }],
                    },
                    then: 475,
                  },
                  { case: { $gte: ["$x12", 500] }, then: "Unknown" },
                ],
              },
            },
          },
        },
        {
          $group: {
            _id: "$distancerange",
            vehicle_count: { $sum: 1 },
          },
        },

        {
          /**
           * Provide any number of field/order pairs.
           */
          $sort: {
            _id: 1,
          },
        },
      ]);

      result.vehicleHistogram = vehicleHistogram.reduce(
        (acc, cum) => [
          ...acc,
          { x: parseInt(cum["_id"]) + 12.5, y: parseInt(cum["vehicle_count"]) },
        ],
        []
      );

      let odometerChart = await VehicleDailyData.aggregate([
        {
          $match: {
            topic: {
              $in: vinsList.map((item) => item.dataValues.VIN),
            },
            date: {
              $gte: startDate,
              $lte: endDate,
            },
            x12: {
              $gt: distance,
              $lte: 500,
            },
          },
        },
        {
          $group: {
            _id: {
              topic: "$topic",
            },
            max_date: { $max: "$date" },
            x11: { $last: "$x11" },
          },
        },
        {
          /**
           * _id: The id of the group.
           * fieldN: The first field name.
           */
          $group: {
            _id: "$_id.topic",
            "0-500": { $sum: { $cond: [{ $lte: ["$x11", 500] }, 1, 0] } },
            "500-1000": {
              $sum: {
                $cond: [
                  { $and: [{ $gt: ["$x11", 500] }, { $lte: ["$x11", 1000] }] },
                  1,
                  0,
                ],
              },
            },
            "1000-5000": {
              $sum: {
                $cond: [
                  { $and: [{ $gt: ["$x11", 1000] }, { $lte: ["$x11", 5000] }] },
                  1,
                  0,
                ],
              },
            },
            "5000-10000": {
              $sum: {
                $cond: [
                  {
                    $and: [{ $gt: ["$x11", 5000] }, { $lte: ["$x11", 10000] }],
                  },
                  1,
                  0,
                ],
              },
            },
            "10000-20000": {
              $sum: {
                $cond: [
                  {
                    $and: [{ $gt: ["$x11", 10000] }, { $lte: ["$x11", 20000] }],
                  },
                  1,
                  0,
                ],
              },
            },
            "20000-30000": {
              $sum: {
                $cond: [
                  {
                    $and: [{ $gt: ["$x11", 20000] }, { $lte: ["$x11", 30000] }],
                  },
                  1,
                  0,
                ],
              },
            },
            "30000-40000": {
              $sum: {
                $cond: [
                  {
                    $and: [{ $gt: ["$x11", 30000] }, { $lte: ["$x11", 40000] }],
                  },
                  1,
                  0,
                ],
              },
            },
            "40000-50000": {
              $sum: {
                $cond: [
                  {
                    $and: [{ $gt: ["$x11", 40000] }, { $lte: ["$x11", 50000] }],
                  },
                  1,
                  0,
                ],
              },
            },
          },
        },
        {
          /**
           * _id: The id of the group.
           * fieldN: The first field name.
           */
          $group: {
            _id: null,
            "0-500": { $sum: "$0-500" },
            "500-1000": { $sum: "$500-1000" },
            "1000-5000": { $sum: "$1000-5000" },
            "5000-10000": { $sum: "$5000-10000" },
            "10000-20000": { $sum: "$10000-20000" },
            "20000-30000": { $sum: "$20000-30000" },
            "30000-40000": { $sum: "$30000-40000" },
            "40000-50000": { $sum: "$40000-50000" },
          },
        },
      ]);

      let odometerXValues = Object.keys(odometerChart[0]).filter(
        (key) => key !== "_id"
      );
      let odometerYValues = Object.entries(odometerChart[0]).reduce(
        (acc, cum) => (cum[0] === "_id" ? acc : [...acc, cum[1]]),
        []
      );
      result.odometerChart.xvalues = odometerXValues;
      result.odometerChart.yvalues = odometerYValues;

      return res.json({ status: true, ...result });
    }
  } catch (error) {
    return res.json(error);
  }
};

module.exports = { getCustomerCategoryData, getCustomerCategoryAnalysis };
