const httpStatus = require('http-status');
const VehicleJobCard  = require('../../models/vehicleJobCard');
// const ApiError = require('../utils/ApiError');
const moment=require('moment');
const mongoose = require('mongoose');
const { response } = require('express');

connection = (url) => {
    mongoose.connect(url, {useNewUrlParser: true,})
}

const url="mongodb+srv://alti-admin-prod:APL2023ADMIN@mqtt-production.iqeii.mongodb.net/mqttDatabase_aplmq";

const TestService = async (req,res) => {
    try {
        const {vin, vehicle_reg_number}=req.body
        await connection(url);
        let data=null;
   if (vin !== '') {
   data=await VehicleJobCard.find({ 'VehicleDetail.ChassisNo': vin }, { _id: 0, __v: 0 });
   return res.json(data)
}

  if (vehicle_reg_number !== ''){
     data=await VehicleJobCard.find({ 'VehicleDetail.RegNo': vehicle_reg_number }, { _id: 0, __v: 0 });
     return res.json(data)
    }

     return res.json(data)
    } catch (error) {
        console.log(error);
        return res.json(error);
    }
   
};

const MonthWiseJobCards = async (req,res) => {
    try {
        let {date}=req.body;  
        date=moment(new Date(date)).format("YYYY-MM")
        await connection(url);
        let query = await VehicleJobCard.find(
          { 'JobCardsDetailsList.Docdate': { $regex: new RegExp(`^${date}`) } },
          { _id: 0 }
        ).select('JobCardsDetailsList VehicleDetail');
      
        let result = [];
        query.map((item) => {
          item.JobCardsDetailsList.map((item1) => {
            if (item1['Docdate'].startsWith(date)) {
              result.push({ JobCardsDetails: item1, VehicleDetails: item.VehicleDetail });
            }
          });
        });
        return res.json(result);
    } catch (error) {
        return res.json(error);
        
    }


};

const vinList = async (req,res) => {
    try {
  console.log('hi')
  await connection(url);
  console.log('hello')
  const query =await VehicleJobCard.aggregate([
    {
      $group: {
        _id: { $first: '$VehicleDetail.ChassisNo' },
        label: {
          $first: {
            $concat: [{ $first: '$VehicleDetail.ChassisNo' }, ' | ', { $first: '$VehicleDetail.RegNo' }],
          },
        },
        value: {
          $first: { $first: '$VehicleDetail.ChassisNo' },
        },
      },
    },
    {
      $project: {
        _id: 0,
        label: 1,
        value: 1,
      },
    },
  ]);
  console.log(query);
  return res.json(query);
    } catch (error) {
        console.log(error);
        return res.json(error);
    }
  
};

const MonthWiseUsingAggregate = async (req,res) => {
    try {
        await connection(url);
        let {date}=req.body;
        date=moment(new Date(date)).format("YYYY-MM")
        const query =await  VehicleJobCard.aggregate([
          {
            $unwind: '$JobCardsDetailsList',
          },
          {
            $match: {
              'JobCardsDetailsList.Docdate': { $regex: new RegExp(`^${date}`) },
            },
          },
          {
            $replaceRoot: {
              newRoot: { JobCards: '$JobCardsDetailsList', vehicleDetails: '$VehicleDetail' },
            },
          },
          {
            $project:{
              _id:0,
              JobCards:1,
              vehicleDetails:1
            }
          },
          {
            $group: {
              _id: {
                JobCards: '$JobCards',
                vehicleDetails: '$vehicleDetails'
              }
            }
          },
          {
            $project: {
              _id: 0,
              JobCards: '$_id.JobCards',
              vehicleDetails: '$_id.vehicleDetails'
            }
          }
        ]);
        return res.json(query);
    } catch (error) {
        return res.json(error);
    }
  
};

const OdoWiseAggregate=async(req,res)=>{

    try {
        await connection(url);
        let {date,odo}=req.body;
        date=moment(new Date(date)).format("YYYY-MM")
        console.log(date);
        if(date==undefined || odo==undefined){
          return {Message:"Bad Request: Either Date or Odo is missing"}
        }
      let query=null
      if(odo==""){
        query=await VehicleJobCard.aggregate([
      {
        $unwind:'$JobCardsDetailsList',
      },
      {
        $unwind:'$JobCardsDetailsList.SpareList'
      },
      {
        $match:{
          "JobCardsDetailsList.Docdate":{
            $regex:`^${date}`
          },
        }
      },
      {
        $replaceRoot:{
          newRoot:{
            JobCards:"$JobCardsDetailsList",
            Vehicles:{$first:"$VehicleDetail"}  
          }
        }
      },
      {
        $project:{
       vin:"$Vehicles.ChassisNo",
       reg_No:"$Vehicles.RegNo",
       PartName:"$JobCards.SpareList.partName",
       PartNumber:"$JobCards.SpareList.partNumber",
       DocDate:"$JobCards.Docdate", 
       Model:"$Vehicles.ModelName",
       Odometer:"$Vehicles.KMReading",
       serviceType:"$JobCards.SpareList.serviceType",
       Qty:"$JobCards.SpareList.Qty",
       Amount:"$JobCards.SpareList.Amount",
        
        }
      },
      {
        $group: {
          _id: {
            vin: '$vin',
            reg_No: '$reg_No',
            PartName: '$PartName',
            PartNumber: '$PartNumber',
            DocDate: '$DocDate',
            Model: '$Model',
            Odometer: '$Odometer',
            serviceType: '$serviceType',
            Qty: '$Qty',
            Amount: '$Amount'
          }
        }
      },
      {
        $project: {
          _id: 0,
          vin: '$_id.vin',
          reg_No: '$_id.reg_No',
          PartName: '$_id.PartName',
          PartNumber: '$_id.PartNumber',
          DocDate: '$_id.DocDate',
          Model: '$_id.Model',
          Odometer: '$_id.Odometer',
          serviceType: '$_id.serviceType',
          Qty: '$_id.Qty',
          Amount: '$_id.Amount'
        }
      }
        ])
      }
      if(odo.indexOf("-")!==-1){
        startOdo=Number(odo.split("-")[0])
        endOdo=Number(odo.split("-")[1])
        query=await VehicleJobCard.aggregate([
          {
            $unwind:'$JobCardsDetailsList',
          },
          {
            $unwind:'$JobCardsDetailsList.SpareList'
          },
          {
            $match:{
              "JobCardsDetailsList.Docdate":{
                $regex:`^${date}`
              },
              "VehicleDetail.KMReading":{
                $gte:startOdo,
                $lte:endOdo
              }
            }
          },
          {
            $replaceRoot:{
              newRoot:{
                JobCards:"$JobCardsDetailsList",
                Vehicles:{$first:"$VehicleDetail"}  
              }
            }
          },
          {
            $project:{
           vin:"$Vehicles.ChassisNo",
           reg_No:"$Vehicles.RegNo",
           PartName:"$JobCards.SpareList.partName",
           PartNumber:"$JobCards.SpareList.partNumber",
           DocDate:"$JobCards.Docdate", 
           Model:"$Vehicles.ModelName",
           Odometer:"$Vehicles.KMReading",
           serviceType:"$JobCards.SpareList.serviceType",
           Qty:"$JobCards.SpareList.Qty",
           Amount:"$JobCards.SpareList.Amount",
            
            }
          },
          {
            $group: {
              _id: {
                vin: '$vin',
                reg_No: '$reg_No',
                PartName: '$PartName',
                PartNumber: '$PartNumber',
                DocDate: '$DocDate',
                Model: '$Model',
                Odometer: '$Odometer',
                serviceType: '$serviceType',
                Qty: '$Qty',
                Amount: '$Amount'
              }
            }
          },
          {
            $project: {
              _id: 0,
              vin: '$_id.vin',
              reg_No: '$_id.reg_No',
              PartName: '$_id.PartName',
              PartNumber: '$_id.PartNumber',
              DocDate: '$_id.DocDate',
              Model: '$_id.Model',
              Odometer: '$_id.Odometer',
              serviceType: '$_id.serviceType',
              Qty: '$_id.Qty',
              Amount: '$_id.Amount'
            }
          }
            ])
      }
      if(odo.indexOf(">")!==-1){
      endOdo=Number(odo.split(">")[1]);
      query=await VehicleJobCard.aggregate([
        {
          $unwind:'$JobCardsDetailsList',
        },
        {
          $unwind:'$JobCardsDetailsList.SpareList'
        },
        {
          $match:{
            "JobCardsDetailsList.Docdate":{
              $regex:`^${date}`
            },
            "VehicleDetail.KMReading":{
              $gte:endOdo,
            }
          }
        },
        {
          $replaceRoot:{
            newRoot:{
              JobCards:"$JobCardsDetailsList",
              Vehicles:{$first:"$VehicleDetail"}  
            }
          }
        },
        {
          $project:{
         vin:"$Vehicles.ChassisNo",
         reg_No:"$Vehicles.RegNo",
         PartName:"$JobCards.SpareList.partName",
         PartNumber:"$JobCards.SpareList.partNumber",
         DocDate:"$JobCards.Docdate", 
         Model:"$Vehicles.ModelName",
         Odometer:"$Vehicles.KMReading",
         serviceType:"$JobCards.SpareList.serviceType",
         Qty:"$JobCards.SpareList.Qty",
         Amount:"$JobCards.SpareList.Amount",
          
          }
        },
        {
          $group: {
            _id: {
              vin: '$vin',
              reg_No: '$reg_No',
              PartName: '$PartName',
              PartNumber: '$PartNumber',
              DocDate: '$DocDate',
              Model: '$Model',
              Odometer: '$Odometer',
              serviceType: '$serviceType',
              Qty: '$Qty',
              Amount: '$Amount'
            }
          }
        },
        {
          $project: {
            _id: 0,
            vin: '$_id.vin',
            reg_No: '$_id.reg_No',
            PartName: '$_id.PartName',
            PartNumber: '$_id.PartNumber',
            DocDate: '$_id.DocDate',
            Model: '$_id.Model',
            Odometer: '$_id.Odometer',
            serviceType: '$_id.serviceType',
            Qty: '$_id.Qty',
            Amount: '$_id.Amount'
          }
        }
          ])
      }
      
        return res.json(query);
        
    } catch (error) {
       return res.json(error); 
    }


}

module.exports = {
  TestService,
  MonthWiseJobCards,
  vinList,
  MonthWiseUsingAggregate,
  OdoWiseAggregate
};