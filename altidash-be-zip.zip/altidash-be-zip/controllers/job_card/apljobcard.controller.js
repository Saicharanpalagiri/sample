const httpStatus = require("http-status");
const AplJobCards = require("../../models/AplJobCards");
const Vehicle = require("../../models/vehicle");
const ClientVehicle = require("../../models/client-vehicle");
// const ApiError = require('../utils/ApiError');
const moment = require("moment");
const mongoose = require("mongoose");
const sequelize = require("../../utils/sqldb");
const Client = require("../../models/client");

connection = (url) => {
  mongoose.connect(url, { useNewUrlParser: true });
};

const url =
  "mongodb+srv://alti-admin-prod:APL2023ADMIN@mqtt-production.iqeii.mongodb.net/mqttDatabase_aplmq";

const TestService = async (req, res) => {
  try {
    const { vin } = req.body;
    await connection(url);
    let data = null;
    if (vin !== "") {
      data = await AplJobCards.aggregate([
        {
          $match: {
            vin: vin,
          },
        },
      ]);
      return res.json(data);
    }
    return res.json(data);
  } catch (error) {
    console.log(error);
    return res.json(error);
  }
};

const vinList = async (req, res) => {
  try {
    await connection(url);
    const query = await AplJobCards.aggregate([
      {
        $group: {
          _id: "$vin",
          // label: {
          //   $first:{
          //     $concat:['$vin',' | ',"$registartion_no"]
          //   }
          // },
          label: {
            $first: {
              $cond: {
                if: { $eq: ["$registartion_no", ""] },
                then: "$vin",
                else: { $concat: ["$vin", " | ", "$registartion_no"] },
              },
            },
          },
          value: { $first: "$vin" },
        },
      },
      {
        $project: {
          _id: 0,
          label: 1,
          value: 1,
          reg: 1,
        },
      },
    ]);
    console.log(query.length);
    return res.json({ status: true, code: 200, data: query });
  } catch (error) {
    console.log(error);
    return res.json({ status: false, code: 500, error: error });
  }
};

const MonthWiseCards = async (req, res) => {
  try {
    await connection(url);
    let { date } = req.body;
    if (date === "") {
      const dateQuery = await AplJobCards.aggregate([
        {
          $sort: { repair_order_date: -1 },
        },
        {
          $limit: 1,
        },
        {
          $project: {
            _id: 0,
            date: {
              $substr: ["$repair_order_date", 3, 8],
            },
          },
        },
      ]);
      date = dateQuery[0]["date"];
    } else {
      date = moment(new Date(date)).format("MM-YYYY");
    }
    date = date + "$";
    let query = await AplJobCards.aggregate([
      {
        $match: {
          repair_order_date: { $regex: new RegExp(date) },
        },
      },
      // {
      //   $addFields: {
      //     convertedDate: {
      //       $dateFromString: {
      //         dateString: {
      //           $concat: [
      //             { $substr: ['$repair_order_date', 6, 4] },
      //             '-',
      //             { $substr: ['$repair_order_date', 3, 2] },
      //             '-',
      //             { $substr: ['$repair_order_date', 0, 2] }
      //           ]
      //         },
      //         format: '%Y-%m-%d'
      //       }
      //     }
      //   }
      // },
      // {
      //   $sort: {
      //     convertedDate: -1
      //   }
      // },
      {
        $sort: {
          repair_order_date: -1,
        },
      },
      {
        $project: {
          _id: 0,
          vin: "$vin",
          vehicle_reg_num: "$registartion_no",
          date: "$repair_order_date",
          repair_order_no: "$repair_order_no",
          repair_type: "$repair_type",
          odo: "$kmm",
          "part/labour_group": "$part/labour_group",
          "part/service": "$part/service",
          part_description: "$part_description",
          activeCustomerName: "$activeCustomerName",
          amount: "$total_amount",
          rate: "$rate",
          totalAmount: "$total_amount",
          mechanic: "$mechanic",
          city: "$city",
          state: "$state",
          model: "$model",
          status: "$status",
          rate: "$rate",
          "CGST%": "$CGST%",
          "IGST%": "$IGST%",
          CGST: "$CGST",
          IGST: "$IGST",
          "SGST%": "$SGST%",
          SGST: "$SGST",
        },
      },
    ]);
    if (query) {
      query = query.map((i) => {
        return {
          ...i,
          amount: Number(i.amount).toLocaleString("en-IN"),
          rate: Number(i.rate).toLocaleString("en-IN"),
        };
      });
    }
    return res.json({ status: true, code: 200, date: query });
  } catch (error) {
    console.log(error);
    return res.json({ status: false, code: 500, error: error });
  }
};

const fleetSelector = async (req, res) => {
  try {
    await sequelize.sync();
    let data = await Client.findAll(
      { attributes: ["clientCode"] },
      { where: { deleteClientStatus: 0 } }
    );
    return res.json({
      status: true,
      code: 200,
      data: data.map((i) => {
        return {
          label: i.clientCode,
          value: i.clientCode,
        };
      }),
    });
  } catch (error) {
    return res.json({ status: false, code: 500, error: error });
  }
};

const vinJobCards = async (req, res) => {
  try {
    let { fleet, date } = req.body;
    await connection(url);
    Vehicle.belongsToMany(Client, {
      through: ClientVehicle,
      foreignKey: "vid",
    });
    Client.belongsToMany(Vehicle, {
      through: ClientVehicle,
      foreignKey: "cid",
    });
    await sequelize.sync();
    const vinQuery = await Vehicle.findAll({
      include: [
        {
          model: Client,
          attributes: [],
          where: { clientCode: fleet },
        },
      ],
 //     where: { deletevehicleStatus: 0, Immob_status: 1 },
      raw: true,
      nest: true,
      attributes: ["VIN"],
    });
    console.log(vinQuery,'vinQuery')
    date = moment(date).format("MM-YYYY");
    date = date + "$";
    console.log(date, "date");
    const vins = vinQuery.map((i) => i.VIN.slice(3));
    const mainQuery = await AplJobCards.aggregate([
      [
        {
          $match: {
            vin: {
              $in: vins,
            },
            repair_order_date: { $regex: new RegExp(date) },
          },
        },
        {
          $addFields: {
            convertedDate: {
              $dateFromString: {
                dateString: {
                  $concat: [
                    { $substr: ["$repair_order_date", 6, 4] },
                    "-",
                    { $substr: ["$repair_order_date", 3, 2] },
                    "-",
                    // { $substr: ['$repair_order_date', 0, 2] }
                    {
                      $cond: {
                        if: {
                          $eq: [
                            { $substr: ["$repair_order_date", 0, 2] },
                            "00",
                          ],
                        },
                        then: "01",
                        else: { $substr: ["$repair_order_date", 0, 2] },
                      },
                    },
                  ],
                },
                format: "%Y-%m-%d",
              },
            },
          },
        },
        {
          $sort: {
            convertedDate: -1,
          },
        },
        // {$limit:15000},
        {
          $facet: {
            groupByRepairType: [
              {
                $group: {
                  _id: {
                    $trim: {
                      input: "$repair_type",
                    },
                  },
                  count: {
                    $sum: 1,
                  },
                  uniquevins: {
                    $addToSet: "$vin",
                  },
                  amount: {
                    $sum: {
                      $cond: {
                        if: {
                          $and: [
                            { $ne: ["$total_amount", "NA"] },
                            { $ne: ["$total_amount", ""] },
                          ],
                        },
                        then: { $toDouble: "$total_amount" },
                        else: 0,
                      },
                    },
                  },
                  matchingObjects: {
                    $push: "$$ROOT",
                  },
                },
              },
              {
                $project: {
                  _id: 0,
                  repair_type: "$_id",
                  count: "$count",
                  array: "$matchingObjects",
                  amount: "$amount",
                  uniquevins: "$uniquevins",
                },
              },
            ],
          },
        },
        {
          $project: {
            "groupByRepairType.array._id": 0,
          },
        },
      ],
    ]);
    console.log(mainQuery, "mainQuery");

    // return res.json({mainQuery})
    let val = {
      repair_type: "",
      count: 0,
      amount: 0,
      array: [],
      vins: [],
      uniquevins: 0,
      length: 0,
    };
    const result = {
      "First Free Service": { ...val, repair_type: "First Free Service" },
      "Second Free Service": { ...val, repair_type: "Second Free Service" },
      "Third Free Service": { ...val, repair_type: "Third Free Service" },
      "Fourth Free Service": { ...val, repair_type: "Fourth Free Service" },
      "Accidental Paid": { ...val, repair_type: "Accidental Paid" },
      Paid: { ...val, repair_type: "Paid" },
      "Running Repair": { ...val, repair_type: "Running Repair" },
      "Accidental Insurance": { ...val, repair_type: "Accidental Insurance" },
      Warranty: { ...val, repair_type: "Warranty" },
      PDI: {...val,repair_type:'PDI'},
      "Pre Sales Repair Order":{...val,repair_type:'Pre Sales Repair Order'}
    };
    if (mainQuery) {
      mainQuery[0].groupByRepairType.map((item) => {
        if (item.repair_type !== "NULL") {
          let vinset = new Set();
          const dat = item.array.map((i) => {
            // console.log(i,'oi')
            vinset.add(i.repair_order_no);
            return {
              repair_order_no: i.repair_order_no,
              vin: i.vin,
              vehicle_reg_num: i.registartion_no,
              date: i.repair_order_date,
              repair_type: i.repair_type,
              odo: i.kmm,
              "part/service": i["part/service"],
              part_description: i.part_description,
              activeCustomerName: i.activeCustomerName.trim(),
              amount: i.amount,
              rate: i.rate,
              totalAmount: i.total_amount,
              mechanic: i.mechanic,
              city: i.city,
              state: i.state,
              model: i.model,
              status: i.status,
              "part/labour_group": i["part/labour_group"],
              "CGST%": i["CGST%"],
              "IGST%": i["IGST%"],
              CGST: i["CGST"],
              IGST: i["IGST"],
              "SGST%": i["SGST%"],
              SGST: i["SGST"],
            };
          });
          result[item.repair_type] = {
            ...item,
            amount: item.amount.toFixed(2),
            array: dat,
            vins: item.uniquevins,
            uniquevins: item.uniquevins.length,
            length: vinset.size,
          };
        }
      });
    }
    let count = 0,
      allArray = [];
    const vinSet = new Set();
    Object.keys(result).map((item) => {
      count += Number(result[item].amount);
      result[item]["array"].map((i) => vinSet.add(i.vin));
      allArray = [...allArray, ...result[item]["array"]];
    });
    const set = new Set();
    allArray.map((item) => set.add(item["repair_order_no"]));
    return res.json({
      status: true,
      code: 200,
      summary: {
        totalAmount: count.toFixed(2),
        length: set.size,
        jobcards: allArray,
        vins: Array.from(vinSet),
        uniquevins: Array.from(vinSet).length,
      },
      data: result,
    });
  } catch (error) {
    console.log(error, "err");
    return res.json({ status: false, code: 500, error: error });
  }
};
const formatData = (data) => {
  const result = {
    "First Free Service": [],
    "Second Free Service": [],
    "Third Free Service": [],
    "Fourth Free Service": [],
    "Accidental Paid": [],
    Paid: [],
    "Running Repair": [],
    "Accidental Insurance": [],
    Warranty: [],
  };
  if (data) {
    data.map((item) => {
      if (item.repair_type !== "NULL") {
        result[item.repair_type.trim()] = {
          vin: item.vin,
          vehicle_reg_num: item.registartion_no,
          city: item.city,
          state: item.state,
          model: item.model,
          odo: item["kmm"],
          activeCustomerName: item["activeCustomerName"],
          partData: [],
        };
      }
    });
  }
  return result;
};

const newjobcards = async (req, res) => {
  try {
    let { date, fleet } = req.body;
    Vehicle.belongsToMany(Client, {
      through: ClientVehicle,
      foreignKey: "vid",
    });
    Client.belongsToMany(Vehicle, {
      through: ClientVehicle,
      foreignKey: "cid",
    });
    await sequelize.sync();
    const vinQuery = await Vehicle.findAll({
      include: [
        {
          model: Client,
          attributes: [],
          where: { clientCode: fleet },
        },
      ],
      where: { deletevehicleStatus: 0, Immob_status: 1 },
      raw: true,
      nest: true,
      attributes: ["VIN"],
    });
    await connection(url);
    const vins = vinQuery.map((i) => i.VIN.slice(3));
    date = moment(date).format("MM-YYYY");
    date = date + "$";
    console.log(date, "date");
    const mainQuery = await AplJobCards.aggregate([
      [
        {
          $match: {
            vin: {
              $in: vins,
            },
            repair_order_date: { $regex: new RegExp(date) },
          },
        },
        {
          $addFields: {
            convertedDate: {
              $dateFromString: {
                dateString: {
                  $concat: [
                    { $substr: ["$repair_order_date", 6, 4] },
                    "-",
                    { $substr: ["$repair_order_date", 3, 2] },
                    "-",
                    // { $substr: ['$repair_order_date', 0, 2] }
                    {
                      $cond: {
                        if: {
                          $eq: [
                            { $substr: ["$repair_order_date", 0, 2] },
                            "00",
                          ],
                        },
                        then: "01",
                        else: { $substr: ["$repair_order_date", 0, 2] },
                      },
                    },
                  ],
                },
                format: "%Y-%m-%d",
              },
            },
          },
        },
        {
          $sort: {
            convertedDate: -1,
          },
        },
        // {
        //   $group:{
        //     '_id':'$repair_order_no',
        //     'vin':{
        //       $first:'$vin'
        //     },
        //     'city':{
        //       $first:'$city'
        //     },
        //     'state':{
        //       $first:'$state'
        //     },
        //     // value:{
        //     //   $push:{
        //     //     'part/service':'$$ROOT.part_description',
        //     //     'rate':'$$ROOT.rate',
        //     //     'amount':'$$ROOT.amount',
        //     //     'status':'$$ROOT.status',
        //     //     'mechanic':'$$ROOT.mechanic',
        //     //     'total_amount':'$$ROOT.total_amount',
        //     //     'rate':'$$ROOT.rate'
        //     // }
        //     // }
        //   }
        // }
      ],
    ]);
    const data = {};
    console.log(mainQuery.length);
    for (let i of mainQuery) {
      data[i["repair_order_no"]] = {
        vin: i.vin,
        vehicle_reg_num: i.registartion_no,
        city: i.city,
        state: i.state,
        model: i.model,
        odo: i["kmm"],
        activeCustomerName: i["activeCustomerName"],
        partData: [],
      };
    }
    for (let i of mainQuery) {
      data[i["repair_order_no"]] = {
        ...data[i["repair_order_no"]],
        partData: [
          ...data[i["repair_order_no"]]["partData"],
          {
            part: i["part/service"],
            part_description: i["part_description"],
            rate: i["rate"],
            amount: i["total_amount"],
            "part/labour_group": i["part/labour_group"],
            mechanic: i["mechanic"],
            status: i["status"],
            repair_type: i["repair_type"],
          },
        ],
      };
    }
    console.log(Object.keys(data).length);
    const formattedData = formatData(mainQuery);
    return res.json({
      status: true,
      code: 200,
      data: data,
      formattedData: formattedData,
    });
  } catch (error) {
    console.log(error, "err");
    return res.json({ status: false, code: 500, error: error });
  }
};

const vinselect=async(req,res)=>{
  try {
    const {vin}=req.body;
    await connection(url);
    let data=await AplJobCards.aggregate([
      {
        $match:{
          vin:vin
        }
      },
      {
        $sort:{
          repair_order_date:-1
        }
      },
      {
        $project:{
          _id: 0,
          vehicle_reg_num: "$registartion_no",
          date: "$repair_order_date",
          repair_type: "$repair_type",
          repair_order_no: "$repair_order_no",
          odo: "$kmm",
          "part/labour_group": "$part/labour_group",
          "part/service": "$part/service",
          part_description: "$part_description",
          activeCustomerName: "$activeCustomerName",
          amount: "$total_amount",
          rate: "$rate",
          totalAmount: "$total_amount",
          mechanic: "$mechanic",
          city: "$city",
          state: "$state",
          model: "$model",
          status: "$status",
          rate: "$rate",
          "CGST%": "$CGST%",
          "IGST%": "$IGST%",
          CGST: "$CGST",
          IGST: "$IGST",
          "SGST%": "$SGST%",
          SGST: "$SGST",
        }
      }
    ])
    if(data.length){
    reg_number=data[0].vehicle_reg_num
    data=data.map(item=>{
      return {...item,vehicle_reg_num:reg_number}
    })}
    data.sort((a,b)=>moment(a['date'].split('-').reverse().join('-'))-moment(b['date'].split('-').reverse().join('-')))
    return res.json({status: true, code:200,data:data})
  } catch (error) {
    console.log(error)
    return res.json({ status: false, code: 500, error: error});
  }
}

module.exports = {
  TestService,
  vinList,
  MonthWiseCards,
  fleetSelector,
  vinJobCards,
  newjobcards,
  vinselect
};
