const dealerDetails = require("../../models/dealerDetails");
const dealerMonthly = require("../../models/dealerMonthly");
const VehicleDailyData = require("../../models/vehicleDailyData");
// const ApiError = require('../utils/ApiError');
const moment = require("moment");
const mongoose = require("mongoose");
const { aplToVDD } = require("../../utils/vehicleDailyDataMapping");
const sequelize = require("../../utils/sqldb");
const Vehicle = require("../../models/vehicle");
const { Sequelize, Op } = require("sequelize");
const Client = require("../../models/client");
const ClientVehicle = require("../../models/client-vehicle");



connection = (url) => {
  mongoose.connect(url, { useNewUrlParser: true })
};

const url =
  "mongodb+srv://alti-admin-prod:APL2023ADMIN@mqtt-production.iqeii.mongodb.net/mqttDatabase_aplmq";


const monthNames = {
  1: "January",
  2: "February",
  3: "March",
  4: "April",
  5: "May",
  6: "June",
  7: "July",
  8: "August",
  9: "September",
  10: "October",
  11: "November",
  12: "December",
};

const overViewService = async (req, res) => {
  try {
    await connection(url);
    // console.log('start')
    let leadsThreeMax = await dealerMonthly.aggregate([
      {
        $lookup: {
          from: "dealer_details",
          localField: "dealer_code",
          foreignField: "id",
          as: "deal",
        },
      },
      {
        $unwind: "$deal",
      },
      {
        $match: { "deal.status": 1 },
      },
      {
        $group: {
          _id: "$dealer_code",
          lead_count: { $sum: "$lead_count" },
          dealer_name: { $first: "$deal.dealer_name" },
          zone: { $first: "$deal.zone" },
          state: { $first: "$deal.state" },
          city: { $first: "$deal.city" },
          pincode: { $first: "$deal.pincode" },
        },
      },
      {
        $sort: {
          lead_count: -1,
        },
      },
      {
        $project: {
          _id: 0,
          lead_count: 1,
          dealer_name: 1,
          zone: 1,
          state: 1,
          city: 1,
          pincode: 1,
        },
      },
      {
        $limit: 3,
      },
    ]);

    // console.log(leadsThreeMax);/

    const leadsThreeMin = await dealerMonthly.aggregate([
      {
        $lookup: {
          from: "dealer_details",
          localField: "dealer_code",
          foreignField: "id",
          as: "deal",
        },
      },
      {
        $unwind: "$deal",
      },
      {
        $match: {
          "deal.status": 1,
        },
      },
      {
        $group: {
          _id: "$dealer_code",
          lead_count: { $sum: "$lead_count" },
          dealer_name: { $first: "$deal.dealer_name" },
          zone: { $first: "$deal.zone" },
          state: { $first: "$deal.state" },
          city: { $first: "$deal.city" },
          pincode: { $first: "$deal.pincode" },
          dealer_code:{$first:'$deal.dealer_code'}
        },
      },
      {
        $sort: {
          lead_count: 1,
        },
      },
      {
        $limit: 3,
      },
      {
        $project: {
          _id: 0,
          dealer_code: "$dealer_code",
          lead_count: 1,
          dealer_name: 1,
          zone: 1,
          state: 1,
          city: 1,
          pincode: 1,
        },
      },
    ]);

    /**
     * for getting top 3 and bottom 3 JC_counts from dealers_monthly_report table
     */

    let JcCountThreeMax = await dealerMonthly.aggregate([
      {
        $lookup: {
          from: "dealer_details",
          localField: "dealer_code",
          foreignField: "id",
          as: "deal",
        },
      },
      {
        $unwind: "$deal",
      },
      {
        $match: {
          "deal.status": 1,
        },
      },
      {
        $group: {
          _id: "$dealer_code",
          jc_count: { $sum: "$jc_count" },
          dealer_name: { $first: "$deal.dealer_name" },
          zone: { $first: "$deal.zone" },
          state: { $first: "$deal.state" },
          city: { $first: "$deal.city" },
          pincode: { $first: "$deal.pincode" },
          dealer_code:{$first:'$deal.dealer_code'}
        },
      },
      {
        $sort: {
          jc_count: -1,
        },
      },
      {
        $limit: 3,
      },
      {
        $project: {
          _id: 0,
          dealer_code: "$dealer_code",
          jc_count: 1,
          dealer_name: 1,
          zone: 1,
          state: 1,
          city: 1,
          pincode: 1,
        },
      },
    ]);

    let JcCountThreeMin = await dealerMonthly.aggregate([
      {
        $lookup: {
          from: "dealer_details",
          localField: "dealer_code",
          foreignField: "id",
          as: "deal",
        },
      },
      {
        $unwind: "$deal",
      },
      {
        $match: {
          "deal.status": 1,
        },
      },
      {
        $group: {
          _id: "$dealer_code",
          jc_count: { $sum: "$jc_count" },
          dealer_name: { $first: "$deal.dealer_name" },
          zone: { $first: "$deal.zone" },
          state: { $first: "$deal.state" },
          city: { $first: "$deal.city" },
          pincode: { $first: "$deal.pincode" },
          dealer_code:{$first:'$deal.dealer_code'}
        },
      },
      {
        $sort: {
          jc_count: 1,
        },
      },
      {
        $limit: 3,
      },
      {
        $project: {
          _id: 0,
          dealer_code: "$dealer_code",
          jc_count: 1,
          dealer_name: 1,
          zone: 1,
          state: 1,
          city: 1,
          pincode: 1,
        },
      },
    ]);

    /**
     * for getting top 3 and bottom 3 sales_order leads from dealers_monthly_report
     */

    let soCountThreeMax = await dealerMonthly.aggregate([
      {
        $lookup: {
          from: "dealer_details",
          localField: "dealer_code",
          foreignField: "id",
          as: "deal",
        },
      },
      {
        $unwind: "$deal",
      },
      {
        $match: {
          "deal.status": 1,
        },
      },
      {
        $group: {
          _id: "$dealer_code",
          so_count: { $sum: "$so_count" },
          dealer_name: { $first: "$deal.dealer_name" },
          zone: { $first: "$deal.zone" },
          state: { $first: "$deal.state" },
          city: { $first: "$deal.city" },
          pincode: { $first: "$deal.pincode" },
          dealer_code:{$first:'$deal.dealer_code'}
        },
      },
      {
        $sort: {
          so_count: -1,
        },
      },
      {
        $limit: 3,
      },
      {
        $project: {
          _id: 0,
          dealer_code: "$dealer_code",
          so_count: 1,
          dealer_name: 1,
          zone: 1,
          state: 1,
          city: 1,
          pincode: 1,
        },
      },
    ]);

    let soCountThreeMin = await dealerMonthly.aggregate([
      {
        $lookup: {
          from: "dealer_details",
          localField: "dealer_code",
          foreignField: "id",
          as: "deal",
        },
      },
      {
        $unwind: "$deal",
      },
      {
        $match: {
          "deal.status": 1,
        },
      },
      {
        $group: {
          _id: "$dealer_code",
          so_count: { $sum: "$so_count" },
          dealer_name: { $first: "$deal.dealer_name" },
          zone: { $first: "$deal.zone" },
          state: { $first: "$deal.state" },
          city: { $first: "$deal.city" },
          pincode: { $first: "$deal.pincode" },
          dealer_code:{$first:'$deal.dealer_code'}
        },
      },
      {
        $sort: {
          so_count: 1,
        },
      },
      {
        $limit: 3,
      },
      {
        $project: {
          _id: 0,
          dealer_code: "$dealer_code",
          so_count: 1,
          dealer_name: 1,
          zone: 1,
          state: 1,
          city: 1,
          pincode: 1,
        },
      },
    ]);

    /**
     * for getting top 3 sales_invoice from dealers_monthly_report table
     */

    let siCountThreeMax = await dealerMonthly.aggregate([
      {
        $lookup: {
          from: "dealer_details",
          localField: "dealer_code",
          foreignField: "id",
          as: "deal",
        },
      },
      {
        $unwind: "$deal",
      },
      {
        $match: {
          "deal.status": 1,
        },
      },
      {
        $group: {
          _id: "$dealer_code",
          si_count: { $sum: "$si_count" },
          dealer_name: { $first: "$deal.dealer_name" },
          zone: { $first: "$deal.zone" },
          state: { $first: "$deal.state" },
          city: { $first: "$deal.city" },
          pincode: { $first: "$deal.pincode" },
          dealer_code:{$first:'$deal.dealer_code'}
        },
      },
      {
        $sort: {
          si_count: -1,
        },
      },
      {
        $limit: 3,
      },
      {
        $project: {
          _id: 0,
          dealer_code: "$dealer_code",
          si_count: 1,
          dealer_name: 1,
          zone: 1,
          state: 1,
          city: 1,
          pincode: 1,
        },
      },
    ]);

    let siCountThreeMin = await dealerMonthly.aggregate([
      {
        $lookup: {
          from: "dealer_details",
          localField: "dealer_code",
          foreignField: "id",
          as: "deal",
        },
      },
      {
        $unwind: "$deal",
      },
      {
        $match: {
          "deal.status": 1,
        },
      },
      {
        $group: {
          _id: "$dealer_code",
          si_count: { $sum: "$si_count" },
          dealer_name: { $first: "$deal.dealer_name" },
          zone: { $first: "$deal.zone" },
          state: { $first: "$deal.state" },
          city: { $first: "$deal.city" },
          pincode: { $first: "$deal.pincode" },
          dealer_code:{$first:'$deal.dealer_code'}
        },
      },
      {
        $sort: {
          si_count: 1,
        },
      },
      {
        $limit: 3,
      },
      {
        $project: {
          _id: 0,
          dealer_code: "$dealer_code",
          si_count: 1,
          dealer_name: 1,
          zone: 1,
          state: 1,
          city: 1,
          pincode: 1,
        },
      },
    ]);

    //   /**
    //    * for getting cummulative data from dealers_monthly_report table
    //    */

    let summary = await dealerMonthly.aggregate([
      {
        $group: {
          _id: null,
          leads: { $sum: "$lead_count" },
          jobCards: { $sum: "$jc_count" },
          sales_order: { $sum: "$so_count" },
          sales_invoice: { $sum: "$si_count" },
        },
      },
      {
        $project: {
          _id: 0,
          leads: 1,
          jobCards: 1,
          sales_order: 1,
          sales_invoice: 1,
        },
      },
    ]);

    //   /**
    //    * for comparing zone_wise Data from dealers_monthly_report table
    //    */
    let zoneComparison = await dealerMonthly.aggregate([
      {
        $lookup: {
          from: "dealer_details",
          localField: "dealer_code",
          foreignField: "id",
          as: "deal",
        },
      },
      {
        $unwind: "$deal",
      },
      {
        $match: {
          "deal.status": 1,
        },
      },
      {
        $group: {
          _id: "$dealer_code",
          dealer_name: { $first: "$deal.dealer_name" },
          state: { $first: "$deal.state" },
          city: { $first: "$deal.city" },
          pincode: { $first: "$deal.pincode" },
          zone: { $first: "$deal.zone" },
          dealer_code:{$first:'$deal.dealer_code'}
        },
      },
      {
        $sort: {
          _id: 1,
        },
      },
      {
        $project: {
          _id: 0,
          dealer_code:  "$dealer_code",
          dealer_name: 1,
          state: 1,
          city: 1,
          pincode: 1,
          zone: 1,
        },
      },
    ]);

    let obj = {
      East: [],
      North: [],
      South: [],
      West: [],
    };

    for (let i of zoneComparison) {
      if (i.zone.startsWith("East"))
        obj.East.push(
          Object.fromEntries(
            Object.entries(i).filter((item) => item[0] !== "dealer_code")
          )
        );
      if (i.zone.startsWith("North"))
        obj.North.push(
          Object.fromEntries(
            Object.entries(i).filter((item) => item[0] !== "dealer_code")
          )
        );
      if (i.zone.startsWith("South"))
        obj.South.push(
          Object.fromEntries(
            Object.entries(i).filter((item) => item[0] !== "dealer_code")
          )
        );
      if (i.zone.startsWith("West"))
        obj.West.push(
          Object.fromEntries(
            Object.entries(i).filter((item) => item[0] !== "dealer_code")
          )
        );
    }

    let tableData = await dealerMonthly.aggregate([
      {
        $lookup: {
          from: "dealer_details",
          localField: "dealer_code",
          foreignField: "id",
          as: "deal",
        },
      },
      {
        $unwind: "$deal",
      },
      {
        $match: {
          "deal.status": 1,
        },
      },
      {
        $group: {
          _id: "$deal.dealer_code",
          dealer_name: { $first: "$deal.dealer_name" },
          state: { $first: "$deal.state" },
          city: { $first: "$deal.city" },
          zone: { $first: "$deal.zone" },
          pincode: { $first: "$deal.pincode" },
          leads: { $sum: "$lead_count" },
          sales_invoice: { $sum: "$si_count" },
          job_cards: { $sum: "$jc_count" },
          sales_order: { $sum: "$so_count" },
          sales_po: { $sum: "$vpo_count" },
          service_sales: { $sum: "$ps_count" },
          service_po: { $sum: "$ppo_count" },
          sales_grn: { $sum: "$s_grn_count" },
          dealer_code: { $first: "$deal.dealer_code" },
        },
      },
      {
        $project: {
          _id: 0,
          dealer_name: 1,
          state: 1,
          city: 1,
          zone: 1,
          pincode: 1,
          leads: 1,
          sales_invoice: 1,
          job_cards: 1,
          sales_order: 1,
          sales_po: 1,
          service_sales: 1,
          service_po: 1,
          sales_grn: 1,
          dealer_code: 1,
        },
      },
    ]);

    let zone_comp = await dealerMonthly.aggregate([
      {
        $lookup: {
          from: "dealer_details",
          localField: "dealer_code",
          foreignField: "id",
          as: "deal",
        },
      },
      {
        $unwind: "$deal",
      },
      {
        $match: {
          "deal.status": 1,
        },
      },
      {
        $group: {
          _id: { $trim: { input: "$deal.zone" } },
          leads: { $sum: "$lead_count" },
          jobCards: { $sum: "$jc_count" },
          sales_invoice: { $sum: "$si_count" },
          sales_order: { $sum: "$so_count" },
        },
      },
      {
        $project: {
          _id: 0,
          zone: "$_id",
          leads: 1,
          jobCards: 1,
          sales_invoice: 1,
          sales_order: 1,
        },
      },
    ]);

    let zoneObj = {
      leads: {
        North: 0,
        East: 0,
        West: 0,
        South: 0,
      },
      jobCards: {
        North: 0,
        East: 0,
        West: 0,
        South: 0,
      },
      sales_invoice: {
        North: 0,
        East: 0,
        West: 0,
        South: 0,
      },
      sales_order: {
        North: 0,
        East: 0,
        West: 0,
        South: 0,
      },
    };

    zone_comp.forEach((item) => {
      Object.keys(item).forEach((item1) => {
        if (!(item1 === "zone")) {
          zoneObj[item1][item["zone"].trim()] = item[item1];
        }
      });
    });

    return res.json({
      status:true,
      code:200,
      data:{
      tableData: tableData,
      zone: obj,
      summary: summary,
      maxThree: {
        leads: leadsThreeMax,
        si: siCountThreeMax,
        jc: JcCountThreeMax,
        so: soCountThreeMax,
      },
      minThree: {
        leads: leadsThreeMin,
        si: siCountThreeMin,
        jc: JcCountThreeMin,
        so: soCountThreeMin,
      },
      zone_comp: zoneObj,
    }
    });
  } catch (error) {
    console.log(error);
    return res.json({status:false,
    code:500,
  data:error});
  }
};

const dealersCummulative = async (req, res) => {
  try {
    await connection(url);
    console.log("hi");

    let statData = await dealerMonthly.aggregate([
      {
        $group: {
          _id: {
            year: "$year",
            month: "$month",
          },
          leads: { $sum: "$lead_count" },
          jobCards: { $sum: "$jc_count" },
          sales_order: { $sum: "$so_count" },
          sales_invoice: { $sum: "$si_count" },
        },
      },
      {
        $project: {
          _id: 0,
          year: "$_id.year",
          month: "$_id.month",
          leads: 1,
          jobCards: 1,
          sales_order: 1,
          sales_invoice: 1,
        },
      },
    ]);
    console.log(statData);
    console.log("hi");
    let result = statData.map((item) => {
      return { ...item, month: monthNames[`${item.month}`] };
    });

    return res.json({status:true,data:result});
    // return result;
  } catch (error) {
    return res.json({status:false,data:error});
    // return error;
  }
};

const availableDealers = async (req, res) => {
  try {
    await connection(url);
    let distinctDealers = await dealerMonthly.aggregate([
      {
        $lookup: {
          from: "dealer_details",
          let: { dealerCode: "$dealer_code" },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $eq: ["$id", "$$dealerCode"] },
                    { $eq: ["$status", 1] },
                  ],
                },
              },
            },
          ],
          as: "deal",
        },
      },
      {
        $unwind: "$deal",
      },
      {
        $group: {
          _id: "$deal.id",
          dealer_code: { $first: "$deal.id" },
          dealer_name: { $first: "$deal.dealer_name" },
          city: { $first: "$deal.city" },
        },
      },
      {
        $sort: {
          dealer_code: 1,
        },
      },
      {
        $project: {
          _id: 0,
          dealer_code: 1,
          dealer_name: 1,
          city: 1,
        },
      },
    ]);

    // console.log(distinctDealers);

    const result = distinctDealers.map((item) => {
      return {
        dealer_code: item.dealer_code,
        dealer_name: (item.dealer_name + " " + item.city).trim(),
      };
    });
    return res.json({status:true,
    code:200,
  data:result});
    // return result;
  } catch (error) {
    return res.json({status:false,
    code:500,
    data:error
  });
    // return error;
  }
};

const overviewGraph = async (req, res) => {
  try {
    await connection(url);
    // Aggregation query to get monthly statistics for each dealer
    let statData = await dealerMonthly.aggregate([
      {
        $lookup: {
          from: "dealer_details",
          let: { dealerCode: "$dealer_code" },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $eq: ["$id", "$$dealerCode"] },
                    { $eq: ["$status", 1] },
                  ],
                },
              },
            },
          ],
          as: "deal",
        },
      },
      {
        $unwind: "$deal",
      },
      {
        $group: {
          _id: {
            dealer_code: "$deal.dealer_code",
            year: "$year",
            month: "$month",
          },
          leads: { $sum: "$lead_count" },
          jobCards: { $sum: "$jc_count" },
          sales_invoice: { $sum: "$si_count" },
          sales_order: { $sum: "$so_count" },
          dealer_name: { $first: "$deal.dealer_name" },
          city: { $first: "$deal.city" },
        },
      },
      {
        $project: {
          _id: 0,
          dealer_code: "$_id.dealer_code",
          year: "$_id.year",
          month: "$_id.month",
          leads: 1,
          jobCards: 1,
          sales_invoice: 1,
          sales_order: 1,
          dealer_name: 1,
          city: 1,
        },
      },
      {
        $sort: {
          dealer_code: 1,
          year: 1,
          month: 1,
        },
      },
    ]);

    // Distinct months and years
    let distinctMonthsYears = await dealerMonthly.aggregate([
      {
        $group: {
          _id: {
            month: "$month",
            year: "$year",
          },
        },
      },
      {
        $sort: {
          "_id.year": 1,
          "_id.month": 1,
        },
      },
      {
        $project: {
          _id: 0,
          month: "$_id.month",
          year: "$_id.year",
        },
      },
    ]);
    let monthYears = [];
    distinctMonthsYears.map((item) =>
      monthYears.push(item.month + "-" + item.year)
    );
    let obj = {};
    statData.forEach((item) => {
      let key = (item.dealer_name + " " + item.city).trim();
      if (!obj[key]) {
        obj[key] = [];
      }
      obj[key].push({ ...item, month: item.month.toString() });
    });

    let obj1 = {};
    let monthYear = obj[Object.keys(obj)[0]].map((item) => ({
      month: item.month,
      year: item.year,
    }));

    const formatDealer = (arr1, arr) => {
      let params = {
        leads: "0",
        jobCards: "0",
        sales_invoice: "0",
        sales_order: "0",
      };

      let mainArr = [...arr1];
      arr.map((item) => {
        let flag = 0;
        let misMatch = [];
        arr1.map((item1) => {
          if (item.month + item.year === item1.month + item1.year) {
            flag++;
          }
        });
        if (flag === 0) {
          let obj = {
            ...params,
            month: item.month,
            year: item.year,
            dealer_code: arr1[0].dealer_code,
            dealer_name: arr1[0].dealer_name,
            city: arr1[0].city,
          };
          misMatch.push(obj);
        }
        mainArr = [...misMatch, ...mainArr];
      });
      let result = arr.map((item1) => {
        return mainArr[
          mainArr.findIndex(
            (item) => item.month + item.year === item1.month + item.year
          )
        ];
      });
      obj1[arr1[0].dealer_name + " " + arr1[0].city] = result.map((ob) => ({
        ...ob,
        month: monthNames[ob.month],
      }));
      return result;
    };
    Object.keys(obj).map((item) => formatDealer(obj[item], monthYear));

    return res.json({
      status:true,
      code:200,
      data:obj1});
  } catch (error) {
    console.log(error+"  err ");
    return res.json({
      status:true,
      code:500,
      data:error
    });
    // return error;
  }
};

const zoneWiseController = async (req, res) => {
  try {
    await connection(url);
    let statData = await dealerMonthly.aggregate([
      {
        $lookup: {
          from: "dealer_details",
          localField: "dealer_code",
          foreignField: "id",
          as: "deal",
        },
      },
      {
        $unwind: "$deal",
      },
      {
        $match: {
          "deal.status": 1,
        },
      },
      {
        $group: {
          _id: {
            year: "$year",
            month: "$month",
            zone: { $trim: { input: "$deal.zone" } },
          },
          leads: { $sum: "$lead_count" },
          sales_invoice: { $sum: "$si_count" },
          sales_order: { $sum: "$so_count" },
          jobCards: { $sum: "$jc_count" },
        },
      },
      {
        $project: {
          _id: 0,
          year: "$_id.year",
          month: "$_id.month",
          zone: "$_id.zone",
          leads: 1,
          sales_invoice: 1,
          sales_order: 1,
          jobCards: 1,
        },
      },
      {
        $sort: {
          year: 1,
          month: 1,
        },
      },
    ]);

    let result = statData.map((item) => {
      return { ...item, month: monthNames[`${item.month}`] };
    });

    let obj = {};

    let zones = ["North", "East", "West", "South"];

    let terms = { leads: 0, sales_order: 0, sales_invoice: 0, jobCards: 0 };

    result.map((item) => {
      if (!Object.keys(obj).includes(item.month)) {
        obj[item.month] = [item];
      } else {
        obj[item.month].push(item);
      }
    });

    Object.keys(obj).map((item) => {
      let inZones = obj[item].map((ob) => ob.zone.trim()); // console.log(inZones)
      let noZones = zones.filter((zone) => !inZones.includes(zone));

      let ar = noZones.map((zn) => ({
        ...terms,
        zone: zn,
        month: item,
      }));

      obj[item] = [...obj[item], ...ar];
    });
    resp = Object.values(obj);

    return res.json({
      status:true,
      code:200,
      data:resp.flat(1)});
  } catch (error) {
    return res.json({
      status:true,
      code:500,
      data:error
    });
    // return error;
  }
};

const monthlyController = async (req, res) => {
  try {
    let { date } = req.params;
    let [year, month] = date.split("-");
    await connection(url);
    let result = await dealerMonthly.aggregate([
      {
        $lookup: {
          from: "dealer_details",
          localField: "dealer_code",
          foreignField: "id",
          as: "deal",
        },
      },
      {
        $unwind: "$deal",
      },
      {
        $match: {
          "deal.status": 1,
          year: parseInt(year),
          month: parseInt(month),
        },
      },
      {
        $facet: {
          leadtop3: [
            {
              $sort: {
                lead_count: -1,
              },
            },
            {
              $limit: 3,
            },
            {
              $project: {
                _id: 0,
                lead_count: 1,
                dealer_code: "$deal.dealer_code",
                dealer_name: "$deal.dealer_name",
                zone: "$deal.zone",
                state: "$deal.state",
                city: "$deal.city",
                pincode: "$deal.pincode",
              },
            },
          ],
          Jctop3: [
            {
              $sort: {
                jc_count: -1,
              },
            },
            {
              $limit: 3,
            },
            {
              $project: {
                _id: 0,
                jc_count: 1,
                dealer_code: "$deal.dealer_code",
                dealer_name: "$deal.dealer_name",
                zone: "$deal.zone",
                state: "$deal.state",
                city: "$deal.city",
                pincode: "$deal.pincode",
              },
            },
          ],
          sitop3: [
            {
              $sort: {
                si_count: -1,
              },
            },
            {
              $limit: 3,
            },
            {
              $project: {
                _id: 0,
                si_count: 1,
                dealer_code: "$deal.dealer_code",
                dealer_name: "$deal.dealer_name",
                zone: "$deal.zone",
                state: "$deal.state",
                city: "$deal.city",
                pincode: "$deal.pincode",
              },
            },
          ],
          sotop3: [
            {
              $sort: {
                so_count: -1,
              },
            },
            {
              $limit: 3,
            },
            {
              $project: {
                _id: 0,
                so_count: 1,
                dealer_code: "$deal.dealer_code",
                dealer_name: "$deal.dealer_name",
                zone: "$deal.zone",
                state: "$deal.state",
                city: "$deal.city",
                pincode: "$deal.pincode",
              },
            },
          ],
          zone_comp: [
            {
              $group: {
                _id: { $trim: { input: "$deal.zone" } },
                leads: { $sum: "$lead_count" },
                jobCards: { $sum: "$jc_count" },
                sales_order: { $sum: "$so_count" },
                sales_invoice: { $sum: "$si_count" },
              },
            },
            {
              $project: {
                _id: 0,
                zone: "$_id",
                leads: 1,
                jobCards: 1,
                sales_order: 1,
                sales_invoice: 1,
              },
            },
          ],

          // tableData:[
          //   { $group: {
          //   _id: "$deal.dealer_code",
          //   dealer_name: { $first: "$deal.dealer_name" },
          //   state: { $first: "$deal.state" },
          //   city: { $first: "$deal.city" },
          //   zone: { $first: "$deal.zone" },
          //   pincode: { $first: "$deal.pincode" },
          //   leads: { $sum: "$lead_count" },
          //   sales_invoice: { $sum: "$si_count" },
          //   job_cards: { $sum: "$jc_count" },
          //   sales_order: { $sum: "$so_count" },
          //   sales_po: { $sum: "$vpo_count" },
          //   service_sales: { $sum: "$ps_count" },
          //   service_po: { $sum: "$ppo_count" },
          //   sales_grn: { $sum: "$s_grn_count" },
          //   dealer_code: { $first: "$deal.dealer_code" }
          // }}]
        },
      },
    ]);

    let summary = await dealerMonthly.aggregate([
      {
        $match: {
          year: parseInt(year),
          month: parseInt(month),
        },
      },
      {
        $group: {
          _id: {
            year: "$year",
            month: "$month",
          },
          leads: { $sum: "$lead_count" },
          jobCards: { $sum: "$jc_count" },
          sales_order: { $sum: "$so_count" },
          sales_invoice: { $sum: "$si_count" },
        },
      },
      {
        $project: {
          _id: 0,
          year: "$_id.year",
          month: "$_id.month",
          leads: 1,
          jobCards: 1,
          sales_order: 1,
          sales_invoice: 1,
        },
      },
    ]);

    let zoneObj = {
      leads: {
        North: 0,
        East: 0,
        West: 0,
        South: 0,
      },
      jobCards: {
        North: 0,
        East: 0,
        West: 0,
        South: 0,
      },
      sales_invoice: {
        North: 0,
        East: 0,
        West: 0,
        South: 0,
      },
      sales_order: {
        North: 0,
        East: 0,
        West: 0,
        South: 0,
      },
    };

    result[0].zone_comp.map((item) => {
      Object.keys(item).map((item1) => {
        if (!(item1 === "zone")) {
          zoneObj[item1][item["zone"].trim()] = item[item1];
        }
      });
    });

    return res.json({
      status:true,
      code:200,
      data:{summary: summary[0],
      maxThree: {
        leads: result[0].leadtop3,
        si: result[0].Jctop3,
        jc: result[0].leadtop3,
        so: result[0].sotop3,
      },
      // minThree: {
      //   leads: leadsThreeMin,
      //   si: SiCountThreeMin,
      //   jc: JcCountThreeMin,
      //   so: SoCountThreeMin,
      // },
      zone_comp: zoneObj,}
    });

    // return result;
  } catch (error) {
    console.log(error);
    return res.json({
      status:true,
      code:500,
      data:error});
    // return error;
  }
};

const dealerMonthlyController = async (req, res) => {
  try {
    await connection(url)
    const date = req.params.date;
    const [year, month] = date.split("-");
    // console.log(year,month);

    const top3data = await dealerMonthly.aggregate([
      {
        $lookup: {
          from: "dealer_details",
          localField: "dealer_code",
          foreignField: "id",
          as: "deal",
        },
      },
      {
        $unwind: "$deal",
      },
      {
        $match: {
          "deal.status": 1,
          year: parseInt(year),
          month: parseInt(month),
        },
      },
      {
        $facet: {
          topDealersByFirstFreeService: [
            {
              $group: {
                _id: "$dealer_code",
                dealer_name: { $first: "$deal.dealer_name" },
                zone: { $first: "$deal.zone" },
                state: { $first: "$deal.state" },
                city: { $first: "$deal.city" },
                pincode: { $first: "$deal.pincode" },
                first_free_service: { $sum: "$no_first_free_service" },
                dealer_code: { $first: "$deal.dealer_code" },
              },
            },
            {
              $sort: {
                first_free_service: -1,
              },
            },
            {
              $limit: 3,
            },
            {
              $project: {
                _id: 0,
                dealer_code: 1,
                dealer_name: 1,
                zone: 1,
                state: 1,
                city: 1,
                pincode: 1,
                first_free_service: 1,
              },
            },
          ],
          topDealersBySecondFreeService: [
            {
              $group: {
                _id: "$dealer_code",
                dealer_name: { $first: "$deal.dealer_name" },
                zone: { $first: "$deal.zone" },
                state: { $first: "$deal.state" },
                city: { $first: "$deal.city" },
                pincode: { $first: "$deal.pincode" },
                second_free_service: { $sum: "$no_second_free_service" },
                dealer_code: { $first: "$deal.dealer_code" },
              },
            },
            {
              $sort: {
                second_free_service: -1,
              },
            },
            {
              $limit: 3,
            },
            {
              $project: {
                _id: 0,
                dealer_code: 1,
                dealer_name: 1,
                zone: 1,
                state: 1,
                city: 1,
                pincode: 1,
                second_free_service: 1,
              },
            },
          ],
          topDealersByThirdFreeService: [
            {
              $group: {
                _id: "$dealer_code",
                dealer_name: { $first: "$deal.dealer_name" },
                zone: { $first: "$deal.zone" },
                state: { $first: "$deal.state" },
                city: { $first: "$deal.city" },
                pincode: { $first: "$deal.pincode" },
                third_free_service: { $sum: "$no_third_free_service" },
                dealer_code: { $first: "$deal.dealer_code" },
              },
            },
            {
              $sort: {
                third_free_service: -1,
              },
            },
            {
              $limit: 3,
            },
            {
              $project: {
                _id: 0,
                dealer_code: 1,
                dealer_name: 1,
                zone: 1,
                state: 1,
                city: 1,
                pincode: 1,
                third_free_service: 1,
              },
            },
          ],
          topDealersByFourthFreeService: [
            {
              $group: {
                _id: "$dealer_code",
                dealer_name: { $first: "$deal.dealer_name" },
                zone: { $first: "$deal.zone" },
                state: { $first: "$deal.state" },
                city: { $first: "$deal.city" },
                pincode: { $first: "$deal.pincode" },
                fourth_free_service: { $sum: "$no_fourth_free_service" },
                dealer_code: { $first: "$deal.dealer_code" },
              },
            },
            {
              $sort: {
                fourth_free_service: -1,
              },
            },
            {
              $limit: 3,
            },
            {
              $project: {
                _id: 0,
                dealer_code: 1,
                dealer_name: 1,
                zone: 1,
                state: 1,
                city: 1,
                pincode: 1,
                fourth_free_service: 1,
              },
            },
          ],
          topDealersByDealerStock: [
            {
              $group: {
                _id: "$dealer_code",
                dealer_name: { $first: "$deal.dealer_name" },
                zone: { $first: "$deal.zone" },
                state: { $first: "$deal.state" },
                city: { $first: "$deal.city" },
                pincode: { $first: "$deal.pincode" },
                dealer_stock: { $sum: "$dealer_stock" },
                dealer_code: { $first: "$deal.dealer_code" },
              },
            },
            {
              $sort: {
                dealer_stock: -1,
              },
            },
            {
              $limit: 3,
            },
            {
              $project: {
                _id: 0,
                dealer_code: 1,
                dealer_name: 1,
                zone: 1,
                state: 1,
                city: 1,
                pincode: 1,
                dealer_stock: 1,
              },
            },
          ],
          topDealersByPaidService: [
            {
              $group: {
                _id: "$dealer_code",
                dealer_name: { $first: "$deal.dealer_name" },
                zone: { $first: "$deal.zone" },
                state: { $first: "$deal.state" },
                city: { $first: "$deal.city" },
                pincode: { $first: "$deal.pincode" },
                paid_service: { $sum: "$no_paid_service" },
                dealer_code: { $first: "$deal.dealer_code" },
              },
            },
            {
              $sort: {
                paid_service: -1,
              },
            },
            {
              $limit: 3,
            },
            {
              $project: {
                _id: 0,
                dealer_code: 1,
                dealer_name: 1,
                zone: 1,
                state: 1,
                city: 1,
                pincode: 1,
                paid_service: 1,
              },
            },
          ],
          topDealersByWarrantyService: [
            {
              $group: {
                _id: "$dealer_code",
                dealer_name: { $first: "$deal.dealer_name" },
                zone: { $first: "$deal.zone" },
                state: { $first: "$deal.state" },
                city: { $first: "$deal.city" },
                pincode: { $first: "$deal.pincode" },
                warranty_service: { $sum: "$no_warranty_service" },
                dealer_code: { $first: "$deal.dealer_code" },
              },
            },
            {
              $sort: {
                warranty_service: -1,
              },
            },
            {
              $limit: 3,
            },
            {
              $project: {
                _id: 0,
                dealer_code: 1,
                dealer_name: 1,
                zone: 1,
                state: 1,
                city: 1,
                pincode: 1,
                warranty_service: 1,
              },
            },
          ],
          zone_comp: [
            {
              $group: {
                _id: { $trim: { input: "$deal.zone" } },
                first_free_service: { $sum: "$no_first_free_service" },
                second_free_service: { $sum: "$no_second_free_service" },
                third_free_service: { $sum: "$no_third_free_service" },
                fourth_free_service: { $sum: "$no_fourth_free_service" },
                running_repair: { $sum: "$no_running_repair" },
                accidental_repair: { $sum: "$no_accidentail_repair" },
                dealer_stock: { $sum: "$dealer_stock" },
                warranty_service: { $sum: "$no_warranty_service" },
                paid_service: { $sum: "$no_paid_service" },
              },
            },
            {
              $project: {
                _id: 0,
                zone: "$_id",
                first_free_service: 1,
                second_free_service: 1,
                third_free_service: 1,
                fourth_free_service: 1,
                running_repair: 1,
                accidental_repair: 1,
                dealer_stock: 1,
                warranty_service: 1,
                paid_service: 1,
              },
            },
          ],
          totalServicesAndRepairs: [
            {
              $group: {
                _id: {
                  month: "$month",
                  year: "$year",
                },
                first_free_service: { $sum: "$no_first_free_service" },
                second_free_service: { $sum: "$no_second_free_service" },
                third_free_service: { $sum: "$no_third_free_service" },
                fourth_free_service: { $sum: "$no_fourth_free_service" },
                running_repair: { $sum: "$no_running_repair" },
                accidental_repair: { $sum: "$no_accidentail_repair" },
                dealer_stock: { $sum: "$dealer_stock" },
                warranty_service: { $sum: "$no_warranty_service" },
                paid_service: { $sum: "$no_paid_service" },
              },
            },
            {
              $project: {
                _id: 0,
                month: "$_id.month",
                year: "$_id.year",
                first_free_service: 1,
                second_free_service: 1,
                third_free_service: 1,
                fourth_free_service: 1,
                running_repair: 1,
                accidental_repair: 1,
                dealer_stock: 1,
                warranty_service: 1,
                paid_service: 1,
              },
            },
          ],
        },
      },
    ]);

    const summary = await dealerMonthly.aggregate([
      {
        $match: {
          year: parseInt(year),
          month: parseInt(month),
        },
      },
      {
        $group: {
          _id: {
            month: "$month",
            year: "$year",
          },
          first_free_service: { $sum: "$no_first_free_service" },
          second_free_service: { $sum: "$no_second_free_service" },
          third_free_service: { $sum: "$no_third_free_service" },
          fourth_free_service: { $sum: "$no_fourth_free_service" },
          running_repair: { $sum: "$no_running_repair" },
          accidental_repair: { $sum: "$no_accidentail_repair" },
          dealer_stock: { $sum: "$dealer_stock" },
          warranty_service: { $sum: "$no_warranty_service" },
          paid_service: { $sum: "$no_paid_service" },
        },
      },
      {
        $project: {
          _id: 0,
          month: "$_id.month",
          year: "$_id.year",
          first_free_service: 1,
          second_free_service: 1,
          third_free_service: 1,
          fourth_free_service: 1,
          running_repair: 1,
          accidental_repair: 1,
          dealer_stock: 1,
          warranty_service: 1,
          paid_service: 1,
        },
      },
    ]);

    let topData3 = top3data[0];

    let zoneObj = {
      dealer_stock: {
        North: 0,
        East: 0,
        West: 0,
        South: 0,
      },
      first_free_service: {
        North: 0,
        East: 0,
        West: 0,
        South: 0,
      },
      second_free_service: {
        North: 0,
        East: 0,
        West: 0,
        South: 0,
      },
      third_free_service: {
        North: 0,
        East: 0,
        West: 0,
        South: 0,
      },
      fourth_free_service: {
        North: 0,
        East: 0,
        West: 0,
        South: 0,
      },
      running_repair: {
        North: 0,
        East: 0,
        West: 0,
        South: 0,
      },
      accidental_repair: {
        North: 0,
        East: 0,
        West: 0,
        South: 0,
      },
      paid_service: {
        North: 0,
        East: 0,
        West: 0,
        South: 0,
      },
      warranty_service: {
        North: 0,
        East: 0,
        West: 0,
        South: 0,
      },
    };

    topData3.zone_comp.map((item) => {
      Object.keys(item).map((item1) => {
        if (!(item1 === "zone")) {
          zoneObj[item1][item["zone"].trim()] = item[item1];
        }
      });
    });

    return res.json({
      status:true,
      code:200,
      data:{
      summary: summary,
      maxThree: {
        firstServiceThreeMax: topData3.topDealersByFirstFreeService,
        secondServiceThreeMax: topData3.topDealersBySecondFreeService,
        thirdServiceThreeMax: topData3.topDealersByThirdFreeService,
        fourthServiceThreeMax: topData3.topDealersByFourthFreeService,
        dealerStockThreeMax: topData3.topDealersByDealerStock,
        warrantyServiceThreeMax: topData3.topDealersByWarrantyService,
        paidServiceThreeMax: topData3.topDealersByPaidService,
      },
      zone_comp: zoneObj,}
    });
  } catch (error) {
    // console.log(error+"error");
    return res.json({
      status:false,
      code:500,
      data:error});
  }
};

const datesController = async (req, res) => {
  try {
    await connection(url);
    let dates = await dealerMonthly.aggregate([
      {
        $facet: {
          endMonthDates: [
            {
              $group: {
                _id: "$year",
                maxMonth: { $max: "$month" },
              },
            },
            {
              $sort: {
                _id: -1,
              },
            },
            {
              $limit: 1,
            },
            {
              $project: {
                _id: 0,
                year: "$_id",
                month: "$maxMonth",
              },
            },
          ],
          startMonthDates: [
            {
              $group: {
                _id: "$year",
                minMonth: { $min: "$month" },
              },
            },
            {
              $sort: {
                _id: 1,
              },
            },
            {
              $limit: 1,
            },
            {
              $project: {
                _id: 0,
                year: "$_id",
                month: "$minMonth",
              },
            },
          ],
        },
      },
    ]);
    return res.json({
      endMonthDates: dates[0] ? dates[0].endMonthDates[0] : null,
      startMonthDates: dates[0] ? dates[0].startMonthDates[0] : null,
    });
  } catch (error) {
    console.log(error);
    return res.json(error);
  }
};

const dealerLocationController = async (req, res) => {
  try {
    await connection(url);
    //  await sequelize.sync();
    //   const query = {
    //     $and: [
    //       {date:moment().format('YYYY-MM-DD')},
    //       { [aplToVDD['avg_speed']]: { $lt: 70 } },
    //       { [aplToVDD['max_speed']]: { $lt: 70 } },
    //       {
    //         $or: [
    //           { [aplToVDD['start_geo_code']]: { $ne: 'NA' } },
    //           { [aplToVDD['end_geo_code']]: { $ne: 'NA' } }
    //         ]
    //       },
    //       { [aplToVDD['distance']]: { $gt: 0, $lte: 500 } }
    //     ]
    //   };
    // let result=await VehicleDailyData.find(query).select(['topic','x58','x59','x11','x55','x12','x82','x94']);

    // const query = {
    //   $and: [
    //     { date: moment().format('YYYY-MM-DD') },
    //     { [aplToVDD['avg_speed']]: { $lt: 70 } },
    //     { [aplToVDD['max_speed']]: { $lt: 70 } },
    //     {
    //       $or: [
    //         { [aplToVDD['start_geo_code']]: { $ne: 'NA' } },
    //         { [aplToVDD['end_geo_code']]: { $ne: 'NA' } }
    //       ]
    //     },
    //     { [aplToVDD['distance']]: { $gt: 0, $lte: 500 } }
    //   ]
    // };

    const query = {
      $and: [
        { date: moment().format("YYYY-MM-DD") },
        { x13: { $lt: 70 } },
        { x14: { $lt: 70 } },
        {
          $or: [{ x58: { $ne: "NA" } }, { x59: { $ne: "NA" } }],
        },
        { x12: { $gt: 0, $lte: 500 } },
      ],
    };
    const pipeline = [
      { $match: query },
      {
        $project: {
          vin: {
            $substr: ["$topic", 3, { $strLenCP: "$topic" }]
          },
          vehicle_reg_number: "$x1",
          start_geo_code: "$x58",
          end_geo_code: "$x59",
          end_odo: "$x11",
          end_soc: "$x55",
          distance: "$x12",
          soh: "$x53",
          end_time: {
            $dateToString: {
              format: "%Y-%m-%d %H:%M:%S",
              date: {
                $convert: {
                  input: "$x82",
                  to: "date",
                },
              },
            },
          },
          _id: 0,
        },
      },
    ];

    let result = await VehicleDailyData.aggregate(pipeline);
    // let vinsReg=await Vehicle.findAll({
    //   attributes: ['VIN', 'VehicleRegNo'],
    //   where: {
    //     VIN: {
    //       [Sequelize.Op.or]: [
    //         { [Sequelize.Op.startsWith]: 'mq/MD9' },
    //         { [Sequelize.Op.startsWith]: 'mq/P6R' }
    //       ]
    //     }
    //   }
    // });
    // let vinsRegMap={};
    // vinsReg.map(item=>{
    //   vinsRegMap[item.VIN]=item.VehicleRegNo
    // })
    // const response=result.map(item=>{
    //   return {...item,vehicle_reg_number:vinsRegMap[item.vin]}
    // })
    return res.json(result);
  } catch (error) {
    console.log(error);
    return res.json(error);
  }
};

const dealerDetailsController = async (req, res) => {
  try {
    await connection(url);

    let result = await dealerDetails.aggregate([
      {
        $match: {
          status: {
            $in: [1, 2],
          },
        },
      },{
        $sort:{id:1}
      },
      {
        $project: {
          _id: 0,
          id: 1,
          dealer_code: 1,
          branch_code: 1,
          dealer_name: 1,
          launch_date: 1,
          gstin_no: 1,
          gstin_dt: 1,
          subsidy_code: 1,
          zone: 1,
          state: 1,
          city: 1,
          address: 1,
          pincode: 1,
          latitude: 1,
          longitude: 1,
          sales_name_1: 1,
          sales_name_2: 1,
          sales_mobile_1: 1,
          sales_mobile_2: 1,
          sales_email_1: 1,
          sales_email_2: 1,
          service_name_1: 1,
          service_name_2: 1,
          service_mobile_1: 1,
          service_mobile_2: 1,
          service_email_1: 1,
          service_email_2: 1,
          gm_name_1: 1,
          gm_name_2: 1,
          gm_mobile_1: 1,
          gm_mobile_2: 1,
          gm_email_1: 1,
          gm_email_2: 1,
          it_name_1: 1,
          it_name_2: 1,
          it_mobile_1: 1,
          it_mobile_2: 1,
          it_email_1: 1,
          it_email_2: 1,
          status: 1,
        },
      },
    ]);

    return res.json({status:true,code:200,data:result});
  } catch (error) {
    console.log(error);
    return res.json({status:false,code:500,data:error});
  }
};

const dealerFleets = async (req, res) => {
  try {
    await sequelize.sync();
    let result = await Client.findAll({
      where: { clientCode: { [Op.like]: `Dealer%` }, deleteClientStatus: 0 },
      raw: true,
      nest: true,
      attributes: [
        ["clientCode", "label"],
        ["clientCode", "value"],
      ],
    });
    return res.json({status:true,code:200,data:result});
  } catch (error) {
    console.log(error);
    return res.json({status:false,code:500,data:error});
  }
};

const dealerFleetsVehicles = async (req, res) => {
  try {
    const { fleet } = req.body;
    const yesterdayDate = moment().subtract(1, "days").format("YYYY-MM-DD");
    await connection(url);
    await sequelize.sync();
    Vehicle.belongsToMany(Client, {
      through: ClientVehicle,
      foreignKey: "vid",
    });
    Client.belongsToMany(Vehicle, {
      through: ClientVehicle,
      foreignKey: "cid",
    });
    let data = await Vehicle.findAll({
      include: [
        {
          model: Client,
          attributes: [],
          through: { attributes: [] },
          where: { clientCode: { [Op.like]: `${fleet}%` } },
        },
      ],
      where: {
        deleteVehicleStatus: 0,
        VIN: {
          [Op.or]: [{ [Op.like]: "mq/MD9%" }, { [Op.like]: "mq/P6R%" }],
        },
      },
      raw: true,
      nest: true,
      attributes: [
        "VIN",
        "VehicleRegNo",
        "model",
        "SIMservicePrName",
        "network_type",
        "Clients.clientCode",
      ],
    });
    const dealerVinsList = [],
      VehicleTableData = {};
    data.map((item) => {
      dealerVinsList.push(item.VIN);
      VehicleTableData[item.VIN] = item;
    });
    let VehicleData = await VehicleDailyData.aggregate([
      {
        $match: {
          x12: { $ne: "NA", $gte: 0, $lte: 600 },
          x11: { $ne: "NA" },
          x10: { $ne: "NA" },
          topic: {
            $in: dealerVinsList,
          },
        },
      },
      {
        $facet: {
          overview: [
            {
              $group: {
                _id: "$topic",
                vin: {
                  $last: "$topic",
                },
                vehicle_reg_number: {
                  $last: "$x1",
                },
                date: {
                  $max: { $toDate: "$date" },
                },
                odo: { $last: "$x11" },
              },
            },
            {
              $project: {
                _id: 0,
                vin: "$_id",
                vehicle_reg_number: "$vehicle_reg_number",
                latestDate: {
                  $dateToString: { date: "$date", format: "%Y-%m-%d" },
                },
                odo: "$odo",
              },
            },
          ],
          topDistance: [
            {
              $match: {
                x12: { $gt: 0, $lte: 500 },
                x13: { $lt: 70 },
                x14: { $lt: 70 },
                date: yesterdayDate,
              },
            },
            {
              $group: {
                _id: "$topic",
                vehicle_reg_number: { $last: "$x1" },
                distance: { $max: { $toDouble: "$x12" } },
              },
            },
            {
              $project: {
                _id: 0,
                vin: "$_id",
                vehicle_reg_number: 1,
                distance: { $round: ["$distance", 2] },
              },
            },
            {
              $sort: { distance: -1 },
            },
            {
              $limit: 5,
            },
          ],
          topodo: [
            {
              $match: {
                x12: { $gte: 0, $lte: 500 },
                x13: { $lt: 70 },
                x14: { $lt: 70 },
              },
            },
            {
              $sort: { date: -1 },
            },
            {
              $group: {
                _id: "$topic",
                vehicle_reg_number: { $last: "$x1" },
                odo: { $first: { $toDouble: "$x11" } },
              },
            },
            {
              $project: {
                _id: 0,
                vin: "$_id",
                vehicle_reg_number: 1,
                odo: { $round: ["$odo", 2] },
              },
            },
            {
              $sort: { odo: -1 },
            },
            {
              $limit: 5,
            },
          ],
          yesterdayTotalDistance: [
            {
              $match: {
                x12: { $gt: 0, $lte: 500 },
                x13: { $lt: 70 },
                x14: { $lt: 70 },
                date: yesterdayDate,
              },
            },
            {
              $group: {
                _id: null,
                count: {
                  $sum: 1,
                },
                sum: {
                  $sum: "$x12",
                },
                vins: {
                  $addToSet: {
                    vin: "$topic",
                    vehicle_reg_number: "$x1",
                    odo: "$x11",
                    distance: "$x12",
                  },
                },
              },
            },
            {
              $project: {
                _id: 0,
                distance: "$sum",
                count: "$count",
                vins: "$vins",
              },
            },
          ],
        },
      },
    ]);
    totalVehicles = VehicleData[0].overview.map((item) => {
      data = {
        vin: item["vin"].slice(3),
        vehicle_reg_number: VehicleTableData[item.vin]['VehicleRegNo'],
        name: VehicleTableData[item.vin]["clientCode"],
        model_name: VehicleTableData[item.vin]["model"],
        odo: item["odo"],
        last_driven_date: item["latestDate"],
        network_type: VehicleTableData[item.vin]["network_type"],
        sim_service_provider_name:
          VehicleTableData[item.vin]["SIMservicePrName"],
      };
      return data;
    });

    yesterdayvehicles = VehicleData[0].yesterdayTotalDistance[0]
      ? VehicleData[0].yesterdayTotalDistance[0].vins.map((item) => {
          data = {
            vin: item["vin"].slice(3),
            vehicle_reg_number: item["vehicle_reg_number"],
            name: VehicleTableData[item.vin]["clientCode"],
            model_name: VehicleTableData[item.vin]["model"],
            odo: item["odo"],
            network_type: VehicleTableData[item.vin]["network_type"],
            sim_service_provider_name:
              VehicleTableData[item.vin]["SIMservicePrName"],
          };
          return data;
        })
      : [];

    return res.json({
      status:true,
      code:200,
      data:{
      total_vehicles: totalVehicles,
      yesterdayvehicles: VehicleData[0].yesterdayTotalDistance[0]
        ? VehicleData[0].yesterdayTotalDistance[0].count
        : 0,
      yesterdayVehiclesData: yesterdayvehicles,
      yesterDayDistance: VehicleData[0].yesterdayTotalDistance[0]
        ? VehicleData[0].yesterdayTotalDistance[0].distance
        : 0,
      topDistance: VehicleData[0].topDistance.map((item) => {
        return { ...item, vin:item.vin.slice(3), name: VehicleTableData[item.vin]["clientCode"] };
      }),
      topOdo: VehicleData[0].topodo.map((item) => {
        return { ...item,vin:item.vin.slice(3), name: VehicleTableData[item.vin]["clientCode"] };
      }),
    }});
  } catch (error) {
    // console.log(error);
    return res.json({status:false,code:500,data:error});
  }
};

const dealerMonthVehicles = async (req, res) => {
  try {
        const { date } = req.body;
        await sequelize.sync();
        await connection(url);
        const monthStartDate = moment(date, 'YYYY-MM').startOf('month').format('YYYY-MM-DD');
        const monthEndDate = moment(date, 'YYYY-MM').endOf('month').format('YYYY-MM-DD');
        const yesterdayDate = moment().subtract(1, "days").format("YYYY-MM-DD");
        console.log(monthStartDate+" "+monthEndDate)
        Vehicle.belongsToMany(Client, {
          through: ClientVehicle,
          foreignKey: "vid",
        });
        Client.belongsToMany(Vehicle, {
          through: ClientVehicle,
          foreignKey: "cid",
        });
        let data = await Vehicle.findAll({
          include: [
            {
              model: Client,
              attributes: [],
              through: { attributes: [] },
              where: { clientCode: { [Op.like]: `Dealer%` } },
            },
          ],
          where: {
            deleteVehicleStatus: 0,
            VIN: {
              [Op.or]: [{ [Op.like]: "mq/MD9%" }, { [Op.like]: "mq/P6R%" }],
            },
          },
          raw: true,
          nest: true,
          attributes: [
            "VIN",
            "model",
            "SIMservicePrName",
            "network_type",
            "Clients.clientCode",
            "VehicleRegNo"
          ],
        });
        const dealerVinsList = [],
          VehicleTableData = {};
        data.map((item) => {
          dealerVinsList.push(item.VIN);
          VehicleTableData[item.VIN] = item;
        });
        console.log(dealerVinsList.length);
        let VehicleData = await VehicleDailyData.aggregate([
          {
            $match: {
              x12: { $ne: "NA", $gte: 0, $lte: 600 },
              x11: { $ne: "NA" },
              x10: { $ne: "NA" },
              topic: {
                $in: dealerVinsList,
              },
            },
          },
          {
            $facet: {
              overview: [
                 {
                  $match: {
                     x12: { $gt: 0, $lte: 500 },
                    // x13: { $lt: 70 },
                    // x14: { $lt: 70 },
                    date: {$gte:monthStartDate,$lte:monthEndDate},
                  },
                },
                {
                  $group: {
                    _id: "$topic",
                    vin: {
                      $last: "$topic",
                    },
                    vehicle_reg_number: {
                      $last: "$x1",
                    },
                    date: {
                      $max: { $toDate: "$date" },
                    },
                    distance: { $sum: "$x12" },
                    odo: { $last: "$x11" },
                  },
                },
                {
                  $project: {
                    _id: 0,
                    vin: "$_id",
                    vehicle_reg_number: "$vehicle_reg_number",
                    latestDate: {
                      $dateToString: { date: "$date", format: "%Y-%m-%d" },
                    },
                    distance:'$distance',
                    odo: "$odo",
                  },
                },
              ],
              topDistance: [
                {
                  $match: {
                    x12: { $gt: 0, $lte: 500 },
                    x13: { $lt: 70 },
                    x14: { $lt: 70 },
                    date: {$gte:monthStartDate,$lte:monthEndDate},
                  },
                },
                {
                  $group: {
                    _id: "$topic",
                    vehicle_reg_number: { $last: "$x1" },
                    distance: { $max: { $toDouble: "$x12" } },
                  },
                },
                {
                  $project: {
                    _id: 0,
                    vin: "$_id",
                    vehicle_reg_number: 1,
                    distance: { $round: ["$distance", 2] },
                  },
                },
                {
                  $sort: { distance: -1 },
                },
                {
                  $limit: 10,
                },
              ],
              topodo: [
                {
                  $match: {
                    x12: { $gte: 0, $lte: 500 },
                    x13: { $lt: 70 },
                    x14: { $lt: 70 },
                    date: {$gte:monthStartDate,$lte:monthEndDate},
                  },
                },
                {
                  $sort: { date: -1 },
                },
                {
                  $group: {
                    _id: "$topic",
                    vehicle_reg_number: { $last: "$x1" },
                    odo: { $first: { $toDouble: "$x11" } },
                  },
                },
                {
                  $project: {
                    _id: 0,
                    vin: "$_id",
                    vehicle_reg_number: 1,
                    odo: { $round: ["$odo", 2] },
                  },
                },
                {
                  $sort: { odo: -1 },
                },
                {
                  $limit: 10,
                },
              ],
              yesterdayTotalDistance: [
                {
                  $match: {
                    x12: { $gt: 0, $lte: 500 },
                    x13: { $lt: 70 },
                    x14: { $lt: 70 },
                    date: yesterdayDate,
                  },
                },
                {
                  $group: {
                    _id: null,
                    count: {
                      $sum: 1,
                    },
                    sum: {
                      $sum: "$x12",
                    },
                    vins: {
                      $addToSet: {
                        vin: "$topic",
                        vehicle_reg_number: "$x1",
                        odo: "$x11",
                        distance: "$x12",
                      },
                    },
                  },
                },
                {
                  $project: {
                    _id: 0,
                    distance: "$sum",
                    count: "$count",
                    vins: "$vins",
                  },
                },
              ],
              vehiclecountInMonth:[
                {
                  $match: {
                     x12: { $gt: 0, $lte: 500 },
                    date: {$gte:monthStartDate,$lte:monthEndDate},
                  },
                },{
                  $group:{
                    _id: "$topic",
                    count:{
                      $sum:1
                    }
                  }
                },
                {
                  $project:{
                    _id:0,
                    vin:'$_id',
                    count:'$count'
                  }
                }
              ]
            },
          },
        ]);

        // return res.json({VehicleData})

        totalVehicles = VehicleData[0].overview.map((item) => {
          data = {
            vin: item["vin"].slice(3),
            vehicle_reg_number: VehicleTableData[item.vin]['VehicleRegNo'],
            name: VehicleTableData[item.vin]["clientCode"],
            model_name: VehicleTableData[item.vin]["model"],
            odo: item["odo"],
            last_driven_date: item["latestDate"],
            network_type: VehicleTableData[item.vin]["network_type"],
            sim_service_provider_name:
              VehicleTableData[item.vin]["SIMservicePrName"],
          };
          return data;
        });

        yesterdayvehicles = VehicleData[0].yesterdayTotalDistance[0]
        ? VehicleData[0].yesterdayTotalDistance[0].vins.map((item) => {
            data = {
              vin: item["vin"].slice(3),
              vehicle_reg_number:VehicleTableData[item.vin]['VehicleRegNo'],
              name: VehicleTableData[item.vin]["clientCode"],
              model_name: VehicleTableData[item.vin]["model"],
              odo: item["odo"],
              network_type: VehicleTableData[item.vin]["network_type"],
              sim_service_provider_name:
                VehicleTableData[item.vin]["SIMservicePrName"],
            };
            return data;
          })
        : [];


        let RangeObj = {
          '1 to 5': 0,
          '5 to 10': 0,
          '10 to 15': 0,
          '15 to 20': 0,
          '20 to 25': 0,
        };
    
        let rangeKeys = Object.keys(RangeObj)
        let rangeValues = []
        let RangeObject = {
          '1 to 5 days': [],
          '5 to 10 days': [],
          '10 to 15 days': [],
          '15 to 20 days': [],
          '20 to 25 days': [],
        };
        let remObj={}  
        let remObject={} 

        for(let i=25;i<=monthEndDate.split("-")[2];i++){
          remObj[i.toString()]=0
          rangeKeys.push(i.toString())
          remObject[i.toString()+" days"]=[]
          }
          VehicleData[0].vehiclecountInMonth.map(item=>{
            let keysRem=Object.keys(remObj)
            if(keysRem.indexOf(item.count.toString())!==-1){
              remObj[item.count.toString()]++;
             remObject[item.count.toString()+" days"].push({vin:item.vin.slice(3),vehicle_reg_number:VehicleTableData[item.vin]['VehicleRegNo'],fleet_name:VehicleTableData[item.vin]['clientCode']})
            }      
          })
          const func = (condArr,value)=>{
            let tmp = condArr.slice(0,condArr.length-1).map(item=>(`${value} >= ${item.split(' to ')[0]} && ${value} < ${item.split(' to ')[1]}`))
            let last = condArr[condArr.length-1]
            tmp.push(`${value} >= ${last.split(' to ')[0]} && ${value} < ${last.split(' to ')[1]}`)
            let ind = tmp.findIndex(item=>eval(item)==true)
            return ind
            }
          VehicleData[0].vehiclecountInMonth.map(item=>{
            let ind = func(Object.keys(RangeObj), item.count)
            if(ind !== (-1)){
              RangeObj[Object.keys(RangeObj)[ind]]++;
              RangeObject[Object.keys(RangeObj)[ind]+" days"].push({vin:item.vin.slice(3),vehicle_reg_number:VehicleTableData[item.vin]['VehicleRegNo'],fleet_name:VehicleTableData[item.vin]['clientCode']});
            }        
          })

          // vehiclecountInMonth=VehicleData[0].vehiclecountInMonth
          

           
        newRangeKeys=rangeKeys.map(item=>item+" days")
        RangeObj={...RangeObj,...remObj}
        RangeObject={...RangeObject,...remObject}
        for(let i of rangeKeys){  
          rangeValues.push(RangeObj[i])
        }

        return res.json({
          status:true,
          code:200,
          data:{
          total_vehicles: totalVehicles,
          yesterdayvehicles: VehicleData[0].yesterdayTotalDistance[0]
            ? VehicleData[0].yesterdayTotalDistance[0].count
            : 0,
          yesterdayVehiclesData: yesterdayvehicles,
          yesterDayDistance: VehicleData[0].yesterdayTotalDistance[0]
            ? VehicleData[0].yesterdayTotalDistance[0].distance
            : 0,
          topDistance: VehicleData[0].topDistance.map((item) => {
            return { ...item,vin:item.vin.slice(3), name: VehicleTableData[item.vin]["clientCode"] };
          }),
          topOdo: VehicleData[0].topodo.map((item) => {
            return { ...item,vin:item.vin.slice(3), name: VehicleTableData[item.vin]["clientCode"] };
          }),
          rangeObj:[newRangeKeys,rangeValues],
          RangeObject:RangeObject,
          }});
    
  } catch (error) {
    // console.log(error);
    return res.json({
      status:false,
      code:500,
      data:error
    });
  }
};

module.exports = {
  overViewService,
  dealersCummulative,
  availableDealers,
  overviewGraph,
  zoneWiseController,
  monthlyController,
  dealerMonthlyController,
  datesController,
  dealerLocationController,
  dealerDetailsController,
  dealerFleetsVehicles,
  dealerFleets,
  dealerMonthVehicles,
};
