const httpStatus = require("http-status");
const moment = require("moment");
const mongoose = require("mongoose");
const Mqtt = require("../../models/mqttSecure");
const { last7days } = require("../../utils/constants");
const momentTz = require("moment-timezone");

connection = (url) => {
  mongoose.connect(url, { useNewUrlParser: true });
};

const url =
  "mongodb+srv://alti-admin-prod:APL2023ADMIN@mqtt-production.iqeii.mongodb.net/mqttDatabase_aplmq";

const packetsCount = async (req, res) => {
  try {
    await connection(url);
    let result = []; // Initialize result as an empty array

    let dates = last7days();
    console.log(dates);

    for (const date of dates) {
      let packetDetails = await Mqtt.aggregate([
        {
          $match: {
            RTC: {
              $gte: `${date}T00:00:00`,
              $lte: `${date}T23:59:59`,
            },
          },
        },
        {
          $count: "total",
        },
      ]);
      console.log(packetDetails);

      if (packetDetails.length) {
        result.push({ date, packets: packetDetails[0].total });
      }
    }

    return res.json({
      status: true,
      code: 200,
      data: result,
    });
  } catch (error) {
    console.log(error, "err");
    return res.json({
      status: false,
      code: 500,
      error: "Internal Server Error",
    });
  }
};

const lastPackets = async (req, res) => {
  try {
    await connection(url);
    const currentTime = moment().tz("Asia/Kolkata");
    const time90MinutesBefore = currentTime
      .subtract(90, "minutes")
      .format("YYYY-MM-DDTHH:mm:ss");

    const timeNow = moment().tz("Asia/Kolkata").format("YYYY-MM-DDTHH:mm:ss");
    // console.log(time90MinutesBefore, timeNow);
    // const today = momentTz().tz("Asia/Kolkata").format("YYYY-MM-DDTHH:mm:ss"); // Initialize result as an empty array
    // console.log(today);

    let packetsBasedOnTimeStamp = await Mqtt.aggregate([
      {
        $match: {
          RTC: {
            $gte: time90MinutesBefore,
            $lte: timeNow,
          },
        },
      },
      // {
      //   $project: {
      //     _id: 0,
      //     id: 0,
      //     topic: 1,
      //     RTC: 1,
      //     timeStamp: 1
      //   }
      // },
      {
        $sort: {
          timeStamp: -1,
        },
      },
      {
        $limit: 100,
      },
    ]);
    packetsBasedOnTimeStamp.sort((a,b)=>moment(b.RTC)-moment(a.RTC))

    // const packetsBasedOnRTC = await Mqtt.aggregate([
    //   {
    //     $match: {
    //       RTC: {
    //         $gte: time90MinutesBefore,
    //         $lte: timeNow,
    //       },
    //     },
    //   },
    //   // {
    //   //   $project: {
    //   //     _id: 0,
    //   //     id: 0,
    //   //     topic: 1,
    //   //     RTC: 1,
    //   //     timeStamp: 1
    //   //   }
    //   // },
    //   {
    //     $sort: {
    //       RTC: -1,
    //     },
    //   },
    //   {
    //     $limit: 100,
    //   },
    // ]);

    const result = {
      insertionTime: packetsBasedOnTimeStamp.map((item) => ({
        vin: item.topic.slice(3),
        creation_time: item.RTC,
        insertion_time: item.timeStamp,
      })),
      // creationTime: packetsBasedOnRTC.map((item) => ({
      //   vin: item.topic.slice(3),
      //   creation_time: item.RTC,
      //   insertion_time: item.timeStamp,
      // }))
    }

    return res.json({
      status: true,
      code: 200,
      data: result,
    });
  } catch (error) {
    console.log(error, "err");
    return res.json({
      status: false,
      code: 500,
      error: "Internal Server Error",
    });
  }
};

module.exports = { packetsCount, lastPackets };
