const mongoose = require("mongoose");
const { response } = require("express");
const Vehicle = require("../../models/vehicle");
const sequelize = require("../../utils/sqldb_tcp");
const Mqtt = require("../../models/mqttSecure");

const moment = require("moment");;
const { Op, ConnectionError } = require("sequelize");
const { Sequelize, literal } = require("sequelize");
const VehicleIm = require("../../models/vehicleIm");
const ClientIm = require("../../models/clientIm");
const ClientVehicleIm = require("../../models/client-vehicleIm");
// const VehicleSaleStatmentTest = require("../../models/vehicleSaleTest");
// const AplJobcardsTest = require("../../models/JobcardsTest");
const csvParser = require("csv-parser");
const fs = require("fs");
// const VinSerialTest=require("../../models/VinSerialTest")
const VinSerialNum=require("../../models/VinSerialNum")
const AplJobCards=require("../../models/AplJobCards")
const VehicleSaleStatement=require("../../models/VehicleSaleStatement")

connection = (url) => {
  mongoose.connect(url, { useNewUrlParser: true });
};

const url =
  "mongodb+srv://alti-admin-prod:APL2023ADMIN@mqtt-production.iqeii.mongodb.net/mqttDatabase_aplmq";

const addVehicle = async (req, res) => {
  try {
    const request = req.body;
    await sequelize.sync();
    VehicleIm.belongsToMany(ClientIm, {
      through: ClientVehicleIm,
      foreignKey: "vid",
    });
    ClientIm.belongsToMany(VehicleIm, {
      through: ClientVehicleIm,
      foreignKey: "cid",
    });
    const invalidData = [],
      duplicateData = [],
      successData = [];
    for (let item of request) {
      if (!item || !item.VIN) {
        continue;
      }
      let vin = item.VIN.startsWith("mq/") ? item.VIN : "mq/" + item.VIN;
      if (!(vin.startsWith("mq/MD9") || vin.startsWith("mq/P6R"))) {
        invalidData.push(item);
        continue;
      } else if (vin.length != 20) {
        invalidData.push(item);
        continue;
      }
      let VehicleRegNo = item.hasOwnProperty("VehicleRegNo")
        ? item.VehicleRegNo
        : item.VIN;
      let vDisplayName = item.hasOwnProperty("vDisplayName")
        ? item.vDisplayName
        : item.VIN;
      let chassisSrNo = item.hasOwnProperty("chassisSrNo")
        ? item.chassisSrNo
        : item.VIN;

      let kit = item.Kit_ID;
      let findVehicle = await VehicleIm.findAll({
        where: {
          [Op.or]: [
            { VIN: vin },
            { VehicleRegNo: VehicleRegNo },
            { Kit_ID: kit },
          ],
        },
        raw: true,
      });
      if (findVehicle.length) {
        duplicateData.push(item);
        continue;
      } else {
        let dat = await VehicleIm.create({
          ...item,
          VIN: vin,
          VehicleRegNo: VehicleRegNo,
          vDisplayName: vDisplayName,
          chassisSrNo: chassisSrNo,
        });
        console.log(dat, "dat");
        if (dat) {
          await ClientVehicleIm.create({
            cid: 1,
            vid: dat.vid,
          });
          successData.push(dat);
        }
      }
    }
    return res.json({
      status: true,
      code: 200,
      data: request,
      successData: successData,
      invalidData: invalidData,
      duplicateData: duplicateData,
    });
  } catch (error) {
    console.log(error, "err");
    return res.json({
      status: false,
      code: 500,
      error: error,
    });
  }
};
const saleObject = {
  "Document Name": "document_name",
  Company: "company",
  "Document Date": "document_date",
  Branch: "branch",
  "Branch Code": "branch_code",
  "Dealer Code": "dealer_code",
  "Customer Code": "customer_code",
  Customer: "customer",
  "Mobile No": "mobile",
  Region: "region",
  State: "state",
  City: "city",
  Salesperson: "salesperson",
  Financier: "financier",
  "Finance Amount": "finance_amount",
  Make: "make",
  "Model Family": "model_family",
  "Model Code": "model_code",
  "Model Name": "model_name",
  Color: "color",
  "Chassis No": "chassis_no",
  "Motor No": "motor_no",
  "Insurer Name": "insurer_name",
  Qty: "quantity",
  Rate: "rate",
  Discount: "discount",
  Amount: "amount",
  Scheme: "scheme",
  "Manufacturing Date": "manufacturing_date",
  "Exchange Amount": "exchange_amount",
  "Exchange Mfg Year": "exchange_mfg_year",
  "Exchange Model": "exchange_model",
  "Exchange Model Remarks": "exchange_model_remarks",
  ExShowroomPrice: "ex_showroom_price",
  Charger: "charger",
  ControllerNo: "controller_no",
  BatterySerialNo: "battery_serial_no",
  "Battery Maker": "battery_maker",
  "Battery Capacity": "battery_capacity",
  "Battery Chemistry": "battery_chemistry",
  "Customer Type": "customer_type",
  "Customer Type Code": "customer_type_code",
  "Customer Type Name": "customer_type_name",
  Battery1: "battery1",
  Battery2: "battery2",
  "Total Amount": "total_amount",
};
// const addVehicleSaleStatement=async(req,res)=>{
// try {
//     await connection(url);
//     const request=req.body;
//     let requestObject=[]
//     const bulkOperations=[]
//     for(item of request){
//         let object={};
//         Object.keys(item).map(key=>{
//             if(key=="Document Date"){
//                object[saleObject[key]]=item[key].split('-').reverse().join('-')
//             }else{
//                 object[saleObject[key]]=item[key]
//             }
//         })
//         requestObject.push(object)
//         let {'chassis_no':chassis_no, ...updateData}=object
//         const updateOperation = {
//             updateOne: {
//                 filter: { 'chassis_no': chassis_no },
//                 update: { $set: updateData },
//                 upsert: true
//             }
//         };
//         bulkOperations.push(updateOperation);
//     }
//     const data=await VehicleSaleStatmentTest.bulkWrite(bulkOperations);
//     return res.json({
//         status:true,
//         code:200,
//         data:data,
//     })
// } catch (error) {
//     console.log(error,'err')
//     return res.json({
//         status:false,
//         code:500,
//         error:error
//     })
// }
// }
const jobCardObject = {
  "Repair order": "repair_order_no",
  "Job Card Date": "repair_order_date",
  Region: "region",
  State: "state",
  City: "city",
  Make: "make",
  Model: "model",
  Vehicle: "vehicle_code",
  "Model Code": "model_code",
  "Registration No": "registartion_no",
  VIN: "vin",
  "Motor NO": "motor_no",
  "Bay Code": "bay_code",
  "Bay Name": "bay_name",
  Customer: "customer_code",
  "Branch Code": "branch_code",
  "Dealer Code": "dealer_code",
  "Customer Name": "activeCustomerName",
  "Service Advisor": "serviceAdvisor",
  "KM Reading": "kmm",
  "Repair Type": "repair_type",
  Source: "source",
  Campaign: "campaign",
  "Part/Service": "part/service",
  "Part/Service Name": "part_description",
  "Part/Labour Group":"part_labour_group",
  "Start Date Time": "start_date_time",
  "End Date Time": "end_date_time",
  "Requested Qty": "requested_qty",
  "Issued Qty": "issued_qty",
  "Returned Qty": "returned_qty",
  "Cancelled Qty": "cancelled_qty",
  Rate: "rate",
  "Trade Discount": "trade_discount",
  Amount: "amount",
  "Cancellation Date": "cancellation_date",
  Status: "status",
  Mechanic: "mechanic",
  "Part/Labour Group": "part/labour_group",
  "CGST%": "CGST%",
  "IGST%": "IGST%",
  CGST: "CGST",
  IGST: "IGST",
  "SGST%": "SGST%",
  SGST: "SGST",
  "Total Amount": "total_amount",
};
const addJobCards = async (req, res) => {
  try {
    console.log("Job Card import started");
    if (!req.file) {
      return res
        .status(400)
        .json({ status: false, code: 400, error: "No file uploaded" });
    }
    await connection(url);
    const fileRows = [];
    fs.createReadStream(req.file.path)
      .pipe(csvParser())
      .on("data", (data) => {
        fileRows.push(data);
      })
      .on("end", async () => {
        const bulkOperations = [],resArray=[];
        for (const item of fileRows) {
          let object = {};
          Object.keys(item).forEach((key) => {
            let value = item[key].trim();
            // Convert "NULL" to null
            if (value === "NULL") {
              value = null;
            }
            object[jobCardObject[key.trim()]] = value;
          });

          const numberKeys = new Set([
            "CGST%",
            "IGST%",
            "SGST%",
            "CGST",
            "SGST",
            "IGST",
            "rate",
            "kmm",
            "discount",
            "total_amount",
            "amount",
            "requested_qty",
            "issued_qty",
            "returned_qty",
            "cancelled_qty",
            "trade_discount",
            "branch_code",
            "dealer_code",
          ]);

          Object.keys(object).forEach((key) => {
            if (numberKeys.has(key)) {
              if (object[key] === "" || object[key] === null) {
                object[key] = null;
              } else {
                let value = parseFloat(object[key].replace(/,/g, ""));
                if (isNaN(value)) {
                  value = null;
                }
                object[key] = value;
              }
            }
          });
          resArray.push(object);
          bulkOperations.push({
            insertOne: {
              document: object,
            },
          });
        }

        if (bulkOperations.length > 0) {
          console.log(bulkOperations.length, 'length');
          const result = await AplJobCards.bulkWrite(bulkOperations);
          await fs.promises.unlink(req.file.path);
          return res
            .status(200)
            .json({ status: true, code: 200, data: result ,dataIn:resArray});
        } else {
          console.log("No operations to perform");
          return res
            .status(500)
            .json({ status: false, code: 500, error: "Internal Server Error" });
        }
      });
  } catch (error) {
    console.log(error, "err");
    return res.json({
      status: false,
      code: 500,
      error: error,
    });
  }
};


const addVehicleSaleStatement = async (req, res) => {
  try {
    if (!req.file) {
      return res
        .status(400)
        .json({ status: false, code: 400, error: "No file uploaded" });
    }
    await connection(url);
    const fileRows = [];
    const vinset = new Set([]);
    fs.createReadStream(req.file.path)
      .pipe(csvParser())
      .on("data", (data) => {
        return fileRows.push(data);
      })
      .on("end", async () => {
        const bulkOperations = [],dataIn=[];
        for (const item of fileRows) {
          let object = {};
          Object.keys(item).map((key) => {
            // console.log(key,'key')
            if (key == "Document Date") {
              object[saleObject[key.trim()]] = item[key]
                .split("-")
                .reverse()
                .join("-");
            } else {
              object[saleObject[key.trim()]] = item[key];
            }

            if (item[key] == "NULL") {
              object[saleObject[key.trim()]] = null;
            }
          });
          const numberKeys = new Set([
            "branch_code",
            "dealer_code",
            "finance_amount",
            "quantity",
            "rate",
            "discount",
            "amount",
            "exchange_amount",
            "ex_showroom_price",
            "total_amount",
          ]);
          Object.keys(object).map((key) => {
            if (numberKeys.has(key)) {
              if (object[key] == "") {
                object[key] = 0;
              } else {
                const value = parseFloat(object[key].replace(/,/g, ""));
                object[key] = value;
              }
            }
          });
          let { chassis_no: chassis_no, ...updateData } = object;
          const updateOperation = {
            updateOne: {
              filter: { chassis_no: chassis_no },
              update: { $set: updateData },
              upsert: true,
            },
          };
          // console.log(object['document_name'],typeof object['document_name'],Number(object['document_name']))

          vinset.add(chassis_no);
          if (isNaN(Number(object["document_name"]))){
            dataIn.push(object)
            bulkOperations.push(updateOperation);
          }
        }
        // console.log(bulkOperations.length)
        const result = await VehicleSaleStatement.bulkWrite(bulkOperations);
        await fs.promises.unlink(req.file.path);
        return res.status(200).json({ status: true, code: 200, data: result ,dataIn:dataIn});
      });
  } catch (error) {
    console.log(error);
    return res
      .status(500)
      .json({ status: false, code: 500, error: "Internal server error" });
  }
};

const getVehicleSerialDetails = (item) => {
  let models = {
    A: "ADI",
    B: "BHAI",
    N: "neEv",
    T: "TEZ",
    R: "RAHI",
  };
  let colors = {
    B: "Blue",
    Y: "Yellow",
    Z: "Zesty Orange",
    W: "White",
    G: "Green",
  };
//   let vin = item.VIN;
  let vin=item["VIN No."]
//   let dates = item.Manufactured_Date.split("-");
let dates=item['Production Date'].split("-")
  let obj= {
    VIN:vin,
    color: colors[vin[8]],
    type: models[vin[4]],
    mfgmonth: parseInt(dates[1], 10),
    mfgyear: parseInt(dates[2], 10),
    Manufactured_Date: item['Production Date'],
  };
  if(vin.startsWith("P6R")){
  return {
    ...obj,
    type: models[vin[4]],  
  };
}
  else if (vin.startsWith("MD9")){
    return {
    ...obj,
    type:'neEv',
    }
  }
};


const VehicleSerialNoUpload = async (req, res) => {
  try {
    const stripBomStream = (await import("strip-bom-stream")).default;
    await sequelize.sync();
    if (!req.file) {
      return res
        .status(400)
        .json({ status: false, code: 400, error: "No file uploaded" });
    }
    const fileRows = [],
      vehicleObj = {};
    let vehicles = await Vehicle.findAll({
    //   where: { deletevehicleStatus: 0, Immob_status: 1 },
      raw: true,
      nest: true,
      attributes: ["VIN", "VehicleRegNo", "vid"],
    });
    const VehiclesTableData = vehicles.reduce((acc, cur) => {
      let vin = cur.VIN.slice(3);
      if (!acc[vin]) acc[vin] = cur;
      return acc;
    }, {});
    let vehicleSerialData = await VinSerialNum.findAll({
      attributes: ["VIN", "id", "vinserialnum", "Manufactured_Date"],
      raw: true,
      nest: true,
    });
    let pastMaxVinSerial = 0;
    const pastVinSerialData = vehicleSerialData.reduce((acc, cur) => {
      let splicedVIN = parseInt(cur.vinserialnum.replace("VIN", ""), 10);
      pastMaxVinSerial =
        splicedVIN > pastMaxVinSerial ? splicedVIN : pastMaxVinSerial;
      if (!acc[cur.VIN]) {
        acc[cur.VIN] = cur;
      }
      return acc;
    }, {});
    for (const item of vehicles) {
      vehicleObj[item["VIN"].slice(3)] = item;
    }
    fs.createReadStream(req.file.path)
      .pipe(stripBomStream())
      .pipe(csvParser())
      .on("data", (data) => {
        if(data['VIN No.'].length===0) {
           return; 
        }
        return fileRows.push(data);
      })
      .on("end", async () => {
        // console.log(fileRows.length,'fileRows')
        await fs.promises.unlink(req.file.path);
        let bulkData = [];
        let vinprefix="VIN";
        for (const row of fileRows) {
            let item={}
            let vin=row['VIN No.']
            if(!vin.startsWith("MD9") && !vin.startsWith('P6R')){
              return res.status(400).json({
                status: false,
                code: 400,
                error: `Invalid Vin Name - ${vin}`
              })
            }
            if(!pastVinSerialData[vin]){
                ++pastMaxVinSerial;
                let nextSerialNum=vinprefix+String(pastMaxVinSerial).padStart(6,'0');
                if(!VehiclesTableData[vin]){
                  return res.status(400).json({
                    status: false,
                    code: 400,
                    error: `No vehicle found for VIN ${vin}- Invalid Vin Name`
                  })
                }
                item={vinserialnum:nextSerialNum,vehicleId:VehiclesTableData[vin]['vid'],...getVehicleSerialDetails(row)}
            }else{
                item={vinserialnum:pastVinSerialData[vin]['vinserialnum'],vehicleId:VehiclesTableData[vin]['vid'],...getVehicleSerialDetails(row)}
            }
            bulkData.push(item)
        }
        await VinSerialNum.bulkCreate(bulkData, {
            updateOnDuplicate: ['type','color','mfgyear','mfgmonth','Manufactured_Date'],
          });
        return res.json({
          status: true,
          code: 200,
          data: bulkData
        });
      });
  } catch (error) {
    console.log(error);
    return res.json({
      status: false,
      code: 500,
      error: "Internal server error",
    });
  }
};

module.exports = {
  addVehicle,
  addVehicleSaleStatement,
  addJobCards,
  VehicleSerialNoUpload,
};
