const mongoose = require("mongoose");
const { response } = require("express");
const Vehicle = require("../../models/vehicle");
const Mqtt = require("../../models/mqttSecure");
const moment = require("moment");
const fs = require("fs");
const VehicleOneTimeInfo = require("../../models/vehicleOneTimeInfo");
connection = (url) => {
  mongoose.connect(url, { useNewUrlParser: true });
};

const url =
  "mongodb+srv://alti-admin-prod:APL2023ADMIN@mqtt-production.iqeii.mongodb.net/mqttDatabase_aplmq";

const otiObject = {
  topic: String,
  ver: Number,
  RTC: Date,
  O1: String,
  O2: Number,
  O3: String,
  O4: String,
  O5: String,
  O6: Number,
  O7: Number,
  O8: Number,
  O9: Number,
  O10: Number,
  O11: Number,
  O12: Number,
  O13: Number,
  O14: Number,
  O15: Number,
  O16: Number,
  O17: Number,
  O18: Number,
  O19: Number,
  O20: Number,
  O21: Number,
  O22: Number,
  O23: Number,
  O24: Number,
  O25: Number,
  O26: Number,
  O27: Number,
  O28: Number,
  O29: Number,
  O30: Number,
  O31: Number,
  O32: Number,
  O33: Number,
  O34: Number,
  O35: Number,
  timeStamp: Date,
  KIT: String,
  F: String,
};

const getOtiInfo = async (req, res) => {
  try {
    await connection(url);
    let { vin, startDate, endDate } = req.body;
    vin = vin.startsWith("mq/") ? vin : "mq/" + vin;
    startDate = moment(startDate).format("YYYY-MM-DDT00:00:00");
    endDate = moment(endDate).format("YYYY-MM-DDT23:59:59");
    console.log(vin, startDate, endDate);
    const data = await VehicleOneTimeInfo.aggregate([
      {
        $match: {
          topic: vin,
          RTC: {
            $gte: startDate,
            $lte: endDate,
          },
        },
      },
      {
        $sort: {
          RTC: -1,
        },
      },
      {
        $project: {
          _id: 0,
          vin: "$topic",
          date: "$RTC",
          ICCID: "$O1",
          IMEI: "$O2",
          "SIM Provider": "$O3",
          "VDM ID": "$O6",
          "VDM SOFTWARE VERSION": "$O7",
          "VDM SOFTWARE CHECKSUM": "$O8",
          "VDM SERIAL NUMBER": "$O9",
          "BATTERY SERIAL NUMBER": "$O11",
          "BMS V1": "$O12",
          "BMS V2": "$O13",
          "BMS V3": "$O14",
          "CONTROLLER SOFTWARE CHECKSUM": "$O15",
          "CONTROLLER SERIAL NUMBER": "$O16",
          "EV CONFIG (2)": "$O17",
          "POWER TRAIN CONFIG": "$O18",
          "MOTOR SERIAL NUMBER": "$O19",
          "PACKET COUNT": "$O26",
          "RTC Date": "$O32",
          "RTC Tmie": "$O33",
          timeStamp: "$timeStamp",
          KIT: "$KIT",
          F: "$F",
        },
      },
    ]);
    // console.log(data.length, "len");
    return res.json({
      status: true,
      code: 200,
      data: data,
    });
  } catch (error) {
    console.log(error, "err");
    return res.json({
      status: false,
      code: 500,
      error: error,
    });
  }
};

module.exports = {
  getOtiInfo,
};
