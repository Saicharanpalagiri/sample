const mongoose = require("mongoose");
const Vehicle = require("../../models/vehicle");
const Client = require("../../models/client");
const ClientVehicle = require("../../models/client-vehicle");
const sequelize = require("../../utils/sqldb");
const { Op } = require("sequelize");
const { monthsObject } = require("../../utils/constants");

connection = (url) => {
  mongoose.connect(url, { useNewUrlParser: true });
};

const url =
  "mongodb+srv://alti-admin-prod:APL2023ADMIN@mqtt-production.iqeii.mongodb.net/mqttDatabase_aplmq";

  const filterKeys = (object, keysToRemove) => {
    const filteredObject = { ...object };

    keysToRemove.forEach(key => {
        if (filteredObject.hasOwnProperty(key)) {
            delete filteredObject[key];
        }
    });

    return filteredObject;
}

const getConfigurationData = async (req, res) => {
  let result = {
    montlyData: null,
    yearlyData: null,
    models: null,
    sim_service_provider: null,
  };
  const { year } = req.body;
  let vehiclesList;
  await connection(url);
  Client.belongsToMany(Vehicle, { through: ClientVehicle, foreignKey: "cid" });
  Vehicle.belongsToMany(Client, { through: ClientVehicle, foreignKey: "vid" });

  await sequelize.sync();

  try {
    vehiclesList = await Vehicle.findAll({
      attributes: [
        ["VIN", "vin"],
        ["VehicleRegNo", "reg_no"],
        "model",
        "SIMservicePrName",
        "mfgyear",
        "mfgmonth",
        "network_type"
      ],
      where: {
        model: {
          [Op.notIn]: [
            "model",
            "N",
            "004",
            "0001",
            "002",
            "test151",
            "testmodel301",
            "1001001",
            "1001002",
            "1001003",
            "1001005",
            "1001006",
            "1001007",
            "1001009",
            "1001011",
            "1003",
            "1004",
            "1005",
            "1006",
            "1007",
            "1008",
            "MD93WD6CZXM515418",
          ],
        },
        SIMservicePrName: {
          [Op.notIn]: [
            "001",
            "0001",
            "002",
            "test151",
            "testsimprovname301",
            "1001001",
            "1001002",
            "1001005",
            "1001006",
            "1001009",
            "1001011",
            "1003",
            "1004",
            "1005",
            "1006",
            "1007",
            "1008",
            "MD93WD6CZXM515418",
            "P6R3NAACNKK000304",
            "MD93WD6PGKY515418",
            "testimei10",
            "test1236",
            "xxxxx"
          ],
        },
        deleteVehicleStatus: 0,
        mfgyear: year
      },
       order:[['mfgmonth','ASC']],
      nest: true,
      include: [
        {
          model: Client,
          attributes: ["clientCode"],
          through: { attributes: [] },
        },
      ],
    });

    
    vehiclesList=vehiclesList.sort((a,b)=>(a.mfgmonth-b.mfgmonth))
    vehiclesList = vehiclesList.map((item) => ({
      vin: item.dataValues.vin.slice(3),
      reg_no: item.dataValues.reg_no,
      fleets: item["Clients"]
        .map((client) => client.dataValues.clientCode)
        .join(","),
        "model": item.dataValues.model,
        "SIMservicePrName": item.dataValues.SIMservicePrName,
        "mfgyear": item.dataValues.mfgyear,
        "mfgmonth": item.dataValues.mfgmonth,
        "network_type": item.dataValues.network_type
    }));



    result.montlyData = vehiclesList.reduce((acc, cum) => {
      if (
        !cum.mfgmonth ||
        cum.mfgyear !== year.toString()
      ) {
        return acc;
      }
      if (!acc.hasOwnProperty(monthsObject[[cum.mfgmonth]])) {
        return {
          ...acc,
          [monthsObject[[cum.mfgmonth]]]: [
            filterKeys(cum, ["SIMservicePrName", "mfgyear", "mfgmonth"]),
          ],
        };
      } else {
        return {
          ...acc,
          [monthsObject[[cum.mfgmonth]]]: [
            ...acc[monthsObject[[cum.mfgmonth]]],
            filterKeys(cum, ["SIMservicePrName", "mfgyear", "mfgmonth"]),
          ],
        };
      }
    }, {});

    result.yearlyData = vehiclesList.reduce((acc, cum) => {
      if (cum.mfgyear === "" || !cum.mfgyear || cum.mfgyear === "0") return acc;
      if (!acc.hasOwnProperty(cum.mfgyear)) {
        return {
          ...acc,
          [cum.mfgyear]: [
            filterKeys(cum, ["SIMservicePrName", "mfgyear", "mfgmonth"]),
          ],
        };
      } else {
        return {
          ...acc,
          [cum.mfgyear]: [
            ...acc[cum.mfgyear],
            filterKeys(cum, ["SIMservicePrName", "mfgyear", "mfgmonth"]),
          ],
        };
      }
    }, {});

    result.models = vehiclesList.reduce((acc, cum) => {
      if (cum.model === "") return acc;
      if (!acc.hasOwnProperty(cum.model)) {
        return {
          ...acc,
          [cum.model]: [
            filterKeys(cum, ["SIMservicePrName", "mfgyear", "mfgmonth"]),
          ],
        };
      } else {
        return {
          ...acc,
          [cum.model]: [
            ...acc[cum.model],
            filterKeys(cum, ["SIMservicePrName", "mfgyear", "mfgmonth"]),
          ],
        };
      }
    }, {});

    result.sim_service_provider = vehiclesList.reduce((acc, cum) => {
      if (cum.SIMservicePrName === "") return acc;
      if (!acc.hasOwnProperty(cum.SIMservicePrName)) {
        return {
          ...acc,
          [cum.SIMservicePrName]: [
            filterKeys(cum, [ "mfgyear", "mfgmonth"]),
          ],
        };
      } else {
        return {
          ...acc,
          [cum.SIMservicePrName]: [
            ...acc[cum.SIMservicePrName],
            filterKeys(cum, ["mfgyear", "mfgmonth"]),
          ],
        };
      }
    }, {});

    if(!vehiclesList.length) return res.json({status: false, result: []})

    return res.json({ status: true, ...result });
  } catch (error) {
    console.log(error)
    return res.json(error);
  }
};

module.exports = { getConfigurationData };
