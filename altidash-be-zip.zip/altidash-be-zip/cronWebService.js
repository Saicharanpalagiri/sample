/* (c) 2022 Autoven Private Limited. All rights reserved. */

var CronJob = require('cron').CronJob;
const mongoose = require('mongoose')
const Vehicle = require('./models/vehicle')
const Mqtt = require('./models/mqttSecure');
const axios = require ('axios')
const Client = require ('./models/client')
const ClientVehicle = require ('./models/client-vehicle')
const sequelize = require('./utils/sqldb')
const ClientCustomAPI = require('./models/client-customApi');
const CustomAPI = require('./models/customAPI');
const logger = require('./logger')
const moment = require("moment");
const {unixtime}=require('./utils/helpers/unixTimeStamp')
const https = require('https');
const momentTz = require("moment-timezone");
const PushApiLog = require('./models/pushApiLog');
const pushApiLog = require('./models/pushApiLog');
//to connet mongo server
connection = (url) => {
  mongoose.connect(url, {useNewUrlParser: true,})
}

//to get mongo data
const getMongoData = async (url, VIN) => {
	await connection(url);  
	let mongoData;
	try {
	  const timeNow = momentTz().tz("Asia/Kolkata").format("YYYY-MM-DDTHH:mm:ss");
	  mongoData = await Mqtt.find({topic: VIN,RTC:{$lte:timeNow}}).sort({RTC : -1}).limit(1)
	} catch (err) {
	  mongoData = []
	}
	return mongoData
}

//to get ignition status
getIngnitionStatus = (vData) => {
	let ignition = false;
	  var ignitionEnable = vData.C5 & 0x0800
	  if (ignitionEnable){
		ignition = true;
	  }
	return ignition;
}

//get fleet name
const getFleets = async() =>{
	Client.belongsToMany(CustomAPI,{through:ClientCustomAPI,foreignKey : 'cid'})
	CustomAPI.belongsToMany(Client,{through :ClientCustomAPI,foreignKey : 'apid'})
	let allFleets = await Client.findAll({
		include:[{
			model : CustomAPI,
			attributes :['apid','apiName'],
			where : {apiName : 'VendorAssestData'}
		}],
		where : [{ enablePushApis : 1 }],
		attributes : ["clientCode","cid","mongoDbName","duration","apiKey","endPoint","paramOne","paramTwo","paramThree"]
	})
	// console.log(allFleets,'allFleets');
	return allFleets;
}

//get Vehicles of the fleet
const getVehicles = async (cid) =>{
	Vehicle.belongsToMany(Client, {through: ClientVehicle, foreignKey: 'vid'})
	Client.belongsToMany(Vehicle, {through: ClientVehicle, foreignKey: 'cid'})
	await sequelize.sync();
	let vehicles;
	let vehicleList = []
	try{
		vehicles = await Vehicle.findAll({
			include : [{ 
				model : Client,
				attributes : [],
				where : { cid : cid }
			}],
			where: { deletevehicleStatus: 0,Immob_status : 1},
			raw : true,
			nest : true,
			attributes : ['VIN']
		})
		for(i in vehicles){
			vehicleList.push(vehicles[i].VIN)
		}
	}catch(err){
		return [];
	}
	return vehicleList
}

//scheduling cron job per minutes
var job = new CronJob('*/4 * * * *', async function() {
	console.log("Running cron NOW")
	let d = new Date();
	let	m = d.getHours() * 60 + d.getMinutes(); 
	let fleets = await getFleets();
	// console.log({fleets : fleets.length})
	let count = 1;

	for(let data in fleets){
		console.log(fleets[data].clientCode,fleets[data].cid)
		// Lets transport
		if(fleets[data].cid == 148){
			//staging -337
			//prod-148
			console.log({data : fleets[data].cid})

			await pushDataOne(fleets[data],count);
			count +=1
		}
	}
	console.log("complete")
	}
);

var job1 = new CronJob('*/4 * * * *', async function() {
	console.log("Running cron NOW")
	let d = new Date();
	let	m = d.getHours() * 60 + d.getMinutes(); 
	let fleets = await getFleets();
	// console.log({fleets : fleets.length})
	let count = 1;

	for(let data in fleets){
		console.log(fleets[data].clientCode,fleets[data].cid)
		//mahindra
		if(fleets[data].cid == 60){
			//staging -341
			//prod-60
			console.log({data : fleets[data].cid})

			await pushData(fleets[data],count);
			count +=1
		}
	}
	console.log("complete")
	}
);

var job2 = new CronJob('*/5 * * * *', async function() {
	console.log("Running cron")
	 
	// console.log(m)
	let fleets = await getFleets();
	console.log({fleets : fleets.length})
	// console.log(fleets)
	let count = 1;

	for(let data in fleets){
		if(fleets[data].cid == 58){
			// console.log({data : fleets[data].cid})
			//staging-1044
			//prod-58
			await cogoData(fleets[data],count);
			count +=1
		}
	}
	}
);




async function pushData(fleets,count){

	try{

	console.log(`Running for fleet ${count}`)
	
	const mahindraHeaders = {
		'Content-Type': 'application/json',
        'username' : "Mahindra",
        "password": "Mahindra@t4u",
		"accesskey":"MAHINDRA",        
		"serviceprovidername": "ALTIGREEN"
	}
	
	let LData;
	let LocationData;
	let obj;
	let assetData =[];
	const  logObject = {};
	let vehicleList = await getVehicles(fleets.cid);
	let url = fleets.mongoDbName;
	// console.log({vehicleList,url})
	let pushAssetUrl = process.env.MAHINDRA_URL;
	let vcount =1;
	// console.log(vehicleList,'vehicleList mahindra')
	for(i in vehicleList){
		// console.log(`Running for fleet ${count} , Vehicle : ${vcount} / ${vehicleList.length}`)
		try {
			const vSqlData = await Vehicle.findOne({
				where: {VIN: vehicleList[i]},
				attributes: ['VIN','VehicleRegNo']
			})
			let vMongoData = await getMongoData(url,vehicleList[i])
			vMongoData = vMongoData.length ? vMongoData[0] : null;
			if (vMongoData){
				LData = {
					"assetId": vSqlData.VehicleRegNo,
					"unit_no": vSqlData.VIN.slice(3,vSqlData.VIN.length),
					"latitude": vMongoData.lat ? vMongoData.lat.toFixed(6) : 0,
					"longitude": vMongoData.lng ? vMongoData.lng.toFixed(6) : 0,
					"gps_datetime": moment(vMongoData.RTC).format('YYYY-MM-DD HH:mm:ss.SSSSSS'),
					"gmt": moment(vMongoData.RTC).utc().format('YYYY-MM-DD HH:mm:ss.SSSSSS'),
					"speed": vMongoData.C19 ? (vMongoData.C19*0.01).toFixed(2).toString():"0",
					"battery_status": (vMongoData.C17*0.01) ? (vMongoData.C17*0.01).toFixed(2) : 0,
					"odometer": vMongoData.C20 || vMongoData.C21? ((vMongoData.C20*65536 + vMongoData.C21)/10) : 0,
				}
			}
			else{
				continue;
			}

			// assetData.push(LData)
			obj = {
				    // source : "newscript",
					LocationData : [LData]
			}

			//call API to push data
			// console.log({pushAssetUrl,obj,headers})
            const headers = mahindraHeaders;
			logObject.url = pushAssetUrl;
			logObject.body = obj;
			logObject.headers = headers;
			let result = null;
			try{
				 result = await axios.post(pushAssetUrl, obj, {headers});
			}
			catch(err){
               result = err;
			}
			console.log(result,'res')
			logObject.response = result.data
            logObject.api = "MAHINDRA"
			logObject.success = true;

			console.log(logObject)
			await PushApiLog.create({...logObject})
			// console.log({result})
			if(result){
				let succObj;
				// if(result.data.code === 200){
				// 	succObj = {
				// 		status : "Publish was successful, No retry needed",
				// 		code : 200,
				// 		message : "Publish Successful"
				// 	}
				// }
				assetData = []
				vcount +=1

			continue ;	
			}
		}catch(error){
			logObject.url = pushAssetUrl;
            logObject.api = "MAHINDRA"
			logObject.success = false;
			await PushApiLog.create({...logObject})
			continue
		}
		vcount +=1
	}
}catch(err){
	console.log({err})
}		
}

async function pushDataOne(fleets,count){
	try{

	console.log(`Running for fleet ${count}`)
	const letsTransportHeaders = {
		'Content-Type': 'application/json',
        'username' : "LETS",
        "password": "LETS@t4u",
		"accesskey":"LETS",        
		"serviceprovidername": "ALTIGREEN"
	}
	const logObject={};
	let LData;
	let LocationData;
	let obj;
	let assetData =[];
	let vehicleList = await getVehicles(fleets.cid);
	let url = fleets.mongoDbName;
	// console.log(url,'url')
	// console.log(vehicleList,'vehicleList')
	let pushAssetUrl = process.env.LETS_TRANSPORT_URL;
	// console.log({vehicleList,url})
	let vcount =1;
	for(i in vehicleList){
		// console.log(`Running for fleet ${count} , Vehicle : ${vcount} / ${vehicleList.length}`)
		try {
			const vSqlData = await Vehicle.findOne({
				where: {VIN: vehicleList[i]},
				attributes: ['VIN','VehicleRegNo']
			})
			let vMongoData = await getMongoData(url,vehicleList[i])
			vMongoData = vMongoData.length ? vMongoData[0] : null;
			if (vMongoData){
				LData = {
					"assetId": vSqlData.VehicleRegNo,
					"unit_no": vSqlData.VIN.slice(3,vSqlData.VIN.length),
					"latitude": vMongoData.lat ? vMongoData.lat.toFixed(6) : 0,
					"longitude": vMongoData.lng ? vMongoData.lng.toFixed(6) : 0,
					"gps_datetime": moment(vMongoData.RTC).format('YYYY-MM-DD HH:mm:ss.SSSSSS'),
					"gmt": moment(vMongoData.RTC).utc().format('YYYY-MM-DD HH:mm:ss.SSSSSS'),
					"speed": vMongoData.C19 ? (vMongoData.C19*0.01).toFixed(2).toString() :"0",
					"battery_status": (vMongoData.C17*0.01) ? (vMongoData.C17*0.01).toFixed(2) : 0,
					"odometer": vMongoData.C20 || vMongoData.C21? ((vMongoData.C20*65536 + vMongoData.C21)/10) : 0,
				}
			}
			else{
				continue;
			}

			// assetData.push(LData)
			obj = {
				    // source : "newscript",
					LocationData : [LData]
			}

			//call API to push data
			// console.log({pushAssetUrl,obj,headers})
			let result = null;
			const headers=letsTransportHeaders;
			logObject.url=pushAssetUrl;
			logObject.body=obj;
			logObject.headers=headers;

			try {
				result=await axios.post(pushAssetUrl, obj,{headers});
			} catch (error) {
				result=error;
			}

			logObject.response=result.data;
			logObject.api="LETSTRANSPORT";
			logObject.success=true;
			await pushApiLog.create({...logObject})

			// console.log(result)
			if(result){
				let succObj;
				// if(result.data.code === 200){
				// // 	succObj = {
				// // 		status : "Publish was successful, No retry needed",
				// // 		code : 200,
				// // 		message : "Publish Successful"
				// // 	}
				// }
				assetData = []
				vcount +=1

			continue ;	
			}
		}catch(error){
			// console.log(error)
			// 	if(error.response && error.response.status === 401){
			// 		errObj = {
			// 			status : "Publish was not successful, Need to stop iterator and retry current packet",
			// 			code : 401,
			// 			message : "Unauthorized: You are not authorized to perform this action, please check your token or contact you Delhivery POC"
			// 		}
			// 	}else{
			// 		errObj = {
			// 			status : "Publish was not successful, Need to stop iterator and retry current packet after 1s, if this crosses 1min",
			// 			code : 500,
			// 			message : "Unknown Error"
			// 		}
			// 	}
			// return errObj;
			logObject.url=pushAssetUrl;
			logObject.api="LETSTRANSPORT";
			logObject.success=false;
			await pushApiLog.create({...logObject});
			continue;
		}
		vcount +=1
	}
}catch(err){
	console.log({err})
}		
}

async function cogoData(fleets,count){
	try{

	console.log(`Running for fleet ${count}`)
	const logObject={};
	let LData;
	let LocationData;
	let obj;
	let assetData =[];
	let vehicleList = await getVehicles(fleets.cid);
	let url = fleets.mongoDbName;
	let pushAssetUrl =process.env.COGOS_URL;
	// console.log(vehicleList,'vehicleList cogos')
	// console.log({vehicleList,url})
	let vcount =1;
	for(i in vehicleList){
		console.log(`Running for fleet ${count} , Vehicle : ${vcount} / ${vehicleList.length}`)
		try {
			const vSqlData = await Vehicle.findOne({
				where: {VIN: vehicleList[i]},
				attributes: ['VIN','VehicleRegNo']
			})
			let vMongoData = await getMongoData(url,vehicleList[i])
			vMongoData = vMongoData.length ? vMongoData[0] : null;
			if (vMongoData){
				LData = {
					"unit_no": vSqlData.VIN.slice(3,vSqlData.VIN.length),
					"lat": vMongoData.lat ? vMongoData.lat.toFixed(6) : 0,
					"lon": vMongoData.lng ? vMongoData.lng.toFixed(6) : 0,
					"speed": vMongoData.C19 ? (vMongoData.C19*0.01).toFixed(2).toString():"0",
					"altitude": (vMongoData.G7) ? (vMongoData.G7) : 0,
					"odometer": vMongoData.C20 || vMongoData.C21? ((vMongoData.C20*65536 + vMongoData.C21)/10) : 0,
					"accuracy":vMongoData.G6,
					"timestamp":unixtime(vMongoData.RTC)
					}
					// console.log(LData);
			}
			else{
				continue;

			}
			// assetData.push(LData)
			// obj = {
			// 	    source : "newscript",
			// 		LocationData : assetData
			// }
			
			console.log(assetData,'assetData')
			//call API to push data
			// console.log({pushAssetUrl,obj,headers})
			logObject.url=pushAssetUrl+`/?id=${LData.unit_no}&amp;timestamp=${LData.timestamp}&lat=${LData.lat}&lon=${LData.lon}&speed=${LData.speed}&altitude=${LData.altitude}&accuracy=${LData.accuracy}`;
			// logObject.body=obj;

			let result = null;
			try {
				result = await axios.get(pushAssetUrl+`/?id=${LData.unit_no}&amp;timestamp=${LData.timestamp}&lat=${LData.lat}&lon=${LData.lon}&speed=${LData.speed}&altitude=${LData.altitude}&accuracy=${LData.accuracy}`
				,{
					httpsAgent: new https.Agent({ rejectUnauthorized: false })
				});
				console.log({result})
			} catch (error) {
				result=error;
			}
			logObject.response=result.data;
			logObject.api="cogosdata";
			logObject.success=true;
			await PushApiLog.create({...logObject})
			
			//  console.log({result})
			//   const result =null;
			if(result){
				let succObj;
				// if(result.data.code === 200){
				// 	succObj = {
				// 		status : "Publish was successful, No retry needed",
				// 		code : 200,
				// 		message : "Publish Successful"
				// 	}
				// }
				assetData = []
				vcount +=1

			continue ;	
			}
		}catch(error){
			console.log(error)
			// 	if(error.response && error.response.status === 401){
			// 		errObj = {
			// 			status : "Publish was not successful, Need to stop iterator and retry current packet",
			// 			code : 401,
			// 			message : "Unauthorized: You are not authorized to perform this action, please check your token or contact you Delhivery POC"
			// 		}
			// 	}else{
			// 		errObj = {
			// 			status : "Publish was not successful, Need to stop iterator and retry current packet after 1s, if this crosses 1min",
			// 			code : 500,
			// 			message : "Unknown Error"
			// 		}
			// 	}
			// return errObj;
			logObject.url =pushAssetUrl +`/?id=${LData.unit_no}&amp;timestamp=${LData.timestamp}&lat=${LData.lat}&lon=${LData.lon}&speed=${LData.speed}&altitude=${LData.altitude}&accuracy=${LData.accuracy}`;
            logObject.api = "cogosdata"
			logObject.success = false;
			await PushApiLog.create({...logObject})
			continue;
		}
		vcount +=1
	}
}catch(err){
	console.log({err})
}		
}

job.start()
job1.start()
job2.start()
