/* (c) 2022 Autoven Private Limited. All rights reserved. */

var CronJob = require('cron').CronJob;
const mongoose = require('mongoose')
const Vehicle = require('./models/vehicle')
const Mqtt = require('./models/mqttSecure');
const axios = require ('axios')
const Client = require ('./models/client')
const ClientVehicle = require ('./models/client-vehicle')
const sequelize = require('./utils/sqldb')
const CustomApi = require ('./models/customAPI')
const ClientCustomAPI = require('./models/client-customApi');
const CustomAPI = require('./models/customAPI');
const logger = require('./logger')

//to connet mongo server
connection = (url) => {
  mongoose.connect(url, {useNewUrlParser: true,})
}

//to get mongo data
const getMongoData = async (url, VIN) => {
	await connection(url);  
	let mongoData;
	try {
	  mongoData = await Mqtt.find({topic: VIN}).sort({RTC : -1}).limit(2)
	} catch (err) {
	  mongoData = []
	}
	return mongoData
}

//to get ignition status
getIngnitionStatus = (vData) => {
	let ignition = false;
	var ignitionEnable = vData.C5 & 0x0800
	if (ignitionEnable){
		ignition = true;
	}
	return ignition;
}

//get fleet name
const getFleets = async() =>{
	Client.belongsToMany(CustomAPI,{through:ClientCustomAPI,foreignKey : 'cid'})
	CustomAPI.belongsToMany(Client,{through :ClientCustomAPI,foreignKey : 'apid'})
	let allFleets = await Client.findAll({
		include:[{
			model : CustomApi,
			attributes :['apid','apiName'],
			where : {apiName : 'PushMTSData'}
		}],
		where : [{ enablePushApis : 1 }],
		attributes : ["clientCode","cid","mongoDbName","duration","apiKey","endPoint","paramOne","paramTwo","paramThree"]
	})
	return allFleets;
}

//get Vehicles of the fleet
const getVehicles = async (cid) =>{
	Vehicle.belongsToMany(Client, {through: ClientVehicle, foreignKey: 'vid'})
	Client.belongsToMany(Vehicle, {through: ClientVehicle, foreignKey: 'cid'})
	await sequelize.sync();
	let vehicles;
	let vehicleList = []
	try{
		vehicles = await Vehicle.findAll({
			include : [{ 
				model : Client,
				attributes : [],
				where : { cid : cid }
			}],
			where: { deletevehicleStatus: 0,Immob_status : 1},
			raw : true,
			nest : true,
			attributes : ['VIN']
		})
		for(i in vehicles){
			vehicleList.push(vehicles[i].VIN)
		}
	}catch(err){
		return [];
	}
	return vehicleList
}

//scheduling cron job per minutes
var job = new CronJob('* * * * *', async function() {
	let d = new Date();
	let	m = d.getHours() * 60 + d.getMinutes();
	let fleets = await getFleets();
	for(let data in fleets){
		if(m%fleets[data].duration === 0){
			pushData(fleets[data]);
		}
	}
	}
);

async function pushData(fleets){
	const headers = {
			'Content-Type': 'application/json',
			'Authorization': `Bearer ${fleets.apiKey}` // here 'apiKey' will come from fleets table for the perticular fleet
		}
	username = fleets.paramOne;
	let coordinates;
	let obj;
	let mData =[];
	let vList = await getVehicles(fleets.cid);
	let url = fleets.mongoDbName;
	for(let j in vList){
		try {
			const vSqlData = await Vehicle.findOne({
				where: {VIN: vList[j]},
				attributes: ['VIN','VehicleRegNo']
			})
			const vMongoData = await getMongoData(url,vList[j])
			if(vMongoData.length !== 0){
				for (let item in  vMongoData){
					const vRunningStatus = await getIngnitionStatus(vMongoData[item])
					if(vRunningStatus){
						coordinates = {
							"epoch": Date.parse(vMongoData[item].RTC),
							"lat": vMongoData[item].lat,
							"lon": vMongoData[item].lng,
							"spd": vMongoData[item].C19*0.01,
							"server_timestamp": Date.parse(vMongoData[item].RTC),
							"vendor_device_id": vSqlData.VehicleRegNo,
							"vendor_device_details": "Dummy-Model",
							"vehicle_number": vSqlData.VIN,
							"ignition": true,
							"gps_status": "valid",
							"gps_packet_type": item === 0 ? "current" : "past",
						}
					}else{
						coordinates = {
							"epoch": Date.parse(vMongoData[item].RTC),
							"lat": null,
							"lon": null,
							"spd": null,
							"server_timestamp": Date.parse(vMongoData[item].RTC),
							"vendor_device_id": vSqlData.VehicleRegNo,
							"vendor_device_details": "Dummy-Model",
							"vehicle_number": vSqlData.VIN,
							"ignition":false,
							"gps_status": "invalid",
							"gps_packet_type": item === 0 ? "current" : "past",
						}
					}	
				}
			}else{
				coordinates = {
					"epoch": 0,
					"lat": 0,
					"lon": 0,
					"spd": 0,
					"server_timestamp": 0,
					"vendor_device_id": vSqlData.VehicleRegNo,
					"vendor_device_details": "NA",
					"vehicle_number": vSqlData.VIN,
					"ignition": false,
					"gps_status": "NA",
					"gps_packet_type": "NA",
			}}
			mData.push(coordinates)
			obj = {
				VIN : vSqlData.VIN,
				vendor_name : "Altigreen",
				count : 2,
				coordinates : mData,
				authkey : fleets.apiKey,
				username : fleets.paramOne
			}
			let pushUrl = fleets.endPoint.concat("/pushMtsData") // here 'endPoint' will come from fleets tabel
			const data = await axios.post(pushUrl, obj, {
				headers:headers
			})
			if(data){
				let succObj;
				if(data.data.code === 200){
					succObj = {
						status : "Publish was successful, No retry needed",
						code : 200,
						message : "Publish Successful"
					}
				}
			continue;
			}		
		}catch(error){
			if(error.response.status === 401){
				errObj = {
					status : "Publish was not successful, Need to stop iterator and retry current packet",
					code : 401,
					message : "Unauthorized: You are not authorized to perform this action, please check your token or contact you Delhivery POC"
				}
			}else{
				errObj = {
					status : "Publish was not successful, Need to stop iterator and retry current packet after 1s, if this crosses 1min",
					code : 500,
					message : "Unknown Error"
				}
			}
		return errObj;
		}
	}			
}

job.start()
