/* (c) 2022 Autoven Private Limited. All rights reserved. */
const {Sequelize} = require('sequelize');

const sequelizeTcp = new Sequelize("apl_MetaDB", "admin","Altigreen2022", {
  host: "apl-metadb-staging.cp2cudaw267x.ap-south-1.rds.amazonaws.com",
  dialect: 'mysql',
  logging: false,
  dialectOptions: {
    dateStrings: true,
    typeCast: function (field, next) { // for reading from database
      if (field.type === 'DATETIME') {
          return field.string()
      }
      return next()
    },
  },
  timezone: '+05:30'
});
module.exports = sequelizeTcp;
