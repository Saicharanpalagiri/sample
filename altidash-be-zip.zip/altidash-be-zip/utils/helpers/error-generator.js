
/**
 * Used to generate Errors that are caught by global error handler
 * @param {Error Message} message 
 * @param {Status code of the error} statusCode 
 * @returns 
 */

const generateError = (message, statusCode = 200) => {
    const error = new Error(message);
    error[`code`] = statusCode;
    return error;
}

module.exports = {
    generateError : generateError
}