/**
 * Used to handle all errors across the server
 * 1. Logs Error Locally
 * 2. Creates a Copy of the request in DB
 * 3. Logs to loggly
 */

const { Logger } = require("../../lib/logger")

const errorHandler = async( request,response,error ) => {
    Logger.error(error);
    
}

module.exports = {
    errorHandler : errorHandler
}