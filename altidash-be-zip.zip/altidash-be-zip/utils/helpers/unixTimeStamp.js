const momentTz = require("moment-timezone");

const unixtime=(rtc)=>{
    const unixTimestampUTC=momentTz.tz(rtc,'YYYY-MM-DDTHH:mm:ss','Asia/Calcutta').valueOf()
    return (unixTimestampUTC/1000);
    
    };

module.exports={unixtime};

