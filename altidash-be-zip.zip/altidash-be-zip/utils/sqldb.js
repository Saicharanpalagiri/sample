/* (c) 2022 Autoven Private Limited. All rights reserved. */
const {Sequelize} = require('sequelize');

console.log(process.env.SQL_DB_NAME)  
const sequelize = new Sequelize(process.env.SQL_DB_NAME, process.env.SQL_DB_USER, process.env.SQL_DB_PASSWORD, {
  host: process.env.SQL_HOST,
  dialect: 'mysql',
  logging: false,
  dialectOptions: {
    dateStrings: true,
    typeCast: function (field, next) { // for reading from database
      if (field.type === 'DATETIME') {
          return field.string()
      }
      return next()
    },
  },
  timezone: '+05:30'
});

module.exports = sequelize;
