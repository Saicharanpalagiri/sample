const aplToVDD={
    vin:'topic',
    end_odo:'x11',
    start_odo:'x10',
    distance:'x12',
    avg_speed:'x13',
    max_speed:'x14',
    start_geo_code:'x58',
    end_geo_code:'x59',
    soh:'x53',
    end_time:'x82',
    start_time:'x81',
    end_soc:'x55',
    start_soc:'x54',
    start_geo_code:'x58',
    end_geo_code:'x59',
    efficiency:'x35',
    energy_used:'x33',
    cummulative_energy:'x87',
    charging_status:'x99'
}

module.exports={aplToVDD};