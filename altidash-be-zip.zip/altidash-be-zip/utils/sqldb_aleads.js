const {Sequelize} = require('sequelize');
// const sequelize_aleads = new Sequelize("fusion", "root", "root", {
//     host: "localhost",  
const sequelize_aleads = new Sequelize("a_lead", "alead", "PHSrJhWE7EzBzG", {
    host: "apl-apps.cp2cudaw267x.ap-south-1.rds.amazonaws.com",  
    port: 3306,
    dialect: 'mysql',
    logging: false,
    dialectOptions: {
      dateStrings: true,
      typeCast: function (field, next) {
        // for reading from the database
        if (field.type === 'DATETIME') {
          return field.string();
        }
        return next();
      },
    },
    timezone: '+05:30',
});

module.exports = sequelize_aleads;

