4.12
 * Added 24 hour time check in remoteLockUnlock API for unlock requests.
 * User role checked in check custom auth
 * Resolved issue with lockUnlock
4.11
 * Env file added and variables set
4.10
 * Added Loggly.
4.9
 * Auditlogs added for RemoteLockUnlock & mqttLockUnlock controllers
 * Audit logs added for all pull Apis
4.8
 * Middleware to check Enabled Apis for users
 * Push API codes modified for selected  Fleets
4.7
 * Push API- cron files to run every minute. API integrated to fetch values from fleet Table
 * GetVehicleStatus controller modified to give status from immob_Status
 * Latitude & longitude getting code changed
4.6
 * Multiple vehicle_id Validations for RemoteLockUnlock & VehicleStatus
 * Trimming of spaces in RemoteLockUnlock & VehicleStatus
 * Deactivated vehicle response changes for  RemoteLockUnlock & VehicleStatus
4.5
 * Validations for Push APIs
 * Date mandatory error added
 * Get API access error Modified
 * Vehicle-id & request-for validations in RemoteLockUnlock
4.4
 * Cron-Data fetched for Customer APIs 
 * cron-Data fetched for New APIs
4.3
 * Key to generate AuthToken Changed for users. 
 * Auth token to be stored in database against user
4.2.9
 * trim function modified - spaces from start and end removed in username and authKey
4.2.8
 * trim function for date, username and authtoken added.
4.2.7
 * Date format filter updated
 * mqttsecure model G8 type updated to string
 * display name field added to getVehicleFinance info
 * Vehicle from database filter code
 * Updated 'fleetInsights.py', 'liveLocation.py' script using cron data collection.
4.2.6
 * Error code added for duplicate parameter from Postman
 * Error code if date conatins alphabet getDayCumulativeVehicleInfo1 
4.2.5
 * Response for Invalid VIN removed
 * Error response added if extra parameter is passed
 * get-vehicles middleware modified to get all vehicles for "Super"
4.2.4
 * Deactivated user check code added in checkCustom- Auth
 * Deactivated Fleet code added in checkCustom- Auth
4.2.3
 * Unmapped VIN response changed
 * Mongo URL to be added to SQlDb when adding fleet.
 * Last RTC data is sent for getvehicleInfo - removed time stamp comparison
4.2.2
 * Date format checker for getDayCumulativeVehicleInfo1 controller
 * Added code to handle unchecked vehicle_ids from Postman
 * Added code to filterout duplicate vehicles in customAPI's
4.2.1
 * Updated default timestamp format to IST in sqlDb.
4.2
 * Custom API changes added for spaces in Multiple VIN's
 * Date format checker code for getDayCumulativeVehicleInfo2 controller
4.1
 * first commit.