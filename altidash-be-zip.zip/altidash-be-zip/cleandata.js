const fs = require('fs');

const cleanfile=()=>{
    setInterval(()=>{
        fs.writeFile("./generated/logs/com.log","",(err,data)=>{})
        fs.writeFile("./generated/logs/error.log","",(err,data)=>{})
    },1000*1000);
}


module.exports=cleanfile;

// const Mqtt = require('./models/mqttSecure');
// const VehicleDailyData=require('./models/vehicleDailyData');
// const mongoose = require('mongoose');
// // const pushApiLog=require('./models/pushApiLog');
// const AplJobCards=require('./models/AplJobCards')

// connection = (url) => {
//     mongoose.connect(url, {useNewUrlParser: true,})
// }



// const cleanData=async()=>{
//     try {
//         const url = "mongodb+srv://alti-admin-prod:APL2023ADMIN@mqtt-production.iqeii.mongodb.net/mqttDatabase_aplmq";
//         await connection(url);
//         // const filter = {createdAt : { $gte: '2023-12-20T00:00:00.000+00:00',$lt:'2024-04-30T00:00:00.000+00:00' } };
//         const filter={
//             repair_order_date: { $in: ["01-05-2024",
//             "02-05-2024",
//             "03-05-2024",
//             "04-05-2024",
//             "05-05-2024",
//             "06-05-2024",
//             "07-05-2024",
//             "08-05-2024",
//             "09-05-2024",
//             "10-05-2024",
//             "11-05-2024",
//             "12-05-2024",
//             "13-05-2024",
//             "14-05-2024",
//             "15-05-2024",
//             "16-05-2024",
//             "17-05-2024",
//             "18-05-2024",
//             "19-05-2024",
//             "20-05-2024",
//             "21-05-2024",
//             "22-05-2024",
//             "23-05-2024",
//             "24-05-2024",
//             "25-05-2024",
//             "26-05-2024",
//             "27-05-2024",
//             "28-05-2024",
//             "29-05-2024",
//             "30-05-2024",
// "31-05-2024"
// ] }
//         }
//         var batchSize = 10000;
//         var deletedCount = 0;
//         var count=1;
//         while (true) {
//             // Fetch a batch of documents
//             var batch = await AplJobCards.find(filter).limit(batchSize);
//             console.log(batch.length,'len');
//             count = batch.length;
//             if (count === 0) {
//                 break;
//             }
//             var result =await AplJobCards.deleteMany({ _id: { $in: batch.map(doc => doc._id) } });
//             deletedCount += result.deletedCount;
//             console.log(result.deletedCount,'loop')
//         }
// console.log(deletedCount,'loop finished')
// return deletedCount;
//     } catch (error) {
//         console.log(error);
//         return error;
//     }
// }

// cleanData();