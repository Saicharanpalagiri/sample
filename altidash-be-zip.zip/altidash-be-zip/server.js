/* (c) 2021 Autoven Private Limited. All rights reserved. */
const path = require("path");
const express = require("express");
const bodyParser = require("body-parser");

// const userRoutes = require('./routes/users-routes');
// const customApiRoutes = require('./routes/customApi-routes');
// const versionTwoApiRoutes = require('./routes/versionTwo-routes');
// const superApiRoutes = require('./routes/superUser-routes');
// const pushApiRoutes = require ('./routes/pushAPI-routes')
// const versionTwoFinanceApiRoutes = require('./routes/versionTwoFinance-routes');

// const { authLimiter } = require('./middleware/rateLimiter');
// const { morganMiddleware } = require('./middleware/morgan');
const cors = require("cors");
const HttpError = require("./models/http-error");
const fs = require("fs");
const logger = require("./logger");
const morgan = require("morgan");
const cleanfile = require("./cleandata.js");
const jobcardRoutes = require("./routes/jobcard.route.js");
const batteryHealthCardRoutes = require("./routes/batteryHealthCard.route.js");
const driveScoreRoutes = require("./routes/driveScore.route.js");
const vehicleInfoRoutes = require("./routes/vehicleInfo.route.js");
const configurationRoutes = require("./routes/configuration.route.js");
const vehicleCustomerCategoryRoutes = require("./routes/vehicleCustomerCategory.route.js");
const dashboardRoutes = require("./routes/dashboard.route.js");
const dealerInfoRoutes = require("./routes/dealerInfo.route.js");
const overviewDashboardRoutes = require("./routes/overviewDashboard.route.js");
const packetsCountRoutes = require("./routes/packetCounter.route.js");
const dataexportRoutes = require("./routes/dataexport.routes.js");
const apljobcardRoutes = require("./routes/apljobcard.route.js");
const pincodeRoutes = require("./routes/pincode.route.js");
const auditLogRoutes = require("./routes/auditLogs.routes.js");
const vehicleImportRoutes = require("./routes/vehicleImport.route.js");
const otiRoutes = require("./routes/vehicleoneTimeInfo.route.js");
const driverAppRoutes = require("./routes/driverApp.routes.js");
const usersRoutes = require("./routes/users.routes.js");
const dmsRoutes=require('./routes/dms.route.js')

const v8 = require("v8");

const app = express();
app.set("trust proxy", true);

//multer for form data
var multer = require("multer");
const { errorHandler } = require("./utils/helpers/error-handler");
// var upload = multer();
var upload = multer({
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB limit
  fileFilter: (req, file, cb) => {
    // Define file filter logic if needed
    // For example, to accept only CSV files:
    if (file.mimetype === "text/csv") {
      cb(null, true);
    } else {
      cb(new Error("Invalid file type. Only CSV files are allowed."));
    }
  },
}).single("file");

cleanfile();

// app.use(morgan("combined",{stream : logger.stream}))
// var accessLogStream = fs.createWriteStream(path.join(__dirname, './generated/logs/com.log'), { flags: 'a' });
// const option = {
//   stream: accessLogStream
// };
// app.use(morgan('1 -:remote-addr 2- :remote-user 3- [:date[clf]] 4- :method 5- URL :url 6 -HTTP/:http-version  7-Status :status  8- Response Length :res[content-length] 9- ":referrer" 10- ":user-agent"   11-Response Time :response-time[digits] 12- :req[hedaer]'
// ,option));

app.use(bodyParser.json());
app.use(express.urlencoded({ extended: true }));

const whitelist = [
  "http://localhost:3000",
  "https://stagingfeinsights.altigreen.app",
  "https://fuelcalc.dw45zdl3si6yr.amplifyapp.com",
  "https://dashboard.altigreen.app",
  "https://dataexport.d1p7dawe7zzbe.amplifyapp.com",
  "https://immoblise.d36f1to6bdepnx.amplifyapp.com",
  "https://altidash.altigreen.app",
  "https://dataexport.altigreen.app",
  "https://aplengineer.altigreen.app",
  "https://dcountdown.d15qy551nlz8u2.amplifyapp.com",
  "https://countdown.altigreen.app",
];

var corsOptions = {
  origin: function (origin, callback) {
    if (!origin || whitelist.indexOf(origin) !== -1) {
      callback(null, true);
    } else {
      callback(new Error("Not allowed by CORS"));
    }
  },
};
app.use(cors(corsOptions));

// app.use(upload.array());
// app.use(morganMiddleware);

// If the user pass the empty request body parameter in that time the bellow code perform that actions.
// If the error message is 'Field name missing', continue to the next middleware.
// Otherwise, send a JSON error response to the client, including the error code and a sanitized error message.
// Additionally, invoke the 'errorHandler' function for further error handling if necessary.
app.use(async (err, req, res, next) => {
  if (!err) {
    return next();
  }

  if (err.message == "Field name missing") {
    next();
  } else {
    console.log("getting error");
    res.json({
      status: false,
      code: err.code || 500,
      error: err.message.replace(/"/g, ""),
    });
    await errorHandler(req, res, err);
  }
});

// app.use('/api/', userRoutes);
// app.use('/api/customApis', customApiRoutes)
// app.use('/api/superApis', superApiRoutes)
// app.use('/api/v2', versionTwoApiRoutes )
// app.use('/api/pushApis', pushApiRoutes)
// app.use('/api/finance/v2', versionTwoFinanceApiRoutes)

app.use("/jobcard", jobcardRoutes);
app.use("/apljobcard", apljobcardRoutes);
app.use("/batteryhealth", batteryHealthCardRoutes);
app.use("/drivescore", driveScoreRoutes);
app.use("/vehicleinfo", vehicleInfoRoutes);
app.use("/configuration", configurationRoutes);
app.use("/vehicle-customer-category", vehicleCustomerCategoryRoutes);
app.use("/dashboard", dashboardRoutes);
app.use("/dealer", dealerInfoRoutes);
app.use("/dashboardoverview", overviewDashboardRoutes);
app.use("/packets", packetsCountRoutes);
app.use("/packets", packetsCountRoutes);
app.use("/apljobcard", apljobcardRoutes);
app.use("/pincode", pincodeRoutes);
app.use("/auditLog", auditLogRoutes);
app.use("/vehicleImport", vehicleImportRoutes);
app.use("/oti", otiRoutes);
app.use("/driver-app", driverAppRoutes);
app.use("/users", usersRoutes);
app.use("/dms",dmsRoutes);

app.use("/", dataexportRoutes);

//api to check memory state
app.get("/api/memory-stats", (req, res) => {
  console.log({ req });
  const memoryUsage = process.memoryUsage();
  const heapStats = v8.getHeapStatistics();
  const totalHeapSize = heapStats.total_available_size;
  const usedHeapSize = memoryUsage.heapUsed;
  let totalHeapSizeFormatted = totalHeapSize / 1024 / 1024;
  let usedHeapSizeFormatted = usedHeapSize / 1024 / 1024;
  let usedHeapPercentage =
    (usedHeapSizeFormatted / totalHeapSizeFormatted) * 100;
  console.log(
    totalHeapSize + " sizes " + usedHeapSize + " % " + usedHeapPercentage
  );
  res.json({
    totalHeapSize: (totalHeapSize / 1024 / 1024).toFixed(2) + " MB",
    usedHeapSize: (usedHeapSize / 1024 / 1024).toFixed(2) + " MB",
    usedHeapPercentage: usedHeapPercentage.toFixed(2) + "%",
  });
});

//** Global Error Handler */
app.use(async (err, req, res, next) => {
  if (!err) {
    return next();
  }
  res.json({
    status: false,
    code: err.code || 500,
    error: err.message.replace(/"/g, ""),
  });
  await errorHandler(req, res, err);
});

const server = app.listen(process.env.PORT, () => {
  console.log(`Server started on Port ${process.env.PORT}`);
});
app.use(express.static("public"));

// dealing with CORS
app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept, Authorization"
  );
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, PATCH, DELETE");

  next();
});

// app.use((req, res, next) => {
//   const error = new HttpError('Could not find this route.', 404);
//   let response = {status: false, code: 404, values: "Route Not Found"}
//   if(req.body.username){
//     logger.error({username: req.body.username, error_on_url:req.url, method:req.method, message: response} );
//   }
//   else if(req.body.email){
//     logger.error({username: req.body.email, error_on_url:req.url, method:req.method, message: response} );
//   }
//   else {
//     logger.error({error_on_url:req.url, method:req.method, message: response} );
//   }
//   res.json(response)
// })

server.timeout = 960000;
