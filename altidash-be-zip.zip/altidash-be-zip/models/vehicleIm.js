/* (c) 2022 Autoven Private Limited. All rights reserved. */

const {DataTypes} = require('sequelize');

const sequelize = require('../utils/sqldb_tcp')

const VehicleIm = sequelize.define('Vehicle', {
  vid: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    allowNull: false,
    autoIncrement: true
  },
  VIN: {
    type: DataTypes.STRING,
    unique: true,
    allowNull: false
  },
  registered_at: {
    type: DataTypes.DATE,
    defaultValue: sequelize.literal("CURRENT_TIMESTAMP"),
    allowNull: false
  },
  Immob_status: {
    type: DataTypes.TINYINT,
    allowNull: false,
    defaultValue: 1,
  },
  last_updatedAt: {
    type: DataTypes.DATE,
    defaultValue: sequelize.literal("CURRENT_TIMESTAMP"),
    allowNull: false,
  },
  Immob_reason: {
    type: DataTypes.STRING,
    allowNull: false,
    defaultValue: 'first edition'
  },
  VehicleRegNo : {
    type: DataTypes.STRING,
    defaultValue: ''
  },
  vDisplayName : {
    type: DataTypes.STRING,
    defaultValue: ''
  },
  Kit_ID : {
    type: DataTypes.STRING,
    defaultValue: ''
  },
  model: {
    type: DataTypes.STRING,
    defaultValue: ''
  },
  bModel: {
    type: DataTypes.STRING,
    defaultValue: ''
  },
  batteryCapacity: {
    type: DataTypes.INTEGER,
    defaultValue: 0
  },
  batteryVolt: {
    type: DataTypes.INTEGER,
    defaultValue: 0
  },
  batteryChem: {
    type: DataTypes.STRING,
    defaultValue: ''
  },
  motorSrNo: {
    type: DataTypes.STRING,
    defaultValue: ''
  },
  batterySrNo: {
    type: DataTypes.STRING,
    defaultValue: ''
  },
  gearBoxSrNo: {
    type: DataTypes.STRING,
    defaultValue: ''
  },
  chassisSrNo: {
    type: DataTypes.STRING,
    defaultValue: ''
  },
  distributionSrNo : {
    type: DataTypes.STRING,
    defaultValue: ''
  },
  dc_dcSrNo : {
    type: DataTypes.STRING,
    defaultValue: ''
  },
  displayConsoleSrNo : {
    type: DataTypes.STRING,
    defaultValue: ''
  },
  displaySoftwareVr : {
    type: DataTypes.STRING,
    defaultValue: ''
  },
  controllerSoftwareVr: {
    type: DataTypes.STRING,
    defaultValue: ''
  },
  SIMservicePrName: {
    type: DataTypes.STRING,
    defaultValue: ''
  },
  SIMsrNo: {
    type: DataTypes.STRING,
    defaultValue: ''
  },
  mobNo: {
    type: DataTypes.STRING,
    defaultValue: ''
  },
  contactName: {
    type: DataTypes.STRING,
    defaultValue: ''
  },
  contactNo: {
    type: DataTypes.STRING,
    defaultValue: ''
  },
  drivingLicenseNo: {
    type: DataTypes.STRING,
    defaultValue: ''
  },
  drivingLicenseVal: {
    type: DataTypes.STRING,
    defaultValue: ''
  },
  vehicleColor: {
    type: DataTypes.STRING,
    defaultValue: ''
  },
  chargerSrNo: {
    type: DataTypes.STRING,
    defaultValue: ''
  },
  network_type:{
    type: DataTypes.STRING,
    defaultValue: ''
  },
  lastDataSentAt: {
    type: DataTypes.STRING,
    defaultValue: ''
  },
  deleteVehicleStatus: {
    type: DataTypes.TINYINT,
    allowNull: false,
    defaultValue: 0,
  },
  category: {
    type: DataTypes.STRING,
    allowNull: false,
    defaultValue: "No cateogry",
  },
  mfgmonth: {
    type: DataTypes.STRING,
    allowNull: true,
    // defaultValue: "No cateogry",
  },
  mfgyear: {
    type: DataTypes.STRING,
    allowNull: true,
    // defaultValue: "No cateogry",
  },
 
}, {
  timestamps: true,
  createdAt: "registered_at",
  createdAt: "last_updatedAt",
  updatedAt: false,
  freezeTableName: true
})
 
 
module.exports = VehicleIm;