/* (c) 2022 Autoven Private Limited. All rights reserved. */

const mongoose = require("mongoose");

const altidashLogsSchema = new mongoose.Schema(
  {
    email: {
      type: String,
      required: true,
      trim: true,
    },
    timeStamp: {
      type: String,
    },
    action: {
      type: String,
    },
    description: {
      type: String,
    },
    ip: {
      type: String,
    },
  },
  {
    timestamps: false,
    collection: "AltidashLogs",
  }
);

const AltidashLogs = mongoose.model("AltidashLogs", altidashLogsSchema);

module.exports = AltidashLogs;
