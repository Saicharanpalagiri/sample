const mongoose = require('mongoose');

const vehicleOneTimeInfoSchema = new mongoose.Schema({
  topic: String,
  ver: Number,
  RTC: Date,
  O1: String,
  O2: Number,
  O3: String,
  O4: String,
  O5: String,
  O6: Number,
  O7: Number,
  O8: Number,
  O9: Number,
  O10: Number,
  O11: Number,
  O12: Number,
  O13: Number,
  O14: Number,
  O15: Number,
  O16: Number,
  O17: Number,
  O18: Number,
  O19: Number,
  O20: Number,
  O21: Number,
  O22: Number,
  O23: Number,
  O24: Number,
  O25: Number,
  O26: Number,
  O27: Number,
  O28: Number,
  O29: Number,
  O30: Number,
  O31: Number,
  O32: Number,
  O33: Number,
  O34: Number,
  O35: Number,
  timeStamp: Date,
  KIT: String,
  F: String
},
{
  collection: 'vehicleOneTimeInfo'
});

const VehicleOneTimeInfo = mongoose.model('vehicleSaleStatement', vehicleOneTimeInfoSchema);

module.exports = VehicleOneTimeInfo;
