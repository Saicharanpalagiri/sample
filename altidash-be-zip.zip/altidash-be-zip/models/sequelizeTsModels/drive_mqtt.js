const {DataTypes} = require('sequelize');

 

const sequelizeTcp = require('../../utils/sqldb_tcp')

 

 

const drive_mqtt = sequelizeTcp.define('drivescore_MQTT',

 {

    id: {

        type: DataTypes.INTEGER,

        primaryKey: true,

        allowNull: false,

        // autoIncrement: true

      },

    vin:{

        type:DataTypes.STRING,

        allowNull:true,

 

      },

    Date:{

        type:DataTypes.DATE,

        allowNull:true

    },

    regen:{

        type:DataTypes.FLOAT,

        allowNull:true,

    },

    eEfficiency:{

        type:DataTypes.FLOAT,

        allowNull:true,

    },

    drive_score:{

        type:DataTypes.FLOAT,

        allowNull:true,

    },

    percentage_agressive_acceleration:{

        type:DataTypes.FLOAT,

        allowNull:true,

    },

    percentage_agressive_acceleration:{

        type:DataTypes.FLOAT,

        allowNull:true,

    },

    percentage_agressive_braking:{

        type:DataTypes.INTEGER,

        allowNull:true,

    },

    percentage_agressive_turning:{

        type:DataTypes.FLOAT,

        allowNull:true,

    },

    average_vehicle_speed:{

        type:DataTypes.FLOAT,

        allowNull:true,

    },

    normalised_throttle_position:{

        type:DataTypes.FLOAT,

        allowNull:true,

    },

    brake_pedal_percentage:{

        type:DataTypes.FLOAT,

        allowNull:true,

    },

    distance:{

        type:DataTypes.FLOAT,

        allowNull:true,

    },

    range:{

        type:DataTypes.STRING,

        allowNull:true,

    },

    city:{

        type:DataTypes.STRING,

        allowNull:true,

    },

    city_rank:{

        type:DataTypes.STRING,

        allowNull:true,

    },vehicle_id:{

        type:DataTypes.INTEGER,

        allowNull:true,

    },

},

{

    timestamps: false,

    createdAt: false,

    updatedAt: false,

    freezeTableName: true

  })

 

 

module.exports = drive_mqtt;