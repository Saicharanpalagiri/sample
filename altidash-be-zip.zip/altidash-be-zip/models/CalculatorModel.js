/* (c) 2022 Autoven Private Limited. All rights reserved. */

const mongoose = require('mongoose')


const CalculatorUser = new mongoose.Schema({
    name : {
        type : String
    },
    mobile : {
        type : String,
        unique: true,
        validate: {
            validator: function(value) {
                return /^\d{10}$/.test(value);
            },
            message: props => `${props.value} is not a valid mobile number!`
        }
    },    
    time:{
        type:String
    },
    data:{
        type:Object
    }
}, {
    timestamps: true,
    collection: 'calculatorUser'
})

const calculatorUser = mongoose.model('calculatorUser', CalculatorUser )


module.exports = calculatorUser;
