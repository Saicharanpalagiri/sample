/* (c) 2022 Autoven Private Limited. All rights reserved. */

const {DataTypes} = require('sequelize');
const sequelize = require('../utils/sqldb_tcp');
const ClientIm = require('./clientIm');
const VehicleIm = require('./vehicleIm');


const ClientVehicleIm = sequelize.define('ClientVehicle', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    allowNull: false,
    autoIncrement: true 
  },
  cid: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: ClientIm,
      key: 'cid'
    }
  },
  vid: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: VehicleIm,
      key: 'vid'
    }
  }
}, {
  timestamps: false,
  freezeTableName: true
})


module.exports = ClientVehicleIm;