const mongoose = require('mongoose');

const monthlyBatteryHealthCardReportSchema = new mongoose.Schema({
    _id: mongoose.Types.ObjectId,
    id: Number,
    vehicle_id: Number,
    vin: String,
    min_soh: Number,
    max_soh: Number,
    avg_soh: Number,
    end_soh: Number,
    calculated_soh: Number,
    min_cell_voltage: Number,
    max_cell_voltage: Number,
    avg_of_min_cell_voltage: Number,
    avg_of_max_cell_voltage: Number,
    max_delta_cell_voltage: Number,
    min_battery_temp: Number,
    max_battery_temp: Number,
    avg_of_min_battery_temp: Number,
    avg_of_max_battery_temp: Number,
    max_delta_battery_temp: Number,
    peak_battery_power_used: Number,
    start_battery_pack_cycle: Number,
    end_battery_pack_cycle: Number,
    start_odometer: Number,
    end_odometer: Number,
    year: Number,
    month: Number,
    creation_date: Date,
},{
    collection:'monthly_battery_healthcard_report'
});

const MonthlyBatteryHealthCardReport = mongoose.model('monthly_battery_healthcard_report', monthlyBatteryHealthCardReportSchema);

module.exports = MonthlyBatteryHealthCardReport;
