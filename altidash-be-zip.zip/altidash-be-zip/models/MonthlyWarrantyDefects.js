const { DataTypes } = require('sequelize');
const sequelize = require('../utils/sqldb');

//Monthly Warranty Defects
const MonthlyWarrantyDefects = sequelize.define('MonthlyWarrantyDefects', {
    ID: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
    },
    created_by: {
        type: DataTypes.STRING(255),
        allowNull: false,
    },
    created_date: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
    },
    month: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    year: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    raised_tickets: {
        type: DataTypes.INTEGER,
        defaultValue: 0,
    },
    open_tickets: {
        type: DataTypes.INTEGER,
        defaultValue: 0,
    },
    Parts_in_transit_tickets: {
        type: DataTypes.INTEGER,
        defaultValue: 0,
    },
    under_rca_tickets: {
        type: DataTypes.INTEGER,
        defaultValue: 0,
    },
    closed_tickets: {
        type: DataTypes.INTEGER,
        defaultValue: 0,
    },
    less_than_5k_defects: {
        type: DataTypes.INTEGER,
        defaultValue: 0,
    },
    number_of_vehicles_repaired: {
        type: DataTypes.INTEGER,
        defaultValue: 0,
    },
}, {
    tableName: 'monthly_warranty_defects',
    timestamps: false,
    indexes: [
        {
            unique: true,
            fields: ['month', 'year']
        }
    ]
});

module.exports = MonthlyWarrantyDefects;