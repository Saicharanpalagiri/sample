/* (c) 2022 Autoven Private Limited. All rights reserved. */

const {DataTypes} = require('sequelize');
const sequelize = require('../utils/sqldb')
const Client = require('./client');
const CustomAPI = require('./customAPI');


const ClientCustomAPI = sequelize.define('ClientCustomAPI', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    allowNull: false,
    autoIncrement: true 
  },
  cid: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: Client,
      key: 'cid'
    }
  },
  apid: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: CustomAPI,
      key: 'apid'
    }
  },
}, {
  freezeTableName: true
})


module.exports = ClientCustomAPI;