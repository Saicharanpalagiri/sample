/* (c) 2022 Autoven Private Limited. All rights reserved. */

const mongoose = require('mongoose')


const pushApiLogSchema = new mongoose.Schema({
    headers : {
        type: Object,
    },
    body : {
        type : Object
    },
    url : {
        type : String
    },    
    api : {
        type : String
    },
    response : {
        type : Object
    },
    success:{
        type : Boolean
    }
}, {
    timestamps: true,
    collection: 'pushApiLog'
})

const pushApiLog = mongoose.model('pushApiLog', pushApiLogSchema )


module.exports = pushApiLog;
