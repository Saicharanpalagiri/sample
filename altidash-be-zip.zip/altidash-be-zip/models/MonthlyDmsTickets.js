const { DataTypes } = require('sequelize');
const sequelize = require('../utils/sqldb');

const MonthlyDmsTickets = sequelize.define('MonthlyDMSTickets', {
    ID: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
    },
    created_by: {
        type: DataTypes.STRING(255),
        allowNull: false,
    },
    created_date: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
    },
    month: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    year: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    number_of_service_request: {
        type: DataTypes.INTEGER,
        defaultValue: 0,
    },
    number_of_training_and_clarification_tickets: {
        type: DataTypes.INTEGER,
        defaultValue: 0,
    },
    other_tickets: {
        type: DataTypes.INTEGER,
        defaultValue: 0,
    },
    avg_time_taken_to_resolve_service_request: {
        type:  DataTypes.INTEGER,
    },
    avg_time_taken_to_resolve_training_and_clarification: {
        type:  DataTypes.INTEGER,
    },
}, {
    tableName: 'monthly_dms_tickets',
    timestamps: false,
    indexes: [
        {
            unique: true,
            fields: ['month', 'year']
        }
    ]
});

module.exports = MonthlyDmsTickets;