/* (c) 2022 Autoven Private Limited. All rights reserved. */

const mongoose = require('mongoose')


const vehicleLastSnapshotSchema = new mongoose.Schema({
    topic: {
        type: String,
        required: true,
        trim: true
    },
    date: {
        type: String,
        required: true
        // date is the date on which last datapacket was received from vehicle
    },
    processed_at: {
        type: String,
    },
    x68: {
        type: Number
    },
    x69: {
        type: Number
    },
    x70: {
        type: String
    },
    x71: {
        type: Number
    },
    x72: {
        type: Number
    },
    x73: {
        type: Number
    },
    x74: {
        type: Number
    },
    x75: {
        type: String
    },
    x1: {
        type: String
    },
    x79: {
        type: Boolean
    },
    x80: {
        type: String
    },
}, {
    timestamps: false,
    collection: 'vehicleLastSnapshot'
})

const vehicleLastSnapshot = mongoose.model('vehicleLastSnapshot', vehicleLastSnapshotSchema )


module.exports = vehicleLastSnapshot;