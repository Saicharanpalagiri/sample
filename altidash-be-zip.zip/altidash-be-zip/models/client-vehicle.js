/* (c) 2022 Autoven Private Limited. All rights reserved. */

const {DataTypes} = require('sequelize');
const sequelize = require('../utils/sqldb');
const Client = require('./client');
const Vehicle = require('./vehicle');


const ClientVehicle = sequelize.define('ClientVehicle', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    allowNull: false,
    autoIncrement: true 
  },
  cid: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: Client,
      key: 'cid'
    }
  },
  vid: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: Vehicle,
      key: 'vid'
    }
  }
}, {
  timestamps: false,
  freezeTableName: true
})


module.exports = ClientVehicle;