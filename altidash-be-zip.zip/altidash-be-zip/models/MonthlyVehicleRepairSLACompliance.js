const { DataTypes } = require('sequelize');
const sequelize = require('../utils/sqldb');

const MonthlyVehicleRepairSLACompliance = sequelize.define('MonthlyVehicleRepairSLACompliance', {
    ID: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
    },
    created_by: {
        type: DataTypes.STRING(255),
        allowNull: false,
    },
    created_date: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
    },
    month: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    year: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    open_tickets: {
        type: DataTypes.INTEGER,
        defaultValue: 0,
    },
    closed_tickets: {
        type: DataTypes.INTEGER,
        defaultValue: 0,
    },
    less_than_5km_tickets: {
        type: DataTypes.INTEGER,
        defaultValue: 0,
    },
    less_than_48hrs_tickets: {
        type: DataTypes.INTEGER,
        defaultValue: 0,
    },
    avg_closure_tat: {
        type: DataTypes.DECIMAL(10, 2),
        defaultValue: 0.00,
    },
    number_of_unique_vehicles_repaired: {
        type: DataTypes.INTEGER,
        defaultValue: 0,
    },
}, {
    tableName: 'monthly_vehicle_repair_sla_compliance',
    timestamps: false,
    indexes: [
        {
            unique: true,
            fields: ['month', 'year']
        }
    ]
});

module.exports = MonthlyVehicleRepairSLACompliance;