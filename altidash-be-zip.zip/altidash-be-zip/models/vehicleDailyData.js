/* (c) 2022 Autoven Private Limited. All rights reserved. */

const mongoose = require('mongoose')


const vehicleDailyDataSchema = new mongoose.Schema({
    topic: {
        type: String,
        required: true,
        trim: true
    },
    processed_at: {
        type: String,
    },
    date: {
        type: String,
        required: true
    },
    x1: {
        type: String
    },
    x2: {
        type: String
    },
    x3: {
        type: Number
    },
    x4: {
        type: String
    },
    x5: {
        type: Number
    },
    x6: {
        type: String
    },
    x7: {
        type: Number
    },
    x8: {
        type: Number
    },
    x9: {
        type: Number
    },
    x10: {
        type: Number
    },
    x11: {
        type: Number
    },
    x12: {
        type: Number
    },
    x13: {
        type: Number
    },
    x14: {
        type: Number
    },
    x15: {
        type: Number
    },
    x16: {
        type: Number
    },
    x17: {
        type: Number
    },
    x18: {
        type: Number
    },
    x19: {
        type: Number
    },
    x20: {
        type: Number
    },
    x21: {
        type: Number
    },
    x22: {
        type: Number
    },
    x23: {
        type: Number
    },
    x24: {
        type: Number
    },
    x25: {
        type: Number
    },
    x26: {
        type: Number
    },
    x27: {
        type: Number
    },
    x28: {
        type: Number
    },
    x29: {
        type: Number
    },
    x30: {
        type: Number
    },
    x31: {
        type: Number
    },
    x32: {
        type: Number
    },
    x33: {
        type: Number
    },
    x34: {
        type: Number
    },
    x35: {
        type: Number
    },
    x36: {
        type: Number
    },
    x37: {
        type: Number
    },
    x38: {
        type: Number
    },
    x39: {
        type: Number
    },
    x40: {
        type: Number
    },
    x41: {
        type: Number
    },
    x42: {
        type: Number
    },
    x43: {
        type: Number
    },
    x44: {
        type: Number
    },
    x45: {
        type: Number
    },
    x46: {
        type: Number
    },
    x47: {
        type: Number
    },
    x48: {
        type: Number
    },
    x49: {
        type: Number
    },
    x50: {
        type: Number
    },
    x51: {
        type: Number
    },
    x52: {
        type: Number
    },
    x53: {
        type: Number
    },
    x54: {
        type: Number
    },
    x55: {
        type: Number
    },
    x56: {
        type: String
    },
    x57: {
        type: Array
    },
    x58: {
        type: Object
    },
    x59: {
        type: Object
    },
    x60: {
        type: Number
    },
    x61: {
        type: Number
    },
    x62: {
        type: Number
    },
    x63: {
        type: Number
    },
    x64: {
        type: Number
    },
    x65: {
        type: Number
    },
    x66: {
        type: Number
    },
    x67: {
        type: Number
    },
    x76: {
        type: String
    },
    x77: {
        type: Number
    },
    x78: {
        type: String
    },
    x81: {
        type: String,
    },
    x82: {
        type: String,
    },
    x83: {
        type: Object,
    },
    x84: {
        type: Object,
    },
    x96: {
        type: String,
    },
    x100: {
        type: Number
    },
    x101: {
        type: Number
    },
    x108: {
        type: Number
    },
    x109: {
        type: Number
    },
    x102: {
        type: String,
    },
    x103: {
        type: String,
    },
    x85: {
        type: Number
    },
    x86: {
        type: Number
    },
    x87:{
        type:Number
    },
    x110: {
        type: Number
    },
    x111:{
        type: Number
    },
    x112:{
        type: Number 
    },
    x113:{
        type: Number 
    },
    x114:{
        type: Number 
    },
    x115:{
        type: Number 
    },
    x95:{
        type:Number
    },
    x116:{
        type:Number,
    },
    x117:{
        type:Number
    }
}, {
    timestamps: false,
    collection: 'vehicleDailyData'
})

const VehicleDailyData = mongoose.model('vehicleDailyData', vehicleDailyDataSchema )


module.exports = VehicleDailyData;
