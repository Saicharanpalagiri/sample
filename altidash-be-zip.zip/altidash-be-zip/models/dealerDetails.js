const mongoose = require('mongoose');

const dealerSchema = new mongoose.Schema({
    _id: mongoose.Types.ObjectId,
    id: Number,
    dealer_code: Number,
    branch_code: Number,
    dealer_name: String,
    launch_date: String,
    gstin_no: String,
    gstin_dt: String,
    subsidy_code: String,
    zone: String,
    state: String,
    city: String,
    address: String,
    pincode: Number,
    latitude: Number,
    longitude: Number,
    sales_name_1: String,
    sales_name_2: String,
    sales_mobile_1: String,
    sales_mobile_2: String,
    sales_email_1: String,
    sales_email_2: String,
    service_name_1: String,
    service_name_2: String,
    service_mobile_1: String,
    service_mobile_2: String,
    service_email_1: String,
    service_email_2: String,
    gm_name_1: String,
    gm_name_2: String,
    gm_mobile_1: String,
    gm_mobile_2: String,
    gm_email_1: String,
    gm_email_2: String,
    it_name_1: String,
    it_name_2: String,
    it_mobile_1: String,
    it_mobile_2: String,
    it_email_1: String,
    it_email_2: String,
    status: Number,
},{
    collection:'dealer_details'
});

const dealerDetails = mongoose.model('dealer_details', dealerSchema);

module.exports = dealerDetails;
