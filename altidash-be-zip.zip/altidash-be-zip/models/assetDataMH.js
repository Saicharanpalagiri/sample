/* (c) 2023 Autoven Private Limited. All rights reserved. */

const mongoose = require ('mongoose')

const AssetDataScheme = new mongoose.Schema({
    assetId :{
        type : String,
        // required : true,
    },
    unit_no : {
        type : String,
        default :"NA"
    },
    battery_status : {
        type : String,
        default :"NA"
    },
    gps_datetime :{
        type : String,
        // required : true,
    },
    gmt :{
        type : String,
        // required : true,
    },
    lon :{
        type : Number,
        // required : true,
    },
    lat : {
        type : Number,
        // required : true,
    },
    odometer : {
        type : Number,
        default : 0
    },
    speed : {
        type : Number,
        default : 0
    },
    accuracy : {
        type : Number,
        default : 0
    },
    source:{
        type : String
    },

},{
    timestamps: true,
    collection: 'assetData'
})


const AssetDataNew = mongoose.model('assetData', AssetDataScheme )

module.exports = AssetDataNew;