/* (c) 2022 Autoven Private Limited. All rights reserved. */

const mongoose = require('mongoose')

const mqttSecureSchema = new mongoose.Schema({
  topic: {
    type: String,
    required: true,
    trim: true
  },
  ver: {
    type: Number
  },
  lat: {
    type: Number
  },
  lng: {
    type: Number
  },
  RTC: {
    type: String
  },
  G1: {
    type: String
  },
  G2: {
    type: Number
  },
  G3: {
    type: String
  },
  G4: {
    type: Number
  },
  G5: {
    type: String
  },
  G6: {
    type: Number
  },
  G7: {
    type: Number
  },
  G8: {
    type: String
  },
  G9: {
    type: Number
  },
  G10: {
    type: Number
  },
  C1: {
    type: Number
  },
  C2: {
    type: Number
  },
  C3: {
    type: Number
  },
  C4: {
    type: Number
  },
  C5: {
    type: Number
  },
  C6: {
    type: Number
  },
  C7: {
    type: Number
  },
  C8: {
    type: Number
  },
  C9: {
    type: Number
  },
  C10: {
    type: Number
  },
  C11: {
    type: Number
  },
  C12: {
    type: Number
  },
  C13: {
    type: Number
  },
  C14: {
    type: Number
  },
  C15: {
    type: Number
  },
  C16: {
    type: Number
  },
  C17: {
    type: Number
  },
  C18: {
    type: Number
  },
  C19: {
    type: Number
  },
  C20: {
    type: Number
  },
  C21: {
    type: Number
  },
  C22: {
    type: Number
  },
  C23: {
    type: Number
  },
  C24: {
    type: Number
  },
  C25: {
    type: Number
  },
  C26: {
    type: Number
  },
  C27: {
    type: Number
  },
  C28: {
    type: Number
  },
  C29: {
    type: Number
  },
  C30: {
    type: Number
  },
  C31: {
    type: Number
  },
  C32: {
    type: Number
  },
  C33: {
    type: Number
  },
  C34: {
    type: Number
  },
  C35: {
    type: Number
  },
  C36: {
    type: Number
  },
  C37: {
    type: Number
  },
  C38: {
    type: Number
  },
  C39: {
    type: Number
  },
  C40: {
    type: Number
  },
  C41: {
    type: Number
  },
  C42: {
    type: Number
  },
  C43: {
    type: Number
  },
  C44: {
    type: Number
  },
  C45: {
    type: Number
  },
  C46: {
    type: Number
  },
  timestamp: {
    type: String
  }
}, {
  timestamps: false,
  collection: 'mqttSecure'
})

const Mqtt = mongoose.model('mqttSecure', mqttSecureSchema )


module.exports = Mqtt;