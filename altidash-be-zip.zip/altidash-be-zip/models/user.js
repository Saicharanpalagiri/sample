/* (c) 2022 Autoven Private Limited. All rights reserved. */

const {DataTypes} = require('sequelize');

const sequelize = require('../utils/sqldb')


const User = sequelize.define('User', {
  uid: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    allowNull: false,
    autoIncrement: true 
  },
  email: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true
  },
  password: {
    type: DataTypes.STRING,
    allowNull: false
  },
  mobile: {
    type: DataTypes.STRING,
    allowNull: false,
    defaultValue: 'xxxxxxxxxx'
  },
  token: {
    type: DataTypes.STRING
  },
  deleteUserStatus: {
    type: DataTypes.TINYINT,
    allowNull: false,
    defaultValue: 0,
  },
  enableCustomApis: {
    type: DataTypes.TINYINT,
    allowNull: false,
    defaultValue: 0,
  },
  role: {
    type: DataTypes.STRING,
    allowNull: false,
    defaultValue: 'User',
  },
  userName: {
    type: DataTypes.STRING,
    allowNull: false,
    defaultValue: 'userName',
  },
  firstAppLogin: {
    type: DataTypes.STRING,
    allowNull: true,
  }
}, {
  timestamps: false,
  freezeTableName: true
})


module.exports = User;