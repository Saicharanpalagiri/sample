const mongoose = require('mongoose')

const vehicleDetailSchema = new mongoose.Schema({
    IBID: Number,
    RegNo: String,
    ChassisNo: String,
    EngineNo: String,
    ModelCode: String,
    ModelName: String,
    KMReading: Number
})

const customerDetailSchema = new mongoose.Schema({
    IBID: Number,
    ContactID: Number,
    CustomerCode: String,
    CustomerName: String,
    MobileNo: String,
    CustomerAddress: String
})

const jobCardCustomerDetailSchema = new mongoose.Schema({
    LnID: Number,
    ContactName: String,
    MobileNumber: String,
    ContactEmail: String,
    CustomerAddress: String
})

const jobCardVehicleDetailSchema = new mongoose.Schema({
    LnID: Number,
    KiloMeterReadingChange: String,
    CustomerVoice: String,
    RootCauseOfRepeat: String,
    FutureAdvise: String,
    OdometerChanged: Boolean
})

const spareListSchema = new mongoose.Schema({
    LnID: Number,
    partNumber: String,
    partName: String,
    serviceType: String,
    Qty: Number,
    Amount: Number
})

const labourListSchema = new mongoose.Schema({
    LnID: Number,
    labourCode: String,
    labourName: String,
    serviceType: String,
    Amount: Number,
    isRepeated: Boolean,
    isOutsideService: Boolean
})

const jobCardsDetailsListSchema = new mongoose.Schema({
    LnID: Number,
    Docdate: String,
    jobCardNumber: String,
    MobileNumber: String,
    serviceType: String,
    MechanicName: String,
    ServiceAdvisorName: String,
    BranchName: String,
    Visit: Number,
    JobCardCustomerDetail: [jobCardCustomerDetailSchema],
    JobCardVehicleDetail: [jobCardVehicleDetailSchema],
    SpareList: [spareListSchema],
    LabourList: [labourListSchema],
    InvoiceList: [mongoose.Schema.Types.Mixed]
})

const contractDetailsListSchema = new mongoose.Schema({
    Contractname: String,
    servicetype: String,
    isAvailed: String,
    StartDate: String,
    EndDate: String
})

const vehicleJobCardSchema = new mongoose.Schema({
    VehicleDetail: [vehicleDetailSchema],
    CustomerDetail: [customerDetailSchema],
    JobCardsDetailsList: [jobCardsDetailsListSchema],
    contractDetailsList: [contractDetailsListSchema]
}, {
    timestamps: false,
    collection: 'vehicleJobCard'
})

const vehicleJobCard = mongoose.model('vehicleJobCard', vehicleJobCardSchema)

module.exports = vehicleJobCard;
