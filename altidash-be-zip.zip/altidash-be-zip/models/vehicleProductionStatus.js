const {DataTypes} = require('sequelize');
const sequelize = require('../utils/sqldb')


const VehicleProductionStatus = sequelize.define('vehicle_produced_status', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false,
    },
    vin: {
        type: DataTypes.STRING(45),
        allowNull: false,
    },
    date: {
        type: DataTypes.STRING(45),
        allowNull: false,
    },
    produced_status: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    order_no: {
        type: DataTypes.STRING(45),
        allowNull: true,
    },
    model: {
        type: DataTypes.STRING(45),
        allowNull: true,
    },
    vehicle_type: {
        type: DataTypes.STRING(255),
        allowNull: true,
    },
    amount_loc: {
        type: DataTypes.DECIMAL(12, 2),
        allowNull: true,
    },
    vehicleRegNo: {
        type: DataTypes.STRING(45),
        allowNull: true,
    },
    year: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    month: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    datetime: {
        type: DataTypes.DATE,
        allowNull: true,
    }
}, {
    indexes: [
        {
            unique: true,
            fields: ['vin', 'produced_status', 'date', 'order_no']
        }
    ],
    timestamps: false,
    freezeTableName: 'vehicle_produced_status',
});


module.exports = VehicleProductionStatus;