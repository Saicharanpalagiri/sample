/* (c) 2022 Autoven Private Limited. All rights reserved. */

const {DataTypes} = require('sequelize');

const sequelize = require('../utils/sqldb')

const Vehicle = sequelize.define('Vehicle', {
  vid: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    allowNull: false,
    autoIncrement: true
  },
  VIN: {
    type: DataTypes.STRING,
    unique: true,
    allowNull: false
  },
  registered_at: {
    type: DataTypes.DATE,
    defaultValue: sequelize.literal("CURRENT_TIMESTAMP"),
    allowNull: false
  },
  Immob_status: {
    type: DataTypes.TINYINT,
    allowNull: false,
    defaultValue: 1,
  },
  last_updatedAt: {
    type: DataTypes.DATE,
    defaultValue: sequelize.literal("CURRENT_TIMESTAMP"),
    allowNull: false,
  },
  Immob_reason: {
    type: DataTypes.STRING,
    allowNull: false,
    defaultValue: 'first edition'
  },
  VehicleRegNo : {
    type: DataTypes.STRING,
    defaultValue: 'xxxxx'
  },
  vDisplayName : {
    type: DataTypes.STRING,
    defaultValue: 'xxxxx'
  },
  Kit_ID : {
    type: DataTypes.STRING,
    defaultValue: 'xxxxx'
  },
  model: {
    type: DataTypes.STRING,
    defaultValue: 'xxxxx'
  },
  bModel: {
    type: DataTypes.STRING,
    defaultValue: 'xxxxx'
  },
  batteryCapacity: {
    type: DataTypes.INTEGER,
    defaultValue: 0
  },
  batteryVolt: {
    type: DataTypes.INTEGER,
    defaultValue: 0
  },
  batteryChem: {
    type: DataTypes.STRING,
    defaultValue: 'xxxxx'
  },
  motorSrNo: {
    type: DataTypes.STRING,
    defaultValue: 'xxxxx'
  },
  batterySrNo: {
    type: DataTypes.STRING,
    defaultValue: 'xxxxx'
  },
  gearBoxSrNo: {
    type: DataTypes.STRING,
    defaultValue: 'xxxxx'
  },
  chassisSrNo: {
    type: DataTypes.STRING,
    defaultValue: 'xxxxx'
  },
  distributionSrNo : {
    type: DataTypes.STRING,
    defaultValue: 'xxxxx'
  },
  dc_dcSrNo : {
    type: DataTypes.STRING,
    defaultValue: 'xxxxx'
  },
  displayConsoleSrNo : {
    type: DataTypes.STRING,
    defaultValue: 'xxxxx'
  },
  displaySoftwareVr : {
    type: DataTypes.STRING,
    defaultValue: 'xxxxx'
  },
  controllerSoftwareVr: {
    type: DataTypes.STRING,
    defaultValue: 'xxxxx'
  },
  SIMservicePrName: {
    type: DataTypes.STRING,
    defaultValue: 'xxxxx'
  },
  SIMsrNo: {
    type: DataTypes.STRING,
    defaultValue: 'xxxxx'
  },
  mobNo: {
    type: DataTypes.STRING,
    defaultValue: 'xxxxx'
  },
  contactName: {
    type: DataTypes.STRING,
    defaultValue: 'xxxxx'
  },
  contactNo: {
    type: DataTypes.STRING,
    defaultValue: 'xxxxx'
  },
  drivingLicenseNo: {
    type: DataTypes.STRING,
    defaultValue: 'xxxxx'
  },
  drivingLicenseVal: {
    type: DataTypes.STRING,
    defaultValue: 'xxxxx'
  },
  vehicleColor: {
    type: DataTypes.STRING,
    defaultValue: 'xxxxx'
  },
  chargerSrNo: {
    type: DataTypes.STRING,
    defaultValue: 'xxxxx'
  },
  network_type:{
    type: DataTypes.STRING,
    defaultValue: 'xxxxx'
  },
  lastDataSentAt: {
    type: DataTypes.STRING,
    defaultValue: "2022-08-23T13:35:48"
  },
  deleteVehicleStatus: {
    type: DataTypes.TINYINT,
    allowNull: false,
    defaultValue: 0,
  },
  category: {
    type: DataTypes.STRING,
    allowNull: false,
    defaultValue: "No cateogry",
  },
  mfgmonth: {
    type: DataTypes.STRING,
    allowNull: true,
    // defaultValue: "No cateogry",
  },
  mfgyear: {
    type: DataTypes.STRING,
    allowNull: true,
    // defaultValue: "No cateogry",
  },
 
}, {
  timestamps: true,
  createdAt: "registered_at",
  createdAt: "last_updatedAt",
  updatedAt: false,
  freezeTableName: true
})
 
 
module.exports = Vehicle;