const mongoose = require('mongoose');

const vehicleMasterData = new mongoose.Schema({
    created_at: Date,
    vin_id: String,
    kit_id: String,
    motor_sr_no:String,
    motor_bearing_ppr: String,
    display_sr_no: String,
    ev_display_hw_version: String,
    vehicle_type: String,
    vdm_alive_time: String,
    battery_sr_no: String,
    battery_type: String,
    telematics_config :String,
    apn: String,
    max_speed: String,
    vehicle_variant:String,
    controller_sw_part:String,
    display_sw_part:String,
    bms_sw_part: String
  },  
{
    collection:'vehicle_master_data'
  });

const VehicleMasterData = mongoose.model('vehicleMasterData', vehicleMasterData);

module.exports = VehicleMasterData;
