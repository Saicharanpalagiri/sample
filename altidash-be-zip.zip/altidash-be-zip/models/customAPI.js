/* (c) 2022 Autoven Private Limited. All rights reserved. */

const {DataTypes} = require('sequelize');

const sequelize = require('../utils/sqldb')


const CustomAPI = sequelize.define('CustomAPI',{
    apid: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false,
        autoIncrement: true 
    },
    apiName : {
        type : DataTypes.STRING,
        allowNull : false,
        unique : true
    },
    apiType : {
        type : DataTypes.STRING,
        allowNull : false,
    },  
},{
        freezeTableName: true
})

module.exports = CustomAPI;