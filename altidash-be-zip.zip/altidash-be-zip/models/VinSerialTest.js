const {DataTypes} = require('sequelize');
const sequelize = require('../utils/sqldb')


const VinSerialTest= sequelize.define('VehicleSerialTest', {
    id:{
        type:DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    VIN:{
        type:DataTypes.STRING,
        unique:true
    },
    vehicleId:{
        type:DataTypes.INTEGER,
    },
    vinserialnum:{
        type:DataTypes.STRING,
    },
    type:{
        type:DataTypes.STRING,
    },
    color:{
        type:DataTypes.STRING
    },
    mfgyear:{
        type:DataTypes.INTEGER,
    },
    mfgmonth:{
        type:DataTypes.INTEGER,
    },
    Manufactured_Date: {
        type:DataTypes.STRING
    },
    customer_name: {
        type:DataTypes.STRING
    },
    customer_category: {
        type:DataTypes.STRING
    },
    finance: {
        type:DataTypes.STRING
    },
    financier_name: {
        type:DataTypes.STRING
    } ,
    application: {
        type:DataTypes.STRING
    } ,
    description: {
        type:DataTypes.STRING
    },
    dealer_name:{
        type:DataTypes.STRING
    },
    state:{
        type:DataTypes.STRING,
        defaultValue:null
    },
    city:{
        type:DataTypes.STRING,
        defaultValue:null
    },
    zone:{
        type:DataTypes.STRING,
        defaultValue:null
    },
    variant:{
        type:DataTypes.STRING,
        defaultValue:null
    } ,
},{
    timestamps:false,
    freezeTableName:'VehicleSerialTest',
})

module.exports = VinSerialTest;