/* (c) 2023 Autoven Private Limited. All rights reserved. */

const mongoose = require ('mongoose')

const MtsDataScheme = new mongoose.Schema({
    unit_no : {
        type : String,
    },
    timestamp : {
        type : String,
        // required : true
    },
    lon :{
        type : Number,
        // required : true,
    },
    lat : {
        type : Number,
        // required : true,
    },
    accuracy : {
        type : Number,
        default : 0
    },
    speed : {
        type : Number,
        default : 0
    },
    source:{
        type : String
    },
    altitude : {
        type : Number,
            default : 0
    }
},
{
    timestamps: true,
    collection: 'mtsData'
})

const MtsData = mongoose.model('mtsData', MtsDataScheme )

module.exports = MtsData;