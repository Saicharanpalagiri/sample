const mongoose = require('mongoose');

const dealerMonthlySchema = new mongoose.Schema({
    _id: mongoose.Types.ObjectId,
    id: Number,
    dealer_code: Number,
    year: Number,
    month: Number,
    lead_count: Number,
    so_count: Number,
    si_count: Number,
    jc_count: Number,
    vpo_count: Number,
    s_grn_count: Number,
    ppo_count: Number,
    ps_count: Number,
    dealer_stock: Number,
    no_first_free_service: Number,
    no_second_free_service: Number,
    no_third_free_service: Number,
    no_fourth_free_service: Number,
    no_paid_service: Number,
    no_warranty_service: Number,
    no_running_repair: Number,
    no_accidentail_repair: Number,
},{
    collection:'dealer_monthly_report',
});

const dealerMonthly = mongoose.model('dealer_monthly_report', dealerMonthlySchema);

module.exports = dealerMonthly;
