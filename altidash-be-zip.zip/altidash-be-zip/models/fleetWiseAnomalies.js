/* (c) 2022 Autoven Private Limited. All rights reserved. */

const {DataTypes} = require('sequelize');

const sequelize = require('../utils/sqldb')

const FleetAnomalies = sequelize.define('FleetAnomalies', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    allowNull: false,
    autoIncrement: true
  },
  monthYear: {
    type: DataTypes.STRING,
    unique: true,
    allowNull: false
  },
  vins: {
    type: DataTypes.STRING,
    unique: false,
    allowNull: false
  },
  lastUpdated: {
    type: DataTypes.STRING,
    unique: false,
    allowNull: false
  }
 
}, {
  timestamps: true,
  freezeTableName: true
})
 
 
module.exports = FleetAnomalies;