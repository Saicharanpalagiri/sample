/* (c) 2023 Autoven Private Limited. All rights reserved. */

const mongoose = require('mongoose')


const vehicleLockUnlockSchema = new mongoose.Schema({
    VIN: {
        type: String,
        required: true,
        trim: true
    },
    userEmail: {
        type: String,
        trim: true,
    },
    IP: {
        type: String,
        trim: true,
    },
    status: {
        type: String,
        trim: true,
    },
    reason: {
        type: String,
        trim: true,
    },
    requestTimeStamp: {
        type: String
    },
    confirmTimeStamp: {
        type: String
    }
}, {
    timestamps: false,
    collection: 'vehicleLockUnlock'
})

const VehicleLockUnlock = mongoose.model('vehicleLockUnlock', vehicleLockUnlockSchema )


module.exports = VehicleLockUnlock;