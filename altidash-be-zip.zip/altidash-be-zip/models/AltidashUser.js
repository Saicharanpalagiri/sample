const {DataTypes} = require('sequelize');
const sequelize = require('../utils/sqldb')


const AltidashUser= sequelize.define('altidash_users', {
    id:{
        type:DataTypes.INTEGER,
        primaryKey: true,
    },
    role_id:{
        type:DataTypes.STRING,
    },
    email:{
        type:DataTypes.STRING,
        primaryKey: true,
    },
    created_at: {
        type: DataTypes.STRING,
        defaultValue: "0000-00-00"
    },
    status: {
        type: DataTypes.INTEGER,
        defaultValue: 0
    }

},{
    timestamps:false,
    freezeTableName:'altidash_users',
})

module.exports = AltidashUser;