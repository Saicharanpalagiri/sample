/* (c) 2022 Autoven Private Limited. All rights reserved. */

const {DataTypes} = require('sequelize');

const sequelize = require('../utils/sqldb');
const User = require('./user');
const Vehicle = require('./vehicle');


const UserVehicle = sequelize.define('UserVehicle', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    allowNull: false,
    autoIncrement: true 
  },
  uid: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: User,
      key: 'uid'
    }
  },
  vid: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: Vehicle,
      key: 'vid'
    }
  },
  mapped_at: {
    type: DataTypes.DATE,
    defaultValue: sequelize.literal("CURRENT_TIMESTAMP"),
    allowNull: false
  }
}, {
  timestamps: true,
  createdAt: "mapped_at",
  updatedAt: false,
  freezeTableName: true
})


module.exports = UserVehicle;