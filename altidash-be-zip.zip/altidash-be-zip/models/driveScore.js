const mongoose = require('mongoose')

const driveScoreSchema = new mongoose.Schema({
  vin:{
    type:String,
    required:true,
    trim:true,
  },
  Date:{
    type:String,
  },
  regen:{
    type:Number,
  },
  eEfficiency:{
    type:Number,
  },
  drive_score:{
    type:Number,
  },
  percentage_agressive_acceleration:{
    type:Number,
  },
  percentage_agressive_braking:{
    type:Number,
  },
  percentage_agressive_turning:{
    type:Number,
  },
  average_vehicle_speed:{
    type:Number,
  },
  normalised_throttle_position:{
    type:Number,
  },
  brake_pedal_percentage:{
    type:Number,
  },
  distance:{
    type:Number,
  },
  range:{
    type:Number,
  },
  city:{
    type:String,
  },
  city_rank:{
    type:Number,
  },

}, {
    timestamps: false,
    collection: 'drive-score'
  })
  
  const driveScore = mongoose.model('drive-score', driveScoreSchema);
  module.exports = driveScore;