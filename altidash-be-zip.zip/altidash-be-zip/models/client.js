/* (c) 2022 Autoven Private Limited. All rights reserved. */

const {DataTypes} = require('sequelize');

const sequelize = require('../utils/sqldb')


const Client = sequelize.define('Client', {
    cid: {
       type: DataTypes.INTEGER,
       primaryKey: true,
       allowNull: false,
       autoIncrement: true 
    },
    clientCode: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true,
    },
    ClientFullName: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    address:{
        type: DataTypes.STRING,
        allowNull: false,
    },
    city:{
        type: DataTypes.STRING,
        allowNull: false,
    },
    pincode:{
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    state:{
        type: DataTypes.STRING,
        allowNull: false,
    },
    country:{
        type: DataTypes.STRING,
        allowNull: false,
        defaultValue: 'India'
    },
    addressContact:{
        type: DataTypes.STRING,       
    },
    emailContact:{
        type: DataTypes.STRING,       
    },
    telephoneContact:{
        type: DataTypes.INTEGER,               
    },
    enablePushApis: {
        type: DataTypes.TINYINT,
        allowNull: false,
        defaultValue: 0,
    },
    duration:{
        type: DataTypes.INTEGER,               
    },
    apiKey:{
        type: DataTypes.STRING,               
    },
    endPoint:{
        type: DataTypes.STRING,               
    },
    paramOne:{
        type: DataTypes.STRING, 
        allowNull: true,              
    },
    paramTwo:{
        type: DataTypes.STRING, 
        allowNull: true,              
    },
    paramThree:{
        type: DataTypes.STRING, 
        allowNull: true,              
    },
    mongoDbName: {
        type: DataTypes.STRING,
    },
    deleteClientStatus: {
        type: DataTypes.TINYINT,
        allowNull: false,
        defaultValue: 0,
    }
}, {
    timestamps: false,
    freezeTableName: true
})


module.exports = Client;