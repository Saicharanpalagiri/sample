/* (c) 2022 Autoven Private Limited. All rights reserved. */

const {DataTypes} = require('sequelize');

const sequelize = require('../utils/sqldb')
const Product = require('./product');
const Client = require('./client');

const ClientProduct = sequelize.define('ClientProduct', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    allowNull: false,
    autoIncrement: true 
  },
  cid: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: Client,
      key: 'cid'
    }
  },
  pid: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: Product,
      key: 'pid'
    }
  },
}, {
  timestamps: false,
  freezeTableName: true
})


module.exports = ClientProduct;