// const { Int32, Double } = require('mongodb');
// const mongoose = require('mongoose');

// const AplJobCard = new mongoose.Schema({
//   repair_order_no: String,
//   repair_order_date: String,
//   region: String,
//   state: String,
//   city: String,
//   make: String,
//   model: String,
//   vehicle_code: String,
//   model_code: String,
//   registration_no: String,
//   vin: String,
//   motor_no: String,
//   bay_code: String,
//   bay_name: String,
//   customer_code: String,
//   branch_code: String,
//   dealer_code: String,
//   activeCustomerName: String,
//   serviceAdvisor: String,
//   kmm: String,
//   repair_type: String,
//   source: String,
//   campaign: String,
//   "part/service": String, 
//   part_description: String,
//   start_date_time: String,
//   end_date_time: String,
//   requested_qty: String,
//   issued_qty: String,
//   returned_qty: String,
//   cancelled_qty: String,
//   rate: String,
//   trade_discount: String,
//   amount: String,
//   cancellation_date: String,
//   status: String,
//   mechanic: String,
//   part_labour_group: String,
//   "CGST%": { type: Number, default: null },
//   "IGST%": { type: Number, default: null },
//   CGST: Number,
//   IGST: Number,
//   "SGST%": { type: Number, default: null },
//   SGST: Number,
//   total_amount: String
// },
// {
//     collection:'apl_job_cards'
//   });

// const AplJobCards = mongoose.model('AplJobCard', AplJobCard);

// module.exports = AplJobCards;


const { Int32, Double } = require('mongodb');
const mongoose = require('mongoose');

const AplJobCard = new mongoose.Schema({
  repair_order_no: String,
  repair_order_date: String,
  region: String,
  state: String,
  city: String,
  make: String,
  model: String,
  vehicle_code: String,
  model_code: String,
  registration_no: String,
  vin: String,
  motor_no: String,
  bay_code: String,
  bay_name: String,
  customer_code: String,
  branch_code: Number,
  dealer_code: Number,
  activeCustomerName: String,
  serviceAdvisor: String,
  kmm: Number,
  repair_type: { type: String, default: null },
  source: { type: String, default: null },
  campaign: String,
  "part/service": String, 
  part_description: String,
  "part/labour_group":String,
  start_date_time: String,
  end_date_time: String,
  requested_qty: Number,
  issued_qty: Number,
  returned_qty: Number,
  cancelled_qty: Number,
  rate: Number,
  trade_discount: Number,
  amount: Number,
  cancellation_date: String,
  status: String,
  mechanic: String,
  part_labour_group: String,
  "CGST%": { type: Number, default: null },
  "IGST%": { type: Number, default: null },
  CGST: Number,
  IGST: Number,
  "SGST%": { type: Number, default: null },
  SGST: Number,
  total_amount: Number
},
{
    collection:'apl_job_cards'
  });

const AplJobCards = mongoose.model('AplJobCard', AplJobCard);

module.exports = AplJobCards;
