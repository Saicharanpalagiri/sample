const {DataTypes} = require('sequelize');

const sequelize = require('../utils/sqldb')


const pincode = sequelize.define('pincodeMapper', {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      allowNull: false,
      autoIncrement: true
    },
    name: {
      type: DataTypes.STRING,
    },
    type: {
        type: DataTypes.STRING,
        defaultValue:'vehicle'
    },
    lat: {
        type: DataTypes.DECIMAL,
    },
    lng: {
        type: DataTypes.DECIMAL,
    },
    pincode:{
        type: DataTypes.INTEGER,
    },
    imgUrl:{
        type: DataTypes.STRING,
    },
    status:{
        type:DataTypes.INTEGER,
        defaultValue:1
    }
},
{
    freezeTableName: true
})

 
module.exports = pincode;
