/* (c) 2023 Autoven Private Limited. All rights reserved. */

const {DataTypes} = require('sequelize');

const sequelize = require('../utils/sqldb')


const AuditLogs = sequelize.define('AuditLogs', {
    uid: {
       type: DataTypes.INTEGER,
       allowNull: false,
    },
    userRole: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    IP: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    product: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    page:{
        type: DataTypes.STRING,
        allowNull: false,
    },
    action:{
        type: DataTypes.STRING,
        allowNull: false,
    },
    api:{
        type: DataTypes.STRING,
        allowNull: false,
    },
    currData:{
        type: DataTypes.JSON,
    },
    newData:{
        type: DataTypes.JSON,
    },
    responseCode:{
        type: DataTypes.INTEGER,               
    },
    response: {
        type: DataTypes.JSON,
    },
    remarks:{
        type: DataTypes.STRING,       
    },
}, {
    timestamps: true,
    createdAt: true,
    updatedAt: false,
    freezeTableName: true
})


module.exports = AuditLogs;