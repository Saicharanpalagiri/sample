const express = require('express');
const apljobcardController = require('../controllers/job_card/apljobcard.controller');
// const requestValidation = require('../../validations/request.validation');

const router = express.Router();


router.post('/show-test',apljobcardController.TestService);
router.post('/show-vins',apljobcardController.vinList);

// router.post('/month-wise',jobcardController.MonthWiseJobCards);

// router.post('/vin-info',jobcardController.TestService);

router.post('/monthWiseCards',apljobcardController.MonthWiseCards);
router.get('/fleets',apljobcardController.fleetSelector);
router.post('/vinjobcards',apljobcardController.vinJobCards);

router.post('/newjobcards',apljobcardController.newjobcards);
router.post('/vinselect',apljobcardController.vinselect)
// router.post('/odo-wise-Aggregate',jobcardController.OdoWiseAggregate)

module.exports = router;