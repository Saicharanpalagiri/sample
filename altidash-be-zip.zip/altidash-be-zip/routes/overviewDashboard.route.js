const express = require("express");
const overviewContrtoller = require("../controllers/dashboard/overview.controller");

const router = express.Router();

// router.post('/show-data',batteryHealthCardContrtoller.TestService);
router.post("/show-max-avg-speed/:date", overviewContrtoller.maxAvg);
router.post("/rnfb-data", overviewContrtoller.rnfbData);

router.post("/show-config-apis/:date", overviewContrtoller.configApis);

router.post("/show-vin-day", overviewContrtoller.showVins);

router.post("/show-vin-day-tmp", overviewContrtoller.vinOnSearchTemp);

router.post("/show-fleets", overviewContrtoller.fleetList);

router.post("/show-location-dates", overviewContrtoller.getDates);

router.post("/show-efficiency-chart", overviewContrtoller.efficiencyQuery);

router.post("/getbmsfault", overviewContrtoller.getBmsFault);

router.post(
  "/show-efficiency-chart-avg",
  overviewContrtoller.efficiencyQueryavg
);

module.exports = router;
