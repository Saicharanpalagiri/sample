const express = require('express');
// const apljobcardController = require('../controllers/pincode/pincodeController');
// const requestValidation = require('../../validations/request.validation');
const vehicleOneTimeInfoController = require('../controllers/vehicle_controller/vehicleOneTimeInfo.controller');

const router = express.Router();

router.post('/getOtiInfo',vehicleOneTimeInfoController.getOtiInfo)
module.exports=router;