const express = require('express');
const packetsController = require('../controllers/packet-count/packetCounter.controller');
// const requestValidation = require('../../validations/request.validation');

const router = express.Router();


router.post('/packets-count',packetsController.packetsCount);
router.post('/lastPackets',packetsController.lastPackets);





module.exports = router;