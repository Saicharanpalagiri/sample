const express = require("express");
const driverAppController = require("../controllers/driver-app-users/driverAppController");
// const requestValidation = require('../../validations/request.validation');

const router = express.Router();

router.post("/getDriverAppUsers", driverAppController.getDriverAppUserDetails);

module.exports = router;
