const express = require('express');

const  dealerOverViewController= require('../controllers/dealer_info/dealerOverview.controller');

const router = express.Router();

router.post('/show-dealer-overview',dealerOverViewController.overViewService);
router.post('/show-dealers-cummulative' ,dealerOverViewController.dealersCummulative);
router.post('/show-dealers' ,dealerOverViewController.availableDealers);
router.post('/show-dealers-graph' ,dealerOverViewController.overviewGraph);
router.post('/show-dealers-zone' ,dealerOverViewController.zoneWiseController);
router.post('/show-dealer-monthly/:date' ,dealerOverViewController.monthlyController);
router.post('/show-dealers-monthly/:date' ,dealerOverViewController.dealerMonthlyController);
router.post('/show-dealer-dates' ,dealerOverViewController.datesController);
router.post('/show-vehicles-location-api', dealerOverViewController.dealerLocationController);
router.post('/show-dealer-details', dealerOverViewController.dealerDetailsController)
router.post('/show-dealer-segmentation-fleets-vehicles', dealerOverViewController.dealerFleetsVehicles);
router.post('/show-dealer-segmentation-fleets', dealerOverViewController.dealerFleets);
router.post('/show-dealer-segmentation-month-vehicles', dealerOverViewController.dealerMonthVehicles);




module.exports = router;