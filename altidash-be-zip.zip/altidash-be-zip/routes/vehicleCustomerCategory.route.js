const express = require("express");
const vehicleCustomerCategoryController = require("../controllers/customer_category/vehicleCustomerCategory.controller");
// const requestValidation = require('../../validations/request.validation');

const router = express.Router();

// router.post('/show-vins',jobcardController.vinList);

router.post("/getCustomerCategoryData", vehicleCustomerCategoryController.getCustomerCategoryData);

router.post("/get-distance-histogram", vehicleCustomerCategoryController.getCustomerCategoryAnalysis);

module.exports = router;
