const express = require('express');

const MonthlyDashboardController= require('../controllers/dashboard/MonthlyDashboard.controller');
const  dailyDashboardController= require('../controllers/dashboard/dailyDashboard.controller');
const landingPageDashboard = require('../controllers/dashboard/landingDashboard')
const alertController=require('../controllers/dashboard/alerts.controller')


const router = express.Router();


router.post('/show-dashboard-api/:date', dailyDashboardController.dashboardApi);


router.post('/show-gross-custom-month/comparable/:date1/:date2',MonthlyDashboardController.grossMonthComparable);

router.post('/show-custom-week-dashboard-api/:date1/:date2', MonthlyDashboardController.customWeekWiseController);

router.post('/show-gross-custom-month/uncomparable/:date1/:date2',MonthlyDashboardController.grossMonthControllerUnComparable)

router.post('/show-gross-custom-week-dashboard-api/:date1/:date2', MonthlyDashboardController.grossCustomWeekWiseController);

router.post('/show-battery-all', dailyDashboardController.batteryApi)

router.post('/show-landing-dashboard', landingPageDashboard.getAllVehiclesDetails)

router.post('/getDistance', landingPageDashboard.getDistance)



router.post('/show-rto-locations', landingPageDashboard.rtoLocations)

router.post('/createUser', dailyDashboardController.createUser)

router.post('/show-roles',dailyDashboardController.rolesapi)

router.post('/show-customer-daywise',dailyDashboardController.CustomerDayWiseDistance)

router.post('/show-alerts',alertController.alertController)

router.post('/show-alerts-vin',alertController.alertControllerByVin)


router.post('/show-alerts-vin-card',alertController.alertControllerByVinCard)

router.post('/show-anamoly-vin',alertController.anamoliesByVin)

router.post('/show-faultcodes',alertController.getFaultCodesData)

module.exports = router;