const express = require('express');
const apljobcardController = require('../controllers/pincode/pincodeController');
// const requestValidation = require('../../validations/request.validation');

const router = express.Router();


// router.post('/show-test',apljobcardController.TestService);

// router.post('/show-all',apljobcardController.TestService);

module.exports=router;
