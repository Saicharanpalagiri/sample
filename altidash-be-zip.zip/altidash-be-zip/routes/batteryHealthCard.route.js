const express = require('express');
const  batteryHealthCardContrtoller= require('../controllers/batteryHealthCardContrtoller');

const router = express.Router();


router.post('/show-data',batteryHealthCardContrtoller.TestService);

module.exports =router;