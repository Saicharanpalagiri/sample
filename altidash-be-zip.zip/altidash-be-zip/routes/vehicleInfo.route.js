const express = require('express');
const vehicleInfoController = require('../controllers/vehicle_info/vehicleInfo.controller');
const vehicleSegmentationController = require('../controllers/vehicle_info/vehicleSegmentaion.controller');
const vehicleMasterDataController = require('../controllers/vehicle_info/vehicleMasterData.controller')
// const requestValidation = require('../../validations/request.validation');

const router = express.Router();

// router.post('/show-vins',jobcardController.vinList);


router.post('/all-vehicles', vehicleInfoController.getAllVehicles)

router.post('/show-last-30days-each-vin-info', vehicleInfoController.vehicleUsage)

router.post('/show-last-selected-daterange-vehicles', vehicleInfoController.vehicleDateRangeUsage)

router.post('/getCustomVehiclechart', vehicleInfoController.vehicleChartData)

router.post('/show-anamoly-data', vehicleInfoController.anamolyData)

router.post('/show-fleet-segmentation', vehicleInfoController.fleetSegmentation)

router.post('/show-fleet-segmentation-month-wise', vehicleInfoController.fleetSegmentationMonthWise)

router.post('/show-fleet-segmentation-config', vehicleInfoController.fleetSegmentationConfiguration)

router.post('/show-fleet-segmentation-drive-score', vehicleInfoController.fleetSegmentationDriveScore)

router.post('/show-vehicle-master-data', vehicleInfoController.lastLocationData)

router.post('/show-battery-health-data', vehicleInfoController.monthlyBatteryHealthCard)

router.post('/show-service-vehicles', vehicleInfoController.vehicleServiceData)

router.post("/show-vehicle-segmentation", vehicleSegmentationController.vehicleSegmentation);

router.post("/saleDateVehicles", vehicleSegmentationController.soldDateSegmentation);
  
router.post("/odoRangeVehicles", vehicleSegmentationController.odoRangeSegmentation);

router.post('/show-vehicle-not-pinged-today', vehicleInfoController.notPingedVehicles);

router.post('/show-vehicle-not-pinged-fleet', vehicleInfoController.notPingedVehiclesFleet)

router.post('/show-vehicle-vin-info', vehicleInfoController.vehicleMoreInfo)

router.post('/show-location-date-show-all', vehicleInfoController.vehicleLocator)

router.post('/getCustomLocationDetails', vehicleInfoController.customLocationDetails)

router.post('/dummy', vehicleInfoController.dummy)

router.post('/vehicleserial', vehicleInfoController.vehicleSerial)

router.post('/vehicleSerialSegment', vehicleInfoController.vehicleSerialSegmentation)

router.post('/getVinSerialSelectValues', vehicleInfoController.getVinSerialSelectValues)

router.post('/fleetwiseBarrteryHealthCard', vehicleInfoController.fleetWiseBatteryHealthCard)

router.post('/fleetwiseBarrteryHealthCardCustom', vehicleInfoController.fleetWiseBatteryHealthCardCustomUpdatedNewOne)

router.post('/barrteryHealthCardBatteryGraph', vehicleInfoController.MonthWiseBatteryHealthCardBatteryGraph)

router.post('/barrteryHealthCardVinGraph', vehicleInfoController.MonthWiseBatteryHealthCardVinGraph)

router.post('/vinWiseBHC', vehicleInfoController.vinWiseBHC)



router.get('/getvehiclemasterdata',vehicleMasterDataController.vehicleTable)

router.get('/getlockedvehicles',vehicleInfoController.lockedVehicles)

router.get('/applicationsegment',vehicleInfoController.applicationSeg)

router.post('/batteryvindata',vehicleInfoController.batteryvindata)

router.post('/getVehicleTypes',vehicleInfoController.getVehicleTypes)

router.post('/getavgdrivescore',vehicleInfoController.avgDriveScoreData)

router.post('/show-fleet-segmentation-service-logs', vehicleInfoController.fleetSegmentationServiceLogs)

router.post('/fleetWisePdfData', vehicleInfoController.fleetWisePdfData)

router.post('/getvehicle-detailService',vehicleInfoController.vehicleDetailService)


router.get('/getFleetAnomalies',vehicleInfoController.getFleetAnomalies)

router.post('/addFleetAnomalies',vehicleInfoController.addFleetAnomalies)

router.post('/getVehicleFaultCodes',vehicleInfoController.getVehicleFaultCodes)


router.post('/getvehicleproductionInfo',vehicleInfoController.getvehicleproductionInfo)

router.post('/getvehicleproductionInfo-overview',vehicleInfoController.getvehicleproductionInfoOverview)

router.post('/getFleetWiseDriveLogs',vehicleInfoController.getFleetWiseDriveLogs)



module.exports =router;