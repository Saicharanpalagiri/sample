const express = require("express");
const configurationController = require("../controllers/configuration/configurationController");

const router = express.Router();

// router.post('/show-vins',jobcardController.vinList);

router.post("/show-configuration-api", configurationController.getConfigurationData);

module.exports = router;
