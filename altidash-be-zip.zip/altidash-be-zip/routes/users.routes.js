const express = require("express");
const usersController = require("../controllers/users/users.controller");
// const requestValidation = require('../../validations/request.validation');

const router = express.Router();

router.get("/getUsers", usersController.getAllUsers);
router.post("/addUser", usersController.addUser);
router.post("/editUser", usersController.editUser);
router.post("/deleteUser", usersController.deleteUser);

module.exports = router;
