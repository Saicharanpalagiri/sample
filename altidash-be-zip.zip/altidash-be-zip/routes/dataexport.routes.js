const express = require("express");
const dataexportController = require("../controllers/data-export/dataexport.controller");

const router = express.Router();

// router.post('/show-vins',jobcardController.vinList);

router.post("/show-vins-list", dataexportController.showVins);

router.post("/show-vehicle-vin-info/:vin", dataexportController.showVehicleVinInfo);

router.post('/vehicleFaultCodesDump',dataexportController.vehicleFaultCodesDump)

module.exports = router;
