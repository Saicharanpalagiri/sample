const express = require("express");
const auditLogsController = require("../controllers/auditLogs/auditLogs-controller");
// const requestValidation = require('../../validations/request.validation');

const router = express.Router();

router.post("/addLogs", auditLogsController.addLogs);
router.get("/getLogs", auditLogsController.getLogs);

module.exports = router;
