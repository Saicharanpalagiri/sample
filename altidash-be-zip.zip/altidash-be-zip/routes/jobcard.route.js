const express = require('express');
const jobcardController = require('../controllers/job_card/jobcard.controller');
// const requestValidation = require('../../validations/request.validation');

const router = express.Router();


router.post('/show-vins',jobcardController.vinList);


router.post('/month-wise',jobcardController.MonthWiseJobCards);

router.post('/vin-info',jobcardController.TestService);

router.post('/month-wise-Aggregate',jobcardController.MonthWiseUsingAggregate);


router.post('/odo-wise-Aggregate',jobcardController.OdoWiseAggregate)

module.exports = router;