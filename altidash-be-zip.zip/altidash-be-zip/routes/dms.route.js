const express = require('express');

const  dmsController= require('../controllers/monthly_dms/dmsController');

const aleadsPdfController=require('../controllers/aleadsPdfController/AleadsPdf')

const router = express.Router();

router.get('/cxo-defects',dmsController.getDmsDefectData)

router.get('/cxo-tickets',dmsController.getMonthlyDMSTickets)

router.get('/cxo-repair-sla',dmsController.getMonthlyVehicleRepairSLACompliance)

router.post('/cxo-defects-by-date',dmsController.getDmsDefectDataByMonthAndYear)

router.post('/cxo-tickets-by-date',dmsController.getMonthlyDMSTicketsByMonthAndYear)

router.post('/cxo-repair-sla-by-date',dmsController.getMonthlyVehicleRepairSLAComplianceByMonthAndYear)

router.post('/add-defects',dmsController.addMonthlyWarrantyDefects)

router.post('/add-tickets',dmsController.addMonthlyDMSTickets)

router.post('/add-repair-sla',dmsController.addMonthlyVehicleRepairSLACompliance)

router.post('/aleads-pdf',aleadsPdfController.pdfController)

module.exports = router;