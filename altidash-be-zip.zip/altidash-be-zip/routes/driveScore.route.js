const express = require('express');
const driveScoreController = require('../controllers/drive_score/driveScore.controller');
// const requestValidation = require('../../validations/request.validation');

const router = express.Router();

// router.post('/show-vins',jobcardController.vinList);


router.post('/drive-aggregate',driveScoreController.driveScoreAll)

router.post('/drivedate', driveScoreController.driveScoreOnDate)


router.post('/driveScoreVins', driveScoreController.driveScoreVins);



module.exports =router;