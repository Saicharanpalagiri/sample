const express = require('express');
const vehicleImportController=require('../controllers/vehicle_controller/vehicleImportController');
const vehicleProducedStatusController=require('../controllers/vehicle_info/vehicleProducedStatus.controller')
const router = express.Router();
const multer=require('multer')
const upload = multer({ dest: __dirname + '/uploads' });
router.post('/add-vehicle', vehicleImportController.addVehicle)
router.post('/vehicle-sale-import',upload.single('file'),vehicleImportController.addVehicleSaleStatement)
router.post('/jobcard-import',upload.single('file'),vehicleImportController.addJobCards)
router.post('/vehicle-prod-status-import',upload.single('file'),vehicleProducedStatusController.InsertVehicleProducedStatus)
router.post('/vehicle-serial-import',upload.single('file'),vehicleImportController.VehicleSerialNoUpload)


module.exports=router;